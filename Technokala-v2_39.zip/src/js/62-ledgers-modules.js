/* ================================================================
   ==================== چک‌ها (کامل) ================================
   ================================================================ */
const Fc={q:'',st:'',from:'',to:''};
const Fcr={q:'',bank:'',person:'',from:'',to:'',st:''};
const Fcp={from:'',to:'',st:''};
const Fcs={q:'',st:'',from:'',to:''};
const CHQ_STATUSES=['جاری','وصول شده','پاس شده','برگشتی','واگذار شده','باطل شده'];
function chqCls(s){return{'جاری':'b-b','وصول شده':'b-g','پاس شده':'b-g','برگشتی':'b-r','واگذار شده':'b-o','باطل شده':'b-m'}[s]||'b-m'}
function resetFc(){Fc.q='';Fc.st='';Fc.from='';Fc.to=''}
function resetFcr(){Fcr.q='';Fcr.bank='';Fcr.person='';Fcr.from='';Fcr.to='';Fcr.st=''}
function resetFcp(){Fcp.from='';Fcp.to='';Fcp.st=''}
function resetFcs(){Fcs.q='';Fcs.st='';Fcs.from='';Fcs.to=''}
function chqDueCell(c){
 if(c.status!=='جاری')return '<span style="color:#7a8a99">—</span>';
 const dd=daysDiff(jToday(),c.due);
 if(dd<0)return '<span class="bdg b-r">'+fa(-dd)+' روز گذشته</span>';
 if(dd===0)return '<span class="bdg b-o">امروز</span>';
 return '<span class="bdg '+(dd<=10?'b-o':'b-b')+'">'+fa(dd)+' روز مانده</span>';
}
function chqTabs(active){
 return `<div class="tabs">
  <button class="tab ${active==='inst'?'on':''}" onclick="vInst('list')">📅 لیست اقساط</button>
  <button class="tab ${active==='all'?'on':''}" onclick="resetFc();vCheques('all')">📋 همه چک‌ها</button>
  <button class="tab ${active==='rec'?'on':''}" onclick="resetFc();vCheques('rec')">📥 چک دریافتی</button>
  <button class="tab ${active==='paid'?'on':''}" onclick="resetFc();vCheques('paid')">📤 چک پرداختی</button>
  <button class="tab ${active==='reprec'?'on':''}" onclick="resetFcr();vCheques('reprec')">📊 گزارش چک دریافتی</button>
  <button class="tab ${active==='reppaid'?'on':''}" onclick="resetFcp();vCheques('reppaid')">📊 گزارش چک پرداختی</button>
  <button class="tab ${active==='due'?'on':''}" onclick="vCheques('due')">📅 گزارش سررسید</button>
  <button class="tab ${active==='status'?'on':''}" onclick="vCheques('status')">📋 صورت وضعیت چک‌ها</button>
 </div>`;
}
function vFinanceHub(){
 const today=jToday();
 const cheques=DB.cheques.slice().sort((a,b)=>a.due<b.due?-1:1);
 const installments=DB.installments.slice().sort((a,b)=>a.due<b.due?-1:1);
 const openInst=installments.filter(i=>!i.paid);
 const chequeTotal=cheques.reduce((s,c)=>s+c.amount,0);
 const installmentTotal=openInst.reduce((s,i)=>s+i.amount,0);
 const combined=[...cheques.map(c=>({kind:'cheque',date:c.due,data:c})),...installments.map(i=>({kind:'installment',date:i.due,data:i}))].sort((a,b)=>a.date<b.date?-1:1);
 const _pg_hub=pgSlice('hub',combined,'hub',vFinanceHub);
 $('content').innerHTML=`
 <div class="pgtitle"><h1>🏦 چک‌ها و اقساط</h1><span class="sub">مدیریت هم‌زمان تعهدات و دریافتی‌ها</span></div>
 <div class="statgrid">
  <div class="stat o"><div class="l">🏦 تعداد چک‌ها</div><div class="v">${fa(cheques.length)} فقره</div></div>
  <div class="stat r"><div class="l">💰 مبلغ کل چک‌ها</div><div class="v">${fm(chequeTotal)}</div></div>
  <div class="stat o"><div class="l">📅 اقساط باز</div><div class="v">${fa(openInst.length)} قسط</div></div>
  <div class="stat r"><div class="l">📌 بدهی اقساط</div><div class="v">${fm(installmentTotal)}</div></div>
 </div>
 <div class="toolbar" style="margin-bottom:12px">
  <button class="btn p" onclick="chequeForm()">＋ ثبت چک</button>
  <button class="btn p" onclick="vInst('reg')">＋ ثبت قسط</button>
  <button class="btn g" onclick="vCheques('all')">📋 مدیریت کامل چک‌ها</button>
  <button class="btn g" onclick="vInst('list')">📋 مدیریت کامل اقساط</button>
 </div>
 <div class="card"><h3>🏦📅 لیست چک‌ها و اقساط (${fa(combined.length)})</h3>
 ${pgBar('hub','top')}<table data-rn="hub"><thead><tr><th>نوع</th><th>شناسه</th><th>شخص</th><th>بانک / فاکتور</th><th>سررسید</th><th>مبلغ</th><th>وضعیت</th><th>عملیات</th></tr></thead><tbody>
 ${_pg_hub.map(x=>x.kind==='cheque'?(()=>{const c=x.data;return `<tr><td><span class="bdg ${c.dir==='rec'?'b-g':'b-o'}">چک ${c.dir==='rec'?'دریافتی':'پرداختی'}</span></td><td dir="ltr">${esc(c.serial||c.no||'—')}</td><td class="r">${esc(PN(c.person))}</td><td>${esc(c.bank||'—')}</td><td class="${c.status==='جاری'&&jNorm(c.due)<today?'neg':''}">${jShort(c.due)}</td><td class="amt">${fm(c.amount)}</td><td><span class="bdg ${chqCls(c.status)}">${c.status}</span></td><td><select onchange="chequeSt('${c.id}',this.value)">${CHQ_STATUSES.map(s=>`<option ${c.status===s?'selected':''}>${s}</option>`).join('')}</select> <button class="btn sm" onclick="chequeForm('${c.id}')">✏️</button></td></tr>`})():(()=>{const i=x.data;return `<tr><td><span class="bdg b-b">قسط</span></td><td>${fa(i.no)} / ${fa(i.inv||'—')}</td><td class="r">${esc(PN(i.person))}</td><td>فاکتور فروش</td><td class="${!i.paid&&jNorm(i.due)<today?'neg':''}">${jShort(i.due)}</td><td class="amt">${fm(i.amount)}</td><td><span class="bdg ${i.paid?'b-g':'b-o'}">${i.paid?'پرداخت‌شده':'باز'}</span></td><td>${!i.paid?`<button class="btn sm g" onclick="instPay('${i.id}')">💵 پرداخت</button>`:'—'}</td></tr>`})()).join('')||'<tr><td colspan="8"><div class="empty">چک یا قسطی یافت نشد</div></td></tr>'}
 </tbody></table>${pgBar('hub')}</div>`;
}
function vCheques(tab){
 tab=tab||window._chqTab||'all';window._chqTab=tab;
 if(tab==='due')return vChequeDueRep();
 if(tab==='status')return vChequeStatusRep();
 if(tab==='reprec')return vChequeRepX('rec');
 if(tab==='reppaid')return vChequeRepX('paid');
 const isRec=tab==='rec',isPaid=tab==='paid';
 let list=DB.cheques.slice().sort((a,b)=>a.due<b.due?-1:1);
 if(isRec||isPaid)list=list.filter(c=>c.dir===tab);
 if(Fc.q){const q=faDig(Fc.q);list=list.filter(c=>faDig([c.no,PN(c.person),c.bank,c.status,String(c.amount),c.issue,c.due,c.desc||''].join(' ')).includes(q))}
 if(Fc.st)list=list.filter(c=>c.status===Fc.st);
 if(Fc.from&&jNorm(Fc.from))list=list.filter(c=>jNorm(c.due)>=jNorm(Fc.from));
 if(Fc.to&&jNorm(Fc.to))list=list.filter(c=>jNorm(c.due)<=jNorm(Fc.to));
 window._chqList=list;
 window._chqXLf=()=>list.map(c=>({'نوع':c.dir==='rec'?'دریافتی':'پرداختی','شماره چک':c.no,'شخص':PN(c.person),'بانک':c.bank,'تاریخ ثبت':c.issue,'سررسید':c.due,'مبلغ':c.amount,'وضعیت':c.status}));
 const t=jToday();
 const sum=f=>list.filter(f).reduce((s,c)=>s+c.amount,0);
 const net=sum(c=>c.dir==='rec'&&c.status==='جاری')-sum(c=>c.dir==='paid'&&c.status==='جاری');
 const overSum=list.filter(c=>c.status==='جاری'&&jNorm(c.due)<t).reduce((s,c)=>s+c.amount,0);
 const nearSum=list.filter(c=>c.status==='جاری'&&jNorm(c.due)>=t&&daysDiff(t,c.due)<=10).reduce((s,c)=>s+c.amount,0);
 const retSum=list.filter(c=>c.status==='برگشتی').reduce((s,c)=>s+c.amount,0);
 const title=isRec?'چک دریافتی':isPaid?'چک پرداختی':'همه چک‌ها';
 const _pg_cheques=pgSlice('cheques',list,tab+JSON.stringify(Fc),()=>vCheques(tab));
 $('content').innerHTML=`
 <div class="pgtitle"><h1>🏦 مدیریت چک‌ها — ${title}</h1><span class="sub">${fa(list.length)} فقره در نمایش فعلی از ${fa(DB.cheques.length)} فقره کل</span></div>
 <div class="statgrid">
  ${isRec||!isPaid?`<div class="stat g"><div class="l">جمع دریافتی (جاری)</div><div class="v">${fm(sum(c=>c.dir==='rec'&&c.status==='جاری'))}</div></div>`:''}
  ${isPaid||!isRec?`<div class="stat r"><div class="l">جمع پرداختی (جاری)</div><div class="v">${fm(sum(c=>c.dir==='paid'&&c.status==='جاری'))}</div></div>`:''}
  ${(!isRec&&!isPaid)?`<div class="stat ${net>=0?'g':'r'}"><div class="l">⚖️ خالص چک‌های جاری</div><div class="v ${net>=0?'pos':'neg'}">${fm(net)}</div></div>`:''}
  <div class="stat o"><div class="l">⛔ سررسید گذشته (جاری)</div><div class="v">${fm(overSum)}</div></div>
  <div class="stat"><div class="l">⏰ نزدیک سررسید (۱۰ روز)</div><div class="v">${fm(nearSum)}</div></div>
  <div class="stat r"><div class="l">↩️ برگشتی</div><div class="v neg">${fm(retSum)}</div></div>
 </div>
 ${chqTabs(tab)}
 <div class="card">
 <div class="searchbar">
  <input id="qIn" placeholder="🔍 شماره چک، شخص، بانک، مبلغ، وضعیت..." value="${esc(Fc.q)}" style="min-width:260px" oninput="Fc.q=this.value;vCheques('${tab}');rf('qIn')">
  <select onchange="Fc.st=this.value;vCheques('${tab}')"><option value="">همه وضعیت‌ها</option>${CHQ_STATUSES.map(s=>`<option ${Fc.st===s?'selected':''}>${s}</option>`).join('')}</select>
  <input placeholder="از سررسید ۱۴۰۳/۰۱/۰۱" style="width:150px" value="${esc(Fc.from)}" onchange="Fc.from=jNorm(this.value);vCheques('${tab}')">
  <input placeholder="تا سررسید" style="width:130px" value="${esc(Fc.to)}" onchange="Fc.to=jNorm(this.value);vCheques('${tab}')">
  <button class="btn" onclick="resetFc();vCheques('${tab}')">پاک کردن فیلترها</button>
 </div>
 <div class="toolbar">
  <button class="btn p" onclick="chequeForm()">＋ ثبت چک جدید</button>
  <button class="btn o" onclick="chqGroupSMS()" title="پیامک یادآوری چک‌های نزدیک سررسید به اشخاص">✉️ یادآوری گروهی نزدیک سررسید</button>
  <button class="btn" onclick="xlClaimsTemplate()">📥 قالب اکسل مطالبات</button>
  <label class="btn" style="cursor:pointer">📤 ورود چک از اکسل<input type="file" accept=".xlsx,.xls" style="display:none" onchange="xlIn(this,'cheques')"></label>
  <button class="btn g" onclick="xlOut(window._chqXLf(),'چک‌ها-تکنوکالا')">📊 اکسل (نتیجه فیلتر)</button>
  <button class="btn" onclick="printChequeFiltered()">🖨️ چاپ گزارش</button>
 </div>
 ${pgBar('cheques','top')}<table data-rn="cheques"><thead><tr><th>نوع</th><th>سریال چک</th><th>شخص</th><th>بانک</th><th>تاریخ ثبت</th><th>سررسید</th><th>فاصله سررسید</th><th>مبلغ (تومان)</th><th>وضعیت چک</th><th>عملیات</th></tr></thead><tbody>
 ${_pg_cheques.map(c=>`<tr>
  <td><span class="bdg ${c.dir==='rec'?'b-g':'b-o'}">${c.dir==='rec'?'دریافتی':'پرداختی'}</span></td>
  <td dir="ltr">${esc(c.serial||c.no||'—')}</td><td class="r">${esc(PN(c.person))}</td><td>${esc(c.bank||'—')}</td>
  <td>${jShort(c.issue)}</td><td class="${c.status==='جاری'&&jNorm(c.due)<t?'neg':''}">${jShort(c.due)}</td>
  <td>${chqDueCell(c)}</td>
  <td class="amt">${fm(c.amount)}</td>
  <td><span class="bdg ${chqCls(c.status)}">${c.status}</span></td>
  <td style="white-space:nowrap">
   <select style="font-size:11px;padding:4px" onchange="chequeSt('${c.id}',this.value)" title="تغییر وضعیت چک">
    ${CHQ_STATUSES.map(s=>`<option ${c.status===s?'selected':''}>${s}</option>`).join('')}
   </select>
   <button class="btn sm o" onclick="chequeSMS('${c.id}')" title="پیامک یادآوری چک">✉️</button>
   <button class="btn sm" onclick="chequeForm('${c.id}')">✏️</button>
   <button class="btn sm r" onclick="chequeDel('${c.id}')">🗑️</button>
  </td></tr>`).join('')||'<tr><td colspan="10"><div class="empty"><div class="b">🏦</div>چکی یافت نشد</div></td></tr>'}
 </tbody>
 <tfoot><tr style="background:#f4f8fb;font-weight:800"><td colspan="7">جمع ${fa(list.length)} فقره نمایش‌داده‌شده</td><td class="amt">${fm(list.reduce((s,c)=>s+c.amount,0))}</td><td colspan="2"></td></tr></tfoot>
 </table>${pgBar('cheques')}</div>`;
}
/* ✉️ پیامک یادآوری یک چک */
function chequeSMS(id){
 const c=DB.cheques.find(x=>x.id===id);if(!c)return;const p=P(c.person);
 if(!p||!p.phone){toast('⚠️ موبایل شخص ثبت نشده',false);return}
 const msg=smsFill(smsTpl('Chq'),{name:p.name,no:c.no,amount:c.amount,due:c.due});
 askM('✉️ پیامک یادآوری چک','پیامک به '+esc(p.name)+' ('+esc(p.phone)+'):',msg,txt=>{sendSMS(p.phone,txt);smsToGuarantor(p,txt)})
}
/* ✉️ یادآوری گروهی چک‌های نزدیک سررسید */
function chqGroupSMS(){
 const t=jToday();
 const list=DB.cheques.filter(c=>c.status==='جاری'&&daysDiff(t,c.due)<=10&&daysDiff(t,c.due)>=-30);
 if(!list.length){toast('⚠️ چک نزدیک سررسیدی در بازه ۱۰ روز نیست',false);return}
 const byP={};
 list.forEach(c=>{const p=P(c.person);if(p&&p.phone){if(!byP[p.id])byP[p.id]=[];byP[p.id].push(c)}});
 const ids=Object.keys(byP);
 if(!ids.length){toast('⚠️ هیچ‌یک شماره موبایل ثبت‌شده ندارند',false);return}
 confirmM('ارسال یادآوری چک به <b>'+fa(ids.length)+'</b> شخص ('+fa(list.length)+' فقره چک)؟',()=>{
  ids.forEach(pid=>{
   const chs=byP[pid];const p=P(pid);
   const sum=chs.reduce((s,c)=>s+c.amount,0);
   const msg=smsFill(smsTpl('Chq'),{name:p.name,no:chs[0].no,amount:sum,due:chs[0].due,count:chs.length})+(chs.length>1?'\n(و '+fa(chs.length-1)+' چک دیگر)':'');
   sendSMS(p.phone,msg);smsToGuarantor(p,msg);
  });
  toast('📨 ارسال یادآوری به '+fa(ids.length)+' نفر ثبت شد');
 });
}
/* 📅 گزارش سررسید — ۶ بازه زمانی */
function vChequeDueRep(){
 const t=jToday();
 const buckets=[
  {title:'⛔ سررسید گذشته',f:c=>jNorm(c.due)<t},
  {title:'⏰ امروز',f:c=>jNorm(c.due)===t},
  {title:'۱۰ روز آینده',f:c=>{const d=daysDiff(t,c.due);return d>0&&d<=10}},
  {title:'۱۱ تا ۳۰ روز آینده',f:c=>{const d=daysDiff(t,c.due);return d>10&&d<=30}},
  {title:'۳۱ تا ۹۰ روز آینده',f:c=>{const d=daysDiff(t,c.due);return d>30&&d<=90}},
  {title:'بیش از ۹۰ روز',f:c=>daysDiff(t,c.due)>90}
 ];
 const jari=DB.cheques.filter(c=>c.status==='جاری');
 window._dueXL=[];
 let rows='';
 buckets.forEach(b=>{
  const blist=jari.filter(b.f);
  const rc=blist.filter(c=>c.dir==='rec'),pc=blist.filter(c=>c.dir==='paid');
  const rs=rc.reduce((s,c)=>s+c.amount,0),ps=pc.reduce((s,c)=>s+c.amount,0);
  window._dueXL.push({'بازه':b.title,'تعداد دریافتی':rc.length,'مبلغ دریافتی':rs,'تعداد پرداختی':pc.length,'مبلغ پرداختی':ps,'خالص':rs-ps});
  rows+='<tr><td class="r"><b>'+b.title+'</b></td><td>'+fa(rc.length)+'</td><td class="amt pos">'+fm(rs)+'</td><td>'+fa(pc.length)+'</td><td class="amt">'+fm(ps)+'</td><td class="amt '+(rs-ps>=0?'pos':'neg')+'">'+fm(rs-ps)+'</td></tr>';
 });
 const rcA=jari.filter(c=>c.dir==='rec'),pcA=jari.filter(c=>c.dir==='paid');
 const trs=rcA.reduce((s,c)=>s+c.amount,0),tps=pcA.reduce((s,c)=>s+c.amount,0);
 const urgent=jari.filter(c=>jNorm(c.due)<=t).sort((a,b)=>a.due<b.due?-1:1);
 $('content').innerHTML=`
 <div class="pgtitle"><h1>📅 گزارش سررسید چک‌ها</h1><span class="sub">چک‌های جاری در ۶ بازه زمانی — ${jLong(t)}</span></div>
 ${chqTabs('due')}
 <div class="statgrid">
  <div class="stat g"><div class="l">جمع دریافتی جاری</div><div class="v pos">${fm(trs)}</div></div>
  <div class="stat o"><div class="l">جمع پرداختی جاری</div><div class="v">${fm(tps)}</div></div>
  <div class="stat ${trs-tps>=0?'g':'r'}"><div class="l">⚖️ خالص</div><div class="v ${trs-tps>=0?'pos':'neg'}">${fm(trs-tps)}</div></div>
  <div class="stat r"><div class="l">⛔ فوری (گذشته + امروز)</div><div class="v neg">${fm(urgent.reduce((s,c)=>s+c.amount,0))} <small>(${fa(urgent.length)} فقره)</small></div></div>
 </div>
 <div class="card" id="repCard">
 <h3>📅 تفکیک سررسید در ۶ بازه (فقط چک‌های جاری)</h3>
 <table><thead><tr><th>بازه سررسید</th><th>تعداد دریافتی</th><th>مبلغ دریافتی</th><th>تعداد پرداختی</th><th>مبلغ پرداختی</th><th>خالص (دریافتی − پرداختی)</th></tr></thead><tbody>
 ${rows}
 <tr style="background:#f4f8fb;font-weight:800"><td>جمع چک‌های جاری</td><td>${fa(rcA.length)}</td><td class="amt pos">${fm(trs)}</td><td>${fa(pcA.length)}</td><td class="amt">${fm(tps)}</td><td class="amt ${trs-tps>=0?'pos':'neg'}">${fm(trs-tps)}</td></tr>
 </tbody></table>
 ${urgent.length?`<div class="sec-h">⛔ چک‌های سررسیدگذشته و امروزی (فوری)</div>
 <table data-rn="0"><thead><tr><th>نوع</th><th>شماره</th><th>شخص</th><th>بانک</th><th>سررسید</th><th>مبلغ</th></tr></thead><tbody>${urgent.map(c=>`<tr><td><span class="bdg ${c.dir==='rec'?'b-g':'b-o'}">${c.dir==='rec'?'دریافتی':'پرداختی'}</span></td><td>${fa(c.no||'—')}</td><td class="r">${esc(PN(c.person))}</td><td>${esc(c.bank||'—')}</td><td class="neg">${jShort(c.due)}</td><td class="amt">${fm(c.amount)}</td></tr>`).join('')}</tbody></table>`:''}
 <div class="toolbar" style="margin-top:12px">
  <button class="btn g" onclick="xlOut(window._dueXL,'گزارش-سررسید-چک')">📊 اکسل</button>
  <button class="btn" onclick="printSection('repCard','گزارش سررسید چک‌ها — '+jShort(jToday()))">🖨️ چاپ</button>
 </div>
 <div style="font-size:11px;color:#7a8a99">خالص مثبت یعنی در آن بازه چک دریافتی بیشتری دارید. فقط چک‌های «جاری» محاسبه شده‌اند.</div>
 </div>`;
}
/* 📋 صورت وضعیت چک‌ها */
function vChequeStatusRep(){
 const sts=CHQ_STATUSES;
 let list=DB.cheques.slice();
 if(Fcs.q){const q=faDig(Fcs.q);list=list.filter(c=>faDig([c.no,PN(c.person),c.bank,c.issue,c.due,String(c.amount),c.desc||''].join(' ')).includes(q))}
 if(Fcs.st)list=list.filter(c=>c.status===Fcs.st);
 if(Fcs.from&&jNorm(Fcs.from))list=list.filter(c=>jNorm(c.due)>=jNorm(Fcs.from));
 if(Fcs.to&&jNorm(Fcs.to))list=list.filter(c=>jNorm(c.due)<=jNorm(Fcs.to));
 window._cstXL=[];
 window._cstDetailXL=list.map(c=>({'نوع':c.dir==='rec'?'دریافتی':'پرداختی','شماره چک':c.no,'شخص':PN(c.person),'بانک':c.bank,'تاریخ ثبت':c.issue,'سررسید':c.due,'مبلغ':c.amount,'وضعیت':c.status}));
 let rows='';
 let tRc=0,tRcA=0,tPc=0,tPcA=0;
 sts.forEach(s=>{
  const rc=list.filter(c=>c.status===s&&c.dir==='rec');
  const pc=list.filter(c=>c.status===s&&c.dir==='paid');
  const rA=rc.reduce((a,c)=>a+c.amount,0),pA=pc.reduce((a,c)=>a+c.amount,0);
  tRc+=rc.length;tRcA+=rA;tPc+=pc.length;tPcA+=pA;
  window._cstXL.push({'وضعیت':s,'تعداد دریافتی':rc.length,'مبلغ دریافتی':rA,'تعداد پرداختی':pc.length,'مبلغ پرداختی':pA,'جمع':rA+pA});
  rows+='<tr><td class="r"><span class="bdg '+chqCls(s)+'">'+s+'</span></td><td>'+fa(rc.length)+'</td><td class="amt">'+fm(rA)+'</td><td>'+fa(pc.length)+'</td><td class="amt">'+fm(pA)+'</td><td class="amt">'+fm(rA+pA)+'</td></tr>';
 });
 $('content').innerHTML=`
 <div class="pgtitle"><h1>📋 صورت وضعیت چک‌ها</h1><span class="sub">ماتریس وضعیت × نوع چک — ${fa(list.length)} فقره در نتیجه فیلتر از ${fa(DB.cheques.length)} فقره</span></div>
 ${chqTabs('status')}
 <div class="statgrid">
  <div class="stat"><div class="l">کل چک‌های نمایش‌داده‌شده</div><div class="v">${fa(list.length)} فقره</div></div>
  <div class="stat g"><div class="l">جمع دریافتی (همه وضعیت‌ها)</div><div class="v">${fm(tRcA)}</div></div>
  <div class="stat o"><div class="l">جمع پرداختی (همه وضعیت‌ها)</div><div class="v">${fm(tPcA)}</div></div>
  <div class="stat ${tRcA-tPcA>=0?'g':'r'}"><div class="l">⚖️ خالص کل</div><div class="v ${tRcA-tPcA>=0?'pos':'neg'}">${fm(tRcA-tPcA)}</div></div>
 </div>
 <div class="card" id="repCard">
 <div class="searchbar">
  <input placeholder="🔍 شماره، شخص، بانک، مبلغ..." value="${esc(Fcs.q)}" oninput="Fcs.q=this.value;vCheques('status')">
  <input placeholder="از سررسید" value="${esc(Fcs.from)}" style="width:130px" onchange="Fcs.from=jNorm(this.value);vCheques('status')">
  <input placeholder="تا سررسید" value="${esc(Fcs.to)}" style="width:120px" onchange="Fcs.to=jNorm(this.value);vCheques('status')">
  <select onchange="Fcs.st=this.value;vCheques('status')"><option value="">همه وضعیت‌ها</option>${CHQ_STATUSES.map(s=>`<option ${Fcs.st===s?'selected':''}>${s}</option>`).join('')}</select>
  <button class="btn" onclick="resetFcs();vCheques('status')">پاک کردن فیلترها</button>
 </div>
 <table><thead><tr><th>وضعیت</th><th>تعداد دریافتی</th><th>مبلغ دریافتی</th><th>تعداد پرداختی</th><th>مبلغ پرداختی</th><th>جمع کل</th></tr></thead><tbody>
 ${rows}
 <tr style="background:#f4f8fb;font-weight:800"><td>جمع کل</td><td>${fa(tRc)}</td><td>${fm(tRcA)}</td><td>${fa(tPc)}</td><td>${fm(tPcA)}</td><td>${fm(tRcA+tPcA)}</td></tr>
 </tbody></table>
 <div class="sec-h">📋 جزئیات چک‌های فیلترشده (${fa(list.length)} فقره)</div>
 <table data-rn="0"><thead><tr><th>نوع</th><th>شماره چک</th><th>شخص</th><th>بانک</th><th>تاریخ ثبت</th><th>سررسید</th><th>مبلغ</th><th>وضعیت</th></tr></thead><tbody>
 ${list.sort((a,b)=>a.due<b.due?-1:1).map(c=>`<tr><td><span class="bdg ${c.dir==='rec'?'b-g':'b-o'}">${c.dir==='rec'?'دریافتی':'پرداختی'}</span></td><td>${fa(c.no||'—')}</td><td class="r">${esc(PN(c.person))}</td><td>${esc(c.bank||'—')}</td><td>${jShort(c.issue)}</td><td>${jShort(c.due)}</td><td class="amt">${fm(c.amount)}</td><td><span class="bdg ${chqCls(c.status)}">${c.status}</span></td></tr>`).join('')||'<tr><td colspan="8"><div class="empty">چکی با این فیلترها یافت نشد</div></td></tr>'}
 </tbody></table>
 <div class="toolbar" style="margin-top:12px">
  <button class="btn g" onclick="xlOut(window._cstXL,'صورت-وضعیت-چک‌ها')">📊 اکسل</button>
  <button class="btn g" onclick="xlOut(window._cstDetailXL,'جزئیات-صورت-وضعیت-چک‌ها')">📊 اکسل جزئیات</button>
  <button class="btn" onclick="printSection('repCard','صورت وضعیت چک‌ها')">🖨️ چاپ</button>
 </div></div>`;
}
/* 📊 گزارش چک دریافتی / پرداختی */
function vChequeRepX(dir){
 const rpTab=dir==='rec'?'reprec':'reppaid';
 const F=dir==='rec'?'Fcr':'Fcp';
 const fObj=dir==='rec'?Fcr:Fcp;
 const clr=dir==='rec'?'resetFcr()':'resetFcp()';
 const t=jToday();
 let list=DB.cheques.filter(c=>c.dir===dir);
 if(fObj.q){const q=faDig(fObj.q);list=list.filter(c=>faDig([c.no,PN(c.person),c.bank,c.issue,c.due,String(c.amount),c.status].join(' ')).includes(q))}
 if(fObj.bank)list=list.filter(c=>String(c.bank||'').trim()===fObj.bank);
 if(fObj.person)list=list.filter(c=>c.person===fObj.person);
 if(fObj.st)list=list.filter(c=>c.status===fObj.st);
 if(fObj.from&&jNorm(fObj.from))list=list.filter(c=>jNorm(c.due)>=jNorm(fObj.from));
 if(fObj.to&&jNorm(fObj.to))list=list.filter(c=>jNorm(c.due)<=jNorm(fObj.to));
 list.sort((a,b)=>a.due<b.due?-1:1);
 const lbl=dir==='rec'?'دریافتی':'پرداختی';
 const doneSt=dir==='rec'?'وصول شده':'پاس شده';
 const tot=list.reduce((s,c)=>s+c.amount,0);
 const stSum=s=>list.filter(c=>c.status===s).reduce((a,c)=>a+c.amount,0);
 const stCnt=s=>list.filter(c=>c.status===s).length;
 const over=list.filter(c=>c.status==='جاری'&&jNorm(c.due)<t).reduce((s,c)=>s+c.amount,0);
 const near=list.filter(c=>c.status==='جاری'&&jNorm(c.due)>=t&&daysDiff(t,c.due)<=10).reduce((s,c)=>s+c.amount,0);
 const near30=list.filter(c=>c.status==='جاری'&&daysDiff(t,c.due)>=0&&daysDiff(t,c.due)<=30).reduce((s,c)=>s+c.amount,0);
 const overdueList=list.filter(c=>c.status==='جاری'&&jNorm(c.due)<t);
 const collectionRate=tot?Math.round(stSum(doneSt)*1000/tot)/10:0;
 const bankNames=[...new Set(list.map(c=>String(c.bank||'').trim()).filter(Boolean))].sort();
 const personTotals={};list.forEach(c=>{const key=c.person||'__none';if(!personTotals[key])personTotals[key]={name:PN(c.person),count:0,total:0,current:0,overdue:0};personTotals[key].count++;personTotals[key].total+=c.amount;if(c.status==='جاری'){personTotals[key].current+=c.amount;if(jNorm(c.due)<t)personTotals[key].overdue+=c.amount}});
 const topPersons=Object.values(personTotals).sort((a,b)=>b.current-a.current);
 const bankTotals={};list.forEach(c=>{const key=String(c.bank||'بدون بانک').trim()||'بدون بانک';if(!bankTotals[key])bankTotals[key]={name:key,count:0,total:0,current:0};bankTotals[key].count++;bankTotals[key].total+=c.amount;if(c.status==='جاری')bankTotals[key].current+=c.amount});
 const topBanks=Object.values(bankTotals).sort((a,b)=>b.current-a.current);
 window._crXL=list.map(c=>({'شماره چک':c.no,'شخص':PN(c.person),'بانک':c.bank,'تاریخ ثبت':c.issue,'سررسید':c.due,'مبلغ':c.amount,'وضعیت':c.status}));
 window._crPeopleXL=topPersons.map(x=>({'شخص':x.name,'تعداد':x.count,'جمع کل':x.total,'جاری':x.current,'معوق':x.overdue}));
 window._crBanksXL=topBanks.map(x=>({'بانک':x.name,'تعداد':x.count,'جمع کل':x.total,'جاری':x.current}));
 const _pg_chequerep=pgSlice('chequerep',list,dir+JSON.stringify(fObj),()=>vChequeRepX(dir));
 $('content').innerHTML=`
 <div class="pgtitle"><h1>📊 گزارش چک ${lbl}</h1><span class="sub">${fa(list.length)} فقره در نتیجه فیلتر</span></div>
 ${chqTabs(rpTab)}
 <div class="statgrid">
  <div class="stat"><div class="l">تعداد چک ${lbl}</div><div class="v">${fa(list.length)} فقره</div></div>
  <div class="stat ${dir==='rec'?'g':'o'}"><div class="l">💰 جمع کل مبالغ</div><div class="v">${fm(tot)}</div></div>
  <div class="stat g"><div class="l">✅ ${doneSt}</div><div class="v pos">${fm(stSum(doneSt))} <small>(${fa(stCnt(doneSt))} فقره)</small></div></div>
  <div class="stat"><div class="l">🔵 در جریان (جاری)</div><div class="v">${fm(stSum('جاری'))}</div></div>
  <div class="stat r"><div class="l">⛔ سررسید گذشته</div><div class="v neg">${fm(over)}</div></div>
  <div class="stat o"><div class="l">⏰ ۱۰ روز آینده</div><div class="v">${fm(near)}</div></div>
  <div class="stat r"><div class="l">↩️ برگشتی</div><div class="v neg">${fm(stSum('برگشتی'))}</div></div>
   ${dir==='rec'?`<div class="stat g"><div class="l">📈 نرخ وصول</div><div class="v pos">${fa(collectionRate)}٪</div></div>
    <div class="stat r"><div class="l">⚠️ تعداد معوق</div><div class="v neg">${fa(overdueList.length)} فقره</div></div>
    <div class="stat o"><div class="l">📅 سررسید ۳۰ روز</div><div class="v">${fm(near30)}</div></div>`:''}
 </div>
 <div class="card" id="repCard">
 <div class="searchbar">
    ${dir==='rec'?`<input placeholder="🔍 جست‌وجوی شماره، شخص، بانک..." value="${esc(fObj.q)}" oninput="${F}.q=this.value;vCheques('${rpTab}')">
    <select onchange="${F}.person=this.value;vCheques('${rpTab}')"><option value="">همه اشخاص</option>${DB.persons.map(p=>`<option value="${p.id}" ${fObj.person===p.id?'selected':''}>${esc(p.name)}</option>`).join('')}</select>
    <select onchange="${F}.bank=this.value;vCheques('${rpTab}')"><option value="">همه بانک‌ها</option>${bankNames.map(b=>`<option ${fObj.bank===b?'selected':''}>${esc(b)}</option>`).join('')}</select>`:''}
  <input placeholder="از سررسید ۱۴۰۳/۰۱/۰۱" value="${esc(fObj.from)}" onchange="${F}.from=jNorm(this.value);vCheques('${rpTab}')">
  <input placeholder="تا سررسید" value="${esc(fObj.to)}" onchange="${F}.to=jNorm(this.value);vCheques('${rpTab}')">
  <select onchange="${F}.st=this.value;vCheques('${rpTab}')"><option value="">همه وضعیت‌ها</option>${CHQ_STATUSES.map(s=>`<option ${fObj.st===s?'selected':''}>${s}</option>`).join('')}</select>
  <button class="btn" onclick="${clr};vCheques('${rpTab}')">پاک کردن فیلترها</button>
 </div>
 ${pgBar('chequerep','top')}<table data-rn="chequerep"><thead><tr><th>شماره چک</th><th>شخص</th><th>بانک</th><th>تاریخ ثبت</th><th>سررسید</th><th>فاصله سررسید</th><th>مبلغ (تومان)</th><th>وضعیت</th></tr></thead><tbody>
 ${_pg_chequerep.map(c=>`<tr><td>${fa(c.no||'—')}</td><td class="r">${esc(PN(c.person))}</td><td>${esc(c.bank||'—')}</td><td>${jShort(c.issue)}</td><td class="${c.status==='جاری'&&jNorm(c.due)<t?'neg':''}">${jShort(c.due)}</td><td>${chqDueCell(c)}</td><td class="amt">${fm(c.amount)}</td><td><span class="bdg ${chqCls(c.status)}">${c.status}</span></td></tr>`).join('')||'<tr><td colspan="8"><div class="empty">چکی یافت نشد</div></td></tr>'}
 </tbody>
 <tfoot><tr style="background:#f4f8fb;font-weight:800"><td colspan="6">جمع (${fa(list.length)} فقره)</td><td class="amt">${fm(tot)}</td><td></td></tr></tfoot>
 </table>${pgBar('chequerep')}
 ${dir==='rec'?`<div class="grid2" style="margin-top:12px">
  <div><div class="sec-h">👥 مانده جاری به تفکیک شخص</div><table><thead><tr><th>شخص</th><th>تعداد</th><th>جاری</th><th>معوق</th></tr></thead><tbody>${topPersons.map(x=>`<tr><td class="r">${esc(x.name)}</td><td>${fa(x.count)}</td><td class="amt">${fm(x.current)}</td><td class="amt ${x.overdue?'neg':''}">${fm(x.overdue)}</td></tr>`).join('')||'<tr><td colspan="4">داده‌ای نیست</td></tr>'}</tbody></table></div>
  <div><div class="sec-h">🏦 مانده جاری به تفکیک بانک</div><table><thead><tr><th>بانک</th><th>تعداد</th><th>جمع کل</th><th>جاری</th></tr></thead><tbody>${topBanks.map(x=>`<tr><td class="r">${esc(x.name)}</td><td>${fa(x.count)}</td><td class="amt">${fm(x.total)}</td><td class="amt">${fm(x.current)}</td></tr>`).join('')||'<tr><td colspan="4">داده‌ای نیست</td></tr>'}</tbody></table></div>
 </div>`:''}
 <div class="toolbar" style="margin-top:12px">
  <button class="btn g" onclick="xlOut(window._crXL,'گزارش-چک-${lbl}')">📊 اکسل</button>
 ${dir==='rec'?`<button class="btn g" onclick="xlOut(window._crPeopleXL,'چک‌های-دریافتی-به-تفکیک-شخص')">📊 اکسل اشخاص</button><button class="btn g" onclick="xlOut(window._crBanksXL,'چک‌های-دریافتی-به-تفکیک-بانک')">📊 اکسل بانک‌ها</button>`:''}
  <button class="btn" onclick="printSection('repCard','گزارش چک ${lbl}')">🖨️ چاپ</button>
 </div></div>`;
}
function chequeForm(id){
 const c=id?DB.cheques.find(x=>x.id===id):{no:'',serial:'',dir:'rec',person:DB.persons[0]?DB.persons[0].id:'',amount:0,due:jAddD(jToday(),30),issue:jToday(),bank:'',status:'جاری',desc:''};
 openM(mHead(id?'✏️ ویرایش چک':'＋ ثبت چک جدید (دریافتی / پرداختی)')+'<div class="mbody">'+
 '<div class="frow"><div class="fg"><label>نوع چک</label><select id="chDir"><option value="rec" '+(c.dir==='rec'?'selected':'')+'>دریافتی</option><option value="paid" '+(c.dir==='paid'?'selected':'')+'>پرداختی</option></select></div>'+
 '<div class="fg"><label>سریال چک</label><input id="chNo" value="'+esc(c.serial||c.no)+'" placeholder="1206/123456" dir="ltr"></div>'+ 
 '<div class="fg"><label>مبلغ (تومان)</label><input id="chAmt" class="money" value="'+fm(c.amount)+'"></div></div>'+
 '<div class="frow"><div class="fg"><label>شخص</label><select id="chPerson">'+DB.persons.map(p=>'<option value="'+p.id+'" '+(c.person===p.id?'selected':'')+'>'+esc(p.name)+'</option>').join('')+'</select></div>'+
 '<div class="fg"><label>بانک</label><input id="chBank" list="bankL" value="'+esc(c.bank)+'"><datalist id="bankL">'+DB.banks.map(b=>'<option value="'+esc(b.name)+'">').join('')+'</datalist></div></div>'+
 '<div class="frow"><div class="fg"><label>تاریخ ثبت</label><input id="chIssue" value="'+c.issue+'" style="width:115px"></div>'+
 '<div class="fg"><label>سررسید *</label><input id="chDue" value="'+c.due+'" style="width:115px"></div>'+
 '<div class="fg"><label>وضعیت چک</label><select id="chSt">'+CHQ_STATUSES.map(s=>'<option '+(c.status===s?'selected':'')+'>'+s+'</option>').join('')+'</select></div></div>'+
 '<div class="fg"><label>شرح</label><input id="chDesc" value="'+esc(c.desc||'')+'"></div><input type="hidden" id="chId" value="'+(id||'')+'">'+
 '</div><div class="mfoot"><button class="btn p" onclick="chequeSave()">💾 ذخیره</button><button class="btn" onclick="closeM()">انصراف</button></div>');
}
function chqSyncTx(c){DB.accTx.filter(t=>t.ref===c.id).forEach(t=>{t.amount=c.amount;t.type=c.dir==='rec'?'in':'out'})}
 function chequeSave(){
  const id=$('chId').value;
  const due=jNorm($('chDue').value);if(!jValid(due)){toast('⚠️ سررسید نامعتبر است',false);return}
  const serial=faDig($('chNo').value).trim(),obj={dir:$('chDir').value,no:serial,serial,person:$('chPerson').value,amount:pd($('chAmt').value),bank:$('chBank').value,issue:jNorm($('chIssue').value)||jToday(),due,status:$('chSt').value,desc:$('chDesc').value};
  if(!obj.amount){toast('⚠️ مبلغ را وارد کنید',false);return}
  const wantSt=obj.status;let cid=id;
  if(id){
   const c=DB.cheques.find(x=>x.id===id);if(!c)return;
   obj.status=c.status;Object.assign(c,obj);chqSyncTx(c);
  }else{cid=uid();obj.status='جاری';DB.cheques.push({id:cid,inv:'',...obj})}
  logAct('ثبت/ویرایش چک '+obj.no+' ('+(obj.dir==='rec'?'دریافتی':'پرداختی')+')');saveDB();closeM();vCheques();toast('✅ ذخیره شد');
  /* تغییر وضعیت از مسیر اصلی انجام می‌شود تا تراکنش بانکی هم‌زمان ساخته/حذف شود */
  const cur=(DB.cheques.find(x=>x.id===cid)||{}).status;
  if(wantSt!==cur)chequeSt(cid,wantSt);
 }
 function chequeSt(id,st){ixInvalidate();
 const c=DB.cheques.find(x=>x.id===id);if(!c)return;
 if((st==='وصول شده'||st==='پاس شده')&&c.status!==st&&DB.accounts.length){
  openM(mHead('🏦 تسویه چک')+'<div class="mbody"><p>مبلغ چک در کدام حساب بانکی ثبت شود؟</p><div class="frow" style="margin-top:8px"><select id="chAcc">'+DB.accounts.map((a,i)=>'<option value="'+a.id+'" '+(i===0?'selected':'')+'>ثبت در: '+esc(a.title)+'</option>').join('')+'</select></div></div><div class="mfoot"><button class="btn p" onclick="chequeSt2(\''+id+'\',\''+st+'\')">تایید و ثبت در بانک</button><button class="btn" onclick="closeM()">انصراف</button></div>');
  return;
 }
 if((c.status==='وصول شده'||c.status==='پاس شده')&&st!=='وصول شده'&&st!=='پاس شده')DB.accTx=DB.accTx.filter(t=>t.ref!==c.id);
 const was=c.status;c.status=st;c.bouncedDate=st==='برگشتی'?jToday():'';logAct('تغییر وضعیت چک '+c.no+' به '+st);saveDB();vCheques();chqThanks(c,was,st);
}
function chequeSt2(id,st){ixInvalidate();
 const acc=$('chAcc').value;closeM();
 const c=DB.cheques.find(x=>x.id===id);if(!c)return;const was=c.status;c.status=st;
 DB.accTx=DB.accTx.filter(t=>t.ref!==c.id);
 if(acc)DB.accTx.push({id:uid(),acc,date:jToday(),type:c.dir==='rec'?'in':'out',amount:c.amount,desc:'وصول چک '+c.no,ref:c.id});
 logAct('تغییر وضعیت چک '+c.no+' به '+st);saveDB();vCheques();toast('✅ ثبت شد');chqThanks(c,was,st);
}
function chequeDel(id){confirmM('حذف چک؟',()=>{DB.cheques=DB.cheques.filter(x=>x.id!==id);DB.accTx=DB.accTx.filter(t=>t.ref!==id);saveDB();vCheques()})}
function printChequeFiltered(){
 const list=window._chqList||[];
 const tab=window._chqTab||'all';
 printHTML('<h2>گزارش چک‌های '+({all:'همه',rec:'دریافتی',paid:'پرداختی'})[tab]+' — '+esc(DB.settings.shopName)+'</h2><p>تاریخ گزارش: '+jLong(jToday())+' — تعداد: '+fa(list.length)+' فقره — جمع: '+fm(list.reduce((s,c)=>s+c.amount,0))+' تومان</p><table data-rn="0"><tr style="background:#eee"><th>نوع</th><th>شماره</th><th>شخص</th><th>بانک</th><th>ثبت</th><th>سررسید</th><th>مبلغ</th><th>وضعیت</th></tr>'+list.map(c=>'<tr><td>'+(c.dir==='rec'?'دریافتی':'پرداختی')+'</td><td>'+fa(c.no)+'</td><td>'+esc(PN(c.person))+'</td><td>'+esc(c.bank)+'</td><td>'+jShort(c.issue)+'</td><td>'+jShort(c.due)+'</td><td>'+fm(c.amount)+'</td><td>'+c.status+'</td></tr>').join('')+'</table>');
}

/* ================================================================
   ==================== اقساط (کامل) ================================
   ================================================================ */
const Fi={q:'',mode:'',plan:''};
const Fir={st:'',from:'',to:'',person:''};
function instTabs(active){
 return `<div class="tabs">
  <button class="tab ${active==='cheques'?'on':''}" onclick="vCheques('all')">🏦 لیست چک‌ها</button>
  <button class="tab ${active==='list'?'on':''}" onclick="Fi.q='';Fi.mode='';Fi.plan='';vInst('list')">📋 لیست اقساط</button>
  <button class="tab ${active==='reg'?'on':''}" onclick="vInst('reg')">➕ ثبت اقساط</button>
  <button class="tab ${active==='plans'?'on':''}" onclick="vInst('plans')">🗂️ مدیریت طرح‌های اقساط</button>
  <button class="tab ${active==='warn'?'on':''}" onclick="vInst('warn')">🔔 هشدار سررسید</button>
  <button class="tab ${active==='rep'?'on':''}" onclick="resetFir();vInst('rep')">📊 گزارش اقساط</button>
 </div>`;
}
function resetFir(){Fir.st='';Fir.from='';Fir.to='';Fir.person=''}
function planKey(i){return i.planId||('inv-'+(i.inv||i.id))}
function vInst(tab){
 tab=tab||window._instTab||'list';window._instTab=tab;
 if(tab==='reg')return instRegView();
 if(tab==='plans')return instPlansView();
 if(tab==='warn')return instWarnView();
 if(tab==='rep')return instRepView();
 const today=jToday();
 const base=DB.installments.filter(instInGrp);
 let list=base.slice().sort((a,b)=>a.due<b.due?-1:1);
 if(Fi.mode==='due')list=list.filter(i=>!i.paid&&jNorm(i.due)<=today);
 if(Fi.mode==='near')list=list.filter(i=>!i.paid&&jNorm(i.due)>today&&daysDiff(i.due,today)<=10);
 if(Fi.mode==='open')list=list.filter(i=>!i.paid);
 if(Fi.plan)list=list.filter(i=>planKey(i)===Fi.plan);
 if(Fi.q){const q=faDig(Fi.q);list=list.filter(i=>faDig([PN(i.person),i.due,String(i.amount),String(i.no),i.paid?'پرداخت‌شده':'باز'].join(' ')).includes(q))}
 window._instList=list;const debtAll=base.filter(i=>!i.paid).reduce((s,i)=>s+i.amount,0);
 const overN=base.filter(i=>!i.paid&&jNorm(i.due)<today);
 const overSum=overN.reduce((s,i)=>s+i.amount,0);
 const recvAll=base.filter(i=>i.paid).reduce((s,i)=>s+(i.amountPaid||i.amount),0);
 const nearN=base.filter(i=>!i.paid&&jNorm(i.due)>today&&daysDiff(i.due,today)<=10).length;
 const _pg_instlist=pgSlice('instlist',list,JSON.stringify(Fi),()=>vInst('list'));
 $('content').innerHTML=`
 <div class="pgtitle"><h1>📅 مدیریت اقساط</h1><span class="sub">ثبت، پیگیری، هشدار تأخیر، بدهی و دریافتی</span></div>
 ${overN.length?`<div class="notice red"><b>🔔 هشدار: ${fa(overN.length)} قسط سررسیدگذشته به ارزش ${fm(overSum)} تومان!</b> — <a href="#" onclick="vInst('warn');return false" style="color:#8a2b20;font-weight:800">مشاهده هشدارها و یادآوری گروهی</a></div>`:''}
 <div class="inst-fixed">
 <div class="statgrid">
  <div class="stat r"><div class="l">📌 بدهی (جمع اقساط باز)</div><div class="v neg">${fm(debtAll)} <small>تومان</small></div></div>
  <div class="stat g"><div class="l">✅ دریافتی (پرداخت‌شده)</div><div class="v pos">${fm(recvAll)} <small>تومان</small></div></div>
  <div class="stat r"><div class="l">⛔ معوق (سررسید گذشته)</div><div class="v neg">${fm(overSum)} <small>(${fa(overN.length)} قسط)</small></div></div>
  <div class="stat o"><div class="l">⏰ نزدیک سررسید (۱۰ روز)</div><div class="v">${fa(nearN)} قسط</div></div>
 </div>
 ${instTabs('list')}
  ${instGrpBar('list')}
  <div id="instSelBar">${instSelBarHtml()}</div>
 <div class="card" style="margin-bottom:6px"><div class="searchbar">
  <input id="qIn" placeholder="🔍 شخص، مبلغ، تاریخ، وضعیت..." value="${esc(Fi.q)}" style="min-width:240px" oninput="Fi.q=this.value;vInst('list');rf('qIn')">
  <select onchange="Fi.mode=this.value;vInst('list')"><option value="">همه</option><option value="open" ${Fi.mode==='open'?'selected':''}>باز (بدهی)</option><option value="due" ${Fi.mode==='due'?'selected':''}>سررسید گذشته</option><option value="near" ${Fi.mode==='near'?'selected':''}>نزدیک سررسید</option></select>
  ${Fi.plan?`<span class="bdg b-b">نمایش طرح انتخابی <button style="border:none;background:none;cursor:pointer;color:#c0392b;font-weight:800" onclick="Fi.plan='';vInst('list')">✕</button></span>`:''}
  <button class="btn" onclick="xlClaimsTemplate()">📥 قالب اکسل مطالبات</button>
  <button class="btn g" onclick="xlOut(window._instList.map(i=>({'لیست':instGName(instGrp(i)),'شخص':PN(i.person),'قسط':i.no,'سررسید':i.due,'مبلغ':i.amount,'وضعیت':i.paid?'پرداخت‌شده':'باز','تاریخ پرداخت':i.paidDate||'','شرح':i.desc||''})),'اقساط-تکنوکالا')">📊 اکسل</button>
 </div>
 </div>
 ${instGrpTools()}
 <div class="card">
${pgBar('instlist','top')}<table data-rn="instlist"><thead><tr><th style="width:34px"><input type="checkbox" id="instSelHead" title="انتخاب همه‌ی ردیف‌های باز این صفحه" ${(window._instPageIds=_pg_instlist.filter(i=>!i.paid).map(i=>i.id)).length&&window._instPageIds.every(id=>INSTSEL.has(id))?'checked':''} onchange="instSelPage(this.checked)"></th><th>فاکتور</th><th>شخص</th><th>لیست</th><th>قسط</th><th>سررسید</th><th>تأخیر</th><th>مبلغ</th><th>وضعیت</th><th>عملیات</th></tr></thead><tbody>
 ${_pg_instlist.map(i=>{const late=!i.paid&&jNorm(i.due)<today?daysDiff(i.due,today):0;const inv=i.inv?ix().invoice.get(i.inv):null;
  return `<tr id="instr_${i.id}" class="${INSTSEL.has(i.id)?'rowsel':''}">
  <td>${i.paid?'':`<input type="checkbox" ${INSTSEL.has(i.id)?'checked':''} onclick="instSelToggle('${i.id}',this.checked,event)">`}</td><td>${inv?fa(inv.no):'دستی'}</td><td class="r">${esc(PN(i.person))}</td><td><small>${esc(instGName(instGrp(i)))}</small></td><td>${fa(i.no)}</td>
  <td class="${late?'neg':''}">${jShort(i.due)}</td>
  <td>${late?'<span class="bdg b-r">'+fa(late)+' روز</span>':'—'}</td>
  <td class="amt">${fm(i.amount)}</td>
  <td>${i.paid?'<span class="bdg b-g">پرداخت شد '+jShort(i.paidDate)+'</span>':'<span class="bdg b-o">باز</span>'}</td>
  <td style="white-space:nowrap">
   ${!i.paid?`<button class="btn sm g" onclick="instPay('${i.id}')">💵 ثبت پرداخت</button><button class="btn sm o" onclick="instSMS('${i.id}')">✉️ یادآوری</button>`:''}
   <button class="btn sm" onclick="instMovePlan('${i.id}')" title="انتقال این طرح به لیست دیگر">📂</button><button class="btn sm r" onclick="instDel('${i.id}')">🗑️</button>
  </td></tr>`}).join('')||'<tr><td colspan="10"><div class="empty"><div class="b">📅</div>قسطی یافت نشد</div></td></tr>'}
 </tbody></table>${pgBar('instlist')}</div>`;
}
window._regPrev=null;
function instRegView(){
 $('content').innerHTML=`
 <div class="pgtitle"><h1>➕ ثبت اقساط جدید</h1><span class="sub">ثبت طرح اقساط به‌صورت مستقل (بدون نیاز به فاکتور)</span></div>
 ${instTabs('reg')}
 <div class="card">
 <h3>📝 مشخصات طرح اقساط</h3>
 <div class="frow">
  <div class="fg"><label>شخص (بدهکار) *</label><select id="rgPerson" style="min-width:220px">${DB.persons.map(p=>`<option value="${p.id}">${esc(p.name)}</option>`).join('')}</select></div>
  <div class="fg"><label>لیست اقساط</label><select id="rgGrp">${instGroups().map(g=>`<option value="${g.id}" ${(Fi.grp||'ig-normal')===g.id?'selected':''}>${esc(g.name)}</option>`).join('')}</select></div>
   <div class="fg"><label>مبلغ کل (تومان) *</label><input id="rgTotal" class="money" style="width:150px" placeholder="مثلاً 24000000"></div>
  <div class="fg"><label>پیش‌پرداخت (اختیاری)</label><input id="rgPre" class="money" style="width:140px" value="0"></div>
 </div>
 <div class="frow">
  <div class="fg"><label>تعداد اقساط *</label><input id="rgN" class="money" style="width:100px" value="4"></div>
  <div class="fg"><label>فاصله اقساط (ماه)</label><input id="rgGap" class="money" style="width:100px" value="1"></div>
  <div class="fg"><label>اولین سررسید *</label><input id="rgFirst" value="${jAddM(jToday(),1)}" style="width:120px" placeholder="۱۴۰۳/۰۶/۰۱"></div>
  <div class="fg"><label>شرح / بابت</label><input id="rgDesc" style="min-width:200px" placeholder="مثلاً خرید گوشی Samsung A55"></div>
 </div>
 <div class="toolbar">
  <button class="btn p" onclick="instRegPreview()">👁️ پیش‌نمایش جدول اقساط</button>
  <button class="btn g" onclick="instRegSave()">💾 ثبت نهایی اقساط</button>
 </div>
 <div id="rgPrev"></div>
 </div>`;
}
function instRegPreview(){
 const total=pd($('rgTotal').value),pre=pd($('rgPre').value)||0;
 const n=pd($('rgN').value)||1,gap=pd($('rgGap').value)||1;
 const first=jNorm($('rgFirst').value);
 const person=$('rgPerson').value;
 if(!person){toast('⚠️ شخص را انتخاب کنید',false);return null}
 if(!total){toast('⚠️ مبلغ کل را وارد کنید',false);return null}
 if(!jValid(first)){toast('⚠️ تاریخ اولین سررسید نامعتبر است (نمونه: ۱۴۰۳/۰۶/۰۱)',false);return null}
 const rem=total-pre;
 if(rem<=0){toast('⚠️ مبلغ کل باید از پیش‌پرداخت بیشتر باشد',false);return null}
 if(n<1){toast('⚠️ تعداد اقساط نامعتبر است',false);return null}
 const each=Math.floor(rem/n);
 window._regPrev={grp:($('rgGrp')||{}).value||'ig-normal',person,n,gap,first,pre,desc:($('rgDesc')||{}).value||'',items:[]};
 let rows='';
 for(let i=0;i<n;i++){
  const due=i===0?first:jAddM(first,i*gap);
  const amt=i===n-1?rem-each*(n-1):each;
  window._regPrev.items.push({no:i+1,due,amount:amt});
  rows+='<tr><td>'+fa(i+1)+'</td><td>'+jShort(due)+'</td><td class="amt">'+fm(amt)+'</td></tr>';
 }
 $('rgPrev').innerHTML='<div class="sec-h">👁️ پیش‌نمایش جدول اقساط</div><table><thead><tr><th>قسط</th><th>سررسید</th><th>مبلغ (تومان)</th></tr></thead><tbody>'+rows+'</tbody></table><div style="margin-top:6px">پیش‌پرداخت: <b>'+fm(pre)+'</b> — جمع اقساط: <b class="neg">'+fm(rem)+' تومان</b></div>';
 return window._regPrev;
}
function instRegSave(){
 const p=instRegPreview();
 if(!p)return;
 confirmM('ثبت <b>'+fa(p.items.length)+'</b> قسط برای «'+esc(PN(p.person))+'» با جمع '+fm(p.items.reduce((s,i)=>s+i.amount,0))+' تومان؟',()=>{
  const planId=uid();
  p.items.forEach(it=>DB.installments.push({id:uid(),planId,inv:'',person:p.person,no:it.no,amount:it.amount,due:it.due,paid:false,paidDate:'',desc:p.desc,grp:p.grp}));
  logAct('ثبت دستی '+fa(p.items.length)+' قسط برای '+PN(p.person));
  saveDB();window._regPrev=null;vInst('plans');
  toast('✅ '+fa(p.items.length)+' قسط با موفقیت ثبت شد');
 });
}
function instPlansView(){
 const groups={};
 DB.installments.filter(instInGrp).forEach(i=>{
  const k=planKey(i);
  if(!groups[k])groups[k]={id:k,person:i.person,items:[],inv:i.inv||'',desc:i.desc||''};
  groups[k].items.push(i);
 });
 const list=Object.values(groups).map(g=>{
  g.items.sort((a,b)=>a.no-b.no);
  g.paidN=g.items.filter(i=>i.paid).length;
  g.openN=g.items.length-g.paidN;
  g.paidSum=g.items.filter(i=>i.paid).reduce((s,i)=>s+(i.amountPaid||i.amount),0);
  g.openSum=g.items.filter(i=>!i.paid).reduce((s,i)=>s+i.amount,0);
  g.total=g.items.reduce((s,i)=>s+i.amount,0);
  g.first=g.items[0]?g.items[0].due:'';
  g.last=g.items[g.items.length-1]?g.items[g.items.length-1].due:'';
  return g;
 }).sort((a,b)=>(a.openN>0?0:1)-(b.openN>0?0:1)||String(a.first).localeCompare(b.first));
 const tOpen=list.reduce((s,g)=>s+g.openSum,0),tPaid=list.reduce((s,g)=>s+g.paidSum,0);
 window._plansXLf=()=>list.map(g=>({'شخص':PN(g.person),'منبع':g.inv?('فاکتور '+fa((DB.invoices.find(x=>x.id===g.inv)||{}).no||'')):'ثبت دستی','تعداد اقساط':g.items.length,'پرداخت‌شده':g.paidN,'باز':g.openN,'جمع مبلغ':g.total,'دریافتی':g.paidSum,'مانده بدهی':g.openSum,'اولین سررسید':g.first,'آخرین سررسید':g.last,'شرح':g.desc||''}));
 const _pg_instplans=pgSlice('instplans',list,JSON.stringify(Fi.grp),instPlansView);
 $('content').innerHTML=`
 <div class="pgtitle"><h1>🗂️ مدیریت طرح‌های اقساط</h1><span class="sub">${fa(list.length)} طرح — پیگیری بدهی و دریافتی هر طرح</span></div>
 <div class="statgrid">
  <div class="stat"><div class="l">تعداد طرح‌ها</div><div class="v">${fa(list.length)}</div></div>
  <div class="stat g"><div class="l">✅ جمع دریافتی اقساط</div><div class="v pos">${fm(tPaid)} <small>تومان</small></div></div>
  <div class="stat r"><div class="l">📌 مانده بدهی اقساط (باز)</div><div class="v neg">${fm(tOpen)} <small>تومان</small></div></div>
 </div>
 ${instTabs('plans')}
  ${instGrpBar('plans')}
 <div class="card">
 <div class="toolbar">
  <button class="btn p" onclick="vInst('reg')">➕ ثبت اقساط جدید</button>
  <button class="btn g" onclick="xlOut(window._plansXLf(),'طرح‌های-اقساط')">📊 اکسل</button>
  <button class="btn" onclick="printSection('repCard','مدیریت طرح‌های اقساط')">🖨️ چاپ</button>
 </div>
 <div id="repCard">
 ${pgBar('instplans','top')}<table data-rn="instplans"><thead><tr><th>شخص</th><th>منبع</th><th>تعداد</th><th>پرداخت‌شده</th><th>باز</th><th>جمع مبلغ</th><th>دریافتی</th><th>مانده بدهی</th><th>اولین سررسید</th><th>آخرین سررسید</th><th>عملیات</th></tr></thead><tbody>
 ${_pg_instplans.map(g=>{const inv=g.inv?DB.invoices.find(x=>x.id===g.inv):null;
  return `<tr>
  <td class="r"><b>${esc(PN(g.person))}</b></td>
  <td>${inv?'فاکتور '+fa(inv.no):(esc(g.desc||'ثبت دستی'))}</td>
  <td>${fa(g.items.length)}</td>
  <td><span class="bdg b-g">${fa(g.paidN)}</span></td>
  <td><span class="bdg ${g.openN?'b-o':'b-g'}">${fa(g.openN)}</span></td>
  <td class="amt">${fm(g.total)}</td>
  <td class="amt pos">${fm(g.paidSum)}</td>
  <td class="amt ${g.openSum>0?'neg':''}">${fm(g.openSum)}</td>
  <td>${jShort(g.first)}</td><td>${jShort(g.last)}</td>
  <td style="white-space:nowrap">
   <button class="btn sm" onclick="Fi.plan='${g.id}';vInst('list')" title="نمایش اقساط این طرح">👁️ اقساط</button>
   <button class="btn sm r" onclick="instPlanDel('${g.id}')">🗑️ حذف</button>
  </td></tr>`}).join('')||'<tr><td colspan="11"><div class="empty"><div class="b">🗂️</div>طرحی ثبت نشده — از تب «ثبت اقساط» یا فاکتور اقساطی ایجاد کنید</div></td></tr>'}
 </tbody></table>${pgBar('instplans')}</div></div>`;
}
function instPlanDel(pid){
 const items=DB.installments.filter(i=>planKey(i)===pid);
 const unpaid=items.filter(i=>!i.paid);
 if(!items.length){toast('یافت نشد',false);return}
 confirmM('حذف این طرح اقساط؟<br>تعداد کل: <b>'+fa(items.length)+'</b> قسط — پرداخت‌نشده: <b>'+fa(unpaid.length)+'</b> قسط<br><small>اقساط پرداخت‌شده به‌عنوان سوابق مالی حفظ می‌شوند.</small>',()=>{
  DB.installments=DB.installments.filter(i=>!(planKey(i)===pid&&!i.paid));
  logAct('حذف طرح اقساط ('+fa(unpaid.length)+' قسط باز حذف شد)');
  saveDB();vInst('plans');toast('🗑️ طرح حذف شد (اقساط پرداخت‌شده حفظ شد)');
 });
}
function instWarnView(){
 const today=jToday();
 const over=DB.installments.filter(instInGrp).filter(i=>!i.paid&&jNorm(i.due)<today).sort((a,b)=>a.due<b.due?-1:1);
 const td_=DB.installments.filter(instInGrp).filter(i=>!i.paid&&jNorm(i.due)===today);
 const near=DB.installments.filter(instInGrp).filter(i=>!i.paid&&jNorm(i.due)>today&&daysDiff(today,i.due)<=10).sort((a,b)=>a.due<b.due?-1:1);
 const overSum=over.reduce((s,i)=>s+i.amount,0),tdSum=td_.reduce((s,i)=>s+i.amount,0),nearSum=near.reduce((s,i)=>s+i.amount,0);
 window._warnOver=over;window._warnToday=td_;window._warnNear=near;
 const rowHtml=i=>{const late=daysDiff(i.due,today);const inv=i.inv?DB.invoices.find(x=>x.id===i.inv):null;
  return `<tr><td class="r">${esc(PN(i.person))}</td><td>${inv?fa(inv.no):'دستی'}</td><td>${fa(i.no)}</td><td>${jShort(i.due)}</td><td>${late>0?'<span class="bdg b-r">'+fa(late)+' روز تأخیر</span>':late===0?'<span class="bdg b-o">امروز</span>':'<span class="bdg b-b">'+fa(-late)+' روز آینده</span>'}</td><td class="amt">${fm(i.amount)}</td>
  <td style="white-space:nowrap"><button class="btn sm g" onclick="instPay('${i.id}')">💵 پرداخت</button> <button class="btn sm o" onclick="instSMS('${i.id}')">✉️</button></td></tr>`};
 const _pg_warnover=pgSlice('warnover',over,JSON.stringify(Fi.grp),instWarnView);
 const _pg_warntoday=pgSlice('warntoday',td_,JSON.stringify(Fi.grp),instWarnView);
 const _pg_warnnear=pgSlice('warnnear',near,JSON.stringify(Fi.grp),instWarnView);
 $('content').innerHTML=`
 <div class="pgtitle"><h1>🔔 هشدار سررسید اقساط</h1><span class="sub">${jLong(today)}</span></div>
 ${instTabs('warn')}
  ${instGrpBar('warn')}
 ${over.length?`<div class="notice red"><b>⚠️ ${fa(over.length)} قسط سررسیدگذشته به ارزش ${fm(overSum)} تومان — نیاز به پیگیری فوری!</b></div>`:'<div class="notice">✅ قسط سررسیدگذشته‌ای وجود ندارد. وضعیت خوب است!</div>'}
 ${td_.length?`<div class="notice"><b>⏰ ${fa(td_.length)} قسط امروز سررسید می‌شود (${fm(tdSum)} تومان)</b></div>`:''}
 <div class="statgrid">
  <div class="stat r"><div class="l">⛔ معوق (سررسید گذشته)</div><div class="v neg">${fm(overSum)}</div></div>
  <div class="stat o"><div class="l">⏰ سررسید امروز</div><div class="v">${fm(tdSum)}</div></div>
  <div class="stat"><div class="l">📅 ۱۰ روز آینده</div><div class="v">${fm(nearSum)}</div></div>
  <div class="stat r"><div class="l">📌 جمع بدهی هشدارها</div><div class="v neg">${fm(overSum+tdSum+nearSum)}</div></div>
 </div>
 <div class="card"><h3>⛔ اقساط سررسیدگذشته (${fa(over.length)} قسط — بدهی ${fm(overSum)} تومان)</h3>
  ${over.length?`${pgBar('warnover','top')}<table data-rn="warnover"><thead><tr><th>شخص</th><th>فاکتور</th><th>قسط</th><th>سررسید</th><th>تأخیر</th><th>مبلغ</th><th>عملیات</th></tr></thead><tbody>${_pg_warnover.map(rowHtml).join('')}</tbody></table>${pgBar('warnover')}
  <div class="toolbar"><button class="btn o" onclick="instBulkSMS(window._warnOver)">✉️ یادآوری گروهی به معوق‌ها</button></div>`:'<div class="empty"><div class="b">✅</div>موردی نیست</div>'}</div>
 <div class="card"><h3>⏰ سررسید امروز (${fa(td_.length)} قسط — ${fm(tdSum)} تومان)</h3>
  ${td_.length?`${pgBar('warntoday','top')}<table data-rn="warntoday"><thead><tr><th>شخص</th><th>فاکتور</th><th>قسط</th><th>سررسید</th><th>وضعیت</th><th>مبلغ</th><th>عملیات</th></tr></thead><tbody>${_pg_warntoday.map(rowHtml).join('')}</tbody></table>${pgBar('warntoday')}
  <div class="toolbar"><button class="btn o" onclick="instBulkSMS(window._warnToday)">✉️ یادآوری گروهی</button></div>`:'<div class="empty"><div class="b">✅</div>موردی نیست</div>'}</div>
 <div class="card"><h3>📅 نزدیک سررسید — ۱۰ روز آینده (${fa(near.length)} قسط — ${fm(nearSum)} تومان)</h3>
  ${near.length?`${pgBar('warnnear','top')}<table data-rn="warnnear"><thead><tr><th>شخص</th><th>فاکتور</th><th>قسط</th><th>سررسید</th><th>فاصله</th><th>مبلغ</th><th>عملیات</th></tr></thead><tbody>${_pg_warnnear.map(rowHtml).join('')}</tbody></table>${pgBar('warnnear')}
  <div class="toolbar"><button class="btn o" onclick="instBulkSMS(window._warnNear)">✉️ یادآوری گروهی</button></div>`:'<div class="empty"><div class="b">✅</div>موردی نیست</div>'}</div>`;
}
function instBulkSMS(list){
 if(!list||!list.length){toast('⚠️ موردی برای ارسال نیست',false);return}
 const byP={};
 list.forEach(i=>{const p=P(i.person);if(p&&p.phone){if(!byP[p.id])byP[p.id]=[];byP[p.id].push(i)}});
 const ids=Object.keys(byP);
 if(!ids.length){toast('⚠️ هیچ‌یک از این اشخاص شماره موبایل ثبت‌شده ندارند',false);return}
 confirmM('ارسال پیامک یادآوری به <b>'+fa(ids.length)+'</b> شخص؟',()=>{
  ids.forEach(pid=>{
   const items=byP[pid];const p=P(pid);
   const sum=items.reduce((s,i)=>s+i.amount,0);
   const late=daysDiff(items[0].due,jToday());
   const msg=smsFill(smsTpl('Inst'),{name:p.name,no:items[0].no,amount:sum,due:items[0].due,count:items.length})+(late>0?'\n⚠️ '+fa(late)+' روز تأخیر':'')+(items.length>1?'\n(و '+fa(items.length-1)+' قسط دیگر)':'');
   sendSMS(p.phone,msg);smsToGuarantor(p,msg);
  });
  toast('📨 درخواست ارسال یادآوری به '+fa(ids.length)+' نفر ثبت شد');
 });
}
function instRepView(){
 const today=jToday();
 let list=DB.installments.filter(instInGrp);
 if(Fir.st==='open')list=list.filter(i=>!i.paid);
 else if(Fir.st==='paid')list=list.filter(i=>i.paid);
 else if(Fir.st==='over')list=list.filter(i=>!i.paid&&jNorm(i.due)<today);
 else if(Fir.st==='today')list=list.filter(i=>!i.paid&&jNorm(i.due)===today);
 else if(Fir.st==='near')list=list.filter(i=>!i.paid&&jNorm(i.due)>today&&daysDiff(today,i.due)<=10);
 if(Fir.from&&jNorm(Fir.from))list=list.filter(i=>jNorm(i.due)>=jNorm(Fir.from));
 if(Fir.to&&jNorm(Fir.to))list=list.filter(i=>jNorm(i.due)<=jNorm(Fir.to));
 if(Fir.person)list=list.filter(i=>i.person===Fir.person);
 list.sort((a,b)=>a.due<b.due?-1:1);
 const debt=list.filter(i=>!i.paid).reduce((s,i)=>s+i.amount,0);
 const recv=list.filter(i=>i.paid).reduce((s,i)=>s+(i.amountPaid||i.amount),0);
 window._irXLf=()=>list.map(i=>({'لیست':instGName(instGrp(i)),'شخص':PN(i.person),'قسط':i.no,'سررسید':i.due,'مبلغ':i.amount,'وضعیت':i.paid?'پرداخت‌شده':'باز','تاریخ پرداخت':i.paidDate||'','مبلغ دریافتی':i.paid?(i.amountPaid||i.amount):0,'شرح':i.desc||''}));
 const _pg_instrep=pgSlice('instrep',list,JSON.stringify([Fir,Fi.grp]),instRepView);
 $('content').innerHTML=`
 <div class="pgtitle"><h1>📊 گزارش اقساط</h1><span class="sub">${fa(list.length)} قسط در نتیجه فیلتر</span></div>
 ${instTabs('rep')}
  ${instGrpBar('rep')}
 <div class="statgrid">
  <div class="stat"><div class="l">تعداد اقساط</div><div class="v">${fa(list.length)}</div></div>
  <div class="stat r"><div class="l">📌 بدهی (جمع اقساط باز)</div><div class="v neg">${fm(debt)} <small>تومان</small></div></div>
  <div class="stat g"><div class="l">✅ دریافتی (جمع پرداخت‌شده)</div><div class="v pos">${fm(recv)} <small>تومان</small></div></div>
  <div class="stat ${debt-recv>=0?'r':'g'}"><div class="l">⚖️ خالص (بدهی − دریافتی)</div><div class="v ${debt-recv>=0?'neg':'pos'}">${fm(debt-recv)}</div></div>
 </div>
 <div class="card" id="repCard">
 <div class="searchbar">
  <select onchange="Fir.st=this.value;instRepView()">
   <option value="">همه وضعیت‌ها</option>
   <option value="open" ${Fir.st==='open'?'selected':''}>باز (بدهی)</option>
   <option value="paid" ${Fir.st==='paid'?'selected':''}>پرداخت‌شده (دریافتی)</option>
   <option value="over" ${Fir.st==='over'?'selected':''}>سررسید گذشته</option>
   <option value="today" ${Fir.st==='today'?'selected':''}>سررسید امروز</option>
   <option value="near" ${Fir.st==='near'?'selected':''}>نزدیک سررسید (۱۰ روز)</option>
  </select>
  <select onchange="Fir.person=this.value;instRepView()"><option value="">همه اشخاص</option>${DB.persons.map(p=>`<option value="${p.id}" ${Fir.person===p.id?'selected':''}>${esc(p.name)}</option>`).join('')}</select>
  <input placeholder="از سررسید ۱۴۰۳/۰۱/۰۱" value="${esc(Fir.from)}" onchange="Fir.from=jNorm(this.value);instRepView()">
  <input placeholder="تا سررسید" value="${esc(Fir.to)}" onchange="Fir.to=jNorm(this.value);instRepView()">
  <button class="btn" onclick="resetFir();vInst('rep')">پاک کردن فیلترها</button>
 </div>
 ${pgBar('instrep','top')}<table data-rn="instrep"><thead><tr><th>شخص</th><th>قسط</th><th>سررسید</th><th>مبلغ</th><th>وضعیت</th><th>تاریخ پرداخت</th><th>دریافتی</th><th>شرح</th></tr></thead><tbody>
 ${_pg_instrep.map(i=>`<tr><td class="r">${esc(PN(i.person))}</td><td>${fa(i.no)}</td><td class="${!i.paid&&jNorm(i.due)<today?'neg':''}">${jShort(i.due)}</td><td class="amt">${fm(i.amount)}</td>
  <td>${i.paid?'<span class="bdg b-g">پرداخت‌شده</span>':(jNorm(i.due)<today?'<span class="bdg b-r">معوق</span>':'<span class="bdg b-o">باز</span>')}</td>
  <td>${i.paidDate?jShort(i.paidDate):'—'}</td><td class="amt pos">${i.paid?fm(i.amountPaid||i.amount):'—'}</td><td class="r">${esc(i.desc||'')}</td></tr>`).join('')||'<tr><td colspan="8"><div class="empty">قسطی یافت نشد</div></td></tr>'}
 </tbody></table>${pgBar('instrep')}
 <div class="toolbar" style="margin-top:12px">
  <button class="btn g" onclick="xlOut(window._irXLf(),'گزارش-اقساط')">📊 اکسل</button>
  <button class="btn" onclick="printSection('repCard','گزارش اقساط')">🖨️ چاپ</button>
 </div></div>`;
}
function instPay(id){
 const i=DB.installments.find(x=>x.id===id);if(!i)return;
 openM(mHead('💵 ثبت پرداخت قسط '+fa(i.no)+' — '+esc(PN(i.person)))+'<div class="mbody">'+
 '<div class="frow"><div class="fg"><label>مبلغ (تومان)</label><input id="ipAmt" class="money" value="'+fm(i.amount)+'"></div>'+
 '<div class="fg"><label>تاریخ پرداخت</label><input id="ipDate" value="'+jToday()+'" style="width:110px"></div>'+
 '<div class="fg"><label>روش</label><select id="ipM">'+['cash','card','fish','account'].map(m=>'<option value="'+m+'">'+({cash:'نقد',card:'کارت',fish:'فیش',account:'حساب'})[m]+'</option>').join('')+'</select></div>'+
 '<div class="fg"><label>حساب بانکی</label><select id="ipAcc">'+DB.accounts.map((a,i)=>'<option value="'+a.id+'" '+(i===0?'selected':'')+'>'+esc(a.title)+'</option>').join('')+'</select></div></div>'+ 
 '</div><div class="mfoot"><button class="btn p" onclick="instPaySave(\''+id+'\')">ثبت</button><button class="btn" onclick="closeM()">انصراف</button></div>');
}
function instPaySave(id){ixInvalidate();
  const i=DB.installments.find(x=>x.id===id);if(!i)return;
  if(i.paid){closeM();toast('⚠️ این قسط قبلاً تسویه شده است',false);return}
  const amt=pd($('ipAmt').value),date=jNorm($('ipDate').value)||jToday(),m=$('ipM').value,acc=$('ipAcc').value;
  if(!amt){toast('⚠️ مبلغ را وارد کنید',false);return}
  const commit=()=>{
   if(i.paid)return;
   i.paid=true;i.paidDate=date;i.paidMethod=m;i.amountPaid=amt;
   const rid=uid();
   DB.receipts.push({id:rid,instId:i.id,no:nextNo('rec'),date,person:i.person,dir:'in',rows:[{method:m,amount:amt,acc}],desc:'پرداخت قسط '+fa(i.no)+(i.inv?' — فاکتور '+fa((DB.invoices.find(x=>x.id===i.inv)||{}).no||''):'')});
   if(m!=='cash'&&acc)DB.accTx.push({id:uid(),acc,date,type:'in',amount:amt,desc:'قسط '+PN(i.person),ref:rid});
   logAct('دریافت قسط '+PN(i.person)+' — '+fm(amt));saveDB();closeM();
    try{msgThanks('ThankInst',i.person,{amount:amt,no:i.no,date})}catch(e){console.error(e)}
   // به جای پرش اجباری به صفحه اقساط، همان نمای فعلی را مجدداً رندر می‌کنیم
   try{ nav(curView||'inst'); }catch(e){ try{vInst()}catch(_){} }
   toast('✅ قسط تسویه شد');
  };
  if(amt<Number(i.amount))confirmM('مبلغ دریافتی ('+fm(amt)+' ت) کمتر از قسط ('+fm(i.amount)+' ت) است.<br><small>این قسط «تسویه‌شده» ثبت می‌شود و مابه‌التفاوت ('+fm(Number(i.amount)-amt)+' ت) فقط در مانده‌ی حساب مشتری باقی می‌ماند، نه در لیست اقساط. ادامه می‌دهید؟</small>',commit);
  else commit();
 }
 /* ✉️ پیامک یادآوری قسط (با قالب قابل ویرایش) */
function instSMS(id){
 const i=DB.installments.find(x=>x.id===id);if(!i)return;const p=P(i.person);
 if(!p||!p.phone){toast('⚠️ موبایل شخص ثبت نشده',false);return}
 const late=!i.paid&&jNorm(i.due)<jToday()?daysDiff(i.due,jToday()):0;
 const msg=smsFill(smsTpl('Inst'),{name:p.name,no:i.no,amount:i.amount,due:i.due})+(late?'\n⚠️ '+fa(late)+' روز تأخیر':'');
 askM('✉️ پیامک یادآوری قسط','پیامک به '+esc(p.name)+' ('+esc(p.phone)+'):',msg,txt=>{sendSMS(p.phone,txt);smsToGuarantor(p,txt)})
}
function instDel(id){confirmM('حذف این قسط؟',()=>{DB.installments=DB.installments.filter(x=>x.id!==id);saveDB();vInst()})}

/* ================================================================
   ==================== بانک (کامل) =================================
   ================================================================ */
const Fb={bank:'',from:'',to:'',q:''};
function resetFb(){Fb.bank='';Fb.from='';Fb.to='';Fb.q=''}
function bankTabs(active){
 return `<div class="tabs">
  <button class="tab ${active==='banks'?'on':''}" onclick="vBank('banks')">🏦 معرفی بانک</button>
  <button class="tab ${active==='accs'?'on':''}" onclick="vBank('accs')">💳 معرفی حساب</button>
  <button class="tab ${active==='ops'?'on':''}" onclick="Fb.q='';vBank('ops')">🔄 عملیات مرتبط با حساب</button>
  <button class="tab ${active==='rep'?'on':''}" onclick="resetFb();vBank('rep')">📊 گزارش حساب‌ها</button>
 </div>`;
}
function vBank(tab){
 tab=tab||window._bankTab||'banks';window._bankTab=tab;
 if(tab==='accs')return bankAccsView();
 if(tab==='ops')return bankOpsView();
 if(tab==='rep')return bankRepView();
 return bankBanksView();
}
function bankBanksView(){
 $('content').innerHTML=`
 <div class="pgtitle"><h1>🏦 معرفی بانک</h1><span class="sub">ثبت و مدیریت بانک‌ها</span></div>
 ${bankTabs('banks')}
 <div class="grid2">
 <div class="card"><h3>➕ معرفی بانک جدید</h3>
  <div class="frow"><div class="fg" style="flex:1"><label>نام بانک</label><input id="nbName" placeholder="مثلاً: بانک ملت" style="width:100%" onkeydown="if(event.key==='Enter')bankAdd2()"></div>
  <div class="fg" style="justify-content:flex-end"><button class="btn p" onclick="bankAdd2()">💾 افزودن بانک</button></div></div>
 </div>
 <div class="card"><h3>ℹ️ راهنمای بخش بانک</h3>
  <div style="font-size:12px;color:#7a8a99;line-height:2">۱. ابتدا بانک‌ها را در همین تب معرفی کنید<br>۲. در تب «معرفی حساب» برای هر بانک حساب تعریف کنید<br>۳. واریز، برداشت و انتقال در تب «عملیات مرتبط با حساب»<br>۴. مانده و گزارش کامل در تب «گزارش حساب‌ها»</div>
 </div>
 </div>
 <div class="card"><h3>🏦 بانک‌های ثبت‌شده (${fa(DB.banks.length)})</h3>
 <table><thead><tr><th>#</th><th>نام بانک</th><th>تعداد حساب‌ها</th><th>جمع مانده حساب‌ها</th><th>عملیات</th></tr></thead><tbody>
 ${DB.banks.map((b,i)=>{const accs=DB.accounts.filter(a=>a.bank===b.id);const sum=accs.reduce((s,a)=>s+accBal(a),0);
  return `<tr><td>${fa(i+1)}</td><td class="r"><b>${esc(b.name)}</b></td><td>${fa(accs.length)}</td><td class="amt">${fm(sum)}</td>
  <td style="white-space:nowrap"><button class="btn sm" onclick="bankRen('${b.id}')">✏️ ویرایش نام</button><button class="btn sm r" onclick="bankDel('${b.id}')">🗑️ حذف</button></td></tr>`}).join('')||'<tr><td colspan="5"><div class="empty">بانکی ثبت نشده</div></td></tr>'}
 </tbody></table></div>`;
}
function bankAdd2(){
 const n=($('nbName')||{}).value.trim();if(!n){toast('⚠️ نام بانک را وارد کنید',false);return}
 if(DB.banks.some(b=>b.name===n)){toast('⚠️ این بانک قبلاً ثبت شده است',false);return}
 DB.banks.push({id:uid(),name:n});logAct('معرفی بانک: '+n);saveDB();vBank('banks');toast('✅ بانک «'+n+'» اضافه شد');
}
function bankRen(id){const b=DB.banks.find(x=>x.id===id);if(!b)return;const n=prompt('نام جدید بانک:',b.name);if(n&&n.trim()){b.name=n.trim();logAct('ویرایش بانک: '+b.name);saveDB();vBank('banks');toast('✅ نام بانک تغییر کرد')}}
function bankDel(id){
 if(DB.accounts.some(a=>a.bank===id)){toast('⚠️ ابتدا حساب‌های این بانک را حذف یا جابجا کنید',false);return}
 const b=DB.banks.find(x=>x.id===id);
 confirmM('حذف بانک «'+esc(b.name)+'»؟',()=>{DB.banks=DB.banks.filter(x=>x.id!==id);logAct('حذف بانک: '+b.name);saveDB();vBank('banks');toast('🗑️ بانک حذف شد')});
}
function bankAccsView(){
 $('content').innerHTML=`
 <div class="pgtitle"><h1>💳 معرفی حساب</h1><span class="sub">ثبت حساب‌های بانکی با شماره حساب، کارت و شبا</span></div>
 ${bankTabs('accs')}
 <div class="toolbar">
  <button class="btn p" onclick="accForm()">＋ معرفی حساب جدید</button>
 </div>
 <div class="card"><h3>💳 حساب‌های بانکی (${fa(DB.accounts.length)})</h3>
 <table data-rn="0"><thead><tr><th>عنوان حساب</th><th>بانک</th><th>شماره حساب</th><th>شماره کارت</th><th>شبا</th><th>موجودی اولیه</th><th>مانده فعلی</th><th>عملیات</th></tr></thead><tbody>
 ${DB.accounts.map(a=>`<tr>
  <td class="r"><b>${esc(a.title)}</b></td>
  <td>${esc((DB.banks.find(b=>b.id===a.bank)||{}).name||'—')}</td>
  <td>${fa(a.accNo||'—')}</td><td>${fa(a.card||'—')}</td><td style="direction:ltr;font-size:10.5px">${fa(a.iban||'—')}</td>
  <td class="amt">${fm(a.open||0)}</td><td class="amt ${accBal(a)>=0?'pos':'neg'}"><b>${fm(accBal(a))}</b></td>
  <td style="white-space:nowrap">
   <button class="btn sm g" onclick="accOp('${a.id}','in')">💰 واریز</button>
   <button class="btn sm o" onclick="accOp('${a.id}','out')">💸 برداشت</button>
   <button class="btn sm" onclick="accTransfer('${a.id}')">🔄 انتقال</button>
   <button class="btn sm" onclick="accTxView('${a.id}')">📋 گردش</button>
   <button class="btn sm" onclick="accForm('${a.id}')">✏️</button>
   <button class="btn sm r" onclick="accDel('${a.id}')">🗑️</button>
  </td></tr>`).join('')||'<tr><td colspan="8"><div class="empty">حسابی ثبت نشده — از دکمه «معرفی حساب جدید» شروع کنید</div></td></tr>'}
 </tbody>
 <tfoot><tr style="background:#f4f8fb;font-weight:800"><td colspan="6">جمع مانده همه حساب‌ها</td><td class="amt">${fm(DB.accounts.reduce((s,a)=>s+accBal(a),0))}</td><td></td></tr></tfoot>
 </table></div>`;
}
function accForm(id){
 const a=id?ACC(id):{title:'',bank:DB.banks[0]?DB.banks[0].id:'',accNo:'',card:'',iban:'',open:0};
 openM(mHead(id?'✏️ ویرایش حساب':'＋ معرفی حساب جدید')+'<div class="mbody">'+
 '<div class="frow"><div class="fg"><label>عنوان حساب *</label><input id="acTitle" value="'+esc(a.title)+'" placeholder="مثلاً: جاری تکنوکالا"></div>'+
 '<div class="fg"><label>بانک</label><select id="acBank">'+DB.banks.map(b=>'<option value="'+b.id+'" '+(a.bank===b.id?'selected':'')+'>'+esc(b.name)+'</option>').join('')+'</select></div></div>'+
 '<div class="frow"><div class="fg"><label>شماره حساب</label><input id="acNo" value="'+esc(a.accNo)+'"></div>'+
 '<div class="fg"><label>شماره کارت</label><input id="acCard" value="'+esc(a.card)+'" style="direction:ltr"></div></div>'+
 '<div class="frow"><div class="fg"><label>شماره شبا</label><input id="acIban" value="'+esc(a.iban)+'" style="direction:ltr" placeholder="IR..."></div>'+
 '<div class="fg"><label>موجودی اولیه (تومان)</label><input id="acOpen" class="money" value="'+fm(a.open)+'"></div></div>'+
 '<input type="hidden" id="acId" value="'+(id||'')+'"></div>'+
 '<div class="mfoot"><button class="btn p" onclick="accSave()">💾 ذخیره حساب</button><button class="btn" onclick="closeM()">انصراف</button></div>');
}
function accSave(){
 const t=$('acTitle').value.trim();if(!t){toast('⚠️ عنوان حساب را وارد کنید',false);return}
 const obj={title:t,bank:$('acBank').value,accNo:faDig($('acNo').value),card:faDig($('acCard').value),iban:$('acIban').value,open:pdS($('acOpen').value)};
 const id=$('acId').value;
 if(id){Object.assign(ACC(id),obj);logAct('ویرایش حساب: '+t)}
 else{DB.accounts.push({id:uid(),...obj});logAct('معرفی حساب جدید: '+t)}
 saveDB();closeM();vBank('accs');toast('✅ حساب ذخیره شد');
}
function accDel(id){
 if(DB.accTx.some(t=>t.acc===id)){toast('⚠️ این حساب گردش دارد و حذف نمی‌شود',false);return}
 confirmM('حذف این حساب؟',()=>{DB.accounts=DB.accounts.filter(a=>a.id!==id);saveDB();vBank('accs');toast('🗑️ حساب حذف شد')});
}
function bankOpsView(){
 let txs=DB.accTx.slice(-100).reverse();
 if(Fb.q){const q=faDig(Fb.q);txs=txs.filter(t=>faDig([ACC(t.acc)?ACC(t.acc).title:'',t.date,String(t.amount),t.desc||'',t.type==='in'?'واریز':'برداشت'].join(' ')).includes(q))}
 $('content').innerHTML=`
 <div class="pgtitle"><h1>🔄 عملیات مرتبط با حساب</h1><span class="sub">واریز، برداشت، انتقال بین حساب‌ها و گردش</span></div>
 ${bankTabs('ops')}
 <div class="card"><h3>⚡ عملیات سریع</h3>
  ${DB.accounts.length?`
  <div class="toolbar">
   <button class="btn g" onclick="accOp('${DB.accounts[0].id}','in')">💰 واریز به حساب</button>
   <button class="btn o" onclick="accOp('${DB.accounts[0].id}','out')">💸 برداشت از حساب</button>
   <button class="btn p" onclick="accTransfer('')">🔄 انتقال بین حساب‌ها</button>
  </div>
  <div style="margin-top:6px"><b style="font-size:12px">انتخاب سریع حساب (کلیک = واریز):</b>
  <div style="margin-top:6px">${DB.accounts.map(a=>`<span class="chipcol" onclick="accOp('${a.id}','in')" title="مانده: ${fm(accBal(a))}">💰 ${esc(a.title)} — ${fm(accBal(a))}</span>`).join('')}</div></div>`
  :'<div class="empty">ابتدا از تب «معرفی حساب» یک حساب تعریف کنید</div>'}
 </div>
 <div class="card"><h3>💳 مانده حساب‌ها</h3>
 <table data-rn="0"><thead><tr><th>حساب</th><th>بانک</th><th>مانده فعلی</th><th>عملیات</th></tr></thead><tbody>
 ${DB.accounts.map(a=>`<tr><td class="r"><b>${esc(a.title)}</b></td><td>${esc((DB.banks.find(b=>b.id===a.bank)||{}).name||'—')}</td><td class="amt ${accBal(a)>=0?'pos':'neg'}"><b>${fm(accBal(a))}</b></td>
 <td style="white-space:nowrap"><button class="btn sm g" onclick="accOp('${a.id}','in')">💰 واریز</button><button class="btn sm o" onclick="accOp('${a.id}','out')">💸 برداشت</button><button class="btn sm" onclick="accTransfer('${a.id}')">🔄 انتقال</button><button class="btn sm" onclick="accTxView('${a.id}')">📋 گردش</button></td></tr>`).join('')||'<tr><td colspan="4"><div class="empty">حسابی نیست</div></td></tr>'}
 </tbody></table></div>
 <div class="card"><h3>🔄 گردش حساب‌ها (۱۰۰ مورد اخیر)</h3>
 <div class="searchbar">
  <input id="bqIn" placeholder="🔍 حساب، مبلغ، تاریخ، شرح، نوع..." value="${esc(Fb.q)}" style="min-width:240px" oninput="Fb.q=this.value;bankOpsView();rf('bqIn')">
  <button class="btn" onclick="Fb.q='';bankOpsView()">پاک کردن</button>
 </div>
 <table data-rn="0"><thead><tr><th>تاریخ</th><th>حساب</th><th>نوع</th><th>مبلغ</th><th>شرح</th><th>عملیات</th></tr></thead><tbody>
 ${txs.map(tx=>`<tr><td>${jShort(tx.date)}</td><td class="r">${esc(ACC(tx.acc)?ACC(tx.acc).title:'—')}</td><td>${tx.type==='in'?'<span class="bdg b-g">واریز</span>':'<span class="bdg b-r">برداشت</span>'}</td><td class="amt ${tx.type==='in'?'pos':'neg'}">${fm(tx.amount)}</td><td class="r">${esc(tx.desc||'')}</td>
 <td>${!tx.ref?`<button class="btn sm r" onclick="accTxDel('${tx.id}')">🗑️</button>`:''}</td></tr>`).join('')||'<tr><td colspan="6"><div class="empty">گردشی نیست</div></td></tr>'}
 </tbody></table>
 <div style="font-size:11px;color:#7a8a99;margin-top:6px">تراکنش‌های متصل به فاکتور/رسید از طریق همان سند قابل حذف هستند؛ فقط عملیات دستی اینجا قابل حذف‌اند.</div></div>`;
}
function accOp(accId,type){
 const a=ACC(accId);if(!a)return;
 openM(mHead((type==='in'?'💰 واریز به حساب: ':'💸 برداشت از حساب: ')+esc(a.title))+'<div class="mbody">'+
 '<div class="kv" style="margin-bottom:10px"><span class="k">مانده فعلی: <b>'+fm(accBal(a))+' تومان</b></span></div>'+
 '<div class="frow"><div class="fg"><label>مبلغ (تومان) *</label><input id="opAmt" class="money" style="width:150px"></div>'+
 '<div class="fg"><label>تاریخ</label><input id="opDate" value="'+jToday()+'" style="width:110px"></div></div>'+
 '<div class="fg"><label>نوع عملیات</label><select id="opK">'+(type==='in'?'<option value="cap">آورده سرمایه</option><option value="inc">درآمد متفرقه</option>':'<option value="cap">برداشت صاحب سرمایه</option>'+COA.filter(a=>a[2]==='X').map(a=>'<option value="e:'+a[0]+'">هزینه — '+a[1]+'</option>').join(''))+'</select></div>'+
  '<div class="fg"><label>شرح / بابت</label><input id="opDesc" style="width:100%" value="'+(type==='in'?'واریز دستی به حساب':'برداشت دستی از حساب')+'"></div>'+
 '</div><div class="mfoot"><button class="btn p" onclick="accOpSave(\''+accId+'\',\''+type+'\')">💾 ثبت عملیات</button><button class="btn" onclick="closeM()">انصراف</button></div>');
}
function accOpSave(accId,type){
 const a=ACC(accId);if(!a)return;
 const amt=pd($('opAmt').value);if(!amt){toast('⚠️ مبلغ را وارد کنید',false);return}
 const date=jNorm($('opDate').value);if(!jValid(date)){toast('⚠️ تاریخ نامعتبر است',false);return}
 DB.accTx.push({id:uid(),acc:accId,date,type,amount:amt,desc:$('opDesc').value||'',kind:$('opK').value,ref:''});
 logAct((type==='in'?'واریز ':'برداشت ')+fm(amt)+' — حساب '+a.title);
 saveDB();closeM();vBank(window._bankTab||'ops');
 toast('✅ عملیات ثبت شد — مانده جدید: '+fm(accBal(a))+' تومان');
}
function accTransfer(fromId){
 if(DB.accounts.length<2){toast('⚠️ برای انتقال حداقل دو حساب لازم است',false);return}
 openM(mHead('🔄 انتقال بین حساب‌ها')+'<div class="mbody">'+
 '<div class="frow"><div class="fg"><label>از حساب *</label><select id="trFrom">'+DB.accounts.map(a=>'<option value="'+a.id+'" '+(fromId===a.id?'selected':'')+'>'+esc(a.title)+' — مانده: '+fm(accBal(a))+'</option>').join('')+'</select></div>'+
 '<div class="fg"><label>به حساب *</label><select id="trTo">'+DB.accounts.map(a=>'<option value="'+a.id+'">'+esc(a.title)+'</option>').join('')+'</select></div></div>'+
 '<div class="frow"><div class="fg"><label>مبلغ (تومان) *</label><input id="trAmt" class="money" style="width:150px"></div>'+
 '<div class="fg"><label>تاریخ</label><input id="trDate" value="'+jToday()+'" style="width:110px"></div></div>'+
 '<div class="fg"><label>شرح</label><input id="trDesc" style="width:100%" value="انتقال بین حساب‌ها"></div>'+
 '</div><div class="mfoot"><button class="btn p" onclick="accTransferSave()">💾 ثبت انتقال</button><button class="btn" onclick="closeM()">انصراف</button></div>');
}
function accTransferSave(){
 const from=$('trFrom').value,to=$('trTo').value;
 if(from===to){toast('⚠️ حساب مبدأ و مقصد یکسان است',false);return}
 const amt=pd($('trAmt').value);if(!amt){toast('⚠️ مبلغ را وارد کنید',false);return}
 const date=jNorm($('trDate').value);if(!jValid(date)){toast('⚠️ تاریخ نامعتبر است',false);return}
 DB.accTx.push({id:uid(),acc:from,date,type:'out',amount:amt,desc:($('trDesc').value||'انتقال')+' → '+ACC(to).title,ref:''});
 DB.accTx.push({id:uid(),acc:to,date,type:'in',amount:amt,desc:($('trDesc').value||'انتقال')+' ← '+ACC(from).title,ref:''});
 logAct('انتقال '+fm(amt)+' از '+ACC(from).title+' به '+ACC(to).title);
 saveDB();closeM();vBank('ops');toast('✅ انتقال ثبت شد');
}
function accTxDel(id){
 const tx=DB.accTx.find(t=>t.id===id);if(!tx)return;
 confirmM('حذف این تراکنش دستی ('+(tx.type==='in'?'واریز':'برداشت')+' '+fm(tx.amount)+')؟',()=>{
  DB.accTx=DB.accTx.filter(t=>t.id!==id);logAct('حذف تراکنش دستی حساب');saveDB();vBank('ops');toast('🗑️ حذف شد')});
}
function bankRepView(){
 let accs=DB.accounts.filter(a=>!Fb.bank||a.bank===Fb.bank);
 const rows=accs.map(a=>{
  const allTx=DB.accTx.filter(t=>t.acc===a.id);
  const tin=allTx.filter(t=>t.type==='in').reduce((s,t)=>s+t.amount,0);
  const tout=allTx.filter(t=>t.type==='out').reduce((s,t)=>s+t.amount,0);
  let ptx=allTx;
  if(Fb.from&&jNorm(Fb.from))ptx=ptx.filter(t=>jNorm(t.date)>=jNorm(Fb.from));
  if(Fb.to&&jNorm(Fb.to))ptx=ptx.filter(t=>jNorm(t.date)<=jNorm(Fb.to));
  const pin=ptx.filter(t=>t.type==='in').reduce((s,t)=>s+t.amount,0);
  const pout=ptx.filter(t=>t.type==='out').reduce((s,t)=>s+t.amount,0);
  return{a,open:a.open||0,tin,tout,bal:accBal(a),pin,pout,nTx:ptx.length};
 });
 const tOpen=rows.reduce((s,r)=>s+r.open,0),tIn=rows.reduce((s,r)=>s+r.tin,0),tOut=rows.reduce((s,r)=>s+r.tout,0),tBal=rows.reduce((s,r)=>s+r.bal,0);
 window._brXL=rows.map(r=>({'حساب':r.a.title,'بانک':(DB.banks.find(b=>b.id===r.a.bank)||{}).name||'','شماره حساب':r.a.accNo||'','شماره کارت':r.a.card||'','موجودی اولیه':r.open,'جمع واریزی‌ها':r.tin,'جمع برداشت‌ها':r.tout,'مانده فعلی':r.bal}));
 $('content').innerHTML=`
 <div class="pgtitle"><h1>📊 گزارش حساب‌ها</h1><span class="sub">مانده، واریز و برداشت هر حساب بانکی</span></div>
 ${bankTabs('rep')}
 <div class="statgrid">
  <div class="stat"><div class="l">تعداد حساب‌ها</div><div class="v">${fa(rows.length)}</div></div>
  <div class="stat g"><div class="l">جمع واریزی‌ها</div><div class="v pos">${fm(tIn)}</div></div>
  <div class="stat r"><div class="l">جمع برداشت‌ها</div><div class="v neg">${fm(tOut)}</div></div>
  <div class="stat ${tBal>=0?'g':'r'}"><div class="l">💰 مانده کل حساب‌ها</div><div class="v ${tBal>=0?'pos':'neg'}">${fm(tBal)} <small>تومان</small></div></div>
 </div>
 <div class="card" id="repCard">
 <div class="searchbar">
  <select onchange="Fb.bank=this.value;bankRepView()"><option value="">همه بانک‌ها</option>${DB.banks.map(b=>`<option value="${b.id}" ${Fb.bank===b.id?'selected':''}>${esc(b.name)}</option>`).join('')}</select>
  <input placeholder="از تاریخ گردش ۱۴۰۳/۰۱/۰۱" value="${esc(Fb.from)}" onchange="Fb.from=jNorm(this.value);bankRepView()">
  <input placeholder="تا تاریخ گردش" value="${esc(Fb.to)}" onchange="Fb.to=jNorm(this.value);bankRepView()">
  <button class="btn" onclick="resetFb();vBank('rep')">پاک کردن فیلترها</button>
 </div>
 <table data-rn="0"><thead><tr><th>حساب</th><th>بانک</th><th>موجودی اولیه</th><th>واریزی دوره</th><th>برداشت دوره</th><th>جمع واریزی کل</th><th>جمع برداشت کل</th><th>مانده فعلی</th></tr></thead><tbody>
 ${rows.map(r=>`<tr><td class="r"><b>${esc(r.a.title)}</b></td><td>${esc((DB.banks.find(b=>b.id===r.a.bank)||{}).name||'—')}</td>
 <td class="amt">${fm(r.open)}</td><td class="amt pos">${fm(r.pin)} <small>(${fa(r.nTx)} تراکنش)</small></td><td class="amt neg">${fm(r.pout)}</td>
 <td class="amt pos">${fm(r.tin)}</td><td class="amt neg">${fm(r.tout)}</td><td class="amt ${r.bal>=0?'pos':'neg'}"><b>${fm(r.bal)}</b></td></tr>`).join('')||'<tr><td colspan="8"><div class="empty">حسابی یافت نشد</div></td></tr>'}
 </tbody>
 <tfoot><tr style="background:#f4f8fb;font-weight:800"><td colspan="2">جمع کل (${fa(rows.length)} حساب)</td><td>${fm(tOpen)}</td><td colspan="3">—</td><td></td><td>${fm(tBal)}</td></tr></tfoot>
 </table>
 <div class="toolbar" style="margin-top:12px">
  <button class="btn g" onclick="xlOut(window._brXL,'گزارش-حساب‌ها')">📊 اکسل</button>
  <button class="btn" onclick="printSection('repCard','گزارش حساب‌های بانکی')">🖨️ چاپ</button>
 </div></div>`;
}
function accTxView(id){
 const a=ACC(id);if(!a)return;
 const tx=DB.accTx.filter(t=>t.acc===id);
 openM(mHead('📋 گردش حساب: '+esc(a.title))+'<div class="mbody">'+
 '<div class="kv" style="margin-bottom:10px"><span class="k">مانده فعلی: <b>'+fm(accBal(a))+' تومان</b></span><span class="k">تعداد تراکنش: <b>'+fa(tx.length)+'</b></span></div>'+
 '<table data-rn="0"><thead><tr><th>تاریخ</th><th>نوع</th><th>مبلغ</th><th>شرح</th></tr></thead><tbody>'+tx.map(t=>'<tr><td>'+jShort(t.date)+'</td><td>'+(t.type==='in'?'<span class="bdg b-g">واریز</span>':'<span class="bdg b-r">برداشت</span>')+'</td><td class="amt '+(t.type==='in'?'pos':'neg')+'">'+fm(t.amount)+'</td><td class="r">'+esc(t.desc||'')+'</td></tr>').join('')+'</tbody></table></div><div class="mfoot"><button class="btn p" onclick="printModalTable(\'گردش حساب '+esc(a.title)+'\')">🖨️ چاپ</button><button class="btn" onclick="closeM()">بستن</button></div>',true);
}

/* ================================================================
   ============ گزارش‌ها (۱۵ گزارش + بازه‌های زمانی) ================
   ================================================================ */
const REP_TYPES=[['buy','📥 خرید'],['sale','🧾 فروش'],['profit','📈 سود'],['rec','💵 دریافتی'],['pay','💸 پرداختی'],['pgood','📦 سود و زیان کالا'],['pinv','🧾 سود و زیان فاکتور'],['pcust','👥 سود و زیان مشتری'],['pnet','📊 سود و زیان خالص'],['kardex','📋 کاردکس'],['stock','🏬 موجودی'],['short','⚠️ کمبود'],['persons','👥 اشخاص'],['cheques','🏦 چک'],['inst','📅 اقساط'],['agecust','⏳ سن مطالبات مشتریان'],['agesup','⏳ سن بدهی به تامین‌کنندگان']];
const NO_DATE_REP=['stock','short','persons','agecust','agesup'];
let curRep='sale',repRange={mode:'month',from:'',to:''};
function rangeVals(){
 const t=jToday();
 if(repRange.mode==='day')return[t,t];
 if(repRange.mode==='week')return[jAddD(t,-6),t];
 if(repRange.mode==='month')return[t.slice(0,8)+'01',t];
 if(repRange.mode==='all')return['0000/01/01','9999/12/31'];
 return[repRange.from||t,repRange.to||t];
}
function inRange(d){const[a,b]=rangeVals();const x=jNorm(d);return!!x&&x>=a&&x<=b}
function vReports(){
 const[a,b]=rangeVals();
 const isNoDate=NO_DATE_REP.includes(curRep);
 $('content').innerHTML=`
 <div class="pgtitle"><h1>📊 مرکز گزارش‌ها (۱۷ گزارش)</h1><span class="sub">هر گزارش تاریخی: روزانه / هفتگی / ماهانه / بازه دلخواه / کل دوره</span></div>
 <div class="rep-grid">
 <div class="repl">${REP_TYPES.map(r=>`<div class="ri ${curRep===r[0]?'on':''}" onclick="curRep='${r[0]}';vReports()">${r[1]}</div>`).join('')}</div>
 <div>
 <div class="card"><div class="searchbar">
  ${isNoDate?`<span class="bdg b-m">📌 «${REP_TYPES.find(r=>r[0]===curRep)[1]}» گزارش وضعیت لحظه‌ای است و به بازه زمانی وابسته نیست</span>`
  :`<button class="btn ${repRange.mode==='day'?'p':''}" onclick="repRange.mode='day';vReports()">روزانه</button>
  <button class="btn ${repRange.mode==='week'?'p':''}" onclick="repRange.mode='week';vReports()">هفتگی</button>
  <button class="btn ${repRange.mode==='month'?'p':''}" onclick="repRange.mode='month';vReports()">ماهانه</button>
  <button class="btn ${repRange.mode==='custom'?'p':''}" onclick="repRange.mode='custom';vReports()">بازه دلخواه</button>
  <button class="btn ${repRange.mode==='all'?'p':''}" onclick="repRange.mode='all';vReports()">کل دوره</button>
  ${repRange.mode==='custom'?`<input placeholder="از ۱۴۰۳/۰۱/۰۱" value="${esc(repRange.from)}" style="width:130px" onchange="repRange.from=jNorm(this.value);vReports()"><input placeholder="تا" value="${esc(repRange.to)}" style="width:120px" onchange="repRange.to=jNorm(this.value);vReports()">`:''}
  <span class="bdg b-b">بازه: ${jShort(a)} تا ${jShort(b)}</span>`}
 </div></div>
 <div class="card" id="repCard">${repRender(curRep)}
 <div class="toolbar" style="margin-top:12px">
  <button class="btn" onclick="printRep()">🖨️ چاپ گزارش</button>
  <button class="btn g" onclick="repExcel()">📊 اکسل</button>${curRep==='agecust'?'<button class="btn o" onclick="smsAgeOpen(30)">📲 پیامک یادآوری مطالبات بالای ۳۰ روز</button>':''}
 </div></div>
 </div></div>`;
}
function repRender(type){
 const invs=DB.invoices.filter(i=>inRange(i.date)&&i.type!=='proforma');
 if(type==='buy'||type==='sale'){
  const list=invs.filter(i=>i.type===(type==='buy'?'buy':'sale'));
  _repData=list.map(i=>({'تاریخ':i.date,'شماره':i.no,'طرف حساب':PN(i.person),'گروه':i.group||'','اقلام':i.lines.length,'جمع':invTotal(i),'تخفیف':pd(i.discount),'پرداخت':invPaid(i),'سود':type==='sale'?invProfit(i):''}));
  _repTitle='گزارش '+invTypeFa(type==='buy'?'buy':'sale');
  return repTable(_repTitle,['تاریخ','شماره','طرف حساب','گروه','اقلام','جمع','تخفیف','پرداخت','سود'],['date','no','person','grp','lines','total','disc','paid','profit']);
 }
 if(type==='profit'){
  const list=invs.filter(i=>i.type==='sale');
  _repData=list.map(i=>({'تاریخ':i.date,'فاکتور':i.no,'مشتری':PN(i.person),'فروش':invTotal(i),'بهای خرید':invTotal(i)-invProfit(i),'سود':invProfit(i),'حاشیه٪':invTotal(i)?Math.round(invProfit(i)/invTotal(i)*100):0}));
  _repTitle='گزارش سود فروش';
  return repTable(_repTitle,['تاریخ','فاکتور','مشتری','فروش','بهای خرید','سود','حاشیه٪'],['date','no','person','sale','cost','profit','margin']);
 }
 if(type==='rec'||type==='pay'){
  const list=DB.receipts.filter(r=>inRange(r.date)&&r.dir===(type==='rec'?'in':'out'));
  _repData=list.map(r=>({'تاریخ':r.date,'شماره':r.no,'شخص':PN(r.person),'مبلغ':r.rows.reduce((s,x)=>s+pd(x.amount),0),'روش':r.rows.map(x=>METHOD_FA[x.method]||x.method).join('، '),'شرح':r.desc||''}));
  _repTitle=type==='rec'?'گزارش دریافت‌ها':'گزارش پرداخت‌ها';
  return repTable(_repTitle,['تاریخ','شماره','شخص','مبلغ','روش','شرح'],['date','no','person','amount','method','desc']);
 }
 if(type==='pgood'){
  const m={};
  invs.filter(i=>i.type==='sale').forEach(i=>i.lines.forEach(l=>{const k=l.pid;if(!m[k])m[k]={name:PR(k)?PR(k).name:'?',q:0,sale:0,cost:0};m[k].q+=l.qty;m[k].sale+=l.price*l.qty;m[k].cost+=l.cost*l.qty}));
  invs.filter(i=>i.type==='saleret').forEach(i=>i.lines.forEach(l=>{if(m[l.pid]){m[l.pid].q-=l.qty;m[l.pid].sale-=l.price*l.qty;m[l.pid].cost-=l.cost*l.qty}}));
  _repData=Object.values(m).map(x=>({'کالا':x.name,'تعداد':x.q,'فروش':x.sale,'بهای خرید':x.cost,'سود':x.sale-x.cost}));
  _repTitle='سود و زیان کالا';
  return repTable(_repTitle,['کالا','تعداد','فروش','بهای خرید','سود'],['name','q','sale','cost','profit']);
 }
 if(type==='pinv'){
  _repData=invs.filter(i=>i.type==='sale').map(i=>({'فاکتور':i.no,'تاریخ':i.date,'مشتری':PN(i.person),'فروش':invTotal(i),'سود':invProfit(i)}));
  _repTitle='سود و زیان فاکتورها';
  return repTable(_repTitle,['فاکتور','تاریخ','مشتری','فروش','سود'],['no','date','person','sale','profit']);
 }
 if(type==='pcust'){
  const m={};
  invs.filter(i=>i.type==='sale').forEach(i=>{const k=i.person;if(!m[k])m[k]={name:PN(k),n:0,sale:0,profit:0};m[k].n++;m[k].sale+=invTotal(i);m[k].profit+=invProfit(i)});
  _repData=Object.values(m).map(x=>({'مشتری':x.name,'تعداد فاکتور':x.n,'فروش':x.sale,'سود':x.profit}));
  _repTitle='سود و زیان مشتریان';
  return repTable(_repTitle,['مشتری','تعداد فاکتور','فروش','سود'],['name','n','sale','profit']);
 }
 if(type==='pnet'){
  const sales=invs.filter(i=>i.type==='sale'),rets=invs.filter(i=>i.type==='saleret'),brets=invs.filter(i=>i.type==='buyret');
  const tS=sales.reduce((s,i)=>s+invTotal(i),0),cS=sales.reduce((s,i)=>s+invTotal(i)-invProfit(i),0);
  const tR=rets.reduce((s,i)=>s+invTotal(i),0),pR=rets.reduce((s,i)=>s+invProfit(i),0);
  const tB=brets.reduce((s,i)=>s+invTotal(i),0);
  const rec=DB.receipts.filter(r=>inRange(r.date)),tIn=rec.filter(r=>r.dir==='in').reduce((s,r)=>s+r.rows.reduce((a,x)=>a+pd(x.amount),0),0),tOut=rec.filter(r=>r.dir==='out').reduce((s,r)=>s+r.rows.reduce((a,x)=>a+pd(x.amount),0),0);
  const net=(tS-tR)-(cS-pR)-tB;
  _repData=[{'شرح':'فروش ناخالص','مبلغ':tS},{'شرح':'بهای تمام‌شده کالای فروش‌رفته','مبلغ':-cS},{'شرح':'برگشت از فروش','مبلغ':-tR},{'شرح':'برگشت از خرید','مبلغ':tB},{'شرح':'جمع دریافت‌ها','مبلغ':tIn},{'شرح':'جمع پرداخت‌ها','مبلغ':-tOut},{'شرح':'سود و زیان خالص دوره','مبلغ':net}];
  _repTitle='صورت سود و زیان خالص';
  return repTable(_repTitle,['شرح','مبلغ'],['desc','amount']);
 }
 if(type==='kardex'){
  return '<div class="frow"><div class="fg"><label>کالا را انتخاب کنید (با بازه زمانی بالای صفحه فیلتر می‌شود)</label><select onchange="repKardex(this.value)" style="min-width:260px">'+DB.products.map(p=>'<option value="'+p.id+'">'+esc(p.name)+'</option>').join('')+'</select></div></div><div id="repKx">'+repKardex(DB.products[0]?DB.products[0].id:'')+'</div>';
 }
 if(type==='stock'){
  _repData=DB.products.map(p=>{const s=stockOf(p.id);return{'کد':p.code,'کالا':p.name,'موجودی تعدادی':s,'فی خرید':unitCost(p),'موجودی ریالی':s*unitCost(p)}});
  _repTitle='موجودی و ارزش انبار (وضعیت فعلی)';
  return repTable(_repTitle,['کد','کالا','موجودی تعدادی','فی خرید','موجودی ریالی'],['code','name','q','cost','val']);
 }
 if(type==='short'){
  _repData=DB.products.filter(p=>stockOf(p.id)<=p.reorder).map(p=>({'کد':p.code,'کالا':p.name,'موجودی':stockOf(p.id),'حداقل':p.minStock,'نقطه سفارش':p.reorder,'وضعیت':stockOf(p.id)<=p.minStock?'کمبود':'سفارش','پیشنهاد سفارش':Math.max(0,Math.max(p.minStock,p.reorder)*2-stockOf(p.id))}));
  _repTitle='گزارش کمبود کالا (وضعیت فعلی)';
  return repTable(_repTitle,['کد','کالا','موجودی','حداقل','نقطه سفارش','وضعیت','پیشنهاد سفارش'],['code','name','q','min','ro','st','need']);
 }
 if(type==='persons'){
  _repData=DB.persons.map(p=>{const b=personBalance(p.id);return{'کد':p.code,'شخص':p.name,'گروه':GNP(p),'موبایل':p.phone,'کد ملی':p.nationalId,'بدهی به ما':b.saleDebt,'بدهی ما':b.buyDebt,'سود ما':b.profit}});
  _repTitle='مانده حساب اشخاص (وضعیت فعلی)';
  return repTable(_repTitle,['کد','شخص','گروه','موبایل','کد ملی','بدهی به ما','بدهی ما','سود ما'],['code','name','grp','phone','nat','debt','owe','profit']);
 }
 if(type==='cheques'){
  _repData=DB.cheques.filter(c=>inRange(c.issue)||inRange(c.due)).map(c=>({'نوع':c.dir==='rec'?'دریافتی':'پرداختی','شماره':c.no,'شخص':PN(c.person),'بانک':c.bank,'تاریخ ثبت':c.issue,'سررسید':c.due,'مبلغ':c.amount,'وضعیت':c.status}));
  _repTitle='صورت وضعیت چک‌ها (بازه: ثبت یا سررسید)';
  return repTable(_repTitle,['نوع','شماره','شخص','بانک','تاریخ ثبت','سررسید','مبلغ','وضعیت'],['dir','no','person','bank','issue','due','amount','st']);
 }
 if(type==='inst'){
  _repData=DB.installments.filter(i=>inRange(i.due)).map(i=>({'شخص':PN(i.person),'قسط':i.no,'سررسید':i.due,'مبلغ':i.amount,'وضعیت':i.paid?'پرداخت‌شده':'باز','دریافتی':i.paid?(i.amountPaid||i.amount):0}));
  _repTitle='گزارش اقساط (بر اساس سررسید)';
  return repTable(_repTitle,['شخص','قسط','سررسید','مبلغ','وضعیت','دریافتی'],['person','no','due','amount','st','recv']);
 }
 if(type==='agecust'||type==='agesup'){
  const side=type==='agecust'?'cust':'sup';
  _repData=ageRows(side).map(({pid,...r})=>r);_repTitle=side==='cust'?'سن مطالبات مشتریان (تا امروز)':'سن بدهی به تامین‌کنندگان (تا امروز)';
  return repTable(_repTitle,['شخص','۰ تا ۳۰ روز','۳۱ تا ۶۰ روز','۶۱ تا ۹۰ روز','بیش از ۹۰ روز','جمع مانده'],['person','b1','b2','b3','b4','total']);
 }
 return '';
}
/* سن مطالبات/بدهی: پرداخت‌ها به قدیمی‌ترین بدهکاری تخصیص می‌یابد؛ قسط/چک‌های آینده در ستون اول می‌آید */
function ageRows(side,today){
 today=today||jToday();const cust=side==='cust',out=[];
 const buckets=d=>{const n=daysDiff(d,today);return n<=30?'b1':n<=60?'b2':n<=90?'b3':'b4'};
 DB.persons.forEach(p=>{
  const ch=[];let cr=0;
  DB.invoices.forEach(inv=>{
   if(inv.person!==p.id)return;const tot=invTotal(inv),paid=invPaid(inv);
   if(inv.type===(cust?'sale':'buy')){
    const its=cust?DB.installments.filter(i=>i.inv===inv.id):[],isum=its.reduce((s,i)=>s+Number(i.amount||0),0);
    ch.push({d:inv.date,v:Math.max(0,tot-isum)});its.forEach(i=>ch.push({d:i.due||inv.date,v:Number(i.amount||0)}));cr+=paid;
   }else if(inv.type===(cust?'saleret':'buyret'))cr+=tot-paid;
  });
  DB.receipts.forEach(r=>{if(r.person===p.id&&r.dir===(cust?'in':'out'))cr+=r.rows.reduce((s,x)=>s+pd(x.amount),0)});
  DB.cheques.forEach(c=>{if(c.status==='برگشتی'&&c.person===p.id&&(c.dir==='rec')===cust)ch.push({d:c.bouncedDate||c.due,v:Number(c.amount||0)})});
  if(!cust)(DB.expenses||[]).forEach(x=>{if(x.method==='credit'&&x.person===p.id)ch.push({d:x.date,v:Number(x.amount||0)})});
  const po=((DB.opening||{}).persons||{})[p.id]||{},ov=cust?(po.rec||0):(po.pay||0);
  if(ov>0)ch.push({d:(DB.opening||{}).date||'0000/01/01',v:ov});
  ch.sort((a,b)=>String(a.d).localeCompare(String(b.d)));
  const row={pid:p.id,person:p.name,b1:0,b2:0,b3:0,b4:0,total:0};
  ch.forEach(c=>{let v=c.v;if(cr>0){const u=Math.min(cr,v);cr-=u;v-=u}if(v>0){row[buckets(c.d)]+=v;row.total+=v}});
  if(row.total>0)out.push(row);
 });
 return out.sort((a,b)=>b.total-a.total);
}
let _repData=null,_repHTML='',_repTitle='';
function repTable(title,cols,keys){
 const numeric=['total','disc','paid','profit','sale','cost','amount','val','debt','owe','recv','need','b1','b2','b3','b4'];
 const sums={};
 keys.forEach(k=>{if(numeric.includes(k)||k==='q'||k==='n'||k==='lines')sums[k]=_repData.reduce((s,r)=>s+(Number(r[k])||0),0)});
 let html='<h3>📋 '+title+'</h3><table><thead><tr>'+cols.map(c=>'<th>'+c+'</th>').join('')+'</tr></thead><tbody>';
 html+=_repData.map(r=>'<tr>'+keys.map(k=>{
  const v=r[k];
  if(['date','due','issue','paidDate'].includes(k))return '<td>'+jShort(v)+'</td>';
  if(typeof v==='number')return '<td class="amt '+(String(k).includes('profit')||k==='sale'||k==='recv'?'pos':'')+'">'+fm(v)+'</td>';
  if(k==='st')return '<td>'+(v==='کمبود'?'<span class="bdg b-r">کمبود</span>':v==='سفارش'?'<span class="bdg b-o">سفارش</span>':v==='باز'?'<span class="bdg b-o">باز</span>':v==='پرداخت‌شده'?'<span class="bdg b-g">پرداخت‌شده</span>':esc(v))+'</td>';
  if(k==='dir')return '<td>'+(v==='دریافتی'?'<span class="bdg b-g">دریافتی</span>':'<span class="bdg b-o">پرداختی</span>')+'</td>';
  return '<td class="r">'+esc(v)+'</td>';
 }).join('')+'</tr>').join('');
 const sumStr=cols.map((c,i)=>{const k=keys[i];return sums[k]!==undefined&&sums[k]!==0?c+': '+fm(sums[k]):''}).filter(Boolean).join(' — ');
 html+='<tr style="background:#f4f8fb;font-weight:800"><td colspan="'+cols.length+'">جمع: '+(sumStr||'—')+'</td></tr>';
 html+='</tbody></table>';
 if(!_repData.length)html='<div class="empty"><div class="b">📊</div>داده‌ای در این بازه نیست</div>';
 return html;
}
function repKardex(pid){
 if(!pid)return '<div class="empty">کالایی نیست</div>';
 const p=PR(pid);if(!p)return '';
 const rows=[];
 DB.invoices.forEach(inv=>inv.lines.forEach(l=>{if(l.pid!==pid||inv.type==='proforma')return;
  if(!inRange(inv.date))return;
  let dir=1;if(inv.type==='buyret'||inv.type==='sale')dir=-1;
  const tn={buy:'خرید',buyret:'برگشت خرید',sale:'فروش',saleret:'برگشت فروش'}[inv.type];
  rows.push({d:inv.date,no:inv.no,tn,dir,q:l.qty,price:l.price,pp:PN(inv.person)});}));
 rows.sort((a,b)=>a.d<b.d?-1:1);let bal=0;
 _repData=rows.map(r=>{bal+=r.dir*r.q;return{'تاریخ':r.d,'سند':r.no,'نوع':r.tn,'طرف حساب':r.pp,'ورود/خروج':(r.dir>0?'+':'−')+r.q,'مانده تعدادی':bal,'فی':r.price,'ارزش ریالی':r.dir*r.q*r.price}});
 _repTitle='کاردکس کالا: '+p.name;
 const h=repTable(_repTitle,['تاریخ','سند','نوع','طرف حساب','ورود/خروج','مانده تعدادی','فی','ارزش ریالی'],['date','no','tn','pp','io','bal','price','val']);
 const el=$('repKx');if(el)el.innerHTML=h;
 return h;
}
function repExcel(){if(!_repData||!_repData.length){toast('⚠️ داده‌ای نیست',false);return}xlOut(_repData,'گزارش-تکنوکالا')}
function printRep(){
 if(!window._repHTML||!_repData||!_repData.length){toast('⚠️ گزارشی برای چاپ نیست',false);return}
 const[a,b]=rangeVals();
 printHTML('<h2>'+esc(_repTitle)+'</h2><p>'+esc(DB.settings.shopName)+' — بازه: '+jShort(a)+' تا '+jShort(b)+' — تاریخ چاپ: '+jLong(jToday())+'</p>'+_repHTML,'A4');
}

/* ================= چاپ (A4/A5 با تاریخ شمسی کامل) ================= */
function printHTML(bodyHtml,size){printHTMLPreview(bodyHtml,size)}
function printSection(id,title){
 const el=$(id);if(!el){toast('⚠️ بخشی برای چاپ نیست',false);return}
 const cl=el.cloneNode(true);
 cl.querySelectorAll('button,input,select,textarea,.toolbar,.searchbar').forEach(x=>x.remove());
 printHTML('<h2>'+esc(title)+'</h2><p>'+esc(DB.settings.shopName)+' — تاریخ چاپ: '+jLong(jToday())+'</p>'+cl.innerHTML,'A4');
}
function printModalTable(title){
 const tb=document.querySelector('#modal table');
 printHTML('<h2>'+esc(title)+'</h2><p>'+esc(DB.settings.shopName)+' — تاریخ: '+jLong(jToday())+'</p>'+(tb?tb.outerHTML:''),'A4');
}
/* فاکتور A4/A5 — شامل فروشگاه، مشتری، اقلام، تعداد، قیمت، تخفیف — تمام تاریخ‌ها شمسی */

/* 🧾 رسید حرارتی ۵۸/۸۰ میلی‌متری — چگال و بهینه برای پرینترهای حرارتی */
function printThermal(id,size){
 const inv=DB.invoices.find(i=>i.id===id);if(!inv)return;const s=DB.settings;const p=P(inv.person)||{};
 const t=invTotal(inv),paid=invPaid(inv),rem=t-paid;
 const isSale=(inv.type==='sale'||inv.type==='proforma'||inv.type==='saleret');
 let h='<div class="h" style="text-align:center"><h2>'+esc(s.shopName)+'</h2><div style="font-size:8px">'+esc(s.shopAddr||'')+' — تلفن: '+fa(s.shopTel||'')+'</div></div>';
 h+='<div style="text-align:center;margin:3px 0"><b>'+invTypeFa(inv.type)+'</b> — شماره: '+fa(inv.no)+' — تاریخ: '+jShort(inv.date)+'</div>';
 h+='<div style="font-size:8.5px;border-bottom:1px dashed #999;padding-bottom:3px;margin-bottom:3px">'+(isSale?'مشتری':'فروشنده')+': <b>'+esc(p.name||'—')+'</b>'+(p.phone||p.phone2?' — '+fa([p.phone,p.phone2].filter(Boolean).join('، ')):'')+(p.addr?'<br>آدرس: '+esc(p.addr):'')+'</div>';
 h+='<table><tr><th style="width:34%">شرح</th><th>تعداد</th><th>قیمت</th><th>جمع</th></tr>';
 inv.lines.forEach(l=>{const pr=PR(l.pid)||{};
  h+='<tr><td style="text-align:right;font-size:8px">'+esc(pr.name||'')+'</td><td>'+fa(l.qty)+'</td><td>'+fm(l.price)+'</td><td>'+fm(l.qty*l.price)+'</td></tr>';});
 h+='<tr><th colspan="3" style="text-align:left">جمع کل</th><th>'+fm(t+pd(inv.discount))+'</th></tr>';
 if(pd(inv.discount))h+='<tr><th colspan="3" style="text-align:left">تخفیف</th><th>'+fm(pd(inv.discount))+'</th></tr>';
 h+='<tr><th colspan="3" style="text-align:left">قابل پرداخت</th><th>'+fm(t)+'</th></tr>';
 h+='<tr><th colspan="3" style="text-align:left">پرداخت‌شده</th><th>'+fm(paid)+'</th></tr>';
 h+='<tr><th colspan="3" style="text-align:left">مانده</th><th>'+fm(rem)+'</th></tr></table>';
 const methods=(inv.pays||[]).map(x=>METHOD_FA[x.method]+': '+fm(pd(x.amount))).join(' — ');
 if(methods)h+='<p><b>تسویه:</b> '+methods+'</p>';
 const insts=DB.installments.filter(i2=>i2.inv===id);
 if(insts.length)h+='<p><b>اقساط:</b> '+insts.map(i2=>'قسط '+fa(i2.no)+' سررسید '+jShort(i2.due)+' مبلغ '+fm(i2.amount)).join('؛ ')+'</p>';
 if(inv.desc&&String(inv.desc).trim())h+='<p style="font-size:8.5px"><b>توضیحات:</b> '+esc(inv.desc)+'</p>';
 h+='<p style="text-align:center;border-top:1px dashed #999;padding-top:4px;margin-top:5px">با تشکر از خرید شما 🙏</p>';
 printHTML(h,size);
}
function printInvoiceReceipt(id){
 const inv=DB.invoices.find(i=>i.id===id);if(!inv)return;
 const paid=invPaid(inv),t=invTotal(inv);
 if(!paid){toast('⚠️ پرداختی برای این فاکتور ثبت نشده است',false);return}
 const s=DB.settings;
 const isBuy=inv.type==='buy';
 let h='<div class="h"><div><h2>'+esc(s.shopName)+'</h2><div>'+esc(s.shopAddr||'')+'</div></div><div style="text-align:left"><b>رسید '+(isBuy?'پرداخت':'دریافت')+' وجه بابت فاکتور</b><br>تاریخ: '+jLong(jToday())+'</div></div>';
 h+='<table><tr><td>'+(isBuy?'فروشنده':'مشتری')+'</td><td style="text-align:right"><b>'+esc(PN(inv.person))+'</b></td></tr>'+
 '<tr><td>فاکتور '+invTypeFa(inv.type)+'</td><td style="text-align:right">شماره '+fa(inv.no)+' — تاریخ '+jLong(inv.date)+'</td></tr>'+
 '<tr><td>مبلغ '+(isBuy?'پرداخت‌شده':'دریافت‌شده')+'</td><td style="text-align:right"><b style="font-size:15px">'+fm(paid)+' تومان</b></td></tr>'+
 '<tr><td>مانده فاکتور</td><td style="text-align:right">'+fm(t-paid)+' تومان</td></tr>'+
 ((inv.pays||[]).length?'<tr><td>روش تسویه</td><td style="text-align:right">'+inv.pays.map(x=>METHOD_FA[x.method]+(x.method==='cheque'?' ('+fa(x.chkNo||'')+'، سررسید '+jShort(x.chkDue)+')':'')+': '+fm(pd(x.amount))).join(' — ')+'</td></tr>':'')+
 '</table><div style="margin-top:34px">امضای '+(isBuy?'پرداخت‌کننده':'گیرنده')+': ................</div>';
 printHTML(h,'A5');
}
function printStatement(pid){
 const p=P(pid),b=personBalance(pid),g=p.guarantor;
 if(!p)return;
 const rows=[];
 DB.invoices.forEach(inv=>{
  if(inv.person!==pid||inv.type==='proforma')return;
  if(inv.type==='sale')rows.push({date:inv.date,desc:'فاکتور فروش شماره '+inv.no+(inv.group?' ('+inv.group+')':''),debit:invTotal(inv),credit:0});
  else if(inv.type==='saleret')rows.push({date:inv.date,desc:'برگشت از فروش شماره '+inv.no,debit:0,credit:invTotal(inv)});
 });
 DB.receipts.forEach(r=>{
  if(r.person!==pid||r.dir!=='in')return;
  const s=r.rows.reduce((a,x)=>a+pd(x.amount),0);
  rows.push({date:r.date,desc:'دریافت وجه رسید '+r.no+' — '+r.rows.map(x=>METHOD_FA[x.method]||x.method).join('، ')+(r.desc?' — '+r.desc:''),debit:0,credit:s});
 });
 rows.sort((a,b2)=>a.date<b2.date?-1:1);
 let bal=0;
 const body=rows.map(r=>{bal+=r.debit-r.credit;
  return '<tr><td>'+jShort(r.date)+'</td><td style="text-align:right">'+esc(r.desc)+'</td><td class="amt">'+(r.debit?fm(r.debit):'—')+'</td><td class="amt">'+(r.credit?fm(r.credit):'—')+'</td><td class="amt">'+fm(bal)+'</td></tr>'}).join('');
 const chqs=DB.cheques.filter(c=>c.person===pid&&c.dir==='rec'&&c.status==='جاری');
 const insts=DB.installments.filter(i=>i.person===pid&&!i.paid);
 let h='<div class="h"><div><h2>'+esc(DB.settings.shopName)+'</h2><div>'+esc(DB.settings.shopAddr||'')+' — تلفن: '+fa(DB.settings.shopTel||'')+'</div></div><div style="text-align:left"><b style="font-size:15px">صورت حساب مشتری</b><br>تاریخ تهیه: '+jLong(jToday())+'</div></div>';
 h+='<table width="75%"><tr><td>مشتری</td><td style="text-align:right"><b>'+esc(p.name)+'</b> (کد '+fa(p.code)+')</td></tr>'+
 '<tr><td>موبایل</td><td style="text-align:right">'+fa(p.phone||'-')+'</td></tr>'+
 '<tr><td>کد ملی / شغل</td><td style="text-align:right">'+fa(p.nationalId||'-')+' / '+esc(p.job||'-')+'</td></tr>'+
 '<tr><td>آدرس</td><td style="text-align:right">'+esc(p.addr||'-')+'</td></tr>'+
 (g&&g.name?'<tr><td>ضامن</td><td style="text-align:right">'+esc(g.name)+' — تلفن: '+fa(g.phone||'')+' — شغل: '+esc(g.job||'')+'</td></tr>':'')+'</table>';
 h+='<h3 style="margin:10px 0 4px">گردش حساب</h3>';
 h+='<table><tr><th>تاریخ (شمسی)</th><th>شرح</th><th>بدهکار (بدهی مشتری)</th><th>بستانکار (تسویه)</th><th>مانده</th></tr>'+
 (body||'<tr><td colspan="5">گردشی ثبت نشده</td></tr>')+
 '<tr><th colspan="4" style="text-align:left">مانده نهایی (بدهی مشتری به فروشگاه)</th><th>'+fm(b.saleDebt)+'</th></tr></table>';
 if(chqs.length)h+='<h3 style="margin:10px 0 4px">چک‌های در جریان ('+fa(chqs.length)+' فقره) — سررسید شمسی</h3><table><tr><th>شماره چک</th><th>بانک</th><th>سررسید شمسی</th><th>مبلغ</th></tr>'+chqs.map(c=>'<tr><td>'+fa(c.no||'-')+'</td><td>'+esc(c.bank||'-')+'</td><td>'+jLong(c.due)+'</td><td>'+fm(c.amount)+'</td></tr>').join('')+'</table>';
 if(insts.length)h+='<h3 style="margin:10px 0 4px">اقساط باز ('+fa(insts.length)+' قسط) — سررسید شمسی</h3><table><tr><th>قسط</th><th>سررسید شمسی</th><th>مبلغ</th></tr>'+insts.map(i=>'<tr><td>'+fa(i.no)+'</td><td>'+jLong(i.due)+'</td><td>'+fm(i.amount)+'</td></tr>').join('')+'</table>';
 h+='<div style="display:flex;justify-content:space-between;margin-top:30px"><div>امضای فروشگاه: ................</div><div>امضای مشتری: ................</div></div>';
 printHTML(h,'A4');
}
function printReceipt(id,kind){
 const r=DB.receipts.find(x=>x.id===id);if(!r)return;const s=DB.settings;
 const amt=r.rows.reduce((a,x)=>a+pd(x.amount),0);
 let h='<div class="h"><div><h2>'+esc(s.shopName)+'</h2><div>'+esc(s.shopAddr||'')+'</div></div><div style="text-align:left"><b>'+(kind==='rec'?'رسید دریافت وجه':'رسید پرداخت وجه')+'</b><br>شماره: '+fa(r.no)+'<br>تاریخ: '+jLong(r.date)+'</div></div>';
 h+='<table><tr><td>شخص</td><td style="text-align:right"><b>'+esc(PN(r.person))+'</b></td></tr><tr><td>مبلغ</td><td style="text-align:right"><b>'+fm(amt)+' تومان</b></td></tr>';
 h+='<tr><td>طریق</td><td style="text-align:right">'+r.rows.map(x=>({cash:'نقد',card:'کارت',cheque:'چک '+fa(x.chkNo||'')+' (سررسید: '+jShort(x.chkDue)+')',fish:'فیش',account:'انتقال بانکی'})[x.method]).join(' — ')+'</td></tr>';
 if(r.desc)h+='<tr><td>بابت</td><td style="text-align:right">'+esc(r.desc)+'</td></tr></table>';
 h+='<div style="margin-top:30px">امضای '+(kind==='rec'?'گیرنده':'پرداخت‌کننده')+': ................</div>';
 printHTML(h,'A5');
}

