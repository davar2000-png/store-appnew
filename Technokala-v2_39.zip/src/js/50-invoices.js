/* ================================================================
   ==================== انبار و موجودی ==============================
   ================================================================ */
const Finv={q:'',pid:'',st:'',color:''};
function vInventory(){
 let ss=DB.serials.slice();
 if(Finv.q){const q=faDig(Finv.q);ss=ss.filter(s=>{const pr=PR(s.pid)||{};const st=serialStFa(s.status);return faDig([s.sn,pr.name||'',pr.code||'',CL(s.color),s.date,st[1]].join(' ')).includes(q)})}
 if(Finv.pid)ss=ss.filter(s=>s.pid===Finv.pid);
 if(Finv.st)ss=ss.filter(s=>s.status===Finv.st);
 if(Finv.color)ss=ss.filter(s=>s.color===Finv.color);
 ss.sort((a,b)=>(a.sn>b.sn?1:-1));
 const inS=ss.filter(s=>s.status==='stock');
 const valCost=inS.reduce((t,s)=>t+s.cost,0);
 const valSell=inS.reduce((t,s)=>t+s.price,0);
 const sold=ss.filter(s=>s.status==='sold').length;
 const ret=ss.filter(s=>s.status==='returned').length;
 $('content').innerHTML=`
 <div class="pgtitle"><h1>🏬 انبار و موجودی</h1><span class="sub">کنترل سریال‌ها، موجودی تعدادی و ریالی</span></div>
 <div class="statgrid">
  <div class="stat g"><div class="l">✅ سریال در انبار</div><div class="v">${fa(inS.length)} عدد</div></div>
  <div class="stat"><div class="l">💰 ارزش انبار (فی خرید)</div><div class="v">${fm(valCost)} <small>تومان</small></div></div>
  <div class="stat g"><div class="l">🏷️ ارزش انبار (قیمت فروش)</div><div class="v">${fm(valSell)}</div></div>
  <div class="stat o"><div class="l">📈 سود بالقوه انبار</div><div class="v pos">${fm(valSell-valCost)}</div></div>
  <div class="stat"><div class="l">📤 فروخته‌شده</div><div class="v">${fa(sold)}</div></div>
  <div class="stat r"><div class="l">↩️ برگشتی</div><div class="v">${fa(ret)}</div></div>
 </div>
 <div class="card"><div class="searchbar">
  <input id="qIn" placeholder="🔍 سریال / کالا / کد / رنگ / تاریخ / وضعیت..." value="${esc(Finv.q)}" style="min-width:280px" oninput="Finv.q=this.value;vInventory();rf('qIn')">
  <select onchange="Finv.pid=this.value;vInventory()"><option value="">همه کالاها</option>${DB.products.map(p=>`<option value="${p.id}" ${Finv.pid===p.id?'selected':''}>${esc(p.name)}</option>`).join('')}</select>
  <select onchange="Finv.st=this.value;vInventory()"><option value="">همه وضعیت‌ها</option><option value="stock" ${Finv.st==='stock'?'selected':''}>در انبار</option><option value="registered" ${Finv.st==='registered'?'selected':''}>ثبت‌شده خارج از انبار</option><option value="sold" ${Finv.st==='sold'?'selected':''}>فروخته‌شده</option><option value="returned" ${Finv.st==='returned'?'selected':''}>برگشتی</option></select>
  <select onchange="Finv.color=this.value;vInventory()"><option value="">همه رنگ‌ها</option>${DB.colors.map(c=>`<option value="${c.id}" ${Finv.color===c.id?'selected':''}>${esc(c.enName||c.name)}</option>`).join('')}</select>
  <button class="btn" onclick="Finv.q='';Finv.pid='';Finv.st='';Finv.color='';vInventory()">پاک کردن</button>
 </div>
 <div class="toolbar">
  <button class="btn g" onclick="xlOut(window._invXL,'سریال‌های-انبار')">📊 خروجی اکسل سریال‌ها</button>
  <button class="btn" onclick="shortageRep()">⚠️ گزارش کمبود</button>
  <button class="btn o" onclick="stockControl()">🎛️ کنترل موجودی</button>
  <button class="btn" onclick="suppliersOfProduct('')">🚚 فروشندگان یک کالا</button>
  <button class="btn" onclick="supplierProducts('')">🏭 کالاهای یک فروشنده</button>
 </div>
 <table data-rn="0"><thead><tr><th>سریال</th><th>کالا</th><th>رنگ</th><th>فی خرید</th><th>قیمت فروش</th><th>وضعیت</th><th>تاریخ ورود</th><th>سند خرید</th><th>سند فروش</th><th>عملیات</th></tr></thead><tbody>
 ${(()=>{window._invXL=ss.map(s=>{const pr=PR(s.pid)||{};const st=serialStFa(s.status);return{'سریال':s.sn,'کد کالا':pr.code||'','کالا':pr.name||'','رنگ':CL(s.color),'قیمت خرید':s.cost,'قیمت فروش':s.price,'وضعیت':st[1],'تاریخ ورود':s.date}});return ss.map(s=>{const pr=PR(s.pid)||{};const st=serialStFa(s.status);const bi=s.buyInv?DB.invoices.find(i=>i.id===s.buyInv):null;const si=s.saleInv?DB.invoices.find(i=>i.id===s.saleInv):null;
  return `<tr><td style="font-family:monospace">${fa(s.sn)}</td><td class="r">${esc(pr.name||'?')}</td><td><span class="sw" style="background:${CLH(s.color)}"></span> ${CL(s.color)}</td><td class="amt">${fm(s.cost)}</td><td class="amt">${fm(s.price)}</td><td><span class="bdg ${st[0]}">${st[1]}</span></td><td>${jShort(s.date)}</td><td>${bi?fa(bi.no):'—'}</td><td>${si?fa(si.no):'—'}</td><td>${s.status==='stock'?`<button class="btn sm" onclick="serialsM('${s.pid}')">#️⃣</button>`:''}</td></tr>`}).join('')||'<tr><td colspan="10"><div class="empty"><div class="b">🏬</div>سریالی یافت نشد</div></td></tr>'})()}
 </tbody></table>
 <div class="sec-h">💰 موجودی ریالی به تفکیک کالا (بر اساس فی خرید)</div>
 <table data-rn="0"><thead><tr><th>کالا</th><th>موجودی تعدادی</th><th>فی خرید</th><th>موجودی ریالی</th></tr></thead><tbody>
 ${DB.products.map(p=>{const s=stockOf(p.id);return `<tr><td class="r">${esc(p.name)}</td><td class="amt">${fa(s)}</td><td class="amt">${fm(unitCost(p))}</td><td class="amt">${fm(s*unitCost(p))}</td></tr>`}).join('')||'<tr><td colspan="4"><div class="empty">کالایی نیست</div></td></tr>'}
 <tr style="background:#f4f8fb;font-weight:800"><td>جمع کل</td><td>${fa(DB.products.reduce((t,p)=>t+stockOf(p.id),0))}</td><td>—</td><td>${fm(DB.products.reduce((t,p)=>t+stockOf(p.id)*unitCost(p),0))}</td></tr>
 </tbody></table></div>`;
}

/* ================= فاکتورها ================= */
function invTypeFa(t){return{sale:'فروش',buy:'خرید',proforma:'پیش‌فاکتور',saleret:'برگشت از فروش',buyret:'برگشت از خرید'}[t]||t}
const Fv={q:'',typ:'',grp:''};
const IV={q:'',typ:'',lim:100};
function invList(kind){
 const types={sales:['sale','proforma','saleret'],purchase:['buy','buyret']}[kind];
 let list=DB.invoices.filter(i=>types.includes(i.type)).sort((a,b)=>(b.no||0)-(a.no||0));
 if(Fv.q){const q=faDig(Fv.q);list=list.filter(i=>{const hay=faDig([String(i.no),PN(i.person),i.date,i.group||'',i.desc||'',String(invTotal(i)),String(invPaid(i)),invTypeFa(i.type)].join(' '));return hay.includes(q)})}
 if(Fv.typ)list=list.filter(i=>i.type===Fv.typ);
 if(Fv.grp)list=list.filter(i=>(i.group||'')===Fv.grp);
 return list;
}
function invGroupsOf(kind){const s=new Set();invList(kind).forEach(i=>{if(i.group)s.add(i.group)});return[...s]}
function vInvoiceList(){
 const all=DB.invoices.slice().sort((a,b)=>(b.no||0)-(a.no||0));
 const iq=faDig(IV.q||''),lst=all.filter(i=>(!IV.typ||i.type===IV.typ)&&(!iq||faDig([String(i.no),PN(i.person),i.date,i.desc||'',i.group||'',String(invTotal(i)),invTypeFa(i.type)].join(' ')).includes(iq)));
 $('content').innerHTML=`<div class="pgtitle"><h1>🧾 لیست فاکتورها</h1><span class="sub">${fa(all.length)} سند ثبت‌شده</span></div>
 <div class="statgrid">
  <div class="stat o"><div class="l">📥 فاکتورهای خرید</div><div class="v">${fa(DB.invoices.filter(i=>i.type==='buy'||i.type==='buyret').length)} سند</div></div>
  <div class="stat g"><div class="l">📤 فاکتورهای فروش</div><div class="v">${fa(DB.invoices.filter(i=>i.type==='sale'||i.type==='saleret').length)} سند</div></div>
  <div class="stat"><div class="l">📝 پیش‌فاکتورها</div><div class="v">${fa(DB.invoices.filter(i=>i.type==='proforma').length)} سند</div></div>
 </div>
 <div class="card"><h3>دسترسی سریع</h3><div class="toolbar">
  <button class="btn p" onclick="nav('purchase')">📥 لیست خرید</button>
  <button class="btn g" onclick="nav('sales')">📤 لیست فروش</button>
  <button class="btn" onclick="invForm('buy')">＋ فاکتور خرید</button>
  <button class="btn" onclick="invForm('sale')">＋ فاکتور فروش</button>
  <button class="btn o" onclick="invForm('proforma')">📝 پیش‌فاکتور</button>
 </div></div>
 <div class="card"><h3>🧾 همه فاکتورها <span class="sub">(${fa(lst.length)} مورد)</span></h3>
  <div class="searchbar"><input id="ivQ" placeholder="🔍 شماره، طرف حساب، تاریخ، مبلغ، شرح..." value="${esc(IV.q)}" style="min-width:280px" oninput="IV.q=this.value;IV.lim=100;vInvoiceList();rf('ivQ')">
   <select onchange="IV.typ=this.value;IV.lim=100;vInvoiceList()"><option value="">همه انواع</option>${[['sale','فروش'],['proforma','پیش‌فاکتور'],['saleret','برگشت از فروش'],['buy','خرید'],['buyret','برگشت از خرید']].map(([v,n])=>`<option value="${v}" ${IV.typ===v?'selected':''}>${n}</option>`).join('')}</select>
   <button class="btn" onclick="IV.q='';IV.typ='';IV.lim=100;vInvoiceList()">پاک کردن</button></div>
  <table data-rn="0"><thead><tr><th>شماره</th><th>تاریخ</th><th>نوع</th><th>طرف حساب</th><th>اقلام</th><th>جمع</th><th>پرداخت</th><th>مانده</th><th>عملیات</th></tr></thead><tbody>
  ${lst.slice(0,IV.lim).map(i=>{const t=invTotal(i),pd2=invPaid(i),rem=t-pd2;return `<tr><td><b>${fa(i.no)}</b></td><td>${jShort(i.date)}</td><td><span class="bdg ${i.type==='buy'?'b-o':i.type==='sale'?'b-g':i.type==='proforma'?'b-b':'b-r'}">${invTypeFa(i.type)}</span></td><td class="r">${esc(PN(i.person))}</td><td>${fa(i.lines.length)} قلم</td><td class="amt">${fm(t)}</td><td class="amt pos">${fm(pd2)}</td><td class="amt ${rem>0?'neg':'pos'}">${fm(rem)}</td><td style="white-space:nowrap"><button class="btn sm" onclick="invView('${i.id}')">👁️ مشاهده</button> <button class="btn sm o" onclick="invForm('${i.type}','${i.id}')">✏️ ویرایش</button> ${invPrintBtns(i)}</td></tr>`}).join('')||'<tr><td colspan="9"><div class="empty">فاکتوری یافت نشد</div></td></tr>'}
  </tbody></table>
  ${lst.length>IV.lim?`<div style="text-align:center;margin-top:8px"><button class="btn" onclick="IV.lim+=100;vInvoiceList()">نمایش بیشتر (${fa(lst.length-IV.lim)} مورد دیگر)</button></div>`:''}</div>`;
}
function vSales(){renderInvList('sales')}
function vPurchase(){renderInvList('purchase')}
function renderInvList(kind){
 const isSale=kind==='sales';
 const list=invList(kind);
 const titles={sales:'🧾 فروش (فاکتور فروش، پیش‌فاکتور، برگشت از فروش)',purchase:'📥 خرید (فاکتور خرید، برگشت از خرید، پرداخت خرید)'};
 const _pg_invlist=pgSlice('invlist',list,kind+JSON.stringify(Fv),()=>renderInvList(kind));
 $('content').innerHTML=`
 <div class="pgtitle"><h1>${titles[kind]}</h1><span class="sub">${fa(list.length)} سند</span></div>
 <div class="card"><div class="searchbar">
  <input id="qIn" placeholder="🔍 شماره فاکتور، طرف حساب، تاریخ، مبلغ، وضعیت..." value="${esc(Fv.q)}" style="min-width:280px" oninput="Fv.q=this.value;${isSale?'vSales()':'vPurchase()'};rf('qIn')">
  <select onchange="Fv.typ=this.value;${isSale?'vSales()':'vPurchase()'}"><option value="">همه انواع</option>${isSale?'<option value="sale" '+(Fv.typ==='sale'?'selected':'')+'>فروش</option><option value="proforma" '+(Fv.typ==='proforma'?'selected':'')+'>پیش‌فاکتور</option><option value="saleret" '+(Fv.typ==='saleret'?'selected':'')+'>برگشت از فروش</option>':'<option value="buy" '+(Fv.typ==='buy'?'selected':'')+'>خرید</option><option value="buyret" '+(Fv.typ==='buyret'?'selected':'')+'>برگشت از خرید</option>'}</select>
  <select onchange="Fv.grp=this.value;${isSale?'vSales()':'vPurchase()'}"><option value="">همه گروه‌ها</option>${invGroupsOf(kind).map(g=>`<option ${Fv.grp===g?'selected':''}>${esc(g)}</option>`).join('')}</select>
  <button class="btn" onclick="Fv.q='';Fv.typ='';Fv.grp='';${isSale?'vSales()':'vPurchase()'}">پاک کردن</button>
 </div>
 <div class="toolbar">
  ${isSale?`<button class="btn p" onclick="invForm('sale')">＋ فاکتور فروش</button>
  <button class="btn g" onclick="posOpen()" title="فروش سریع (POS) — میانبر F9">🛒 فروش سریع (F9)</button>
  <button class="btn" onclick="invForm('proforma')">📝 پیش‌فاکتور</button>
  <button class="btn o" onclick="invForm('saleret')">↩️ برگشت از فروش</button>`
  :`<button class="btn p" onclick="invForm('buy')">＋ فاکتور خرید</button>
  <button class="btn o" onclick="invForm('buyret')">↩️ برگشت از خرید</button>
  <button class="btn" onclick="settleForm('out')">💸 پرداخت به فروشنده</button>`}
  <button class="btn g" onclick="invExcel('${kind}')">📊 خروجی اکسل</button>
 </div>
 ${pgBar('invlist','top')}<table data-rn="invlist"><thead><tr><th>شماره</th><th>تاریخ</th><th>نوع</th><th>گروه</th><th>طرف حساب</th><th>اقلام</th><th>جمع</th><th>تخفیف</th><th>پرداخت</th><th>مانده</th><th>سود</th>${!isSale?'<th>تحویل کالا</th>':''}<th>عملیات</th></tr></thead><tbody>
 ${_pg_invlist.map(i=>{const t=invTotal(i),p=invPaid(i),rem=t-p;
  return `<tr><td><b>${fa(i.no)}</b></td><td>${jShort(i.date)}</td>
  <td><span class="bdg ${i.type==='sale'?'b-g':i.type==='proforma'?'b-b':i.type==='buy'?'b-o':'b-r'}">${invTypeFa(i.type)}</span></td>
  <td>${esc(i.group||'—')}</td><td class="r">${esc(PN(i.person))}</td><td>${fa(i.lines.length)} قلم</td>
  <td class="amt">${fm(t)}</td><td class="amt">${fm(pd(i.discount))}</td><td class="amt pos">${fm(p)}</td>
  <td class="amt ${rem>0?'neg':'pos'}">${fm(rem)}</td>
  <td class="amt ${i.type==='sale'?'pos':''}">${i.type==='sale'?fm(invProfit(i)):'—'}</td>
    ${!isSale?`<td><label style="display:flex;align-items:center;justify-content:center;gap:5px"><input type="checkbox" ${i.delivered?'checked':''} onchange="setInvoiceDelivered('${i.id}',this.checked)"> تحویل شد</label></td>`:''}
  <td style="white-space:nowrap">
   <button class="btn sm" onclick="invView('${i.id}')">👁️</button>
   <button class="btn sm" onclick="invForm('${i.type}','${i.id}')">✏️</button>
   ${invPrintBtns(i)}
   ${i.type==='proforma'?`<button class="btn sm g" onclick="proformaConv('${i.id}')">➡️ فروش</button>`:''}
   <button class="btn sm r" onclick="invDel('${i.id}')">🗑️</button>
  </td></tr>`}).join('')||'<tr><td colspan="'+(isSale?12:13)+'"><div class="empty"><div class="b">🧾</div>فاکتوری یافت نشد</div></td></tr>'}
 </tbody></table>${pgBar('invlist')}</div>`;
}
function setInvoiceDelivered(id,delivered){const inv=DB.invoices.find(i=>i.id===id);if(!inv)return;inv.delivered=!!delivered;inv.deliveredDate=delivered?jToday():'';saveDB();toast(delivered?'✅ تحویل کالا ثبت شد':'تحویل کالا لغو شد');if(curView==='dash')renderDash()}
function invExcel(kind){xlOut(invList(kind).map(i=>({'شماره':i.no,'تاریخ':i.date,'نوع':invTypeFa(i.type),'طرف حساب':PN(i.person),'گروه':i.group||'','جمع':invTotal(i),'تخفیف':pd(i.discount),'پرداخت':invPaid(i),'سود':i.type==='sale'?invProfit(i):'','شرح':i.desc||''})),'فاکتورها-تکنوکالا')}

window.L=[];window.PAY=[];window.PLAN=null;window._planTmp=null;
function invForm(kind,id){
 const isBuy=kind==='buy'||kind==='buyret';
 const inv=id?DB.invoices.find(i=>i.id===id):null;
 window.L=inv?JSON.parse(JSON.stringify(inv.lines)):[];
 window.PAY=inv?JSON.parse(JSON.stringify(inv.pays||[])):[];
 window._invKind=kind;window._invId=id||'';
 const ctr=isBuy?'buy':(kind==='proforma'?'pro':'sale');
 window._invNo=inv?inv.no:(DB.counters[ctr]||1000)+1;
 window.PLAN=(inv&&inv.installPlan)?JSON.parse(JSON.stringify(inv.installPlan)):null;
 window._planTmp=window.PLAN?JSON.parse(JSON.stringify(window.PLAN)):null;
 window.CHKPLAN=(inv&&inv.checkPlan)?JSON.parse(JSON.stringify(inv.checkPlan)):null;
 window._chkPlanTmp=window.CHKPLAN?JSON.parse(JSON.stringify(window.CHKPLAN)):null;
 const personsOpt=sel=>DB.persons.filter(p=>!isBuy||isSupplierPerson(p)).map(p=>'<option value="'+p.id+'" '+(sel===p.id?'selected':'')+'>'+esc(p.name)+' — '+GNP(p)+'</option>').join('');
 openM(mHead((id?'✏️ ویرایش ':'＋ ')+invTypeFa(kind)+(inv?' شماره '+fa(inv.no):' (شماره در لحظه ثبت تخصیص می‌یابد)'))+
 '<div class="mbody">'+
 '<div class="frow">'+
 '<div class="fg"><label>تاریخ میلادی *</label><div style="display:flex;gap:6px;align-items:center"><input id="ivDatePicker" type="date" value="'+jIso(inv?inv.date:jToday())+'" onchange="invoiceDatePicked(this.value)" title="انتخاب تاریخ میلادی" style="width:150px;height:34px"><span style="font-size:11.5px;color:var(--mut)">شمسی: <b id="ivDateFa">'+fa(inv?inv.date:jToday())+'</b></span><button class="btn sm" onclick="$(\'ivDatePicker\').value=jIso(jToday());invoiceDatePicked($(\'ivDatePicker\').value)">امروز</button></div><input type="hidden" id="ivDate" value="'+(inv?inv.date:jToday())+'"></div>'+ 
 '<div class="fg"><label>'+(isBuy?'فروشنده':'مشتری')+' *</label><input id="ivPersonSearch" placeholder="جستجوی نام..." oninput="filterInvoicePersons(this.value)" style="min-width:180px"><select id="ivPerson" style="min-width:210px" onchange="if(this.value===\'__new\')quickPerson();fillSupplierInfo();updSupBal();updCustBal()">'+personsOpt(inv?inv.person:'')+'<option value="__new">＋ شخص جدید (سریع)...</option></select>'+(isBuy?'<button class="btn sm" onclick="supplierM()">مدیریت فروشندگان</button>':'')+'</div>'+ 
 (kind==='buy'?'<div class="fg"><label>وضعیت حساب فروشنده</label><span id="ivSupBal" style="font-size:11.5px;padding-top:8px;display:inline-block;color:#7a8a99"></span></div>':'')+
 (kind==='sale'?'<div class="fg"><label>آخرین وضعیت حساب مشتری</label><span id="ivCustBal" style="font-size:11.5px;padding-top:8px;display:inline-block;color:#7a8a99">—</span></div>':'')+
 (kind==='sale'?'<div class="fg"><label>درصد سود روی قیمت‌ها</label><input id="ivPct" class="money" style="width:80px" placeholder="٪"><button class="btn sm" onclick="applyPct()">اعمال</button></div>':'')+
 '</div>'+
 '<table><thead><tr><th>#</th><th style="min-width:160px">کالا</th><th>موجودی فعلی</th>'+((kind==='buy'||kind==='sale')?'':'<th>سریال</th>')+(kind==='sale'?'':'<th>رنگ</th>')+'<th>تعداد</th><th style="min-width:115px">قیمت واحد</th>'+(kind==='buy'?'<th>قیمت فروش (هنگام خرید)</th>':'')+(kind==='sale'?'<th>بهای خرید (فی)</th><th>سود</th>':'')+'<th>جمع</th><th></th></tr></thead><tbody id="linesTb"></tbody></table>'+ 
'<div class="toolbar" style="margin-top:8px"><button class="btn sm p" onclick="rowAdd()">＋ افزودن قلم</button>'+(kind==='buy'?'<button class="btn sm" onclick="pendToggle()">📥 کالاهای معرفی‌شده (در انتظار خرید)</button>':'')+ 
 (kind==='sale'?'<span style="font-size:11px;color:#7a8a99">💡 قیمت فروش: دستی (مستقل هر سطر) یا درصدی (با دکمه «اعمال» بالای فرم)</span>':'')+
 '</div>'+
  (kind==='buy'?'<div id="pendBox" style="display:none;margin-top:8px"></div>':'')+
'<div class="inv-bottom"><div>'+
  '<div class="sec-h">💱 تسویه '+(kind==='buy'?'(پرداخت خرید)':'')+' — نقدی'+(kind==='sale'?'، طرح فروش اقساطی، طرح فروش با چک':'، چک')+'</div>'+ 
 '<table><thead><tr><th>روش</th><th>مبلغ</th><th>توضیح / مشخصات چک</th><th></th></tr></thead><tbody id="paysTb"></tbody></table>'+ 
 '<div class="toolbar" style="margin-top:6px"><button class="btn sm" onclick="payAdd()">＋ ردیف پرداخت</button><button class="btn sm g" onclick="payFillRemainder()">⚡ مانده → نقد (تسویه سریع)</button><span style="font-size:11px;color:#7a8a99">چند ردیف = پرداخت ترکیبی | باقیمانده = نسیه | اقساط = بخش «طرح اقساط»</span></div>'+
 (kind==='sale'?'<div class="inlbox" style="margin-top:10px"><b style="font-size:12px">📅 طرح اقساط:</b> <button class="btn sm o" onclick="toggleId(\'planBox\')">مدیریت اقساط</button> <span id="planInfo" style="font-size:11.5px;color:#7a8a99"></span>'+
 '<div id="planBox" style="display:none;margin-top:10px">'+
 '<div class="frow"><div class="fg"><label>تعداد اقساط</label><input id="plN" class="money" value="'+(window.PLAN?window.PLAN.count:4)+'" style="width:80px"></div>'+
 '<div class="fg"><label>فاصله (ماه)</label><input id="plGap" class="money" value="'+(window.PLAN?window.PLAN.gap:1)+'" style="width:70px"></div>'+
 '<div class="fg"><label>اولین سررسید</label><input id="plFirst" value="'+(window.PLAN?window.PLAN.first:jAddM(jToday(),1))+'" style="width:110px"></div>'+
 '<button class="btn sm p" onclick="planGenInline()">ساخت جدول</button><button class="btn sm g" onclick="planConfirm()">تایید اقساط</button></div>'+
 '<div id="plPrev"></div></div></div><div class="inlbox" style="margin-top:10px"><b style="font-size:12px">🏦 طرح فروش با چک:</b> <button class="btn sm o" onclick="toggleId(\'checkPlanBox\')">مدیریت چک</button> <span id="checkPlanInfo" style="font-size:11.5px;color:#7a8a99"></span><div id="checkPlanBox" style="display:none;margin-top:10px"><div class="frow"><div class="fg"><label>تعداد چک</label><input id="chN" class="money" value="'+(window.CHKPLAN?window.CHKPLAN.count:1)+'" style="width:80px"></div><div class="fg"><label>سریال شروع</label><input id="chStart" value="'+(window.CHKPLAN?esc(window.CHKPLAN.startSerial||window.CHKPLAN.startNo||''):'')+'" placeholder="1206/123456" style="width:130px;direction:ltr"></div><div class="fg"><label>نام بانک</label><input id="chBank" value="'+(window.CHKPLAN?esc(window.CHKPLAN.bank||''):'')+'" style="width:110px"></div><div class="fg"><label>شعبه</label><input id="chBranch" value="'+(window.CHKPLAN?esc(window.CHKPLAN.branch||''):'')+'" style="width:90px"></div><div class="fg"><label>اولین سررسید</label><input id="chFirst" value="'+(window.CHKPLAN?window.CHKPLAN.first:jAddM(jToday(),1))+'" style="width:110px"></div><button class="btn sm p" onclick="checkPlanGen()">ساخت جدول چک‌ها</button><button class="btn sm g" onclick="checkPlanConfirm()">تایید چک‌ها</button></div><div id="chPrev"></div></div></div>':'')+
 '</div><div>'+
  '<div class="frow" style="margin-top:0;align-items:flex-end">'+
  '<div class="fg"><label>تخفیف (تومان)</label><input id="ivDisc" class="money" style="width:130px" value="'+fm(inv?pd(inv.discount):0)+'" oninput="recalc()"></div>'+
 '<div class="fg"><label>شرح</label><input id="ivDesc" value="'+esc(inv?inv.desc||'':'')+'" style="min-width:220px"></div></div>'+
  '<div id="totBox" style="margin-top:6px;font-size:13px"></div>'+
 '<div id="warnBox"></div>'+
  '</div></div>'+
 '</div>'+
 '<div class="mfoot"><button class="btn p" onclick="invSave()">💾 ثبت نهایی</button><button class="btn" onclick="closeM()">انصراف</button></div>',true);
 {const mm=document.querySelector('#modal .m');if(mm){mm.classList.add('pwfull');$('modal').classList.add('pwfull')}}
  rowAddRenderAll();payRenderAll();recalc();if(kind==='sale'&&window.CHKPLAN){const el=$('checkPlanInfo');if(el)el.textContent='✅ '+fa(window.CHKPLAN.count)+' چک ثبت‌شده'}fillSupplierInfo();updSupBal();updCustBal();
}
function toggleId(id){const el=$(id);if(el)el.style.display=el.style.display==='none'?'':'none'}
function updSupBal(){
 const el=$('ivSupBal');if(!el)return;
 const pid=($('ivPerson')||{}).value;
 if(!pid||pid==='__new'){el.innerHTML='—';return}
 const b=personBalance(pid);
 el.innerHTML=(b.buyDebt>0?'⚠️ ما بدهکاریم: ':'✅ مانده: ')+'<b class="'+(b.buyDebt>0?'neg':'pos')+'">'+fm(b.buyDebt)+' تومان</b>';
}
function updCustBal(){
 const el=$('ivCustBal');if(!el)return;
 const pid=($('ivPerson')||{}).value;
 if(!pid||pid==='__new'){el.innerHTML='—';return}
 const b=personBalance(pid);
 el.innerHTML=(b.saleDebt>0?'⚠️ بدهکار: ':'✅ تسویه/بستانکار: ')+'<b class="'+(b.saleDebt>0?'neg':'pos')+'">'+fm(b.saleDebt)+' تومان</b>';
}
function fillSupplierInfo(){
 const select=$('ivPerson'),person=select&&P(select.value);if(!person)return;
 if($('ivNationalId'))$('ivNationalId').value=person.nationalId||'';
 if($('ivAddr'))$('ivAddr').value=person.addr||'';
 if($('ivPhone2'))$('ivPhone2').value=person.phone2||'';
 if($('ivWebsite'))$('ivWebsite').value=person.website||'';
}
function isSupplierPerson(person){
 return pGroups(person).some(id=>isSupplierGroup(DB.personGroups.find(g=>g.id===id)));
}
function filterInvoicePersons(query){
 const select=$('ivPerson');if(!select)return;
 const q=faDig(query||'').trim();
 [...select.options].forEach(option=>{option.hidden=!!q&&option.value!=='__new'&&!faDig(option.textContent).includes(q)});
 const first=[...select.options].find(option=>!option.hidden&&option.value!=='__new');
 if(q&&first)select.value=first.value;
 updSupBal();updCustBal();
}
function bsUpdSell(){const pid=$('bsPid').value;const p=PR(pid);if(p)$('bsSell').value=fm(p.sellPrice||0)}
function quickPerson(){
 const sel=$('ivPerson');if(!sel)return;
 openM(mHead('＋ درج سریع شخص')+'<div class="mbody"><div class="frow"><div class="fg"><label>نام شخص *</label><input id="qpName"></div><div class="fg"><label>موبایل</label><input id="qpPhone"></div></div><div class="frow"><div class="fg"><label>تلفن ثابت</label><input id="qpPhone2"></div><div class="fg"><label>کد ملی</label><input id="qpNationalId"></div></div><div class="fg"><label>آدرس</label><input id="qpAddr"></div><div class="fg"><label>آدرس سایت</label><input id="qpWebsite"></div></div><div class="mfoot"><button class="btn p" onclick="quickPersonSave()">💾 ذخیره</button><button class="btn" onclick="closeM();$(\'ivPerson\').value=\'\'">انصراف</button></div>');
}
function quickPersonSave(){
 const sel=$('ivPerson'),name=$('qpName').value.trim();if(!sel||!name){toast('⚠️ نام شخص الزامی است',false);return}
 const phone=$('qpPhone').value||'',phone2=$('qpPhone2').value||'',nationalId=$('qpNationalId').value||'',addr=$('qpAddr').value||'',website=$('qpWebsite').value||'';
 if(DB.persons.some(x=>x.name===name)){toast('⚠️ این شخص قبلاً ثبت شده است',false);return}
 const p={id:uid(),code:++DB.counters.person,name:name.trim(),group:window._invKind==='buy'||window._invKind==='buyret'?supplierGroupId():(DB.personGroups[0]?DB.personGroups[0].id:''),phone:faDig(phone),phone2:faDig(phone2),nationalId:faDig(nationalId).trim(),job:window._invKind==='buy'||window._invKind==='buyret'?'فروشنده':'',empNo:'',card:'',addr,website,photo:'',docs:[],guarantor:null,notes:'',created:jToday()};
 DB.persons.push(p);logAct('ثبت سریع شخص: '+p.name);saveDB();closeM();
 const o=document.createElement('option');o.value=p.id;o.textContent=p.name;sel.insertBefore(o,sel.children[sel.children.length-1]);sel.value=p.id;
 fillSupplierInfo();toast('✅ «'+p.name+'» اضافه شد (تکمیل پرونده از بخش اشخاص)');
}
function supplierM(){
 const search=$('supplierSearch')?$('supplierSearch').value:'';
 const suppliers=DB.persons.filter(isSupplierPerson).filter(p=>!search||faDig(p.name).includes(faDig(search)));
 openM(mHead('مدیریت فروشندگان')+'<div class="mbody">'+
 '<div class="frow"><input id="supplierSearch" value="'+esc(search)+'" placeholder="جستجوی فروشنده..." oninput="supplierM()"><button class="btn p" onclick="supplierAdd()">＋ درج فروشنده</button></div>'+
 '<table data-rn="0"><thead><tr><th>نام فروشنده</th><th>موبایل</th><th>عملیات</th></tr></thead><tbody>'+suppliers.map(p=>'<tr><td class="r"><b>'+esc(p.name)+'</b></td><td>'+fa(p.phone||'—')+'</td><td><button class="btn sm" onclick="supplierEdit(\''+p.id+'\')">✏️</button><button class="btn sm r" onclick="supplierDelete(\''+p.id+'\')">🗑️</button></td></tr>').join('')+'</tbody></table></div><div class="mfoot"><button class="btn" onclick="closeM()">بستن</button></div>');
}
function supplierGroupId(){
 let group=DB.personGroups.find(isSupplierGroup);
 if(!group){group={id:uid(),name:'فروشنده/تامین‌کننده',supplier:true};DB.personGroups.push(group);saveDB()}
 return group.id;
}
function supplierAdd(){
 openM(mHead('＋ درج فروشنده')+'<div class="mbody"><div class="frow"><div class="fg"><label>نام فروشنده *</label><input id="supName"></div><div class="fg"><label>موبایل</label><input id="supPhone"></div></div></div><div class="mfoot"><button class="btn p" onclick="supplierSave()">💾 ذخیره</button><button class="btn" onclick="supplierM()">انصراف</button></div>');
}
function supplierSave(){
 const name=$('supName').value.trim(),phone=$('supPhone').value||'';if(!name){toast('⚠️ نام فروشنده الزامی است',false);return}
 if(DB.persons.some(p=>p.name===name)){toast('⚠️ این نام قبلاً ثبت شده است',false);return}
 const p={id:uid(),code:++DB.counters.person,name,group:supplierGroupId(),phone:faDig(phone),phone2:'',nationalId:'',job:'فروشنده',empNo:'',card:'',addr:'',photo:'',docs:[],guarantor:null,notes:'',created:jToday()};
 DB.persons.push(p);logAct('درج فروشنده: '+name);saveDB();supplierM();toast('✅ فروشنده درج شد');
}
function supplierEdit(id){
 const p=P(id);if(!p)return;const name=prompt('نام جدید فروشنده:',p.name);if(!name||!name.trim())return;
 p.name=name.trim();const phone=prompt('موبایل:',p.phone||'');if(phone!==null)p.phone=faDig(phone);
 logAct('ویرایش فروشنده: '+p.name);saveDB();supplierM();toast('✅ فروشنده ویرایش شد');
}
function supplierDelete(id){
 const p=P(id);if(!p)return;
 if(DB.invoices.some(i=>i.person===id)||DB.receipts.some(r=>r.person===id)){toast('⚠️ این فروشنده در اسناد مالی استفاده شده و قابل حذف نیست',false);return}
 confirmM('حذف فروشنده «'+esc(p.name)+'»؟',()=>{DB.persons=DB.persons.filter(x=>x.id!==id);logAct('حذف فروشنده: '+p.name);saveDB();supplierM();toast('🗑️ فروشنده حذف شد')});
}
function prodOpts(sel){return '<option value="">— انتخاب کالا —</option>'+DB.products.map(p=>'<option value="'+p.id+'" '+(sel===p.id?'selected':'')+'>'+esc(p.code+' — '+p.name)+'</option>').join('')}
function serialOpts(pid,cur,mode){
 const p=PR(pid);if(!p||p.track!=='serial')return '<option value="">—</option>';
 let ss=DB.serials.filter(s=>s.pid===pid);
 if(mode==='sale')ss=ss.filter(s=>s.status==='stock');
 if(mode==='saleret')ss=ss.filter(s=>s.status==='sold');
 if(mode==='buyret')ss=ss.filter(s=>s.status==='stock');
 const opts=ss.map(s=>'<option value="'+s.id+'" '+(cur===s.id?'selected':'')+'>'+fa(s.sn)+' ('+CL(s.color)+') — خرید: '+fm(s.cost)+'</option>');
 if(cur&&!ss.some(s=>s.id===cur)){const s=DB.serials.find(x=>x.id===cur);if(s)opts.unshift('<option value="'+cur+'" selected>'+fa(s.sn)+' (سریال فعلی این فاکتور)</option>')}
 return '<option value="">— انتخاب سریال —</option>'+opts.join('');
}
/* ---- کالاهای معرفی‌شده که هنوز خریده نشده‌اند (در فاکتور خرید) ---- */
function pendList(){
 const used=new Set((window.L||[]).map(l=>l.sn).filter(Boolean));
 return DB.serials.filter(s=>s.status==='registered'&&PR(s.pid)&&!used.has(s.sn));
}
function pendToggle(){
 const b=$('pendBox');if(!b)return;
 if(b.style.display!=='none'){b.style.display='none';return}
 const list=pendList();
 b.innerHTML=list.length
  ?'<div class="notice" style="margin-bottom:6px">کالاهای معرفی‌شده‌ای که هنوز وارد انبار نشده‌اند را انتخاب کنید تا به این فاکتور خرید اضافه شوند.</div>'+
   '<div style="max-height:220px;overflow:auto;border:1px solid var(--bd);border-radius:8px;padding:6px">'+
   '<label class="pw-inl" style="margin-bottom:6px"><input type="checkbox" onchange="document.querySelectorAll(\'.pendCk\').forEach(c=>c.checked=this.checked)"> انتخاب همه</label>'+
   list.map(s=>'<label class="pw-inl" style="display:flex;padding:3px 0;white-space:normal"><input type="checkbox" class="pendCk" value="'+s.id+'"> <span dir="ltr">'+esc((PR(s.pid)||{}).name||'?')+'</span> <b dir="ltr">'+esc(s.sn)+'</b> <span style="color:var(--mut)">— خرید: '+fm(s.cost)+'</span></label>').join('')+'</div>'+
   '<div style="margin-top:6px"><button class="btn sm g" onclick="pendAdd()">✅ افزودن انتخاب‌شده‌ها به فاکتور</button></div>'
  :'<div class="notice">کالای معرفی‌شده‌ی در انتظار خرید وجود ندارد. ابتدا از «معرفی کالا» کالا را تعریف کنید.</div>';
 b.style.display='block';
}
function pendAdd(){
 const ids=[...document.querySelectorAll('.pendCk:checked')].map(c=>c.value);
 if(!ids.length){toast('⚠️ موردی انتخاب نشده',false);return}
 ids.forEach(id=>{const s=DB.serials.find(x=>x.id===id);if(!s)return;
  window.L.push({pid:s.pid,sid:'',sn:s.sn,color:s.color||'',qty:1,price:s.cost||0,cost:s.cost||0,sellAtBuy:s.price||0})});
 window.L=window.L.filter(l=>l.pid||l.sn);
 $('pendBox').style.display='none';rowAddRenderAll();recalc();
 toast('✅ '+fa(ids.length)+' کالا به فاکتور خرید اضافه شد');
}
function rowAdd(){window.L.push({pid:'',sid:'',sn:'',color:'',qty:1,price:0,cost:0,sellAtBuy:0});rowAddRenderAll();recalc();const ix=window.L.length-1;setTimeout(()=>{const e=$('pcbIn_'+ix);if(e)e.focus()},30)}
function rowDel(i){window.L.splice(i,1);rowAddRenderAll();recalc()}
function rowAddRenderAll(){
 const kind=window._invKind;const isBuy=kind==='buy';
 const tb=$('linesTb');if(!tb)return;
 tb.innerHTML=window.L.map((l,i)=>{
  const serialCell=isBuy
   ?`<input style="max-width:150px;direction:ltr;font-size:11px" placeholder="شماره سریال" value="${esc(l.sn||'')}" oninput="window.L[${i}].sn=this.value">`
   :`<select style="max-width:165px;font-size:11px" onchange="rowSerialChange(this,${i})">${serialOpts(l.pid,l.sid,kind)}</select>`;
  const sellCell=isBuy?`<td><input id="rsl_${i}" class="money" style="width:110px" value="${fm(l.sellAtBuy||((PR(l.pid)||{}).sellPrice||0))}" oninput="window.L[${i}].sellAtBuy=pd(this.value);window.L[${i}].sellManual=1"></td>`:'';
  return `<tr>
  <td>${fa(i+1)}</td>
<td><div class="pcb"><input id="pcbIn_${i}" class="pcb-in" autocomplete="off" placeholder="🔍 جستجوی کالا: نام، کد، مدل یا سریال…" value="${esc(pcbText(l.pid))}" onfocus="pcbOpen(${i},true)" oninput="pcbOpen(${i})" onkeydown="pcbKey(event,${i})" onblur="pcbClose()"></div>${(isBuy||kind==='sale')&&l.sn?`<div dir="ltr" style="font-size:10.5px;color:var(--mut);margin-top:2px">#️⃣ ${esc(l.sn)}</div>`:''}</td>
  <td class="amt" id="rstock_${i}">${fa(l.pid?stockOf(l.pid):0)}</td>
  ${isBuy||kind==='sale'?'':`<td>${serialCell}</td>`}
  ${kind==='sale'?'':rowColorCell(i,l)}
  <td><input id="rq_${i}" class="money" style="width:64px" value="${fm(l.qty)}" oninput="rowUpd(${i})"></td>
  <td><input id="rp_${i}" class="money" style="width:115px" value="${fm(l.price)}" oninput="rowUpd(${i})"></td>
  ${sellCell}
  ${kind==='sale'?`<td><input id="rkc_${i}" class="money" style="width:115px" value="${fm(l.cost)}" oninput="rowUpd(${i})"></td><td class="amt pos" id="rpr_${i}">${fm((l.price-l.cost)*l.qty)}</td>`:''}
  <td class="amt" id="rt_${i}">${fm(l.qty*l.price)}</td>
  <td><button class="btn sm r" onclick="rowDel(${i})">✕</button></td>
 </tr>`}).join('');
}
/* ===== جستجوی کالا در ردیف‌های فاکتور (نام، کد، برند/مدل، شماره سریال) ===== */
let _pcbHi=0,_pcbRes=[],_pcbRow=-1;
function pcbText(pid){const p=PR(pid);return p?p.code+' — '+p.name:''}
function pcbSearch(q){
 const toks=faDig(q||'').toLowerCase().split(/\s+/).filter(Boolean),kind=window._invKind,res=[];
 const serByP={};DB.serials.forEach(x=>{(serByP[x.pid]=serByP[x.pid]||[]).push(x)});
 for(const p of DB.products){
  if(p.active===false)continue;
  const base=faDig([p.code,p.name,p.brand||'',p.model||''].join(' ')).toLowerCase(),ss=(serByP[p.id]||[]).filter(x=>kind==='sale'?x.status==='stock':true);
  let ok=true,hit=null;
  for(const t of toks){
   if(base.includes(t))continue;
   const x=ss.find(z=>faDig(String(z.sn)).toLowerCase().includes(t));
   if(x){hit=x;continue}
   ok=false;break;
  }
  if(ok)res.push({p,hit});
 }
 return res;
}
function pcbEl(){let e=$('pcbList');if(!e){e=document.createElement('div');e.id='pcbList';e.style.display='none';document.body.appendChild(e)}return e}
function pcbOpen(i,sel){
 const inp=$('pcbIn_'+i);if(!inp)return;
 _pcbRow=i;
 const cur=pcbText((window.L[i]||{}).pid);
 if(sel)inp.select();
 const q=(sel||inp.value===cur)?'':inp.value;
 _pcbRes=pcbSearch(q);_pcbHi=0;
 const box=pcbEl(),r=inp.getBoundingClientRect(),w=Math.max(r.width,430);
 box.style.width=w+'px';box.style.top=Math.min(r.bottom+2,innerHeight-120)+'px';
 box.style.left=Math.max(8,Math.min(r.right-w,innerWidth-w-8))+'px';
 box.style.maxHeight=Math.max(140,innerHeight-r.bottom-20)+'px';
 pcbRender();box.style.display='block';
}
function pcbRender(){
 const box=pcbEl(),kind=window._invKind;
 if(!_pcbRes.length){box.innerHTML='<div class="pcb-empty">کالایی با این مشخصات پیدا نشد</div>';return}
 box.innerHTML=_pcbRes.slice(0,60).map((x,k)=>{
  const st=stockOf(x.p.id);
  return '<div class="pcb-it'+(k===_pcbHi?' hi':'')+'" onmousedown="event.preventDefault();pcbPick('+k+')"><span><b>'+esc(x.p.code)+'</b> — '+esc(x.p.name)+(x.hit?' <small class="pcb-sn" dir="ltr">#'+esc(faDig(String(x.hit.sn)))+'</small>':'')+'</span><span class="pcb-st '+(st<=0&&kind!=='buy'?'neg':'')+'">موجودی: '+fa(st)+'</span></div>'}).join('')+(_pcbRes.length>60?'<div class="pcb-empty">'+fa(_pcbRes.length-60)+' مورد دیگر — عبارت جستجو را دقیق‌تر کنید</div>':'');
 const h=box.querySelector('.hi');if(h)h.scrollIntoView({block:'nearest'});
}
function pcbClose(){const b=$('pcbList');if(b)b.style.display='none'}
function pcbKey(e,i){
 const box=pcbEl();
 if(e.key==='Escape'){pcbClose();return}
 if(box.style.display==='none'&&(e.key==='ArrowDown'||e.key==='ArrowUp')){pcbOpen(i,true);e.preventDefault();return}
 if(e.key==='ArrowDown'){_pcbHi=Math.min(_pcbHi+1,Math.min(_pcbRes.length,60)-1);pcbRender();e.preventDefault()}
 else if(e.key==='ArrowUp'){_pcbHi=Math.max(_pcbHi-1,0);pcbRender();e.preventDefault()}
 else if(e.key==='Enter'){if(box.style.display!=='none'&&_pcbRes.length){e.preventDefault();pcbPick(_pcbHi)}}
 else if(e.key==='Tab')pcbClose();
}
function pcbPick(k){
 const x=_pcbRes[k],i=_pcbRow;if(!x||i<0||!window.L[i])return;
 pcbClose();
 rowProdChange({value:x.p.id},i);
 const l=window.L[i],kind=window._invKind;
 if(x.hit&&x.p.track==='serial'){
  const h=x.hit;
  if(kind==='buy'){l.sn=h.sn;l.qty=1;l.color=h.color||l.color;rowAddRenderAll();recalc()}
  else if(kind==='sale'){l.sid=h.id;l.sn=h.sn;l.qty=1;l.cost=h.cost;l.color=h.color||'';l.price=h.price||l.price;rowAddRenderAll();recalc()}
  else rowSerialChange({value:h.id},i);
 }
 setTimeout(()=>{const q=$('rq_'+i);if(q){q.focus();q.select&&q.select()}},40);
}
function rowProdChange(sel,i){
 const l=window.L[i];l.pid=sel.value;l.sid='';l.sn='';
 const p=PR(l.pid);
  if(p){l.price=window._invKind==='buy'?(p.lastCost||0):(p.sellPrice||0);l.cost=unitCost(p);l.color=window._invKind==='buy'?((p.colors||[])[0]||''):'';l.sellManual=0;l.sellAtBuy=(window._invKind==='buy'&&lapIsGroup(p.group))?((l.price||0)+LAP_MARGIN):(p.sellPrice||0);
   if(p.track==='serial'){
    if(window._invKind==='buy'){
     const used=new Set(window.L.map(x=>x.sn).filter(Boolean));
     const rs=DB.serials.find(x=>x.pid===p.id&&x.status==='registered'&&!used.has(x.sn));
     if(rs){l.sn=rs.sn;l.qty=1;l.color=rs.color||'';l.price=rs.cost||l.price;l.cost=rs.cost||l.cost;l.sellAtBuy=rs.price||l.sellAtBuy}
    }else if(window._invKind==='sale'){
     const ss=DB.serials.filter(x=>x.pid===p.id&&x.status==='stock');
     if(ss.length===1){const x=ss[0];l.sid=x.id;l.sn=x.sn;l.qty=1;l.cost=x.cost;l.color=x.color||'';l.price=x.price||l.price}
    }
   }}
  rowAddRenderAll();recalc();
}
function rowSerialChange(sel,i){
 const l=window.L[i];l.sid=sel.value;
 const s=DB.serials.find(x=>x.id===l.sid);
 if(s){l.cost=s.cost;l.qty=1;l.color=s.color;
  const ip=$('rp_'+i);if(ip&&!pd(ip.value))ip.value=fm(s.price||((PR(l.pid)||{}).sellPrice||0))}
 rowAddRenderAll();recalc();
}
function rowUpd(i){
 const l=window.L[i];if(!l)return;
 l.qty=pd(($('rq_'+i)||{}).value)||1;
 l.price=pd(($('rp_'+i)||{}).value);
 if($('rkc_'+i))l.cost=pd($('rkc_'+i).value);
 if($('rc_'+i))l.color=$('rc_'+i).value;
 if($('rsl_'+i))l.sellAtBuy=pd($('rsl_'+i).value);
 if(window._invKind==='buy'&&!l.sellManual){const _p=PR(l.pid);if(_p&&lapIsGroup(_p.group)&&l.price){l.sellAtBuy=l.price+LAP_MARGIN;if($('rsl_'+i))$('rsl_'+i).value=fm(l.sellAtBuy)}}
 if($('rpr_'+i))$('rpr_'+i).textContent=fm((l.price-l.cost)*l.qty);
 if($('rt_'+i))$('rt_'+i).textContent=fm(l.qty*l.price);
 smartRow(i);recalc();
}
function smartRow(i){
 const kind=window._invKind,l=window.L[i];if(!l)return;
 const rp=$('rp_'+i),rq=$('rq_'+i);
 if(rp)rp.className='money'+(kind==='sale'&&l.price<l.cost&&l.price>0?' warn-pink':'');
 if(rq&&kind==='sale'){const p=PR(l.pid);if(!p)return;
  let avail=Math.max(0,stockOf(l.pid));const oldSale=window._invId&&DB.invoices.find(x=>x.id===window._invId);if(oldSale&&oldSale.type==='sale')avail+=oldSale.lines.filter(x=>x.pid===l.pid&&!x.sid).reduce((s,x)=>s+Number(x.qty||0),0);
  const inInv=window.L.filter((x,j)=>j!==i&&x.pid===l.pid).reduce((s,x)=>s+x.qty,0);
  rq.className='money'+(l.qty>avail-inInv?' warn-yel':'');}
}
function applyPct(){
 const pct=pd($('ivPct').value);if(!pct){toast('⚠️ درصد را وارد کنید',false);return}
 window.L.forEach((l,i)=>{const base=l.cost||unitCost(PR(l.pid));if(base){l.price=Math.round((base+capProfit(base,pct))/1000)*1000;const ip=$('rp_'+i);if(ip)ip.value=fm(l.price);smartRow(i)}});
 recalc();toast('✅ قیمت‌ها با '+fa(pct)+'٪ سود محاسبه شد (سود هر عدد حداکثر '+fm(MAX_PROFIT)+' تومان)');
}
function bulkAddLines(){
 const pid=$('bsPid').value;if(!pid){toast('⚠️ کالا را انتخاب کنید',false);return}
 const sell=pd($('bsSell').value);if(!sell){toast('⚠️ قیمت فروش هنگام خرید را مشخص کنید',false);return}
 const cost=pd($('bsCost').value)||unitCost(PR(pid));
 const sns=faDig($('bsSn').value).split(/[\n,;،]+/).map(x=>x.trim()).filter(Boolean);
 if(!sns.length){toast('⚠️ سریالی وارد نشده',false);return}
 let added=0,skip=0;
 sns.forEach(sn=>{
if(DB.serials.some(s=>s.sn===sn&&!(s.status==='registered'&&s.pid===pid))||window.L.some(l=>l.sn===sn)){skip++;return}
  window.L.push({pid,sid:'',sn,color:((PR(pid)||{}).colors||[])[0]||'',qty:1,price:cost,cost,sellAtBuy:sell});added++;
 });
 toggleId('bulkBox');$('bsSn').value='';
 rowAddRenderAll();recalc();
 toast('✅ '+fa(added)+' سریال به فاکتور اضافه شد'+(skip?' — '+fa(skip)+' تکراری رد شد':''));
}
function payAdd(){window.PAY.push({method:'cash',amount:0,desc:'',chkNo:'',chkBank:'',chkBranch:'',chkCount:1,chkDue:''});payRenderAll();recalc()}
function payDel(i){window.PAY.splice(i,1);payRenderAll();recalc()}
function payFillRemainder(){
 const rem=Math.max(0,invTotalTmp()-window.PAY.reduce((s,x)=>s+(x.method==='installment'?0:pd(x.amount)),0));
 if(rem<=0){toast('⚠️ مانده‌ای برای تسویه نیست',false);return}
 let r=window.PAY.find(x=>x.method==='cash'&&!pd(x.amount));
 if(!r){window.PAY.push({method:'cash',amount:0,desc:'',chkNo:'',chkBank:'',chkBranch:'',chkCount:1,chkDue:''});r=window.PAY[window.PAY.length-1]}
 r.amount=rem;payRenderAll();recalc();
 toast('✅ مانده ('+fm(rem)+' تومان) در ردیف نقدی قرار گرفت');
}
const METHOD_FA={cash:'نقدی',cheque:'چک'};
function payRenderAll(){
 const tb=$('paysTb');if(!tb)return;
 const methods=window._invKind==='sale'?{cash:'نقدی'}:METHOD_FA;
 tb.innerHTML=window.PAY.map((x,i)=>`<tr>
  <td><select onchange="window.PAY[${i}].method=this.value;payRenderAll();recalc()">
   ${Object.keys(methods).map(m=>`<option value="${m}" ${x.method===m?'selected':''}>${methods[m]}</option>`).join('')}
  </select></td>
  <td><input class="money" style="width:130px" value="${fm(x.amount)}" oninput="window.PAY[${i}].amount=pd(this.value);recalc()"></td>
  <td>${['card','fish','account'].includes(x.method)?`<select title=\"حساب بانکی\" onchange=\"window.PAY[${i}].acc=this.value\">${DB.accounts.map(a=>`<option value=\"${a.id}\" ${(x.acc||DB.accounts[0].id)===a.id?'selected':''}>${esc(a.title)}</option>`).join('')}</select>`:''}${x.method==='cheque'?`<div style="display:flex;gap:4px;flex-wrap:wrap"><input placeholder="نام بانک" style="width:100px" value="${esc(x.chkBank||'')}" oninput="window.PAY[${i}].chkBank=this.value"><input placeholder="شعبه" style="width:80px" value="${esc(x.chkBranch||'')}" oninput="window.PAY[${i}].chkBranch=this.value"><input placeholder="شماره سریال چک" style="width:110px" value="${esc(x.chkNo||'')}" oninput="window.PAY[${i}].chkNo=this.value"><input placeholder="تعداد چک" type="number" min="1" style="width:75px" value="${x.chkCount||1}" oninput="window.PAY[${i}].chkCount=Math.max(1,pd(this.value))"><input placeholder="اولین سررسید" style="width:110px" value="${esc(x.chkDue||'')}" oninput="window.PAY[${i}].chkDue=this.value"></div>`:`<input placeholder="توضیح" style="width:220px" value="${esc(x.desc||'')}" oninput="window.PAY[${i}].desc=this.value">`}</td>
  <td><button class="btn sm r" onclick="payDel(${i})">✕</button></td></tr>`).join('');
}
function planGenInline(){
 const rem=Math.max(0,invTotalTmp()-window.PAY.reduce((s,x)=>s+pd(x.amount),0));
 const n=pd($('plN').value)||1,gap=pd($('plGap').value)||1,first=jNorm($('plFirst').value);
 if(!jValid(first)){toast('⚠️ تاریخ اولین سررسید نامعتبر است',false);return}
 if(rem<=0){toast('⚠️ مانده‌ای برای اقساط نیست',false);return}
 const each=Math.floor(rem/n);let rows='';window._planTmp={count:n,gap,first,items:[]};
 for(let i=0;i<n;i++){const due=i===0?first:jAddM(first,i*gap);const amt=i===n-1?rem-each*(n-1):each;window._planTmp.items.push({no:i+1,due,amount:amt});rows+='<tr><td>'+fa(i+1)+'</td><td>'+jShort(due)+'</td><td class="amt">'+fm(amt)+'</td></tr>'}
 $('plPrev').innerHTML='<table><thead><tr><th>قسط</th><th>سررسید</th><th>مبلغ</th></tr></thead><tbody>'+rows+'</tbody></table><div style="margin-top:4px">جمع: <b>'+fm(rem)+' تومان</b></div>';
}
function planConfirm(){window.PLAN=window._planTmp?JSON.parse(JSON.stringify(window._planTmp)):null;planInfoUpd();toggleId('planBox');recalc();toast(window.PLAN?'✅ طرح '+fa(window.PLAN.count)+' قسطی تایید شد':'طرح پاک شد')}
function checkPlanGen(){
 const count=pd($('chN').value)||1,first=jNorm($('chFirst').value),total=Math.max(0,invTotalTmp()-window.PAY.reduce((s,x)=>s+pd(x.amount),0));
 if(!jValid(first)){toast('⚠️ تاریخ اولین سررسید چک نامعتبر است',false);return}
 if(!total){toast('⚠️ مبلغی برای طرح چک باقی نمانده است',false);return}
 const rawSerial=faDig($('chStart').value).trim(),parts=rawSerial.split('/'),prefix=parts.length>1?parts.slice(0,-1).join('/'):'',suffixText=parts.length>1?parts[parts.length-1]:rawSerial,suffix=Number(suffixText);
 if(!rawSerial||!Number.isFinite(suffix)){toast('⚠️ سریال شروع را مثل 1206/123456 وارد کنید',false);return}
 const each=Math.floor(total/count);window._chkPlanTmp={count,startSerial:rawSerial,prefix,startSuffix:suffix,bank:$('chBank').value.trim(),branch:$('chBranch').value.trim(),first,items:[]};let rows='';
 for(let i=0;i<count;i++){const amount=i===count-1?total-each*(count-1):each,due=jAddM(first,i),serial=(prefix?prefix+'/':'')+String(suffix+i);window._chkPlanTmp.items.push({no:i+1,serial,amount,due});rows+='<tr><td>'+fa(i+1)+'</td><td dir="ltr">'+esc(serial)+'</td><td class="amt">'+fm(amount)+'</td><td>'+jShort(due)+'</td></tr>'}
 $('chPrev').innerHTML='<table><thead><tr><th>ردیف</th><th>سریال چک</th><th>مبلغ</th><th>سررسید</th></tr></thead><tbody>'+rows+'</tbody></table>';
}
function checkPlanConfirm(){window.CHKPLAN=window._chkPlanTmp?JSON.parse(JSON.stringify(window._chkPlanTmp)):null;const el=$('checkPlanInfo');if(el)el.textContent=window.CHKPLAN?'✅ '+fa(window.CHKPLAN.count)+' چک تایید شد':'طرح چک تعریف نشده';toggleId('checkPlanBox');toast(window.CHKPLAN?'✅ طرح چک تایید شد':'طرح چک پاک شد')}
function planInfoUpd(){const el=$('planInfo');if(!el)return;el.innerHTML=window.PLAN?('✅ '+fa(window.PLAN.count)+' قسط — اولین سررسید: '+jShort(window.PLAN.first)):'اقساطی تعریف نشده'}
function invTotalTmp(){return window.L.reduce((s,l)=>s+(l.qty||1)*(l.price||0),0)-pd(($('ivDisc')||{}).value||0)}
function recalc(){
 const tb=$('totBox');if(!tb)return;
 const t=invTotalTmp(),paid=window.PAY.reduce((s,x)=>s+(x.method==='installment'?0:pd(x.amount)),0),rem=t-paid;
 const nPay=window.PAY.filter(x=>pd(x.amount)>0).length;
 tb.innerHTML='<span style="margin-left:22px">جمع کل: <b style="color:var(--hd);font-size:15px">'+fm(t)+'</b></span>'+
 '<span style="margin-left:22px">پرداخت‌شده: <b class="pos">'+fm(paid)+'</b></span>'+
 '<span style="margin-left:22px">مانده (نسیه): <b class="'+(rem>0?'neg':'pos')+'">'+fm(rem)+'</b></span>'+
 (nPay>1?'<span class="bdg b-g" style="margin-right:6px">پرداخت ترکیبی</span>':'')+
 (rem>0&&window.PLAN?'<span class="bdg b-b" style="margin-right:6px">📅 اقساط: '+fa(window.PLAN.count)+' قسط — اولین سررسید '+jShort(window.PLAN.first)+'</span>':'')+
 (rem>0&&!window.PLAN?'<span class="bdg b-o" style="margin-right:8px">مانده به‌عنوان بدهی (نسیه) ثبت می‌شود</span>':'');
 const pel=$('ivCustBal');
 if(pel){const pid=($('ivPerson')||{}).value;
  if(pid&&pid!=='__new'){
   let prev=personBalance(pid).saleDebt;
   if(window._invId){const old=DB.invoices.find(i=>i.id===window._invId);if(old&&old.type==='sale')prev-=(invTotal(old)-invPaid(old))}
   pel.innerHTML='مانده فعلی: <b class="'+(prev>0?'neg':'pos')+'">'+fm(prev)+'</b> → پس از این فاکتور: <b class="'+((prev+rem)>0?'neg':'pos')+'">'+fm(prev+rem)+' تومان</b>';
  }else pel.innerHTML='—';}
 if(window._invKind==='sale')planInfoUpd();
}
function collectInv(){
 const kind=window._invKind;
 const rawDate=($('ivDate')||{}).value||'';
 const date=jValid(rawDate)?jNorm(rawDate):jToday();
 return{kind,id:window._invId,
  date,
  person:($('ivPerson')||{}).value||'',
  desc:($('ivDesc')||{}).value||'',
  group:'',
  disc:pd(($('ivDisc')||{}).value),
  lines:window.L.filter(l=>l.pid).map(l=>{const i=window.L.indexOf(l);const rc=$('rc_'+i);const rs=$('rsl_'+i);
   return{pid:l.pid,sid:l.sid||'',sn:faDig(l.sn||'').trim(),color:rc?rc.value:(l.color||''),qty:l.qty||1,price:l.price||0,cost:l.cost||0,sellAtBuy:rs?pd(rs.value):(l.sellAtBuy||0)}}),
  pays:window.PAY.filter(x=>pd(x.amount)>0).map(x=>({method:x.method,amount:pd(x.amount),desc:x.desc||'',chkNo:x.chkNo||'',chkBank:x.chkBank||'',chkBranch:x.chkBranch||'',chkCount:Math.max(1,pd(x.chkCount)||1),chkDue:x.chkDue||'',acc:x.acc||''})),
  plan:kind==='sale'?window.PLAN:null,
  checkPlan:kind==='sale'?window.CHKPLAN:null};
}
function invWarnings(d){
 const kind=d.kind,w=[];
 if(!jValid(d.date))w.push('⛔ تاریخ شمسی نامعتبر است (نمونه صحیح: ۱۴۰۳/۰۵/۱۲)');
 if(!d.person||d.person==='__new')w.push('⛔ '+(kind==='buy'||kind==='buyret'?'فروشنده':'مشتری')+' انتخاب نشده است');
 if(!d.lines.length)w.push('⛔ حداقل یک قلم با کالای مشخص لازم است');
 const sns=d.lines.map(l=>l.sn).filter(Boolean);
 const allSids=d.lines.map(l=>l.sid).filter(Boolean);
 if(kind==='saleret'||kind==='buyret'){
  const need={};d.lines.forEach(l=>{need[l.pid]=(need[l.pid]||0)+Number(l.qty||0)});
  Object.keys(need).forEach(pid=>{const room=retRoom(d.person,pid,kind,d.id);
   if(need[pid]>room)w.push('⛔ برگشت «'+((PR(pid)||{}).name||'؟')+'» ('+fa(need[pid])+') بیشتر از '+(kind==='saleret'?'فروش':'خرید')+' ثبت‌شده به این شخص است (قابل برگشت: '+fa(Math.max(0,room))+')')});
 }
 d.lines.forEach((l,i)=>{
  const p=PR(l.pid);if(!p)return;
  if(kind==='sale'&&l.price<l.cost&&l.price>0)w.push('⚠️ سطر '+fa(i+1)+': قیمت فروش ('+fm(l.price)+') کمتر از بهای خرید ('+fm(l.cost)+') — خانه صورتی');
  if(kind==='sale'&&l.sid&&allSids.filter(x=>x===l.sid).length>1)w.push('⛔ سطر '+fa(i+1)+': این سریال دو بار در فاکتور انتخاب شده است');
  if(kind==='sale'){let avail=Math.max(0,stockOf(l.pid));const oldSale=d.id&&DB.invoices.find(x=>x.id===d.id);if(oldSale&&oldSale.type==='sale')avail+=oldSale.lines.filter(x=>x.pid===l.pid&&!x.sid).reduce((s,x)=>s+Number(x.qty||0),0);
   let skipChk=false;
   if(l.sid){const s=DB.serials.find(x=>x.id===l.sid);if(s&&(s.status==='stock'||(d.id&&s.saleInv===d.id)))skipChk=true;else if(s&&s.status!=='stock')avail=0}
   const inInv=d.lines.filter((x,j)=>j!==i&&x.pid===l.pid&&(!x.sid||((DB.serials.find(y=>y.id===x.sid)||{}).status==='stock'))).reduce((s,x)=>s+x.qty,0);
   if(!skipChk&&l.qty>avail-inInv){
    if(!DB.settings.allowNegative)w.push('⛔ سطر '+fa(i+1)+': تعداد ('+fa(l.qty)+') بیشتر از موجودی ('+fa(Math.max(0,avail-inInv))+') — فروش با موجودی منفی غیرفعال است');
    else w.push('⚠️ سطر '+fa(i+1)+': تعداد ('+fa(l.qty)+') بیشتر از موجودی ('+fa(Math.max(0,avail-inInv))+') — خانه زرد');}}
  if((kind==='buyret'||(kind==='buy'&&d.id))&&p.track!=='serial'&&!l.sid){
    const sum=d.lines.filter(x=>x.pid===l.pid&&!x.sid).reduce((s,x)=>s+Number(x.qty||0),0);
    const after=stockExcl(l.pid,d.id)+(kind==='buy'?sum:-sum);
    if(after<0&&d.lines.findIndex(x=>x.pid===l.pid&&!x.sid)===i){
     const msg='سطر '+fa(i+1)+': با این '+(kind==='buy'?'ویرایش':'برگشت')+' موجودی «'+p.name+'» منفی می‌شود ('+fa(after)+')';
     w.push(DB.settings.allowNegative?'⚠️ '+msg:'⛔ '+msg+' — فروش/برگشت با موجودی منفی غیرفعال است');}}
   if(kind==='buy'&&p.track==='serial'){
   if(!l.sellAtBuy)w.push('⚠️ سطر '+fa(i+1)+': قیمت فروش هنگام خرید تعیین نشده (برای سود مجزای هر سریال)');
   if(l.sn){
    if(sns.filter(x=>x===l.sn).length>1)w.push('⛔ سطر '+fa(i+1)+': سریال '+fa(l.sn)+' در این فاکتور تکراری است');
else if(DB.serials.some(s=>s.sn===l.sn&&!(s.status==='registered'&&s.pid===l.pid)&&(!l.sid||s.id!==l.sid)))w.push('⛔ سطر '+fa(i+1)+': سریال '+fa(l.sn)+' قبلاً در سیستم ثبت شده است');}}
 });
 return w;
}
function renderWarn(list,soft){
 $('warnBox').innerHTML='<div class="notice '+(soft?'':'red')+'"><b>'+(soft?'⚠️ هشدارها (قبل از ثبت نهایی):':'⛔ موارد الزامی:')+'</b><ul style="margin:6px 18px">'+list.map(x=>'<li>'+x+'</li>').join('')+'</ul>'+
 (soft?'<label style="display:flex;gap:6px;align-items:center;font-weight:700"><input type="checkbox" id="warnOk"> با اطلاع از هشدارها، ثبت را تایید می‌کنم</label>':'')+'</div>';
 if($('warnBox').scrollIntoView)$('warnBox').scrollIntoView({behavior:'smooth',block:'nearest'});
}
function invSave(){
 const d=collectInv();
 const w=invWarnings(d);
 const blockers=w.filter(x=>x.startsWith('⛔'));
 const soft=w.filter(x=>!x.startsWith('⛔'));
 if(blockers.length){renderWarn(blockers,false);toast('⛔ موارد الزامی را اصلاح کنید',false);return}
 if(soft.length){const ok=$('warnOk');if(!ok||!ok.checked){renderWarn(soft,true);toast('⚠️ هشدارها را بررسی و تایید کنید',false);return}}
 doSaveInvoice(d);
}
function doSaveInvoice(d){ixInvalidate();
 if(lockBlocked(d.date)||lockBlocked((DB.invoices.find(i=>i.id===d.id)||{}).date))return;
 const kind=d.kind,isBuy=kind==='buy'||kind==='buyret';
 if(kind==='buy')d.lines.forEach(l=>{
  if(!l.sid&&l.sn){
   const registered=DB.serials.find(s=>s.sn===l.sn&&s.pid===l.pid);
   if(registered)l.sid=registered.id;
   else{
    const nid2=uid();
    DB.serials.push({id:nid2,pid:l.pid,sn:l.sn,color:l.color,cost:l.price,price:l.sellAtBuy||((PR(l.pid)||{}).sellPrice||0),status:'stock',buyInv:'',saleInv:'',date:d.date});
    l.sid=nid2;
   }
  }
 });
 if(kind==='buy')d.lines.forEach(l=>{if(l.sid){const s=DB.serials.find(x=>x.id===l.sid);if(s){if(s.status==='registered')s.status='stock';s.cost=l.price;if(s.status!=='sold'){s.price=l.sellAtBuy||s.price;s.date=d.date}}}});
 if(kind==='buyret')d.lines.forEach(l=>{if(l.sid){const s=DB.serials.find(x=>x.id===l.sid);if(s)s.status='returned'}});
 if(kind==='sale')d.lines.forEach(l=>{if(l.sid){const s=DB.serials.find(x=>x.id===l.sid);if(s){s.status='sold';s.price=l.price}}});
 if(kind==='saleret')d.lines.forEach(l=>{if(l.sid){const s=DB.serials.find(x=>x.id===l.sid);if(s){s.status='stock';s.saleInv=''}}});
 if(kind==='saleret')d.lines.forEach(l=>{const c=soldCostOf(d.person,l.pid);if(c>0)l.cost=c});
 const isBuyCtr=kind==='buy'||kind==='buyret';
 const no=d.id?(DB.invoices.find(i=>i.id===d.id)||{}).no:nextNo(isBuyCtr?'buy':(kind==='proforma'?'pro':'sale'));
  const invObj={type:kind,no,date:d.date,person:d.person,lines:d.lines,pays:d.pays,discount:d.disc,desc:d.desc,group:d.group,installPlan:d.plan,checkPlan:d.checkPlan};
 if(d.id){
  const ix=DB.invoices.findIndex(i=>i.id===d.id);if(ix<0)return;
  const old=DB.invoices[ix];
  const keptChq=DB.cheques.filter(c=>c.inv===old.id&&c.status!=='جاری');
  DB.cheques=DB.cheques.filter(c=>c.inv!==old.id||c.status!=='جاری');
   if(kind==='sale')DB.serials.forEach(s=>{if(s.saleInv===old.id&&!d.lines.some(l=>l.sid===s.id)){s.status='stock';s.saleInv=''}});
   if(kind==='buy'){DB.serials.forEach(s=>{if(s.buyInv===old.id&&s.status==='stock'&&!d.lines.some(l=>l.sid===s.id)){if(s.introduced){s.status='registered';s.buyInv=''}else s._drop=1}});DB.serials=DB.serials.filter(s=>!s._drop)}
  DB.installments=DB.installments.filter(i2=>!(i2.inv===old.id&&!i2.paid));
  const paidNos=new Set(DB.installments.filter(i2=>i2.inv===old.id&&i2.paid).map(i2=>Number(i2.no)));
  DB.accTx=DB.accTx.filter(t=>t.ref!==old.id);
  DB.invoices[ix]={...old,...invObj};auditPush('ویرایش '+invTypeFa(kind)+' '+no,old,DB.invoices[ix]);
  d.lines.forEach(l=>{if(l.sid){const s=DB.serials.find(x=>x.id===l.sid);if(s){if(kind==='buy')s.buyInv=old.id;if(kind==='sale')s.saleInv=old.id}}});
  const dupKept=(no2,due2,amt2)=>keptChq.some(k=>(String(no2||'')!==''&&String(k.no||'')===String(no2||''))||(k.due===due2&&Number(k.amount)===Number(amt2)));
  d.pays.forEach(x=>{
   if(x.method!=='cheque')return;
   const count=Math.max(1,Number(x.chkCount)||1),total=Number(x.amount)||0,baseAmount=Math.floor(total/count),firstDue=jValid(x.chkDue)?jNorm(x.chkDue):jAddD(d.date,30),startNo=Number(faDig(x.chkNo));
   for(let i=0;i<count;i++){
    const amount=i===count-1?total-baseAmount*(count-1):baseAmount;
    const checkNo=Number.isFinite(startNo)&&String(x.chkNo||'')!==''?String(startNo+i):(x.chkNo||'');
    const due2=jAddM(firstDue,i);
    if(dupKept(checkNo,due2,amount))continue;
    DB.cheques.push({id:uid(),no:checkNo,dir:kind==='buy'?'paid':'rec',person:d.person,amount,due:due2,issue:d.date,bank:x.chkBank||'',branch:x.chkBranch||'',status:'جاری',inv:old.id,desc:invTypeFa(kind)+' '+no});
   }
  });
  if(kind==='sale'&&d.plan){const plId='inv-'+old.id;d.plan.items.filter(it=>!paidNos.has(Number(it.no))).forEach(it=>DB.installments.push({id:uid(),planId:plId,inv:old.id,person:d.person,no:it.no,amount:it.amount,due:it.due,paid:false,paidDate:'',desc:''}))}
  if(kind==='sale'&&d.checkPlan)d.checkPlan.items.filter(it=>!dupKept(it.serial,it.due,it.amount)).forEach(it=>DB.cheques.push({id:uid(),no:it.serial,serial:it.serial,dir:'rec',person:d.person,amount:it.amount,due:it.due,issue:d.date,bank:d.checkPlan.bank,branch:d.checkPlan.branch,status:'جاری',inv:old.id,desc:'طرح فروش با چک '+no}));
  logAct('ویرایش '+invTypeFa(kind)+' شماره '+no);
 }else{
  const nid=uid();invObj.id=nid;if(kind==='buy')invObj.delivered=false;
  DB.invoices.push(invObj);auditPush('ثبت '+invTypeFa(kind)+' '+no,null,invObj);
  d.lines.forEach(l=>{if(l.sid){const s=DB.serials.find(x=>x.id===l.sid);if(s){if(kind==='buy')s.buyInv=nid;if(kind==='sale')s.saleInv=nid}}});
  d.pays.forEach(x=>{
   if(x.method!=='cheque')return;
   const count=Math.max(1,Number(x.chkCount)||1),total=Number(x.amount)||0,baseAmount=Math.floor(total/count),firstDue=jValid(x.chkDue)?jNorm(x.chkDue):jAddD(d.date,30),startNo=Number(faDig(x.chkNo));
   for(let i=0;i<count;i++){
    const amount=i===count-1?total-baseAmount*(count-1):baseAmount;
    const checkNo=Number.isFinite(startNo)?String(startNo+i):(x.chkNo||'');
    DB.cheques.push({id:uid(),no:checkNo,dir:kind==='buy'?'paid':'rec',person:d.person,amount,due:jAddM(firstDue,i),issue:d.date,bank:x.chkBank||'',branch:x.chkBranch||'',status:'جاری',inv:nid,desc:invTypeFa(kind)+' '+no});
   }
  });
  if(kind==='sale'&&d.plan){const plId='inv-'+nid;d.plan.items.forEach(it=>DB.installments.push({id:uid(),planId:plId,inv:nid,person:d.person,no:it.no,amount:it.amount,due:it.due,paid:false,paidDate:'',desc:''}))}
  if(kind==='sale'&&d.checkPlan)d.checkPlan.items.forEach(it=>DB.cheques.push({id:uid(),no:it.serial,serial:it.serial,dir:'rec',person:d.person,amount:it.amount,due:it.due,issue:d.date,bank:d.checkPlan.bank,branch:d.checkPlan.branch,status:'جاری',inv:nid,desc:'طرح فروش با چک '+no}));
  logAct('ثبت '+invTypeFa(kind)+' شماره '+no+' — مبلغ '+fm(invTotal(invObj)));
 }
 if(kind!=='proforma'&&DB.accounts[0]){const _id=d.id||invObj.id;
  d.pays.forEach(x=>{if(['cash','cheque','installment'].includes(x.method))return;
   DB.accTx.push({id:uid(),acc:x.acc||DB.accounts[0].id,date:d.date,type:(kind==='sale'||kind==='buyret')?'in':'out',amount:pd(x.amount),desc:invTypeFa(kind)+' '+no+' — '+PN(d.person),ref:_id})})}
 if(kind==='buy')refreshLastCost(d.lines.map(l=>l.pid));
  saveDB();closeM();nav(curView==='invoiceList'?'invoiceList':(isBuyCtr?'purchase':'sales'));
 toast('✅ '+invTypeFa(kind)+' شماره '+fa(no)+' ثبت شد');
  if(kind==='sale'&&!d.id)smsAutoInvoice(invObj);
}
function invDel(id){ixInvalidate();
 const inv=DB.invoices.find(i=>i.id===id);if(!inv)return;
 if(lockBlocked(inv.date))return;
 if(inv.type==='sale'||inv.type==='buy'){const rk=inv.type==='sale'?'saleret':'buyret';
  const bad=[...new Set(inv.lines.map(l=>l.pid))].find(pid=>retRoom(inv.person,pid,rk,null)-inv.lines.filter(l=>l.pid===pid).reduce((s,l)=>s+Number(l.qty||0),0)<0&&DB.invoices.some(x=>x.type===rk&&x.person===inv.person&&x.lines.some(l=>l.pid===pid)));
  if(bad){toast('⛔ ابطال ممکن نیست: برای «'+((PR(bad)||{}).name||'؟')+'» برگشت ثبت شده؛ ابتدا فاکتور برگشت را ابطال کنید',false);return}}
 if(inv.type==='buy'&&!DB.settings.allowNegative){const bad=[...new Set(inv.lines.filter(l=>!l.sid).map(l=>l.pid))].map(PR).filter(p=>p&&p.track!=='serial'&&stockExcl(p.id,id)<0);
  if(bad.length){toast('⛔ ابطال ممکن نیست: موجودی «'+bad[0].name+'» منفی می‌شود (بخشی از کالا فروخته شده است)',false);return}}
  confirmM('ابطال '+invTypeFa(inv.type)+' شماره <b>'+fa(inv.no)+'</b>؟<br><small>سریال‌ها اصلاح و اقساط/چک‌های مرتبط از گردش خارج می‌شوند؛ نسخه کامل فاکتور در «ابطال‌شده‌ها» می‌ماند و شماره آن دوباره استفاده نمی‌شود.</small>',()=>{
  const _vi=DB.installments.filter(i=>i.inv===id),_vc=DB.cheques.filter(c=>c.inv===id),_why=(prompt('دلیل ابطال (اختیاری):')||'').trim();
  if(inv.type==='buyret')inv.lines.forEach(l=>{const s=l.sid&&DB.serials.find(x=>x.id===l.sid);if(s&&s.status==='returned')s.status='stock'});
  if(inv.type==='saleret')inv.lines.forEach(l=>{const s=l.sid&&DB.serials.find(x=>x.id===l.sid);if(s&&s.status==='stock'){const so=DB.invoices.filter(x=>x.type==='sale'&&x.lines.some(y=>y.sid===s.id)).pop();if(so){s.status='sold';s.saleInv=so.id}}});
  DB.serials.forEach(s=>{
   if(s.saleInv===id){s.status='stock';s.saleInv=''}
   if(s.buyInv===id){if(s.status==='sold')return;if(s.introduced){s.status='registered';s.buyInv=''}else s._drop=1}});
  DB.serials=DB.serials.filter(s=>!s._drop);
  DB.installments=DB.installments.filter(i=>i.inv!==id);
  const delChq=DB.cheques.filter(c=>c.inv===id).map(c=>c.id);
  DB.cheques=DB.cheques.filter(c=>c.inv!==id);
  DB.accTx=DB.accTx.filter(t=>t.ref!==id&&!delChq.includes(t.ref));
  DB.invoices=DB.invoices.filter(i=>i.id!==id);
  DB.voided.unshift({...JSON.parse(JSON.stringify(inv)),voidedAt:new Date().toLocaleString('fa-IR'),reason:_why,cheques:JSON.parse(JSON.stringify(_vc)),installments:JSON.parse(JSON.stringify(_vi))});auditPush('ابطال '+invTypeFa(inv.type)+' '+inv.no+(_why?' — '+_why:''),inv,null);
  if(inv.type==='buy')refreshLastCost(inv.lines.map(l=>l.pid));
   logAct('ابطال سند شماره '+inv.no);saveDB();nav(curView);toast('🗑️ حذف شد');});
}


/* ستون رنگ فاکتور خرید: فقط رنگِ ثبت‌شده در «معرفی کالا» (قابل انتخاب نیست؛ اگر کالا چند رنگ ثبت‌شده داشته باشد فقط همان رنگ‌ها) */
function rowColorCell(i,l){
 const p=PR(l.pid);
 if(!p)return '<td style="color:var(--mut)">—</td>';
 const cs=(p.colors||[]).filter(Boolean),cur=l.color&&(cs.includes(l.color)||!cs.length)?l.color:(cs[0]||l.color||'');
 if(cs.length<=1){if(cur!==l.color)l.color=cur;return cur?'<td id="rcw_'+i+'"><span class="sw" style="background:'+CLH(cur)+'"></span> '+esc(CL(cur))+'</td>':'<td id="rcw_'+i+'" style="color:var(--mut)">—</td>'}
 if(cur!==l.color)l.color=cur;
 return '<td><select id="rc_'+i+'" onchange="rowUpd('+i+')">'+cs.map(c=>'<option value="'+c+'" '+(cur===c?'selected':'')+'>'+esc(CL(c))+'</option>').join('')+'</select></td>';
}
