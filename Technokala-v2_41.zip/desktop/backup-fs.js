/* عملیات امن فایل‌های بکاپ (فقط فایل‌های «تکنوکالا-بکاپ-*.json» در پوشه‌ی انتخاب‌شده) */
const fs=require('fs'),path=require('path');
const ANY=/^تکنوکالا-بکاپ-.*\.json$/,AUTO=/^تکنوکالا-بکاپ-خودکار-.*\.json$/;
function listBackups(dir){try{return fs.readdirSync(dir).filter(n=>ANY.test(n))}catch(e){return []}}
function removeBackup(dir,name){const n=path.basename(String(name));if(!ANY.test(n))throw new Error('نام فایل مجاز نیست');fs.unlinkSync(path.join(dir,n));return true}
/* فقط بکاپ‌های خودکار: جدیدترین max فایل می‌ماند (بر اساس زمان فایل) */
function pruneAuto(dir,max){
  let files=[];try{files=fs.readdirSync(dir).filter(n=>AUTO.test(n)).map(n=>({n,t:fs.statSync(path.join(dir,n)).mtimeMs}))}catch(e){return 0}
  files.sort((a,b)=>b.t-a.t);let k=0;
  for(const f of files.slice(max)){try{fs.unlinkSync(path.join(dir,f.n));k++}catch(e){}}
  return k;
}
module.exports={listBackups,removeBackup,pruneAuto};
