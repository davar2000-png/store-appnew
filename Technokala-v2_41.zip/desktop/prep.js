/* کپی برنامه‌ی ساخته‌شده (../dist/app.html) داخل پوسته‌ی ویندوز */
const fs=require('fs'),path=require('path');
const src=path.join(__dirname,'..','dist','app.html'),dst=path.join(__dirname,'app','app.html');
if(!fs.existsSync(src)){console.error('فایل ../dist/app.html پیدا نشد؛ ابتدا در پوشه‌ی اصلی «python build.py» را اجرا کنید.');process.exit(1)}
fs.mkdirSync(path.dirname(dst),{recursive:true});fs.copyFileSync(src,dst);console.log('app.html کپی شد');

/* همگام‌سازی نسخه‌ی بسته‌ی ویندوز با نسخه‌ی برنامه (../src/VERSION) و بررسی آیکن */
try{
  const ver=fs.readFileSync(path.join(__dirname,'..','src','VERSION'),'utf8').trim();
  const pj=path.join(__dirname,'package.json'),j=JSON.parse(fs.readFileSync(pj,'utf8'));
  if(/^\d+(\.\d+)*$/.test(ver)&&j.version!==ver+'.0'){j.version=ver+'.0';fs.writeFileSync(pj,JSON.stringify(j,null,2)+'\n');console.log('نسخه‌ی بسته: '+j.version)}
}catch(e){console.warn('همگام‌سازی نسخه انجام نشد:',e.message)}
if(!fs.existsSync(path.join(__dirname,'icon.ico')))console.warn('هشدار: icon.ico پیدا نشد؛ آیکن الکترون دیده می‌شود. (icon-src/make-icon.py را اجرا کنید)');
