/* پس از بسته‌بندی: آیکن و اطلاعات نسخه‌ی تکنوکالا داخل فایل اجرایی (Technokala.exe) نوشته می‌شود
   تا آیکن الکترون روی فایل برنامه، میانبر دسکتاپ، منوی استارت و نوار وظیفه دیده نشود.
   (با signAndEditExecutable:false خودِ electron-builder این کار را انجام نمی‌دهد؛ برای همین از rcedit استفاده می‌کنیم.) */
const path=require('path'),fs=require('fs');
exports.default=async function(ctx){
  if(ctx.electronPlatformName!=='win32')return;
  const exe=path.join(ctx.appOutDir,ctx.packager.appInfo.productFilename+'.exe');
  const icon=path.join(ctx.packager.projectDir,'icon.ico');
  if(!fs.existsSync(exe))throw new Error('afterPack: فایل اجرایی پیدا نشد: '+exe);
  if(!fs.existsSync(icon))throw new Error('afterPack: icon.ico پیدا نشد: '+icon);
  const {rcedit}=await import('rcedit');
  const v=ctx.packager.appInfo.version;
  await rcedit(exe,{
    icon,
    'file-version':v,'product-version':v,
    'version-string':{
      ProductName:'تکنوکالا',
      FileDescription:'تکنوکالا — سامانه حسابداری فروشگاه موبایل',
      CompanyName:'Technokala',
      LegalCopyright:'Technokala',
      OriginalFilename:ctx.packager.appInfo.productFilename+'.exe',
      InternalName:'Technokala'
    }
  });
  console.log('  • آیکن تکنوکالا داخل '+path.basename(exe)+' نوشته شد');
};
