const {app,BrowserWindow,ipcMain,dialog,shell,Menu,net}=require('electron');
const path=require('path'),fs=require('fs'),bfs=require('./backup-fs');
if(!app.requestSingleInstanceLock()){app.quit()}
app.setAppUserModelId('ir.technokala.app'); // شناسه‌ی برنامه برای نوار وظیفه‌ی ویندوز (آیکن و گروه‌بندی درست)
let win;
function create(){
  Menu.setApplicationMenu(null);
  win=new BrowserWindow({width:1366,height:820,minWidth:1000,minHeight:640,backgroundColor:'#f3f7fb',show:false,
    title:'تکنوکالا',icon:path.join(__dirname,process.platform==='win32'?'icon.ico':'icon.png'),autoHideMenuBar:true,
    webPreferences:{preload:path.join(__dirname,'preload.js'),contextIsolation:true,nodeIntegration:false,sandbox:true,spellcheck:false}});
  win.once('ready-to-show',()=>{win.maximize();win.show()});
  win.loadFile(path.join(__dirname,'app','app.html'));
  // لینک‌های بیرونی در مرورگر پیش‌فرض باز شوند؛ پنجره‌ی چاپ/گزارش داخل برنامه
  win.webContents.setWindowOpenHandler(({url})=>{
    if(/^https?:/i.test(url)){shell.openExternal(url);return{action:'deny'}}
    return{action:'allow'};
  });
  win.webContents.on('will-navigate',(e,url)=>{if(!url.startsWith('file:')){e.preventDefault();shell.openExternal(url)}});
}
app.on('second-instance',()=>{if(win){if(win.isMinimized())win.restore();win.focus()}});
app.whenReady().then(create);
app.on('window-all-closed',()=>app.quit());

// درخواست http به گوشی (شبکه‌ی محلی) بدون محدودیت CORS
ipcMain.handle('http-fetch',async(_e,url,o)=>{
  try{
    if(!/^http:\/\/(10\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.|127\.|localhost)/i.test(url)&&!/^https:\/\/(tapi\.bale\.ai|botapi\.rubika\.ir)\//i.test(url))return{error:'فقط آدرس شبکه‌ی محلی و سرور بله/روبیکا مجاز است'};
    const ctl=new AbortController(),t=setTimeout(()=>ctl.abort(),o.timeout||8000);
    let r;
    try{r=await net.fetch(url,{method:o.method,headers:o.headers,body:o.body||undefined,signal:ctl.signal})}
    catch(e1){ if(o.method&&o.method!=='GET'){throw e1} await new Promise(z=>setTimeout(z,400)); r=await net.fetch(url,{method:'GET',headers:o.headers,signal:ctl.signal}) } // یک بار تلاش دوباره (فقط درخواست‌های خواندنی)
    clearTimeout(t);return{status:r.status,body:await r.text()};
  }catch(e){return{error:String(e&&e.message||e)}}
});
const cfgFile=()=>path.join(app.getPath('userData'),'backup-dir.json');
const allowed=new Set();
function loadLast(){try{return JSON.parse(fs.readFileSync(cfgFile(),'utf8')).dir||''}catch(e){return ''}}
ipcMain.handle('pick-dir',async(_e,startName)=>{
  const last=loadLast();
  // اگر همان پوشه‌ی قبلی هنوز وجود دارد، بدون پرسیدن دوباره وصل شود
  if(startName&&last&&path.basename(last)===startName&&fs.existsSync(last)){allowed.add(last);return{path:last,name:startName}}
  const r=await dialog.showOpenDialog(win,{properties:['openDirectory','createDirectory'],title:'پوشه‌ی بکاپ'});
  if(r.canceled||!r.filePaths[0])return null;
  const d=r.filePaths[0];allowed.add(d);
  try{fs.writeFileSync(cfgFile(),JSON.stringify({dir:d}))}catch(e){}
  return{path:d,name:path.basename(d)};
});
ipcMain.handle('write-file',async(_e,dir,name,data)=>{
  if(!allowed.has(dir))throw new Error('پوشه مجاز نیست');
  await fs.promises.writeFile(path.join(dir,path.basename(String(name))),data,'utf8');return true;
});

ipcMain.handle('list-files',async(_e,dir)=>{if(!allowed.has(dir))return[];return bfs.listBackups(dir)});
ipcMain.handle('remove-file',async(_e,dir,name)=>{if(!allowed.has(dir))throw new Error('پوشه مجاز نیست');return bfs.removeBackup(dir,name)});
// خروج: اگر پوشه‌ی بکاپ تنظیم نشده، یک نسخه در Documents\Technokala-Backups ذخیره می‌شود (بدون پنجره‌ی دانلود)
ipcMain.handle('backup-close',async(_e,json,name)=>{
  try{
    const dir=path.join(app.getPath('documents'),'Technokala-Backups');
    fs.mkdirSync(dir,{recursive:true});
    fs.writeFileSync(path.join(dir,path.basename(String(name||'تکنوکالا-بکاپ-خودکار-خروج.json'))),json,'utf8');
    bfs.pruneAuto(dir,12);
  }catch(e){}
  app.quit();
});
ipcMain.handle('quit-app',async()=>{app.quit()});
