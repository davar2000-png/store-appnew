#!/usr/bin/env python3
"""ساخت آیکن «تکنوکالا» (PNG و ICO چندسایزه). نیازمندی‌ها: pip install weasyprint pymupdf pillow
اجرا: python3 make-icon.py   ← خروجی: ../icon.ico  ../icon.png  ../app/icon-48.png"""
import io,os,struct
import weasyprint,pymupdf
from PIL import Image
here=os.path.dirname(os.path.abspath(__file__))
def render(name,px=1024):
    pdf=weasyprint.HTML(filename=os.path.join(here,name)).write_pdf()
    doc=pymupdf.open(stream=pdf,filetype='pdf');page=doc[0]
    pix=page.get_pixmap(matrix=pymupdf.Matrix(px/page.rect.width,px/page.rect.height),alpha=True)
    return Image.open(io.BytesIO(pix.tobytes('png'))).convert('RGBA')
full=render('master-full.html');simple=render('master-simple.html')
def sized(n):
    src=full if n>=128 else simple
    return src.resize((n,n),Image.LANCZOS)
SIZES=[16,24,32,48,64,128,256]
def dib(im):
    """داده‌ی BMP (DIB) با کانال آلفا برای ورودی‌های کوچک ICO (سازگار با همه‌ی نسخه‌های ویندوز و rcedit)"""
    w,h=im.size;px=im.convert('RGBA').load()
    rows=b''.join(b''.join(struct.pack('<BBBB',px[x,y][2],px[x,y][1],px[x,y][0],px[x,y][3]) for x in range(w)) for y in range(h-1,-1,-1))
    mask=b''.join(bytes(((w+31)//32)*4) for _ in range(h))
    return struct.pack('<IiiHHIIiiII',40,w,h*2,1,32,0,len(rows)+len(mask),0,0,0,0)+rows+mask
pngs={}
for n in SIZES:
    im=sized(n)
    if n>=128:
        b=io.BytesIO();im.save(b,'PNG',optimize=True);pngs[n]=b.getvalue()
    else:
        pngs[n]=dib(im)
# ICO دستی با تصویر مخصوص هر اندازه (BMP برای کوچک‌ها، PNG برای ۱۲۸ و ۲۵۶)
hdr=struct.pack('<HHH',0,1,len(SIZES));off=6+16*len(SIZES);ent=b'';data=b''
for n in SIZES:
    d=pngs[n];ent+=struct.pack('<BBBBHHII',0 if n>=256 else n,0 if n>=256 else n,0,0,1,32,len(d),off+len(data));data+=d
open(os.path.join(here,'..','icon.ico'),'wb').write(hdr+ent+data)
full.resize((512,512),Image.LANCZOS).save(os.path.join(here,'..','icon.png'),'PNG',optimize=True)
os.makedirs(os.path.join(here,'..','app'),exist_ok=True)
sized(64).save(os.path.join(here,'..','app','icon-64.png'),'PNG',optimize=True)
simple.resize((128,128),Image.LANCZOS).save(os.path.join(here,'..','app','icon-128.png'),'PNG',optimize=True)
full.save(os.path.join(here,'preview-1024.png'),'PNG',optimize=True)
print('icon ok',SIZES)
