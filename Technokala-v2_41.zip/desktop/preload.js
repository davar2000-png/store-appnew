const {contextBridge,ipcRenderer}=require('electron');
contextBridge.exposeInMainWorld('desktopAPI',{
  httpFetch:(u,o)=>ipcRenderer.invoke('http-fetch',u,o),
  pickDir:n=>ipcRenderer.invoke('pick-dir',n),
  writeFile:(dir,name,data)=>ipcRenderer.invoke('write-file',dir,name,data),
  listFiles:dir=>ipcRenderer.invoke('list-files',dir),
  removeFile:(dir,name)=>ipcRenderer.invoke('remove-file',dir,name)
});
contextBridge.exposeInMainWorld('electronAPI',{
  backupAndClose:(json,name)=>ipcRenderer.invoke('backup-close',json,name),
  quit:()=>ipcRenderer.invoke('quit-app')
});
