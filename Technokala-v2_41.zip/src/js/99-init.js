/* ================= راه‌اندازی ================= */
(async function init(){
 await idb.open();
 let saved=await idb.get('kv','db');
 if(typeof saved==='string'){try{saved=JSON.parse(saved)}catch(e){saved=null}}
 if(!(saved&&saved.persons)){try{const ix=await snapIndex();const last=ix.sort((a,b)=>b.t-a.t)[0];if(last){const r=await idb.get('snap','s'+last.t);const d=snapData(r);if(d&&d.persons){saved=d;toast('⚠️ داده‌ی اصلی خراب بود؛ آخرین اسنپ‌شات بارگذاری شد',false)}}}catch(e){}}
 if(saved&&saved.persons)await hydrateImgs(saved);
 imgWatch();
 if(saved&&saved.persons){DB=saved;DB.settings={...defSettings,...DB.settings};migrate(DB);toast('👋 خوش آمدید — داده‌های قبلی بارگذاری شد')}
 else{DB=seedDB();await saveDB();toast('👋 خوش آمدید — پایگاه داده جدید ایجاد شد')}
 if(DB.settings.demoVersion!=='clean-v1'&&!hasUserData(DB)){DB=seedDB();await saveDB();toast('🧹 پایگاه داده جدید بازنشانی شد')}
 try{tsStamp()}catch(e){}
 try{if(!DB.settings.stdGroupsV1){ensurePersonGroups();DB.settings.stdGroupsV1=true}}catch(e){}
 await seedInstallmentsOnce();
 $('chipDate').textContent='📅 '+jLong(jToday());
 $('stDir').textContent=DB.settings.backupDirName||'تنظیم نشده';
 restoreDirHandle();
 saveDB(true);startAutoBackup();
 lkUI();
 await appLockGate();
 nav('dash');
 lkWatch();setTimeout(()=>migrateSnaps(),4000);
 setTimeout(()=>{try{smsStartupCheck()}catch(e){console.error(e)}},1500);
 setTimeout(()=>{try{instEntryAlert()}catch(e){console.error(e)}},3500);
 setTimeout(()=>smsAutoRemind(),9000);setInterval(()=>smsAutoRemind(),30*60*1000);
 let _act=Date.now(),_actSaved=0;['click','input','keydown','change'].forEach(ev=>document.addEventListener(ev,()=>{_act=Date.now()},true));
 setInterval(()=>{if(_act>_actSaved){_actSaved=Date.now();saveDB(true)}notifDotUpd()},30000);
})();



