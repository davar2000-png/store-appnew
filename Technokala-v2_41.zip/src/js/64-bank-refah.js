/* ===== ورود گردش حساب بانک رفاه و وصول خودکار اقساط مستمری‌بگیران ===== */
const RF_STRIP=/[\u200c\u200e\u200f\u202a-\u202e\u0640]/g;
function rfNormName(s){return String(s||'').replace(RF_STRIP,'').replace(/ي/g,'ی').replace(/ك/g,'ک').replace(/[\u064B-\u065F]/g,'').replace(/[^\u0600-\u06FFa-zA-Z0-9]/g,'')}
function rfNatId(s){let d=faDig(String(s==null?'':s)).replace(/\D/g,'');if(d.length>=8&&d.length<10)d=d.padStart(10,'0');return d.length===10?d:''}
function rfParse(wb){
 const ws=wb.Sheets[wb.SheetNames[0]];if(!ws)return null;
 const a=XLSX.utils.sheet_to_json(ws,{header:1,defval:'',raw:true});
 const cl=x=>String(x==null?'':x).replace(RF_STRIP,'').trim();
 let hi=-1;for(let r=0;r<Math.min(a.length,40);r++){const t=a[r].map(cl);if(t.includes('توضیحات')&&t.includes('واریز')){hi=r;break}}
 if(hi<0)return null;
 const h=a[hi].map(cl),ci=n=>h.indexOf(n);
 const cD=ci('توضیحات'),cI=ci('شناسه واریز'),cDoc=ci('شماره سند'),cA=ci('واریز'),cDt=ci('تاریخ');
 const out=[];let other=0;
 for(let r=hi+1;r<a.length;r++){
  const x=a[r],amt=Number(faDig(String(x[cA]==null?'':x[cA])).replace(/[, ]/g,''))||0,desc=String(x[cD]||'').replace(RF_STRIP,' ').replace(/\s+/g,' ').trim();
  if(!amt||!desc)continue;
  const m=desc.match(/قسط\s+(.+)$/);
  if(!m){other++;continue}
  out.push({date:jNorm(cl(x[cDt])),desc,name:m[1].trim(),idn:cI>=0?rfNatId(x[cI]):'',doc:cl(x[cDoc]),amt});
 }
 return {rows:out,other};
}
function rfMatch(){
 const S=window._rf,rate=S.unit==='rial'?10:1,scope=S.onlyRefah?'ig-refah':'',used=new Set(),seen=DB.bankSeen||{};
 /* نمایه‌ی یک‌باره‌ی اشخاص (کد ملی و نام) تا هر ردیف گردش بانک جست‌وجوی خطی نکند */
 const nidMap=new Map(),nameMap=new Map(),norm=[],push=(m,k,v)=>{let l=m.get(k);if(!l){l=[];m.set(k,l)}l.push(v)};
 DB.persons.forEach(p=>{const a=rfNatId(p.nationalId),b=rfNormName(p.name);if(a)push(nidMap,a,p);if(b){push(nameMap,b,p);norm.push([b,p])}});
 const X=ix();
 S.rows.forEach(r=>{
  r.toman=Math.round(r.amt/rate);r.key='rf|'+r.doc+'|'+r.date+'|'+r.amt;
  r.status='';r.how='';r.cands=[];r.sel='';r.chk=false;r.pids=[];
  if(seen[r.key]){r.status='dup';return}
  let ps=r.idn?(nidMap.get(r.idn)||[]):[];if(ps.length)r.how='کدملی';
  const nn=rfNormName(r.name);
  if(!ps.length){ps=nameMap.get(nn)||[];if(ps.length)r.how='نام'}
  if(!ps.length&&nn.length>=6){ps=norm.filter(x=>x[0].length>=6&&(x[0].includes(nn)||nn.includes(x[0]))).map(x=>x[1]);if(ps.length)r.how='نام (تقریبی)'}
  if(!ps.length){r.status='noperson';return}
  r.pids=[...new Set(ps.map(p=>p.id))];
  r.cands=r.pids.flatMap(id=>X.instByPerson.get(id)||[]).filter(i=>!i.paid&&(!scope||instGrp(i)===scope)).sort((x,y)=>x.due<y.due?-1:x.due>y.due?1:(x.no||0)-(y.no||0));
  if(!r.cands.length){r.status='none';return}
  const free=r.cands.filter(i=>!used.has(i.id)),ex=free.find(i=>Math.abs(Number(i.amount)-r.toman)<=1);
  if(ex){r.sel=ex.id;used.add(ex.id);if(r.how==='نام (تقریبی)')r.status='maybe';else{r.status='ok';r.chk=true}}
  else if(free.length){r.sel=free[0].id;r.status='diff'}
  else r.status='none';
 });
}
const RF_BADGE={ok:['b-g','✅ منطبق'],maybe:['b-o','🔎 نام تقریبی'],diff:['b-o','⚠️ مبلغ متفاوت'],none:['b-r','قسط بازی ندارد'],noperson:['b-r','شخص یافت نشد'],dup:['b-b','قبلاً وصول شده']};
const RF_ORDER=['ok','maybe','diff','none','noperson','dup'];
function rfDiff(r){const i=r.sel?DB.installments.find(x=>x.id===r.sel):null;return i?Math.abs(r.toman-Number(i.amount)):0}
/* فهرست نمایش‌داده‌شده: فیلتر وضعیت + جستجو + مرتب‌سازی (اندیس اصلی ردیف حفظ می‌شود) */
function rfView(){
 const S=window._rf,q=rfNormName(S.q||''),dir=S.dir==='desc'?-1:1;
 const v=S.rows.map((r,k)=>({r,k})).filter(x=>S.show[x.r.status]&&(!q||rfNormName(x.r.name).includes(q)||String(x.r.idn||'').includes(q)));
 const key=x=>S.sort==='name'?rfNormName(x.r.name):S.sort==='amount'?x.r.toman:S.sort==='status'?RF_ORDER.indexOf(x.r.status):S.sort==='diff'?rfDiff(x.r):(x.r.date||'');
 v.sort((a,b)=>{const A=key(a),B=key(b);return (A<B?-1:A>B?1:a.k-b.k)*dir});
 return v;
}
function rfRowHtml(r,k){
 const can=r.sel&&r.status!=='dup',inst=r.sel?DB.installments.find(i=>i.id===r.sel):null;
 let opts='';if(r.cands.length)opts='<select onchange="rfSel('+k+',this.value)" style="max-width:230px">'+r.cands.map(i=>'<option value="'+i.id+'" '+(i.id===r.sel?'selected':'')+'>'+(r.pids.length>1?esc(PN(i.person))+' — ':'')+'قسط '+fa(i.no)+' · '+fa(i.due)+' · '+fm(i.amount)+'</option>').join('')+'</select>';
 const diff=inst&&r.status!=='ok'?'<div style="font-size:11px;color:var(--mut)">اختلاف: '+fm(r.toman-Number(inst.amount))+'</div>':'';
 return '<tr id="rfr'+k+'"><td>'+(can?'<input type="checkbox" '+(r.chk?'checked':'')+' onchange="rfChk('+k+',this.checked)">':'')+'</td><td>'+fa(r.date)+'</td><td class="r">'+esc(r.name)+'</td><td><small>'+fa(r.idn||'')+'</small></td><td>'+fm(r.toman)+'</td><td>'+(r.pids.length?esc(PN(r.pids[0]))+(r.how?'<div style="font-size:11px;color:var(--mut)">'+r.how+'</div>':''):'—')+'</td><td>'+opts+diff+'</td><td><span class="bdg '+RF_BADGE[r.status][0]+'">'+RF_BADGE[r.status][1]+'</span></td></tr>';
}
function rfChips(){
 const S=window._rf,cnt={};S.rows.forEach(r=>cnt[r.status]=(cnt[r.status]||0)+1);
 $('rfChips').innerHTML=RF_ORDER.map(k=>'<label class="bdg '+RF_BADGE[k][0]+'" style="cursor:pointer;padding:5px 9px"><input type="checkbox" '+(S.show[k]?'checked':'')+' onchange="rfFilter(\''+k+'\',this.checked)"> '+RF_BADGE[k][1]+' ('+fa(cnt[k]||0)+')</label>').join(' ')+(S.other?' <span class="bdg b-b">ردیف غیرقسط (نادیده): '+fa(S.other)+'</span>':'');
}
function rfSummary(){
 const S=window._rf,v=rfView(),chosen=S.rows.filter(r=>r.chk&&r.sel&&r.status!=='dup'),sum=chosen.reduce((a,r)=>a+r.toman,0);
 $('rfSum').innerHTML='نمایش <b>'+fa(v.length)+'</b> از '+fa(S.rows.length)+' ردیف — انتخاب‌شده: <b>'+fa(chosen.length)+'</b> قسط — جمع <b>'+fm(sum)+'</b> تومان';
}
function rfRender(){
 const S=window._rf,sc=$('rfScroll'),top=sc?sc.scrollTop:0,v=rfView();
 $('rfBody').innerHTML='<table data-rn="0"><thead><tr><th></th><th>تاریخ</th><th>نام در بانک</th><th>کد ملی</th><th>مبلغ (تومان)</th><th>شخص در برنامه</th><th>قسط</th><th>وضعیت</th></tr></thead><tbody>'+(v.map(x=>rfRowHtml(x.r,x.k)).join('')||'<tr><td colspan="8"><div class="empty">ردیفی با این فیلتر نیست</div></td></tr>')+'</tbody></table>';
 if(sc)sc.scrollTop=top;
 rfSummary();
}
function rfOpen(){
 const S=window._rf,def=(DB.accounts.find(a=>/رفاه/.test(a.title))||DB.accounts[0]||{}).id;
 const so=(v,l)=>'<option value="'+v+'" '+(S.sort===v?'selected':'')+'>'+l+'</option>';
 openM(mHead('🏦 گردش حساب بانک رفاه — وصول خودکار اقساط')+
  '<div id="rfTop" style="flex:none;padding:10px 16px;border-bottom:1px solid var(--bd);background:#fff">'+
  '<div class="frow" style="align-items:flex-end;gap:10px">'+
   '<div class="fg"><label>واحد مبلغ در فایل بانک</label><select id="rfUnit" onchange="rfSet()"><option value="rial" '+(S.unit==='rial'?'selected':'')+'>ریال (÷۱۰ → تومان)</option><option value="toman" '+(S.unit==='toman'?'selected':'')+'>تومان</option></select></div>'+
   '<div class="fg"><label>حساب بانکی (ثبت ورودی)</label><select id="rfAcc">'+DB.accounts.map(a=>'<option value="'+a.id+'" '+(a.id===def?'selected':'')+'>'+esc(a.title)+'</option>').join('')+'</select></div>'+
   '<div class="fg"><label>مرتب‌سازی</label><div style="display:flex;gap:6px"><select id="rfSort" onchange="rfSort()">'+so('date','تاریخ')+so('name','نام')+so('amount','مبلغ')+so('diff','اختلاف مبلغ')+so('status','وضعیت')+'</select><select id="rfDir" onchange="rfSort()"><option value="asc" '+(S.dir==='asc'?'selected':'')+'>صعودی ↑</option><option value="desc" '+(S.dir==='desc'?'selected':'')+'>نزولی ↓</option></select></div></div>'+
   '<div class="fg"><label>جستجو (نام / کد ملی)</label><input id="rfQ" style="min-width:170px" oninput="window._rf.q=this.value;rfRender()"></div>'+
  '</div>'+
  '<div id="rfChips" style="margin:8px 0 6px;font-size:12px;line-height:2.1"></div>'+
  '<div style="display:flex;gap:12px;align-items:center;flex-wrap:wrap;font-size:12px">'+
   '<label><input type="checkbox" id="rfOnly" '+(S.onlyRefah?'checked':'')+' onchange="rfSet()"> فقط اقساط لیست «'+esc(instGName('ig-refah'))+'»</label>'+
   '<label><input type="checkbox" id="rfThanks" '+(DB.settings.thanksOn!==false?'checked':'')+'> ارسال پیام تشکر</label>'+
   '<button class="btn sm g" onclick="rfAll(true)">☑️ تیک همه‌ی نمایش‌داده‌شده</button><button class="btn sm" onclick="rfAll(false)">⬜ برداشتن تیک‌ها</button>'+
   '<span id="rfSum" style="margin-inline-start:auto;font-size:13px"></span></div>'+
  '<div style="font-size:11px;color:var(--mut);margin-top:4px">تطبیق با کد ملی (شناسه واریز) و سپس نام. فقط «منطبق»ها تیک دارند؛ بقیه را پس از بررسی خودتان تیک بزنید. ردیف‌های وصول‌شده دوباره ثبت نمی‌شوند.</div></div>'+
  '<div class="mbody" id="rfScroll" style="padding:0 16px 10px"><div id="rfBody"></div></div>'+
  '<div class="mfoot"><button class="btn p" onclick="rfCommit()">✅ ثبت وصول اقساط انتخاب‌شده</button><button class="btn" onclick="closeM()">انصراف</button></div>',true);
 const mm=document.querySelector('#modal .m');if(mm){mm.classList.add('pwfull');$('modal').classList.add('pwfull')}
 rfChips();rfRender();
}
function rfSet(){const S=window._rf;S.unit=$('rfUnit').value;S.onlyRefah=$('rfOnly').checked;rfMatch();rfChips();rfRender()}
function rfFilter(k,v){window._rf.show[k]=!!v;rfRender()}
function rfSort(){const S=window._rf;S.sort=$('rfSort').value;S.dir=$('rfDir').value;rfRender()}
function rfAll(on){rfView().forEach(x=>{if(!on)x.r.chk=false;else if(x.r.sel&&x.r.status!=='dup')x.r.chk=true});rfRender()}
function rfChk(k,v){window._rf.rows[k].chk=!!v;rfSummary()}
function rfSel(k,id){
 const r=window._rf.rows[k];r.sel=id;const i=DB.installments.find(x=>x.id===id);
 r.status=i&&Math.abs(Number(i.amount)-r.toman)<=1?(r.how==='نام (تقریبی)'?'maybe':'ok'):'diff';r.chk=false;
 const tr=$('rfr'+k);if(tr&&tr.outerHTML!==undefined)tr.outerHTML=rfRowHtml(r,k);
 rfChips();rfSummary();
}
function rfFile(input){
 const f=input.files[0];if(!f)return;const rd=new FileReader();
 rd.onload=e=>{
  try{
   const wb=XLSX.read(new Uint8Array(e.target.result),{type:'array'}),res=rfParse(wb);
   if(!res||!res.rows.length){toast('❌ ردیفی با عبارت «بابت قسط …» در فایل پیدا نشد',false);return}
   window._rf={rows:res.rows,other:res.other,unit:'rial',onlyRefah:true,fname:f.name,show:{ok:true,maybe:true,diff:true,none:true,noperson:true,dup:true},sort:'date',dir:'asc',q:''};rfMatch();rfOpen();
  }catch(err){console.error(err);toast('❌ خطا در خواندن فایل: '+(err&&err.message||err),false)}
  input.value='';
 };
 rd.readAsArrayBuffer(f);
}
async function rfCommit(){ixInvalidate();
 const S=window._rf,acc=$('rfAcc').value,todo=S.rows.filter(r=>r.chk&&r.sel&&r.status!=='dup');
 if(!todo.length){toast('⚠️ موردی انتخاب نشده',false);return}
 try{await snapshot('قبل از وصول اقساط از گردش بانک',true)}catch(e){}
 DB.bankSeen=DB.bankSeen||{};let n=0,sum=0;const thanks=[],doThanks=!!($('rfThanks')||{}).checked;
 todo.forEach(r=>{
  const i=DB.installments.find(x=>x.id===r.sel);if(!i||i.paid||DB.bankSeen[r.key])return;
  const date=r.date||jToday(),amt=r.toman;
  i.paid=true;i.paidDate=date;i.paidMethod='account';i.amountPaid=amt;i.bankRef=r.key;
  const rid=uid();
  DB.receipts.push({id:rid,instId:i.id,no:nextNo('rec'),date,person:i.person,dir:'in',rows:[{method:'account',amount:amt,acc}],desc:'پرداخت قسط '+fa(i.no)+' — گردش بانک رفاه'+(r.doc?' (سند '+r.doc+')':'')});
  if(acc)DB.accTx.push({id:uid(),acc,date,type:'in',amount:amt,desc:'قسط '+PN(i.person)+' — بانک رفاه',ref:rid});
  DB.bankSeen[r.key]=i.id;n++;sum+=amt;thanks.push({kind:'ThankInst',person:i.person,amount:amt,no:i.no,date});
 });
 logAct('وصول '+n+' قسط از گردش حساب بانک رفاه — '+fm(sum)+' تومان');saveDB();closeM();
 try{nav(curView||'inst')}catch(e){}
 if(doThanks){try{msgThanksBatch(thanks)}catch(e){console.error(e)}}
 toast('✅ '+fa(n)+' قسط وصول شد — جمع '+fm(sum)+' تومان');
}
