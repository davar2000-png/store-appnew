/* ================= 📜 ممیزی، ابطال‌شده‌ها و تست داخلی ================= */
function auditPush(act,before,after){
 const sum=x=>x?{no:x.no,type:x.type,date:x.date,total:invTotal(x),lines:(x.lines||[]).length}:null;
 DB.audit.unshift({t:new Date().toLocaleString('fa-IR'),user:'مدیر',act,before:sum(before),after:sum(after),beforeFull:before?JSON.parse(JSON.stringify(before)):null});
 if(DB.audit.length>500)DB.audit.length=500;
}
function auditView(){
 const s=x=>x?(fa(x.lines)+' قلم — '+fm(x.total)+' ت — '+jShort(x.date)):'—';
 openM(mHead('📜 ممیزی و ابطال‌شده‌ها')+'<div class="mbody"><h4>🗑️ فاکتورهای ابطال‌شده ('+fa(DB.voided.length)+')</h4>'+
  (DB.voided.length?'<table data-rn="0"><thead><tr><th>شماره</th><th>نوع</th><th>مبلغ</th><th>زمان</th><th>دلیل</th></tr></thead><tbody>'+DB.voided.slice(0,50).map(v=>'<tr><td>'+fa(v.no)+'</td><td>'+invTypeFa(v.type)+'</td><td>'+fm(invTotal(v))+'</td><td>'+esc(v.voidedAt)+'</td><td>'+esc(v.reason||'—')+'</td></tr>').join('')+'</tbody></table>':'<div class="empty">موردی نیست</div>')+
  '<h4 style="margin-top:14px">🧾 تغییرات فاکتورها (قبل ← بعد)</h4>'+
  (DB.audit.length?'<table data-rn="0"><thead><tr><th>زمان</th><th>عملیات</th><th>قبل</th><th>بعد</th></tr></thead><tbody>'+DB.audit.slice(0,50).map(a=>'<tr><td>'+esc(a.t)+'</td><td>'+esc(a.act)+'</td><td>'+s(a.before)+'</td><td>'+s(a.after)+'</td></tr>').join('')+'</tbody></table>':'<div class="empty">موردی نیست</div>')+
  '</div><div class="mfoot"><button class="btn" onclick="closeM()">بستن</button></div>');
}
function selfTests(){
 const res=[],ck=(n,a,e)=>res.push({n,ok:JSON.stringify(a)===JSON.stringify(e),a,e});
 const real=DB;
 try{
  DB={settings:{},counters:{},products:[{id:'p1',name:'T',track:'qty'},{id:'p2',name:'S',track:'serial'}],persons:[{id:'c1',name:'c'}],
   serials:[{id:'s1',pid:'p2',sn:'1',status:'stock'},{id:'s2',pid:'p2',sn:'2',status:'stock'},{id:'s3',pid:'p2',sn:'3',status:'sold'}],
   invoices:[
    {id:'i1',type:'buy',no:1,date:'1404/01/01',person:'s1',lines:[{pid:'p1',qty:10,price:100,cost:100}],pays:[]},
    {id:'i2',type:'sale',no:2,date:'1404/01/02',person:'c1',lines:[{pid:'p1',qty:4,price:150,cost:100}],pays:[{method:'cash',amount:400},{method:'installment',amount:200}]},
    {id:'i3',type:'saleret',no:3,date:'1404/01/03',person:'c1',lines:[{pid:'p1',qty:1,price:150,cost:100}],pays:[]},
    {id:'i4',type:'proforma',no:4,date:'1404/01/03',person:'c1',lines:[{pid:'p1',qty:99,price:1,cost:1}],pays:[]}],
   receipts:[{id:'r1',person:'c1',dir:'in',rows:[{amount:50,method:'cash'}]}],cheques:[],installments:[],accTx:[],log:[],voided:[],audit:[]};
  const sale=DB.invoices[1];
  ck('موجودی کالای عادی (پیش‌فاکتور اثری ندارد)',stockOf('p1'),7);
  ck('موجودی سریالی',stockOf('p2'),2);
  const bw=q=>invWarnings({kind:'buyret',id:'',date:'1404/01/05',person:'s1',lines:[{pid:'p1',sid:'',sn:'',qty:q,price:100,cost:0}]}).some(x=>x.startsWith('⛔'));
  ck('برگشت از خرید بیش از موجودی مسدود می‌شود',[bw(8),bw(7)],[true,false]);
  DB.settings.allowNegative=true;ck('با مجاز بودن منفی فقط هشدار می‌دهد',bw(8),false);DB.settings.allowNegative=false;
  ck('ویرایش فاکتور خرید به‌طوری‌که موجودی منفی شود مسدود است',invWarnings({kind:'buy',id:'i1',date:'1404/01/01',person:'s1',lines:[{pid:'p1',sid:'',sn:'',qty:2,price:100,cost:0}]}).some(x=>x.startsWith('⛔')),true);
  DB.invoices.push({id:'i9',type:'buy',no:9,date:'1404/01/03',person:'s1',lines:[{pid:'p1',qty:5,price:130,cost:130}],pays:[]});refreshLastCost(['p1']);
  ck('بهای آخرین خرید پس از فاکتور خرید جدید به‌روز می‌شود',DB.products[0].lastCost,130);
  DB.invoices.pop();
  const mkS=(n,auto,off)=>Array.from({length:n},(_,i)=>({t:off+i,label:auto?'خودکار (۵ دقیقه‌ای)':'دستی',auto}));
  const sd=snapsToDelete([...mkS(15,true,1000),...mkS(3,false,5000)]);
  ck('پاک‌سازی اسنپ‌شات: فقط خودکارهای اضافه (۳ قدیمی‌ترین) حذف می‌شود',[sd.length,sd.every(r=>r.auto),Math.max(...sd.map(r=>r.t))],[3,true,1002]);
  ck('اسنپ‌شات‌های دستی با ۱۲ خودکار جابه‌جا نمی‌شوند',snapsToDelete([...mkS(40,true,1000),...mkS(30,false,5000)]).filter(r=>!r.auto).length,0);
  ck('اسنپ‌شات برچسب‌دار قدیمی بدون پرچم، خودکار شناخته می‌شود',[isAutoSnap({t:1,label:'خودکار (۵ دقیقه‌ای)'}),isAutoSnap({t:1,label:'هنگام خروج'})],[true,false]);
  ck('فقط کالا/سریال هم «داده کاربر» حساب می‌شود (پاک نشدن با باز کردن مجدد)',[hasUserData({products:[{}]}),hasUserData({serials:[{}]}),hasUserData({})],[true,true,false]);
  DB.accTx=[{id:'t1',ref:'kx',amount:5,type:'in'},{id:'t2',ref:'other',amount:7,type:'in'}];chqSyncTx({id:'kx',amount:9,dir:'paid'});
  ck('ویرایش مبلغ/نوع چک، تراکنش بانکی همان چک را هم‌گام می‌کند (نه بقیه را)',[DB.accTx[0].amount,DB.accTx[0].type,DB.accTx[1].amount],[9,'out',7]);DB.accTx=[];
  ck('جمع فاکتور',invTotal(sale),600);
  ck('پرداختی (قسط جزو پرداخت نیست)',invPaid(sale),400);
  ck('سود فاکتور',invProfit(sale),200);
  const b=personBalance('c1');
  ck('مانده مشتری (فروش − برگشت − دریافت)',[b.saleDebt,b.profit],[0,200]);
  ck('تبدیل ارقام فارسی',pd('۱٬۲۳۴'),1234);
  ck('تاریخ کبیسه ۱۴۰۳/۱۲/۳۰',jValid('1403/12/30'),true);
  ck('تاریخ غیرکبیسه ۱۴۰۴/۱۲/۳۰',jValid('1404/12/30'),false);
  ck('جمع ماه شمسی (۳۱ شهریور + ۱ ماه)',jAddM('1403/06/31',1),'1403/07/30');
  const jn=jnlBuild(),tb=trialBal(jn),B=c=>{const a=tb.find(x=>x.code===c);return a.d-a.c};
  ck('هر سند متوازن است',jn.every(e=>e.rows.reduce((s,r)=>s+r.d-r.c,0)===0),true);
  ck('تعداد سند (پیش‌فاکتور سند ندارد)',jn.length,4);
  ck('دریافتنی‌ها = مانده اشخاص',B('1201'),personBalance('c1').saleDebt);
  ck('پرداختنی‌ها',-B('2101'),1000);
  ck('موجودی کالا در دفتر',B('1301'),700);
  ck('بهای تمام‌شده خالص',B('5101'),300);
  ck('صندوق',B('1101'),450);
  DB.accounts=[];DB.opening={date:'1404/01/01',cash:500,inventory:0};DB.expenses=[{id:'e1',no:1,date:'1404/01/04',cat:'6101',amount:30,method:'cash'}];
  const j2=jnlBuild(),pl=plBuild(j2),bs=bsBuild(j2);
  ck('اسناد با افتتاحیه و هزینه',j2.length,6);
  const q=bsBuild(j2,'1404/01/03');
  ck('تفکیک سود انباشته و سال جاری',[q.Q.map(x=>x.v),q.balanced],[[500,200,-80],true]);
  DB.opening.persons={c1:{rec:100,pay:0}};
  DB.expenses.push({id:'e2',no:2,date:'1404/01/05',cat:'6102',amount:40,method:'credit',person:'s1'});
  DB.cheques=[{id:'k1',no:'9',dir:'rec',amount:70,issue:'1404/01/02',due:'1404/03/01',status:'جاری',inv:'',person:'c1'}];
  const j3=jnlBuild(),t3=trialBal(j3),B3=c=>{const a=t3.find(x=>x.code===c);return a.d-a.c},bs3=bsBuild(j3),pl3=plBuild(j3);
  ck('مانده اول دوره شخص وارد مانده می‌شود',[personBalance('c1').saleDebt,personBalance('s1').buyDebt],[100,1040]);
  ck('دفتر با مانده اشخاص یکی است',[B3('1201'),-B3('2101')],[100,1040]);
  ck('هر سند متوازن (با افتتاحیه اشخاص، نسیه، چک مستقل)',j3.every(e=>e.rows.reduce((s,r)=>s+r.d-r.c,0)===0),true);
  ck('ترازنامه کامل متوازن',[bs3.balanced,bs3.sa,pl3.net],[true,1790,80]);
  DB.accTx=[{id:'m1',acc:'a',date:'1404/01/06',type:'in',amount:200,ref:'',desc:'واریز'},{id:'m2',acc:'a',date:'1404/01/06',type:'out',amount:50,ref:'',desc:'انتقال → ب'},{id:'m3',acc:'b',date:'1404/01/06',type:'in',amount:50,ref:'',desc:'انتقال ← الف'},{id:'m4',acc:'a',date:'1404/01/07',type:'in',amount:100,ref:'',desc:'بهره',kind:'inc'},{id:'m5',acc:'a',date:'1404/01/07',type:'out',amount:20,ref:'',desc:'قبض',kind:'e:6103'}];
  const j4=jnlBuild(),t4=trialBal(j4),b4=bsBuild(j4);
  ck('تراکنش دستی بانک سند می‌شود، انتقال داخلی نه',[t4.find(x=>x.code==='1102').d-t4.find(x=>x.code==='1102').c,b4.balanced,b4.sa],[280,true,2070]);
  ck('درآمد متفرقه و هزینه از تراکنش بانکی در سود و زیان',plBuild(j4).net,160);
  ck('فیلتر بازه‌ی اسناد برای سود و زیان (تابع جدا از فیلتر گزارش‌ها)',[Array.isArray(jnInRange(j2,'','')),plBuild(jnInRange(j2,'','')).net],[true,120]);
  ck('سود خالص (۴۵۰ − ۳۰۰ − ۳۰)',pl.net,120);
  ck('ترازنامه متوازن',[bs.balanced,bs.sa],[true,1620]);
  ck('صندوق پس از افتتاحیه و هزینه',trialBal(j2).find(x=>x.code==='1101').d-trialBal(j2).find(x=>x.code==='1101').c,920);
 /* --- v2.14: چک برگشتی، میانگین موزون، سقف برگشت، ترازنامه --- */
  DB={settings:{},counters:{},products:[{id:'p1',name:'T',track:'qty',lastCost:400}],persons:[{id:'c1',name:'c'},{id:'s1',name:'s'}],serials:[],receipts:[],accounts:[],accTx:[],expenses:[],
   invoices:[
    {id:'a1',type:'buy',no:1,date:'1404/01/01',person:'s1',lines:[{pid:'p1',qty:10,price:300,cost:300}],pays:[]},
    {id:'a2',type:'buy',no:2,date:'1404/01/02',person:'s1',lines:[{pid:'p1',qty:10,price:400,cost:400}],pays:[]},
    {id:'a3',type:'sale',no:3,date:'1404/01/03',person:'c1',lines:[{pid:'p1',qty:4,price:500,cost:350}],pays:[{method:'cheque',amount:2000}]}],
   cheques:[{id:'h1',no:'1',dir:'rec',person:'c1',amount:2000,due:'1404/02/01',status:'جاری',inv:'a3'}]};
  ck('بهای میانگین موزون دو خرید ۳۰۰ و ۴۰۰ پس از فروش',avgCostOf('p1'),350);
  ck('سقف برگشت از فروش = فروش منهای برگشت‌ها',[retRoom('c1','p1','saleret',null),retRoom('s1','p1','saleret',null)],[4,0]);
  const bb0=personBalance('c1').saleDebt;
  DB.cheques[0].status='برگشتی';DB.cheques[0].bouncedDate='1404/02/02';
  const jb=jnlBuild(),tbb=trialBal(jb),bsb=bsBuild(jb);
  ck('چک برگشتی: بدهی مشتری برمی‌گردد و اسناد دریافتنی صفر می‌شود',[bb0,personBalance('c1').saleDebt,tbb.find(x=>x.code==='1202').d-tbb.find(x=>x.code==='1202').c,bsb.balanced],[0,2000,0,true]);
  DB.invoices.push({id:'a4',type:'saleret',no:4,date:'1404/02/03',person:'c1',lines:[{pid:'p1',qty:4,price:500,cost:350}],pays:[]});
  DB.cheques[0].status='جاری';const bs5=bsBuild(jnlBuild());
  ck('مانده‌ی بستانکار مشتری در ترازنامه در سمت بدهی می‌آید و متوازن است',[bs5.balanced,bs5.A.every(x=>x.v>=0)],[true,true]);
  /* --- سن مطالبات --- */
  DB={settings:{},counters:{},products:[{id:'p1',name:'T',track:'qty'}],persons:[{id:'c1',name:'c'}],serials:[],receipts:[{id:'r1',person:'c1',dir:'in',date:'1404/03/01',rows:[{method:'cash',amount:300}]}],accounts:[],accTx:[],expenses:[],cheques:[],installments:[],
   invoices:[{id:'a1',type:'sale',no:1,date:'1404/01/01',person:'c1',lines:[{pid:'p1',qty:1,price:1000,cost:0}],pays:[]},
    {id:'a2',type:'sale',no:2,date:'1404/05/20',person:'c1',lines:[{pid:'p1',qty:1,price:500,cost:0}],pays:[]}]};
  const ag=ageRows('cust','1404/06/01')[0];
  ck('سن مطالبات: دریافت به قدیمی‌ترین فاکتور تخصیص می‌یابد',[ag.b1,ag.b4,ag.total,personBalance('c1').saleDebt],[500,700,1200,1200]);
 }catch(e){res.push({n:'خطای اجرا: '+e.message,ok:false,a:'',e:''})}
 finally{DB=real}
 return res;
}
function selfTestView(){
 const r=selfTests(),bad=r.filter(x=>!x.ok);
 openM(mHead('🧪 تست داخلی محاسبات')+'<div class="mbody"><div style="margin-bottom:8px"><b>'+fa(r.length-bad.length)+'</b> از <b>'+fa(r.length)+'</b> تست موفق</div>'+r.map(x=>'<div style="padding:4px 0;border-bottom:1px solid var(--bd)">'+(x.ok?'✅':'❌')+' '+esc(x.n)+(x.ok?'':' — مقدار: '+esc(JSON.stringify(x.a))+' انتظار: '+esc(JSON.stringify(x.e)))+'</div>').join('')+'</div><div class="mfoot"><button class="btn" onclick="closeM()">بستن</button></div>');
}

