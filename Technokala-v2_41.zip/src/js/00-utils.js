



/* ================================================================
   تکنوکالا v1.9 — ۱۵ گزارش کامل با روزانه/هفتگی/ماهانه/بازه دلخواه/کل
   دوره + داشبورد لحظه‌ای (به‌روزرسانی خودکار ۶۰ ثانیه + ۳ نمودار) +
   جستجوی جامع همه لیست‌ها + پیامک با ۵ قالب قابل ویرایش + مرکز پیامک +
   یکپارچه‌سازی Webhook (فاکتور/مشتری/پیام) + چاپ A4/A5 با تاریخ شمسی
   + چک‌ها ۷ تب + اقساط ۵ تب + بانک ۴ تب
   ================================================================ */

/* ---------- ابزارها ---------- */
const $=id=>document.getElementById(id);
const uid=()=>Date.now().toString(36)+Math.random().toString(36).slice(2,7);
const fa=s=>String(s==null?'':s).replace(/\d/g,d=>'۰۱۲۳۴۵۶۷۸۹'[d]);
const faDig=s=>String(s==null?'':s).replace(/[۰-۹]/g,d=>'۰۱۲۳۴۵۶۷۸۹'.indexOf(d)).replace(/[٠-٩]/g,d=>'٠١٢٣٤٥٦٧٨٩'.indexOf(d));
const _NF=new Intl.NumberFormat('fa-IR');
const fm=n=>_NF.format(Number(n||0));
const pdParse=(v,signed)=>{
 if(typeof v==='number'){if(!isFinite(v))return 0;const r=Math.round(v*100)/100;return signed||r>=0?r:-r}
 let t=faDig(v).replace(/[\u200e\u200f\u202a-\u202e\s]/g,'').replace(/[٬،,]/g,'').replace(/٫/g,'.');
 const neg=signed&&/^[-−–]/.test(t);
 t=t.replace(/[^\d.]/g,'');
 if(/^\d{1,3}(\.\d{3})+$/.test(t))t=t.replace(/\./g,'');
 const i=t.indexOf('.');if(i>=0)t=t.slice(0,i+1)+t.slice(i+1).replace(/\./g,'');
 let n=parseFloat(t);if(!isFinite(n))return 0;
 n=Math.round(n*100)/100;return neg?-n:n};
const pd=v=>pdParse(v,false);
const pdS=v=>pdParse(v,true);
const esc=s=>String(s==null?'':s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;');
function toast(m,ok=true){const t=$('toast');t.textContent=String(m).replace(/&lt;/g,'<').replace(/&gt;/g,'>').replace(/&quot;/g,'"').replace(/&#39;/g,"'").replace(/&amp;/g,'&');t.className='show '+(ok?'ok':'err');clearTimeout(t._h);t._h=setTimeout(()=>t.className='',3200)}
function rf(id){const el=$(id);if(el){el.focus();try{const l=el.value.length;el.setSelectionRange(l,l)}catch(e){}}}

