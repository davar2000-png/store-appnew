/* ================= 🔐 قفل برنامه — رمز ورود =================
   فقط ورود به برنامه رمز می‌خواهد؛ دیدن مدارک پس از ورود رمز جداگانه ندارد.
   رمز با PBKDF2‑SHA256 (۱۵۰٬۰۰۰ دور) هش می‌شود و خود رمز جایی ذخیره نمی‌شود.
   توجه: این قفل جلوی ورود به برنامه را می‌گیرد؛ داده‌های روی دیسک رمزنگاری نمی‌شوند. */
const b64e=u=>btoa(String.fromCharCode.apply(null,u)),b64d=s=>Uint8Array.from(atob(s),c=>c.charCodeAt(0));
let _lkResolve=null,_locked=false,_lkFails=0,_lkUntil=0,_lastAct=Date.now();
function lkOn(){const a=DB&&DB.settings&&DB.settings.appLock;return !!(a&&a.pw&&a.pw.hash)}
function lkOk(){return typeof crypto!=='undefined'&&!!crypto.subtle&&!!crypto.subtle.deriveBits}
function lkCarry(old){return s=>{s.appLock=(old&&old.appLock)||null;s.delPass=(old&&old.delPass)||null;if(old&&old.autoLockMin!==undefined)s.autoLockMin=old.autoLockMin}}
async function lkHash(pw,salt,iter){
 const k=await crypto.subtle.importKey('raw',new TextEncoder().encode(faDig(String(pw))),'PBKDF2',false,['deriveBits']);
 return b64e(new Uint8Array(await crypto.subtle.deriveBits({name:'PBKDF2',hash:'SHA-256',salt:b64d(salt),iterations:iter},k,256)));
}
async function lkMake(pw){const salt=b64e(crypto.getRandomValues(new Uint8Array(16))),iter=150000;return{salt,iter,hash:await lkHash(pw,salt,iter)}}
async function lkCheck(rec,pw){try{return !!rec&&(await lkHash(pw,rec.salt,rec.iter))===rec.hash}catch(e){return false}}
const lkNormRec=s=>String(s||'').toUpperCase().replace(/[^A-Z0-9]/g,'');
function lkRecCode(){const al='ABCDEFGHJKLMNPQRSTUVWXYZ23456789',r=crypto.getRandomValues(new Uint8Array(16));let s='';r.forEach(x=>{s+=al[x%al.length]});return s.match(/.{4}/g).join('-')}

/* ---- تنظیم / تغییر / حذف رمز (منطق، بدون رابط) ---- */
async function appLockSet(np,cp,newRec){
 if(!lkOk())return{ok:false,msg:'این محیط از رمزنگاری پشتیبانی نمی‌کند'};
 np=String(np||'');if(np.length<4)return{ok:false,msg:'رمز باید حداقل ۴ کاراکتر باشد'};
 if(lkOn()&&cp!==null&&!(await lkCheck(DB.settings.appLock.pw,cp)))return{ok:false,msg:'رمز فعلی اشتباه است'};
 const pw=await lkMake(np);let rec=lkOn()?DB.settings.appLock.rec:null,code='';
 if(!rec||newRec){code=lkRecCode();rec=await lkMake(lkNormRec(code))}
 DB.settings.appLock={pw,rec};
 if(DB.settings.autoLockMin===undefined)DB.settings.autoLockMin=10;
 logAct('تنظیم/تغییر رمز ورود');saveDB();lkUI();return{ok:true,code};
}
async function appLockNewRec(cp){
 if(!lkOn())return{ok:false,msg:'رمزی تنظیم نشده است'};
 if(!(await lkCheck(DB.settings.appLock.pw,cp)))return{ok:false,msg:'رمز فعلی اشتباه است'};
 const code=lkRecCode();DB.settings.appLock.rec=await lkMake(lkNormRec(code));saveDB();return{ok:true,code};
}
async function appLockRemove(cp){
 if(!lkOn())return{ok:true};
 if(!(await lkCheck(DB.settings.appLock.pw,cp)))return{ok:false,msg:'رمز فعلی اشتباه است'};
 DB.settings.appLock=null;logAct('حذف رمز ورود');saveDB();lkUI();return{ok:true};
}

/* ---- صفحه‌ی قفل ---- */
function lkMode(m){$('lkLogin').style.display=m==='login'?'':'none';$('lkRecover').style.display=m==='recover'?'':'none';$('lkMsg').textContent='';setTimeout(()=>{const e=$(m==='login'?'lkPw':'lkRc');if(e)e.focus()},30)}
function lkShow(){
 return new Promise(res=>{_lkResolve=res;_locked=true;const el=$('lockScreen');el.style.display='flex';$('lkPw').value='';lkMode('login')});
}
function lkDone(){
 _locked=false;_lkFails=0;_lkUntil=0;_lastAct=Date.now();$('lockScreen').style.display='none';
 ['lkPw','lkRc','lkRn1','lkRn2'].forEach(i=>{const e=$(i);if(e)e.value=''});
 const r=_lkResolve;_lkResolve=null;if(r)r();
}
async function appLockGate(){if(lkOn())await lkShow()}
function appLockNow(){if(!lkOn()||_locked)return;lkShow()}
async function appUnlock(){
 const msg=$('lkMsg'),now=Date.now();
 if(now<_lkUntil){msg.textContent='چند بار رمز اشتباه وارد شد؛ '+fa(Math.ceil((_lkUntil-now)/1000))+' ثانیه صبر کنید';return}
 const pw=$('lkPw').value;if(!pw)return;
 if(await lkCheck(DB.settings.appLock.pw,pw)){lkDone();return}
 _lkFails++;if(_lkFails>=3)_lkUntil=Date.now()+Math.min(60,(_lkFails-2)*5)*1000;
 msg.textContent='رمز اشتباه است';$('lkPw').value='';$('lkPw').focus();
}
async function lkRecoverDo(){
 const msg=$('lkMsg'),code=lkNormRec($('lkRc').value),n1=$('lkRn1').value,n2=$('lkRn2').value;
 if(Date.now()<_lkUntil){msg.textContent='کمی صبر کنید و دوباره تلاش کنید';return}
 if(!code){msg.textContent='کد بازیابی را وارد کنید';return}
 if(n1!==n2){msg.textContent='رمز جدید و تکرار آن یکی نیست';return}
 if(String(n1).length<4){msg.textContent='رمز جدید باید حداقل ۴ کاراکتر باشد';return}
 if(!(await lkCheck(DB.settings.appLock.rec,code))){_lkFails++;_lkUntil=Date.now()+Math.min(60,_lkFails*5)*1000;msg.textContent='کد بازیابی درست نیست';return}
 const r=await appLockSet(n1,null,true);
 if(!r.ok){msg.textContent=r.msg;return}
 lkDone();setTimeout(()=>lkShowCode(r.code,'رمز تغییر کرد؛ کد بازیابی جدید'),200);
}
function lkUI(){const b=$('btnLock');if(b)b.style.display=lkOn()?'':'none'}
/* قفل خودکار بعد از بی‌کاری */
function lkTick(){if(!DB||!lkOn()||_locked)return;const m=DB.settings.autoLockMin===undefined?10:Number(DB.settings.autoLockMin);if(m>0&&Date.now()-_lastAct>m*60000)appLockNow()}
function lkWatch(){['mousemove','mousedown','keydown','touchstart','wheel'].forEach(e=>document.addEventListener(e,()=>{_lastAct=Date.now()},true));setInterval(lkTick,10000)}

/* ---- پنجره‌های تنظیم ---- */
function lkShowCode(code,title){
 openM(mHead('🆘 '+(title||'کد بازیابی'))+'<div class="mbody"><div class="notice" style="margin-bottom:10px">این کد <b>فقط یک بار</b> نمایش داده می‌شود. اگر رمز را فراموش کنید، فقط با همین کد می‌توانید وارد شوید. آن را جایی امن (روی کاغذ یا در گوشی) نگه دارید.</div><div style="text-align:center;font-size:26px;font-weight:800;letter-spacing:3px;direction:ltr;padding:14px;background:#f4f8fb;border:1px dashed #9db4c8;border-radius:10px;user-select:all">'+esc(code)+'</div></div><div class="mfoot"><button class="btn" onclick="navigator.clipboard&&navigator.clipboard.writeText(\''+code+'\');toast(\'📋 کپی شد\')">📋 کپی</button><button class="btn p" onclick="closeM()">کد را جایی امن نوشتم</button></div>');
}
function lkSetForm(){
 const has=lkOn();
 openM(mHead('🔐 '+(has?'تغییر رمز ورود':'تنظیم رمز ورود'))+'<div class="mbody">'+
  (has?'<div class="fg" style="margin-bottom:8px"><label>رمز فعلی</label><input type="password" id="lkCur" autocomplete="off"></div>':'')+
  '<div class="fg" style="margin-bottom:8px"><label>رمز جدید (حداقل ۴ کاراکتر)</label><input type="password" id="lkNew" autocomplete="new-password"></div>'+
  '<div class="fg"><label>تکرار رمز جدید</label><input type="password" id="lkNew2" autocomplete="new-password"></div>'+
  '<div id="lkErr" style="color:var(--red);font-size:12px;margin-top:8px;min-height:16px"></div></div>'+
  '<div class="mfoot"><button class="btn p" onclick="lkSetDo()">💾 ذخیره</button><button class="btn" onclick="closeM()">انصراف</button></div>');
 setTimeout(()=>rf(has?'lkCur':'lkNew'),50);
}
async function lkSetDo(){
 const has=lkOn(),n1=$('lkNew').value,n2=$('lkNew2').value,err=$('lkErr');
 if(n1!==n2){err.textContent='رمز جدید و تکرار آن یکی نیست';return}
 const r=await appLockSet(n1,has?$('lkCur').value:null,false);
 if(!r.ok){err.textContent=r.msg;return}
 closeM();
 if(r.code)lkShowCode(r.code,'رمز تنظیم شد؛ کد بازیابی');else toast('✅ رمز ورود تغییر کرد');
 if(curView==='tools')setTimeout(()=>nav('tools'),50);
}
function lkAskPw(title,btn,fn){
 openM(mHead(title)+'<div class="mbody"><div class="fg"><label>رمز فعلی</label><input type="password" id="lkCur" onkeydown="if(event.key===\'Enter\')lkAskGo()"></div><div id="lkErr" style="color:var(--red);font-size:12px;margin-top:8px;min-height:16px"></div></div><div class="mfoot"><button class="btn p" onclick="lkAskGo()">'+btn+'</button><button class="btn" onclick="closeM()">انصراف</button></div>');
 window._lkAsk=fn;setTimeout(()=>rf('lkCur'),50);
}
async function lkAskGo(){const r=await window._lkAsk($('lkCur').value);if(!r.ok){$('lkErr').textContent=r.msg;return}closeM();if(r.code)lkShowCode(r.code,'کد بازیابی جدید');else toast('✅ انجام شد');if(curView==='tools')setTimeout(()=>nav('tools'),50)}
function lkNewRecForm(){lkAskPw('🆘 ساخت کد بازیابی جدید','ساخت کد',appLockNewRec)}
function lkRemoveForm(){lkAskPw('🗑️ حذف رمز ورود','حذف رمز',appLockRemove)}

/* ---- کارت «قفل برنامه» در صفحه‌ی ابزار ---- */
function appLockCardHtml(){
 const on=lkOn(),m=DB.settings.autoLockMin===undefined?10:Number(DB.settings.autoLockMin);
 const opts=[[1,'۱ دقیقه'],[2,'۲ دقیقه'],[5,'۵ دقیقه'],[10,'۱۰ دقیقه'],[15,'۱۵ دقیقه'],[30,'۳۰ دقیقه'],[60,'۱ ساعت'],[0,'هرگز']].map(([v,t])=>'<option value="'+v+'" '+(m===v?'selected':'')+'>'+t+'</option>').join('');
 return '<div class="card"><h3>🔐 قفل برنامه (رمز ورود)</h3>'+
  '<div style="font-size:12px;line-height:2;margin-bottom:8px">'+(on?'✅ رمز ورود <b>فعال</b> است؛ هنگام باز شدن برنامه و بعد از قفل خودکار، رمز پرسیده می‌شود.':'⚠️ رمز ورود <b>تنظیم نشده</b> است؛ هر کس برنامه را باز کند، همه‌ی اطلاعات و مدارک مشتریان را می‌بیند.')+'</div>'+
  '<div class="toolbar"><button class="btn p" onclick="lkSetForm()">'+(on?'🔑 تغییر رمز':'🔐 تنظیم رمز ورود')+'</button>'+
  (on?'<button class="btn o" onclick="appLockNow()">🔒 قفل کن همین حالا</button><button class="btn" onclick="lkNewRecForm()">🆘 کد بازیابی جدید</button><button class="btn r" onclick="lkRemoveForm()">🗑️ حذف رمز</button>':'')+'</div>'+
  (on?'<div class="fg" style="margin-top:8px;max-width:260px"><label>قفل خودکار بعد از بی‌کاری</label><select onchange="DB.settings.autoLockMin=Number(this.value);saveDB()">'+opts+'</select></div>':'')+
  '<div style="font-size:11px;color:#7a8a99;line-height:1.9;margin-top:8px">رمز فقط جلوی <b>ورود به برنامه</b> را می‌گیرد؛ دیدن مدارک بعد از ورود رمز جداگانه ندارد. فایل‌های داده و بکاپ رمزنگاری نمی‌شوند؛ برای محافظت از خود دیسک از BitLocker ویندوز استفاده کنید.</div></div>';
}
