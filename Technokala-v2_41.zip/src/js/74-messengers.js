/* ===== پیام‌رسان‌ها: بله و روبیکا (Bot API رسمی) + فاکتور کامل + پیام تشکر ===== */
const MSG_SVC={bale:{name:'بله',idKey:'baleId',tokKey:'baleToken'},rubika:{name:'روبیکا',idKey:'rubikaId',tokKey:'rubikaToken'}};
const MSG_TPL_DEF={
 ThankInst:'{name} عزیز؛\nقسط شما به مبلغ {amount} تومان در تاریخ {date} با موفقیت دریافت شد.\nاز اعتماد شما سپاسگزاریم.\n{shop}',
 ThankChq:'{name} عزیز؛\nچک شماره {no} شما به مبلغ {amount} تومان وصول شد.\nاز همکاری شما سپاسگزاریم.\n{shop}'};
function thTpl(k){return DB.settings['smsTpl'+k]||MSG_TPL_DEF[k]}
function thanksChannels(){if(DB.settings.allMsgOn!==false)return{bale:true,rubika:true,sms:true};const c=DB.settings.thanksCh;return c&&typeof c==='object'?c:{bale:true,rubika:true,sms:false}}

/* --- فراخوانی API --- */
async function msgPost(svc,method,body){
 const S=MSG_SVC[svc],tok=String(DB.settings[S.tokKey]||'').trim();
 if(!tok)throw new Error('توکن '+S.name+' تنظیم نشده');
 const url=svc==='bale'?'https://tapi.bale.ai/bot'+tok+'/'+method:'https://botapi.rubika.ir/v3/'+tok+'/'+method;
 const r=await fetch(url,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body||{})});
 const txt=await r.text();let j;
 try{j=JSON.parse(txt)}catch(e){throw new Error('پاسخ نامعتبر از '+S.name+' (کد '+r.status+')')}
 if(svc==='bale'){if(!j.ok)throw new Error(j.description||('خطای '+S.name+' '+(j.error_code||r.status)));return j.result}
 if(j.status!=='OK')throw new Error(j.status_det||j.status||('خطای '+S.name+' '+r.status));
 return j.data;
}
function msgChunks(t,max){
 max=max||3500;t=String(t||'');const out=[];let cur='';
 t.split('\n').forEach(line=>{
  while(line.length>max){if(cur){out.push(cur);cur=''}out.push(line.slice(0,max));line=line.slice(max)}
  if((cur?cur.length+1:0)+line.length>max){out.push(cur);cur=line}else cur=cur?cur+'\n'+line:line;
 });
 if(cur)out.push(cur);return out.length?out:[''];
}
let _msgChain=Promise.resolve(),_msgPend=0,_msgOk=0,_msgFail=[];
function msgSend(svc,chatId,text,label){
 _msgPend++;
 _msgChain=_msgChain.then(async()=>{
  try{
   const cid=svc==='bale'&&/^\d{1,15}$/.test(String(chatId))?Number(chatId):String(chatId);
   for(const part of msgChunks(text)){await msgPost(svc,'sendMessage',{chat_id:cid,text:part});await _sleep(350)}
   _msgOk++;
  }catch(e){_msgFail.push({svc,label:label||String(chatId),err:String(e&&e.message||e)})}
  if(--_msgPend===0){
   const ok=_msgOk,fl=_msgFail;_msgOk=0;_msgFail=[];
   if(ok)toast('✅ '+fa(ok)+' پیام در بله/روبیکا ارسال شد'+(fl.length?' — '+fa(fl.length)+' ناموفق':''),!fl.length);
   if(fl.length){toast('⚠️ '+fa(fl.length)+' پیام ارسال نشد: '+esc(fl[0].label)+' — '+fl[0].err,false);console.warn('msg fail',fl)}
  }
 });
}
function msgTargets(p,ch){
 const out=[];
 if(ch.sms&&p.phone)out.push('sms');
 if(ch.bale&&p.baleId&&DB.settings.baleToken)out.push('bale');
 if(ch.rubika&&p.rubikaId&&DB.settings.rubikaToken)out.push('rubika');
 return out;
}
/* هر پیامکی که برنامه می‌فرستد (یادآوری، بدهی، رسید، فاکتور، تشکر، …) برای مشتریِ دارای شناسه، در بله و روبیکا هم ارسال می‌شود */
function msgFanout(to,msg){
 if(DB.settings.allMsgOn===false)return;
 const ph=smsPhone(to);if(!ph)return;
 const p=DB.persons.find(x=>x.phone&&smsPhone(x.phone)===ph);if(!p)return;
 if(p.baleId&&DB.settings.baleToken)msgSend('bale',p.baleId,msg,p.name);
 if(p.rubikaId&&DB.settings.rubikaToken)msgSend('rubika',p.rubikaId,msg,p.name);
}
function sendSMS(to,msg){sendSMSRaw(to,msg);try{msgFanout(to,msg)}catch(e){console.error(e)}}
function msgDeliver(p,text,ch){
 const t=msgTargets(p,ch);
 t.forEach(k=>k==='sms'?sendSMSRaw(p.phone,text):msgSend(k,p[MSG_SVC[k].idKey],text,p.name));
 return t;
}

/* --- پیام تشکر پس از وصول قسط/چک --- */
function msgThanks(kind,personId,vars){
 if(DB.settings.thanksOn===false)return 0;
 const p=P(personId);if(!p)return 0;
 const text=smsFill(thTpl(kind),Object.assign({name:p.name,date:jToday()},vars||{}));
 return msgDeliver(p,text,thanksChannels()).length;
}
function msgThanksBatch(items){
 const g={};
 items.forEach(x=>{const k=x.kind+'|'+x.person;const e=g[k]||(g[k]={kind:x.kind,person:x.person,amount:0,count:0,no:x.no,date:x.date});e.amount+=Number(x.amount)||0;e.count++});
 let n=0;Object.values(g).forEach(e=>{n+=msgThanks(e.kind,e.person,{amount:e.amount,no:e.no,date:e.date,count:e.count})?1:0});
 return n;
}
function chqThanks(c,was,st){
 const done=s=>s==='وصول شده'||s==='پاس شده';
 if(done(st)&&!done(was)&&c.dir==='rec'&&c.person){try{msgThanks('ThankChq',c.person,{amount:c.amount,no:c.no})}catch(e){console.error(e)}}
}

/* --- متن کامل فاکتور --- */
function invText(inv){
 const s=DB.settings,p=P(inv.person)||{},t=invTotal(inv),paid=invPaid(inv),rem=t-paid,L=[];
 L.push('🧾 '+invTypeFa(inv.type)+' شماره '+fa(inv.no));
 L.push('🏪 '+(s.shopName||'')+(s.shopTel?' — تلفن: '+fa(s.shopTel):''));
 L.push('📅 تاریخ: '+jLong(inv.date));
 L.push('👤 '+(p.name||PN(inv.person)));
 L.push('──────────────');
 inv.lines.forEach((l,i)=>{
  const sr=l.sid?(DB.serials.find(x=>x.id===l.sid)||{}).sn:(l.sn||'');const pr=PR(l.pid)||{};
  L.push(fa(i+1)+') '+(pr.name||'')+(pr.brand?' — '+pr.brand:'')+(l.color&&CL(l.color)!=='—'?' — '+CL(l.color):''));
  const lp=lapSpecText(pr);if(lp)L.push('    '+lp);
  if(sr)L.push('    سریال: '+fa(sr));
  L.push('    '+fa(l.qty)+' × '+fm(l.price)+' = '+fm(l.qty*l.price));
 });
 L.push('──────────────');
 L.push('جمع کل: '+fm(t+pd(inv.discount))+' تومان');
 if(pd(inv.discount))L.push('تخفیف: '+fm(pd(inv.discount))+' تومان');
 L.push('قابل پرداخت: '+fm(t)+' تومان');
 L.push('پرداخت‌شده: '+fm(paid)+' تومان');
 L.push('مانده: '+fm(rem)+' تومان');
 const pays=(inv.pays||[]).map(x=>(METHOD_FA[x.method]||x.method)+': '+fm(pd(x.amount))+(x.method==='cheque'?' (چک '+fa(x.chkNo||'')+'، سررسید '+jShort(x.chkDue)+')':''));
 if(pays.length){L.push('');L.push('💳 روش تسویه:');pays.forEach(x=>L.push('• '+x))}
 const ins=DB.installments.filter(i=>i.inv===inv.id).sort((a,b)=>a.due<b.due?-1:1);
 if(ins.length){L.push('');L.push('📅 اقساط:');ins.forEach(i=>L.push('• قسط '+fa(i.no)+' — '+jShort(i.due)+' — '+fm(i.amount)+' تومان'+(i.paid?' ✅':'')))}
 if(inv.desc&&String(inv.desc).trim()){L.push('');L.push('📝 '+String(inv.desc).trim())}
 if(inv.type==='sale'){const b=personBalance(inv.person);L.push('');L.push('💼 مانده‌ی کل حساب شما: '+fm(b.saleDebt)+' تومان')}
 L.push('');L.push('با تشکر — '+(s.shopName||''));
 return L.join('\n');
}
function msgInvoiceOpen(id){
 const inv=DB.invoices.find(i=>i.id===id);if(!inv)return;const p=P(inv.person);
 if(!p){toast('⚠️ طرف حساب پیدا نشد',false);return}
 window._miInv=id;
 const row=(k,label,ok,note)=>'<label style="display:flex;gap:8px;align-items:center;margin:4px 0;font-size:13px"><input type="checkbox" id="mi_'+k+'" '+(ok?'checked':'disabled')+'> '+label+' <span style="font-size:11px;color:var(--mut)">'+note+'</span></label>';
 const bOk=!!(p.baleId&&DB.settings.baleToken),rOk=!!(p.rubikaId&&DB.settings.rubikaToken);
 openM(mHead('📨 ارسال فاکتور به '+esc(p.name))+'<div class="mbody">'+
  row('bale','📘 بله',bOk,bOk?'':(DB.settings.baleToken?'شناسه‌ی بله‌ی مشتری ثبت نشده':'توکن بله تنظیم نشده'))+
  row('rubika','📙 روبیکا',rOk,rOk?'':(DB.settings.rubikaToken?'شناسه‌ی روبیکای مشتری ثبت نشده':'توکن روبیکا تنظیم نشده'))+
  (function(){const sOk=!!p.phone;return '<label style="display:flex;gap:8px;align-items:center;margin:4px 0;font-size:13px"><input type="checkbox" id="mi_sms" '+(sOk?'checked':'disabled')+'> ✉️ پیامک <span style="font-size:11px;color:var(--mut)">'+(sOk?'(فقط متن کوتاه فاکتور ارسال می‌شود)':'موبایل ثبت نشده')+'</span></label>'})()+
  '<div class="toolbar" style="margin:6px 0"><button class="btn sm" onclick="msgIdOpen(\''+p.id+'\',\'invoice\')">💬 ثبت/ویرایش شناسه‌ی بله و روبیکا</button><button class="btn sm" onclick="msgSettingsOpen()">⚙️ تنظیمات</button></div>'+
  '<div class="fg"><label>متن کامل فاکتور (قابل ویرایش — برای بله و روبیکا)</label><textarea id="miTxt" rows="14" style="width:100%;font-size:12px"></textarea></div></div>'+
  '<div class="mfoot"><button class="btn p" onclick="msgInvoiceSend()">📨 ارسال</button><button class="btn" onclick="closeM()">انصراف</button></div>',true);
 $('miTxt').value=invText(inv);
}
function msgInvoiceSend(){
 const inv=DB.invoices.find(i=>i.id===window._miInv);if(!inv)return;const p=P(inv.person);if(!p)return;
 const ch={bale:!!$('mi_bale').checked,rubika:!!$('mi_rubika').checked,sms:!!$('mi_sms').checked},txt=String($('miTxt').value||'').trim();
 if(!txt){toast('⚠️ متن خالی است',false);return}
 if(!ch.bale&&!ch.rubika&&!ch.sms){toast('⚠️ حداقل یک مسیر ارسال را انتخاب کنید',false);return}
 closeM();
 msgTargets(p,ch).forEach(k=>{
  if(k==='sms')sendSMSRaw(p.phone,smsFill(smsTpl('Inv'),{name:p.name,no:inv.no,amount:invTotal(inv),date:inv.date,remain:Math.max(0,invTotal(inv)-invPaid(inv))}));
  else msgSend(k,p[MSG_SVC[k].idKey],txt,p.name);
 });
 logAct('ارسال فاکتور '+inv.no+' به '+p.name);
}

/* --- شناسه‌ی چت مشتری --- */
function msgIdOpen(pid,back){
 const p=P(pid);if(!p)return;
 openM(mHead('💬 شناسه‌ی بله و روبیکا — '+esc(p.name))+'<div class="mbody">'+
  '<div style="font-size:12px;color:var(--mut);line-height:1.9;margin-bottom:8px">بات‌ها فقط به کسانی پیام می‌دهند که قبلاً به بات فروشگاه پیام داده یا «استارت» زده باشند. شناسه‌ی چت را می‌توانید خودکار از «تنظیمات ← اتصال مشتریان از بات» بگیرید یا دستی وارد کنید.</div>'+
  '<div class="frow"><div class="fg"><label>شناسه‌ی چت در بله</label><input id="mdBale" style="direction:ltr" value="'+esc(p.baleId||'')+'"></div><div class="fg"><label>شناسه‌ی چت در روبیکا</label><input id="mdRub" style="direction:ltr" value="'+esc(p.rubikaId||'')+'"></div></div>'+
  '<div class="toolbar"><button class="btn sm" onclick="msgIdSave(\''+pid+'\',true);msgIdTest(\''+pid+'\',\'bale\')">🧪 پیام آزمایشی بله</button><button class="btn sm" onclick="msgIdSave(\''+pid+'\',true);msgIdTest(\''+pid+'\',\'rubika\')">🧪 پیام آزمایشی روبیکا</button></div></div>'+
  '<div class="mfoot"><button class="btn p" onclick="msgIdSave(\''+pid+'\')">💾 ذخیره</button><button class="btn" onclick="closeM()">بستن</button></div>');
 window._mdBack=back||'';
}
function msgIdSave(pid,keep){
 const p=P(pid);if(!p)return;
 p.baleId=$('mdBale').value.trim();p.rubikaId=$('mdRub').value.trim();saveDB();
 if(keep)return;closeM();toast('✅ ذخیره شد');
 if(window._mdBack==='invoice'&&window._miInv)msgInvoiceOpen(window._miInv);
}
function msgIdTest(pid,svc){
 const p=P(pid);if(!p)return;const id=p[MSG_SVC[svc].idKey];
 if(!id){toast('⚠️ شناسه‌ی '+MSG_SVC[svc].name+' وارد نشده',false);return}
 msgSend(svc,id,'🧪 پیام آزمایشی از '+(DB.settings.shopName||'فروشگاه'),p.name);
}

/* --- تنظیمات --- */
function msgSettingsOpen(){
 const s=DB.settings,c=thanksChannels();
 const chk=(id,v,l)=>'<label style="font-size:12.5px;margin-inline-end:14px"><input type="checkbox" id="'+id+'" '+(v?'checked':'')+'> '+l+'</label>';
 openM(mHead('💬 بله، روبیکا و پیام تشکر')+'<div class="mbody">'+
  '<div style="font-size:12px;color:var(--mut);line-height:1.9;margin-bottom:8px">در بله و روبیکا با «BotFather» یک بات بسازید و توکن را اینجا بگذارید. مشتری باید یک‌بار به بات پیام بدهد/استارت بزند تا بات بتواند به او پیام بفرستد. توکن در بکاپ برنامه هم ذخیره می‌شود؛ بکاپ را در جای امن نگه دارید.</div>'+
  '<div class="fg"><label>توکن بات بله</label><input id="msBale" style="width:100%;direction:ltr" value="'+esc(s.baleToken||'')+'"></div>'+
  '<div class="fg"><label>توکن بات روبیکا</label><input id="msRub" style="width:100%;direction:ltr" value="'+esc(s.rubikaToken||'')+'"></div>'+
  '<div class="toolbar" style="margin:6px 0"><button class="btn sm g" onclick="msgSettingsSave(true);msgTestToken(\'bale\')">🔌 بررسی بله</button><button class="btn sm g" onclick="msgSettingsSave(true);msgTestToken(\'rubika\')">🔌 بررسی روبیکا</button><button class="btn sm o" onclick="msgSettingsSave(true);msgLinkOpen(\'bale\')">📥 اتصال مشتریان از بات بله</button><button class="btn sm o" onclick="msgSettingsSave(true);msgLinkOpen(\'rubika\')">📥 اتصال مشتریان از بات روبیکا</button></div>'+
  '<div id="msStat" style="font-size:12px;min-height:18px;margin-bottom:8px"></div>'+
  '<div class="sec-h">📡 ارسال همزمان در هر سه پلتفرم</div>'+
  '<div style="margin:6px 0">'+chk('msAll',s.allMsgOn!==false,'همه‌ی پیام‌ها (یادآوری قسط/چک، بدهی، رسید، فاکتور، تشکر، …) هم پیامک شوند، هم در بله، هم در روبیکا')+'</div>'+
  '<div style="font-size:11px;color:var(--mut);margin-bottom:6px">فقط برای مشتری‌هایی که شناسه‌ی بله/روبیکا دارند در آن پلتفرم ارسال می‌شود؛ بقیه فقط پیامک می‌گیرند.</div>'+
  '<div class="sec-h">🙏 پیام تشکر بعد از وصول قسط و چک</div>'+
  '<div style="margin:6px 0">'+chk('msThOn',s.thanksOn!==false,'ارسال خودکار پیام تشکر')+'</div>'+
  '<div style="margin:6px 0;font-size:12px">ارسال از طریق (وقتی گزینه‌ی «همه‌ی پیام‌ها در هر سه پلتفرم» خاموش باشد): '+chk('msChBale',c.bale,'📘 بله')+chk('msChRub',c.rubika,'📙 روبیکا')+chk('msChSms',c.sms,'✉️ پیامک')+'</div>'+
  '<div class="fg"><label>متن تشکر قسط ({name} {amount} {date} {no} {shop})</label><textarea id="msTInst" rows="4" style="width:100%;font-size:12px"></textarea></div>'+
  '<div class="fg"><label>متن تشکر چک</label><textarea id="msTChq" rows="4" style="width:100%;font-size:12px"></textarea></div></div>'+
  '<div class="mfoot"><button class="btn p" onclick="msgSettingsSave()">💾 ذخیره</button><button class="btn" onclick="closeM()">بستن</button></div>',true);
 $('msTInst').value=thTpl('ThankInst');$('msTChq').value=thTpl('ThankChq');
}
function msgSettingsSave(keep){
 const s=DB.settings;
 s.baleToken=$('msBale').value.trim();s.rubikaToken=$('msRub').value.trim();
 s.allMsgOn=!!$('msAll').checked;s.thanksOn=!!$('msThOn').checked;s.thanksCh={bale:!!$('msChBale').checked,rubika:!!$('msChRub').checked,sms:!!$('msChSms').checked};
 s.smsTplThankInst=$('msTInst').value;s.smsTplThankChq=$('msTChq').value;
 saveDB();if(!keep){closeM();toast('✅ تنظیمات ذخیره شد')}
}
async function msgTestToken(svc){
 const el=$('msStat');if(el)el.textContent='⏳ در حال بررسی…';
 try{
  const r=await msgPost(svc,'getMe',{});const b=r&&(r.bot||r)||{};
  if(el)el.innerHTML='✅ اتصال '+MSG_SVC[svc].name+' برقرار است — '+esc(b.username||b.bot_title||b.first_name||b.name||'بات')
 }catch(e){if(el)el.innerHTML='❌ '+esc(String(e&&e.message||e))}
}

/* --- اتصال مشتریان از پیام‌های بات (دریافت شناسه‌ی چت) --- */
function msgDigits(s){return faDig(String(s||'')).replace(/[^\d]/g,' ')}
async function msgLinkOpen(svc){
 const el=$('msStat');if(el)el.textContent='⏳ دریافت پیام‌های بات…';
 try{
  let chats=[];
  if(svc==='bale'){
   const ups=await msgPost('bale','getUpdates',{limit:100})||[];
   ups.forEach(u=>{const m=u.message;if(!m||!m.chat)return;
    const f=m.from||{},nm=[f.first_name,f.last_name].filter(Boolean).join(' ');
    chats.push({id:String(m.chat.id),name:nm||m.chat.first_name||'',user:f.username||'',text:m.text||'',phone:(m.contact&&m.contact.phone_number)||''})});
  }else{
   const d=await msgPost('rubika','getUpdates',{limit:100})||{};
   (d.updates||[]).forEach(u=>{const nm=u.new_message||u.inline_message||{},cid=u.chat_id||nm.chat_id;if(!cid)return;
    chats.push({id:String(cid),name:'',user:'',text:nm.text||'',phone:(nm.contact_message&&nm.contact_message.phone_number)||''})});
  }
  const by={};chats.forEach(c=>{const e=by[c.id]||(by[c.id]=Object.assign({},c,{texts:[]}));if(c.text)e.texts.push(c.text);if(c.phone)e.phone=c.phone;if(c.name)e.name=c.name;if(c.user)e.user=c.user});
  const list=Object.values(by);
  if(!list.length){if(el)el.textContent='ℹ️ پیامی در بات پیدا نشد. از مشتری بخواهید به بات پیام بدهد (و شماره موبایل خود را بفرستد).';return}
  const key=MSG_SVC[svc].idKey;
  list.forEach(c=>{
   const blob=msgDigits((c.phone||'')+' '+c.texts.join(' ')).split(/\s+/).filter(Boolean);
   let per=DB.persons.find(p=>p[key]===c.id);
   if(!per)per=DB.persons.find(p=>{const ph=smsPhone(p.phone);return ph&&blob.some(x=>smsPhone(x)===ph)});
   if(!per)per=DB.persons.find(p=>{const n=rfNatId(p.nationalId);return n&&blob.includes(n)});
   if(!per&&c.name)per=DB.persons.find(p=>rfNormName(p.name)===rfNormName(c.name));
   c.sug=per?per.id:'';
  });
  window._mlSvc=svc;window._mlList=list;
  const opts=sel=>'<option value="">— بدون اتصال —</option>'+DB.persons.map(p=>'<option value="'+p.id+'" '+(p.id===sel?'selected':'')+'>'+esc(p.name)+(p.phone?' — '+esc(p.phone):'')+'</option>').join('');
  openM(mHead('📥 مشتریانی که به بات '+MSG_SVC[svc].name+' پیام داده‌اند')+'<div class="mbody"><div style="font-size:12px;color:var(--mut);margin-bottom:8px">تطبیق پیشنهادی بر اساس موبایل/کد ملی/نام است. قبل از ذخیره بررسی کنید.</div><div style="max-height:55vh;overflow:auto"><table><thead><tr><th>مخاطب در '+MSG_SVC[svc].name+'</th><th>آخرین پیام</th><th>مشتری در برنامه</th></tr></thead><tbody>'+
   list.map((c,k)=>'<tr><td class="r">'+esc(c.name||'—')+(c.user?'<div style="font-size:11px">@'+esc(c.user)+'</div>':'')+'<div style="font-size:11px;color:var(--mut);direction:ltr">'+esc(c.id)+'</div></td><td>'+esc((c.texts[c.texts.length-1]||'').slice(0,60))+'</td><td><select id="ml'+k+'" style="max-width:240px">'+opts(c.sug)+'</select></td></tr>').join('')+
   '</tbody></table></div></div><div class="mfoot"><button class="btn p" onclick="msgLinkSave()">💾 ذخیره‌ی اتصال‌ها</button><button class="btn" onclick="closeM()">بستن</button></div>',true);
 }catch(e){if(el)el.innerHTML='❌ '+esc(String(e&&e.message||e))}
}
function msgLinkSave(){
 const svc=window._mlSvc,key=MSG_SVC[svc].idKey;let n=0;
 (window._mlList||[]).forEach((c,k)=>{const pid=$('ml'+k).value;if(!pid)return;const p=P(pid);if(!p)return;p[key]=c.id;n++});
 saveDB();closeM();toast('✅ '+fa(n)+' مشتری به '+MSG_SVC[svc].name+' متصل شد');
}
