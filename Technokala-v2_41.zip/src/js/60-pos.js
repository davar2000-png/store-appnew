/* ================= 🛒 فاکتور فروش سریع (POS) — F9 ================= */
function posOpen(){
 const avail=DB.products.filter(p=>p.active!==false&&stockOf(p.id)>0);
 if(!avail.length){toast('⚠️ کالای موجودی‌داری برای فروش نیست',false);return}
 const walkIn=DB.persons.find(p=>p.name==='فروش حضوری')||DB.persons[0];
 window._posCart=[];
 openM(mHead('🛒 فروش سریع (POS) — F9')+'<div class="mbody">'+
 '<div class="frow">'+
 '<div class="fg" style="flex:1;min-width:180px"><label>مشتری</label><select id="posPerson">'+DB.persons.map(p=>'<option value="'+p.id+'" '+(walkIn&&p.id===walkIn.id?'selected':'')+'>'+esc(p.name)+'</option>').join('')+'</select></div>'+
 '<div class="fg" style="flex:1.4;min-width:200px"><label>کالا (فقط موجود)</label><select id="posProd" onchange="posProdSel()">'+avail.map(p=>'<option value="'+p.id+'">'+esc(p.name)+' — موجودی '+fa(stockOf(p.id))+'</option>').join('')+'</select></div>'+
 '<div class="fg"><label>تعداد</label><input id="posQty" class="money" value="1" style="width:70px"></div>'+
 '<button class="btn p" style="height:36px" onclick="posAdd()">＋ افزودن</button>'+
 '</div>'+
 '<div id="posSerialBox"></div>'+
 '<div id="posCart"></div>'+
 '<div class="frow" style="margin-top:10px">'+
 '<div class="fg"><label>مبلغ نقدی دریافتی</label><input id="posCash" class="money" style="width:150px" oninput="posCalc()"></div>'+
 '<div class="fg"><label>تخفیف (تومان)</label><input id="posDisc" class="money" style="width:120px" value="0" oninput="posCalc()"></div>'+
 '</div>'+
 '<div id="posTot" style="font-size:14px;margin:8px 0"></div>'+
 '</div>'+
 '<div class="mfoot"><button class="btn g" onclick="posSave()">💾 ثبت و چاپ رسید حرارتی</button><button class="btn" onclick="posSave(true)">💾 ثبت بدون چاپ</button><button class="btn" onclick="closeM()">انصراف</button></div>');
 posProdSel();posCalc();
}
function posProdSel(){
 const pid=($('posProd')||{}).value,p=pid?PR(pid):null;if(!p)return;
 const box=$('posSerialBox'),qty=$('posQty');
 if(p.track==='serial'){
  const sns=DB.serials.filter(s=>s.pid===pid&&s.status==='stock');
  box.innerHTML='<div class="fg" style="max-width:280px"><label>سریال (در انبار)</label><select id="posSerial">'+sns.map(s=>'<option value="'+s.id+'">'+fa(s.sn)+'</option>').join('')+'</select></div>';
  if(qty){qty.value='1';qty.disabled=true}
 }else{box.innerHTML='';if(qty)qty.disabled=false}
}
function posAdd(){
 const pid=($('posProd')||{}).value,p=pid?PR(pid):null;if(!p){toast('⚠️ کالا را انتخاب کنید',false);return}
 const sid=($('posSerial')||{}).value||'';
 const qty=p.track==='serial'?1:(pd(($('posQty')||{}).value)||1);
 if(qty<1){toast('⚠️ تعداد نامعتبر است',false);return}
 if(sid){
  if(window._posCart.some(l=>l.sid===sid)){toast('⚠️ این سریال قبلاً در سبد است',false);return}
 }else{
  const inCart=window._posCart.filter(l=>l.pid===pid&&!l.sid).reduce((s,l)=>s+l.qty,0);
  if(inCart+qty>stockOf(pid)&&!DB.settings.allowNegative){toast('⚠️ موجودی کافی نیست (موجودی: '+fa(stockOf(pid))+')',false);return}
 }
 window._posCart.push({pid,sid,sn:sid?(DB.serials.find(s=>s.id===sid)||{}).sn||'':'',color:'',qty,price:p.sellPrice||0,cost:unitCost(p)});
 posRenderCart();posCalc();
 toast('✅ '+esc(p.name)+' به سبد اضافه شد');
}
function posRenderCart(){
 const tb=$('posCart');if(!tb)return;
 if(!window._posCart.length){tb.innerHTML='<div class="empty" style="padding:16px"><div class="b">🛒</div>سبد خالی است — کالا را انتخاب و «افزودن» را بزنید</div>';return}
 tb.innerHTML='<table><thead><tr><th>کالا</th><th>سریال</th><th>تعداد</th><th>قیمت واحد</th><th>جمع</th><th></th></tr></thead><tbody>'+
 window._posCart.map((l,i)=>{const pr=PR(l.pid)||{};
  return '<tr><td class="r">'+esc(pr.name||'')+'</td><td dir="ltr">'+(l.sn?fa(l.sn):'—')+'</td><td>'+fa(l.qty)+'</td><td class="amt">'+fm(l.price)+'</td><td class="amt">'+fm(l.qty*l.price)+'</td><td><button class="btn sm r" onclick="window._posCart.splice('+i+',1);posRenderCart();posCalc()">✕</button></td></tr>'}).join('')+'</tbody></table>';
}
function posCalc(){
 const t=window._posCart.reduce((s,l)=>s+l.qty*l.price,0)-pd(($('posDisc')||{}).value||0);
 const cash=pd(($('posCash')||{}).value||0);
 const el=$('posTot');if(!el)return;
 el.innerHTML='قابل پرداخت: <b style="color:var(--hd);font-size:16px">'+fm(t)+'</b> تومان — '+(cash>=t?'<b class="pos">✅ تسویه — باقیمانده به مشتری: '+fm(cash-t)+' ت</b>':'<b class="neg">بدهی (نسیه): '+fm(Math.max(0,t-cash))+' ت</b>');
}
function posSave(noPrint){
 if(!window._posCart.length){toast('⚠️ سبد خالی است',false);return}
 const person=($('posPerson')||{}).value;
 if(!person){toast('⚠️ مشتری را انتخاب کنید',false);return}
 const cash=pd(($('posCash')||{}).value||0);
 const disc=pd(($('posDisc')||{}).value||0);
 const t=window._posCart.reduce((s,l)=>s+l.qty*l.price,0)-disc;
 const nBefore=DB.invoices.length;
 doSaveInvoice({kind:'sale',id:'',date:jToday(),person,desc:'فروش سریع (POS)',group:'',
  lines:window._posCart.map(l=>({pid:l.pid,sid:l.sid,sn:l.sn,color:l.color,qty:l.qty,price:l.price,cost:l.cost,sellAtBuy:0})),
  pays:cash>0?[{method:'cash',amount:Math.min(cash,t),desc:'نقدی POS',chkNo:'',chkBank:'',chkBranch:'',chkCount:1,chkDue:''}]:[],
  disc,plan:null,checkPlan:null});
 const inv=DB.invoices.find(i=>i.no&&DB.invoices.indexOf(i)>=nBefore)||DB.invoices[DB.invoices.length-1];
 if(!noPrint&&inv)setTimeout(()=>printThermal(inv.id,'58mm'),350);
}
function invView(id){
 const inv=DB.invoices.find(i=>i.id===id);if(!inv)return;const t=invTotal(inv),p=invPaid(inv);
 openM(mHead('👁️ '+invTypeFa(inv.type)+' شماره '+fa(inv.no))+'<div class="mbody">'+
 '<div class="kv" style="margin-bottom:10px"><span class="k">تاریخ: <b>'+jLong(inv.date)+'</b></span><span class="k">طرف حساب: <b>'+esc(PN(inv.person))+'</b></span>'+(inv.group?'<span class="k">گروه: <b>'+esc(inv.group)+'</b></span>':'')+'</div>'+
 '<table><thead><tr><th>کالا</th><th>سریال</th><th>رنگ</th><th>تعداد</th><th>قیمت</th>'+(inv.type==='buy'?'<th>قیمت فروش تعیین‌شده</th>':'')+'<th>جمع</th>'+(inv.type==='sale'?'<th>سود</th>':'')+'</tr></thead><tbody>'+
 inv.lines.map(l=>{const sr=l.sid?(DB.serials.find(s=>s.id===l.sid)||{}).sn:(l.sn||'');const pr=PR(l.pid)||{};
  return `<tr><td class="r">${esc(pr.name||'?')}</td><td>${fa(sr||'—')}</td><td>${CL(l.color)}</td><td>${fa(l.qty)}</td><td class="amt">${fm(l.price)}</td>${inv.type==='buy'?`<td class="amt">${fm(l.sellAtBuy||pr.sellPrice||0)}</td>`:''}<td class="amt">${fm(l.qty*l.price)}</td>${inv.type==='sale'?`<td class="amt pos">${fm((l.price-l.cost)*l.qty)}</td>`:''}</tr>`}).join('')+
 '</tbody></table>'+
 '<div style="margin-top:10px">جمع: <b>'+fm(t+pd(inv.discount))+'</b> — تخفیف: <b class="neg">'+fm(pd(inv.discount))+'</b> — قابل پرداخت: <b style="font-size:14px;color:var(--hd)">'+fm(t)+'</b> — پرداخت‌شده: <b class="pos">'+fm(p)+'</b> — مانده: <b class="'+(t-p>0?'neg':'pos')+'">'+fm(t-p)+'</b></div>'+
 ((inv.pays||[]).length?'<div class="sec-h">روش‌های تسویه</div>'+inv.pays.map(x=>'<span class="k" style="background:#f4f8fb;border:1px solid var(--bd);border-radius:6px;padding:6px 10px;font-size:11.5px;margin:2px;display:inline-block">'+METHOD_FA[x.method]+' — '+fm(pd(x.amount))+(x.method==='cheque'?' ('+fa(x.chkNo||'')+'، سررسید '+jShort(x.chkDue)+')':'')+'</span>').join(''):'')+
 (inv.installPlan?'<div class="sec-h">📅 اقساط</div><table><thead><tr><th>قسط</th><th>سررسید</th><th>مبلغ</th><th>وضعیت</th></tr></thead><tbody>'+DB.installments.filter(i2=>i2.inv===id).map(i2=>`<tr><td>${fa(i2.no)}</td><td>${jShort(i2.due)}</td><td class="amt">${fm(i2.amount)}</td><td>${i2.paid?'<span class="bdg b-g">پرداخت شد</span>':'<span class="bdg b-o">باز</span>'}</td></tr>`).join('')+'</tbody></table>':'')+
 '</div><div class="mfoot"><button class="btn g" onclick="msgInvoiceOpen(\''+id+'\')">📨 ارسال (بله/روبیکا/پیامک)</button>'+(inv.type==='buy'||inv.type==='buyret'?'<button class="btn p" onclick="printInvoice(\''+inv.type+'\',\''+id+'\',\'A5\')">🖨️ چاپ A5 افقی</button>':'<button class="btn p" onclick="printInvoice(\''+inv.type+'\',\''+id+'\',\'A4\')">🖨️ چاپ A4</button><button class="btn" onclick="printInvoice(\''+inv.type+'\',\''+id+'\',\'A5\')">A5</button>')+''+(inv.type==='buy'||inv.type==='buyret'?'':'<button class="btn" onclick="printThermal(\''+id+'\',\'58mm\')" title="چاپ روی پرینتر حرارتی ۵۸ میلی‌متری">🧾 ۵۸mm</button><button class="btn" onclick="printThermal(\''+id+'\',\'80mm\')" title="چاپ روی پرینتر حرارتی ۸۰ میلی‌متری">🧾 ۸۰mm</button>')+'<button class="btn g" onclick="printInvoiceReceipt(\''+id+'\')">🧾 رسید فاکتور</button><button class="btn" onclick="printStatement(\''+inv.person+'\')">📋 صورت حساب مشتری</button><button class="btn o" onclick="sendInvoiceOuter(\''+id+'\')">📤 ارسال</button><button class="btn" onclick="closeM()">بستن</button></div>',true);
}
function proformaConv(id){
 const pf=DB.invoices.find(i=>i.id===id);if(!pf)return;
 if(pf.convertedTo){toast('⚠️ این پیش‌فاکتور قبلاً به فاکتور فروش شماره '+fa(pf.convertedTo)+' تبدیل شده است',false);return}
 const need={};
 for(const l of pf.lines){
  if(l.sid){const s=DB.serials.find(x=>x.id===l.sid);if(!s||s.status!=='stock'){toast('⛔ سریال '+fa(l.sn||'')+' دیگر در انبار موجود نیست؛ تبدیل ممکن نیست',false);return}}
  else need[l.pid]=(need[l.pid]||0)+Number(l.qty||0);
 }
 if(!DB.settings.allowNegative){for(const pid in need){if(need[pid]>Math.max(0,stockOf(pid))){toast('⛔ موجودی «'+(PR(pid)?PR(pid).name:'?')+'» برای تبدیل کافی نیست',false);return}}}
 const no=nextNo('sale');
 const nid=uid();
 const ninv={id:nid,type:'sale',no,date:jToday(),person:pf.person,lines:JSON.parse(JSON.stringify(pf.lines)),pays:[],discount:pf.discount,desc:'تبدیل از پیش‌فاکتور '+fa(pf.no),group:pf.group||'',installPlan:null};
 DB.invoices.push(ninv);pf.convertedTo=no;
 ninv.lines.forEach(l=>{if(l.sid){const s=DB.serials.find(x=>x.id===l.sid);if(s){s.status='sold';s.saleInv=nid;s.price=l.price}}});
 logAct('تبدیل پیش‌فاکتور '+pf.no+' به فروش '+no);saveDB();vSales();toast('✅ پیش‌فاکتور به فاکتور فروش '+fa(no)+' تبدیل شد');
}
function sendInvoiceOuter(id){
 const inv=DB.invoices.find(i=>i.id===id);if(!inv)return;
 const data={id:inv.id,type:inv.type,no:inv.no,date:inv.date,person:PN(inv.person),total:invTotal(inv),paid:invPaid(inv),discount:pd(inv.discount),pays:inv.pays||[],lines:inv.lines.map(l=>({code:(PR(l.pid)||{}).code,name:(PR(l.pid)||{}).name,sn:l.sn||'',qty:l.qty,price:l.price}))};
 openM(mHead('📤 ارسال فاکتور / یکپارچه‌سازی')+'<div class="mbody">'+
 '<div class="fg"><label>JSON فاکتور</label><textarea rows="7" style="width:100%;direction:ltr;font-size:11px" id="whJson">'+esc(JSON.stringify(data,null,1))+'</textarea></div>'+
 '<div class="frow" style="margin-top:8px"><button class="btn" onclick="navigator.clipboard.writeText($(\'whJson\').value).then(()=>toast(\'📋 کپی شد\'))">📋 کپی</button>'+
 '<button class="btn p" onclick="webhookPost(JSON.parse($(\'whJson\').value),\'فاکتور\')">🌐 ارسال به Webhook</button>'+
 '<button class="btn o" onclick="smsInvoice(\''+id+'\')">✉️ پیامک به مشتری</button></div>'+
 '<div style="font-size:11px;color:#7a8a99;margin-top:8px">آدرس Webhook در «ابزار ← تنظیمات» تعریف می‌شود.</div></div>'+
 '<div class="mfoot"><button class="btn" onclick="closeM()">بستن</button></div>');
}
/* ✉️ پیامک فاکتور (با قالب قابل ویرایش) */
function smsInvoice(id){
 const inv=DB.invoices.find(i=>i.id===id);if(!inv)return;const p=P(inv.person);
 if(!p||!p.phone){toast('⚠️ طرف حساب موبایل ندارد',false);return}
 const msg=smsFill(smsTpl('Inv'),{name:p.name,no:inv.no,amount:invTotal(inv),date:inv.date,remain:Math.max(0,invTotal(inv)-invPaid(inv))});
 askM('✉️ پیامک فاکتور','متن پیامک به '+esc(p.name)+':',msg,txt=>sendSMS(p.phone,txt));
}

