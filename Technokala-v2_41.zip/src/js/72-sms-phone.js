/* ================= 📲 ارسال پیامک با گوشی خودتان (بدون پنل پیامک انبوه) =================
   حالت‌ها: api = سرویس‌دهنده (قبلی) | gw = برنامه‌ی SMS Gateway روی گوشی اندروید (شبکه‌ی محلی) | link = صف پیامک (ارسال با برنامه‌ی پیام خود گوشی) */
function smsMode(){const s=DB.settings;return s.smsMode||(s.smsUrl?'api':'link')}
function smsPhone(v,e164){
 let n=faDig(v||'').replace(/[^\d+]/g,'');
 if(n.startsWith('+'))return n;
 if(n.startsWith('0098'))n='98'+n.slice(4);
 if(/^09\d{9}$/.test(n))return e164?'+98'+n.slice(1):n;
 if(/^989\d{9}$/.test(n))return e164?'+'+n:'0'+n.slice(2);
 if(/^9\d{9}$/.test(n))return e164?'+98'+n:'0'+n;
 return n;
}
let SMSQ=[],_smsQT=null,_gwChain=Promise.resolve();
let _gwPend=0,_gwOk=0,_gwFail=[],_gwDown=false;
const _sleep=ms=>new Promise(r=>setTimeout(r,ms));
function sendSMSRaw(to,msg){
 const m=smsMode();
 if(m==='api')return smsSendApi(to,msg);
 const ph=smsPhone(to),per=DB.persons.find(p=>smsPhone(p.phone)===ph),name=per?per.name:'';
 if(m==='gw'){
  _gwPend++;
  _gwChain=_gwChain.then(async()=>{
   let ok=false;
   if(!_gwDown){ok=await smsSendGw(to,msg,true);if(ok)await _sleep(1200)}
   if(ok)_gwOk++;else _gwFail.push({to:ph,msg,name,sent:false});
   if(--_gwPend===0){const okN=_gwOk,fl=_gwFail;_gwOk=0;_gwFail=[];_gwDown=false;
    if(okN)toast('✅ '+fa(okN)+' پیامک به گوشی سپرده شد'+(fl.length?' — '+fa(fl.length)+' مورد ناموفق':''),!fl.length);
    if(fl.length)setTimeout(()=>smsQueueOpen(fl,'پیامک‌های ناموفق — با برنامه‌ی پیام گوشی بفرستید'),400)}
  });
  return;
 }
 SMSQ.push({to:ph,msg,name,sent:false});
 clearTimeout(_smsQT);_smsQT=setTimeout(()=>{const l=SMSQ;SMSQ=[];smsQueueOpen(l)},60);
}
/* ---- اتصال به گوشی از طریق Wi‑Fi ---- */
function gwBase(){
 let u=(DB.settings.gwUrl||'').trim().replace(/\/+$/,'');if(!u)return '';
 if(!/^https?:\/\//i.test(u))u='http://'+u;
 if(!/:\d+(\/|$)/.test(u.replace(/^https?:\/\//i,'')))u=u.replace(/^(https?:\/\/[^\/]+)/i,'$1:8080');
 return u;
}
function gwHeaders(json){
 const s=DB.settings,h={};if(json)h['Content-Type']='application/json';
 if(s.gwUser)h.Authorization='Basic '+btoa(unescape(encodeURIComponent(s.gwUser+':'+(s.gwPass||''))));
 return h;
}
function gwTimeout(ms){const c=new AbortController();setTimeout(()=>c.abort(),ms||6000);return c.signal}
function gwMixed(base){return location.protocol==='https:'&&/^http:/i.test(base)}
async function smsGwCheck(){
 const el=$('gwStat'),set=(h,c)=>{if(el){el.innerHTML=h;el.style.color=c||''}},base=gwBase();
 if(!base){set('⚠️ آدرس گوشی را وارد کنید (مثل 192.168.1.20:8080)','#b45309');return false}
 if(gwMixed(base)){set('❌ این برنامه با https باز شده و مرورگر اتصال http به گوشی را مسدود می‌کند. برنامه را از فایل روی کامپیوتر (یا آدرس http) باز کنید.','#b91c1c');return false}
 set('⏳ در حال بررسی اتصال…');
 try{await fetch(base+'/health',{mode:'no-cors',signal:gwTimeout(5000)})}
 catch(e){set('❌ گوشی پیدا نشد؛ مطمئن شوید گوشی و کامپیوتر به یک Wi‑Fi وصل‌اند، Local Server در برنامه‌ی گوشی روشن است و IP/پورت درست است.'+(window.desktopAPI?' (جزئیات: '+esc(String(e&&e.message||e))+')':''),'#b91c1c');return false}
 try{
  const r=await fetch(base+'/health',{headers:gwHeaders(false),signal:gwTimeout(5000)});
  if(r.status===401){set('⚠️ گوشی پیدا شد ولی نام کاربری/رمز اشتباه است.','#b45309');return false}
  set('✅ به گوشی متصل شد'+(r.ok?'':' (کد پاسخ '+fa(r.status)+')')+' — می‌توانید «تست ارسال» بزنید.','#15803d');return true;
 }catch(e){
  if(window.desktopAPI){set('⚠️ گوشی پیدا شد ولی پاسخ بررسی دریافت نشد ('+esc(String(e&&e.message||e))+'). «تست ارسال» را امتحان کنید؛ اگر پیام رفت، مشکلی نیست.','#b45309');return false}
  set('⚠️ گوشی در شبکه پیدا شد ولی مرورگر اجازه‌ی خواندن پاسخ را نمی‌دهد (CORS). «تست ارسال» را امتحان کنید؛ اگر پیام نرفت، از روش «صف پیامک» استفاده کنید. پیام‌های ناموفق به‌طور خودکار در صف قرار می‌گیرند.','#b45309');return false;
 }
}
async function smsSendGw(to,msg,quiet){
 const s=DB.settings,base=gwBase();
 if(!base){toast('⚠️ آدرس گوشی را در «ابزار ← ارسال با گوشی» وارد کنید',false);_gwDown=true;return false}
 if(gwMixed(base)){toast('❌ اتصال http به گوشی از صفحه‌ی https مسدود است',false);_gwDown=true;return false}
 const hd=gwHeaders(true),num=smsPhone(to,true);
 let tries=[['/message',{message:msg,phoneNumbers:[num]}],['/messages',{textMessage:{text:msg},phoneNumbers:[num]}]];
 if(s.gwEp)tries.sort((x,y)=>(y[0]===s.gwEp)-(x[0]===s.gwEp));
 for(const[p,b]of tries){
  try{
   const r=await fetch(base+p,{method:'POST',headers:hd,body:JSON.stringify(b),signal:gwTimeout(8000)});
   if(r.ok){if(s.gwEp!==p){s.gwEp=p;saveDB()}if(!quiet)toast('✅ پیامک به صف ارسال گوشی رفت: '+fa(to));return true}
   if(r.status!==404&&r.status!==400){toast('⚠️ پاسخ گوشی: '+fa(r.status)+(r.status===401?' (نام کاربری/رمز را بررسی کنید)':''),false);return false}
  }catch(e){
   _gwDown=true;
   toast('❌ اتصال به گوشی برقرار نشد'+(window.desktopAPI?' ('+String(e&&e.message||e).slice(0,80)+')':'')+'؛ «بررسی اتصال» را در ابزار بزنید. پیام‌ها در صف پیامک قرار می‌گیرند',false);return false;
  }
 }
 toast('⚠️ گوشی درخواست را نپذیرفت (نسخه‌ی برنامه یا قالب پیام)',false);return false;
}
function smsQueueOpen(list,title){
 window._smsQ=list;const gw=!!(DB.settings.gwUrl||'').trim();
 const row=(x,i)=>'<tr id="sqr'+i+'"><td class="r">'+esc(x.name||'—')+'</td><td style="direction:ltr">'+esc(x.to)+'</td><td class="r" style="max-width:340px;white-space:pre-wrap;font-size:11px">'+esc(x.msg)+'</td><td><a class="btn p" href="'+smsHref(x)+'" onclick="smsQMark('+i+')">📲 ارسال</a></td></tr>';
 openM(mHead('📲 '+(title||'صف پیامک')+' ('+fa(list.length)+' پیام)')+'<div class="mbody"><div style="font-size:11px;color:var(--mut);margin-bottom:8px">این صفحه را روی گوشی باز کنید و روی «ارسال» بزنید؛ برنامه‌ی پیام گوشی با متن آماده باز می‌شود و فقط «ارسال» را می‌زنید. روی کامپیوتر، فایل صف را به گوشی بفرستید.</div><div style="overflow:auto;max-height:55vh"><table data-rn="0"><thead><tr><th>نام</th><th>شماره</th><th>متن</th><th></th></tr></thead><tbody>'+list.map(row).join('')+'</tbody></table></div></div><div class="mfoot"><button class="btn g" onclick="smsQueueFile()">⬇️ فایل صف برای گوشی</button>'+(gw?'<button class="btn p" onclick="smsQueueGw()">📤 ارسال همه با گوشی متصل</button>':'')+'<button class="btn" onclick="closeM()">بستن</button></div>',true);
}
function smsHref(x){const ios=/iPhone|iPad|iPod/.test((navigator&&navigator.userAgent)||'');return 'sms:'+x.to+(ios?'&':'?')+'body='+encodeURIComponent(x.msg)}
function smsQMark(i){const r=$('sqr'+i);if(r)r.style.opacity='.45';if(window._smsQ&&window._smsQ[i])window._smsQ[i].sent=true}
async function smsQueueGw(){
 const l=window._smsQ||[];let ok=0;toast('⏳ در حال ارسال به گوشی…');
 for(const x of l){if(await smsSendGw(x.to,x.msg,true))ok++;else break;await new Promise(r=>setTimeout(r,1200))}
 toast(ok===l.length?'✅ همه‌ی '+fa(ok)+' پیامک به گوشی سپرده شد':'⚠️ '+fa(ok)+' از '+fa(l.length)+' ارسال شد',ok===l.length);
}
function smsQueueFile(){
 const items=(window._smsQ||[]).map(x=>({n:x.name||'',t:x.to,m:x.msg}));
 const data=JSON.stringify(items).replace(/</g,'\\u003c');
 const html='<!DOCTYPE html><html lang="fa" dir="rtl"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>صف پیامک تکنوکالا</title><style>body{font-family:Tahoma,sans-serif;background:#f3f7fb;margin:0;padding:12px}h2{font-size:16px}.c{background:#fff;border:1px solid #dfeaf3;border-radius:10px;padding:10px;margin-bottom:10px}.c.s{opacity:.45}.m{white-space:pre-wrap;font-size:13px;margin:6px 0}a{display:block;text-align:center;background:#1a6fb5;color:#fff;text-decoration:none;padding:10px;border-radius:8px}</style></head><body><h2>📲 صف پیامک — '+items.length+' پیام</h2><div id="l"></div><script>var D='+data+';var ios=/iPhone|iPad|iPod/.test(navigator.userAgent);var l=document.getElementById("l");D.forEach(function(x,i){var d=document.createElement("div");d.className="c";var h=document.createElement("b");h.textContent=(x.n||"—")+" — "+x.t;var p=document.createElement("div");p.className="m";p.textContent=x.m;var a=document.createElement("a");a.textContent="ارسال";a.href="sms:"+x.t+(ios?"&":"?")+"body="+encodeURIComponent(x.m);a.onclick=function(){d.className="c s"};d.appendChild(h);d.appendChild(p);d.appendChild(a);l.appendChild(d)});<\/script></body></html>';
 const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([html],{type:'text/html'}));a.download='sms-queue-'+jToday().replace(/\//g,'-')+'.html';document.body.appendChild(a);a.click();a.remove();
 toast('⬇️ فایل صف دانلود شد؛ آن را به گوشی بفرستید و باز کنید');
}
function smsPhoneSaveCfg(){
 const s=DB.settings;s.smsMode=$('smMode').value;s.gwUrl=$('gwUrl').value.trim();s.gwUser=$('gwUser').value.trim();s.gwPass=$('gwPass').value;
 saveDB();toast('✅ تنظیمات ارسال با گوشی ذخیره شد');if(s.smsMode==='gw')smsGwCheck();
}
/* ---------- یادآوری مطالبات بالای ۳۰ روز (از گزارش سن مطالبات) ---------- */
function ageOver(r,th){return th>=90?r.b4:th>=60?r.b3+r.b4:r.b2+r.b3+r.b4}
function smsAgeOpen(th){
 th=th||30;window._ageTh=th;
 const rows=ageRows('cust').filter(r=>ageOver(r,th)>0);
 const pr=r=>DB.persons.find(p=>p.id===r.pid)||{};
 openM(mHead('📲 یادآوری مطالبات بالای '+fa(th)+' روز')+'<div class="mbody"><div class="toolbar" style="margin-bottom:8px"><label>حداقل سن:</label><select onchange="smsAgeOpen(+this.value)"><option value="30" '+(th===30?'selected':'')+'>بالای ۳۰ روز</option><option value="60" '+(th===60?'selected':'')+'>بالای ۶۰ روز</option><option value="90" '+(th===90?'selected':'')+'>بالای ۹۰ روز</option></select></div>'+
  (rows.length?'<div style="overflow:auto;max-height:50vh"><table data-rn="0"><thead><tr><th></th><th>مشتری</th><th>شماره</th><th>مبلغ معوق</th><th>مانده کل</th></tr></thead><tbody>'+rows.map((r,i)=>{const ph=pr(r).phone;return '<tr><td><input type="checkbox" class="sa-ck" data-i="'+i+'" '+(ph?'checked':'disabled')+'></td><td class="r">'+esc(r.person)+'</td><td style="direction:ltr">'+(ph?esc(smsPhone(ph)):'<span class="bdg b-r">بدون شماره</span>')+'</td><td class="amt">'+fm(ageOver(r,th))+'</td><td class="amt">'+fm(r.total)+'</td></tr>'}).join('')+'</tbody></table></div>':'<div class="empty"><div class="b">✅</div>مطالبه‌ای بالای '+fa(th)+' روز نیست</div>')+
  '<div style="font-size:11px;color:var(--mut);margin-top:8px">روش ارسال فعلی: <b>'+({api:'سرویس پیامک',gw:'گوشی متصل (Gateway)',link:'صف پیامک روی گوشی'}[smsMode()])+'</b> — از «ابزار» قابل تغییر است. متن از «قالب مطالبات معوق» می‌آید.</div></div><div class="mfoot">'+(rows.length?'<button class="btn p" onclick="smsAgeSend()">📨 تهیه/ارسال پیامک‌ها</button>':'')+'<button class="btn" onclick="closeM()">بستن</button></div>',true);
 window._ageRows=rows;
}
function smsAgeSend(){
 const th=window._ageTh||30,rows=window._ageRows||[],pick=[...document.querySelectorAll('.sa-ck:checked')].map(c=>rows[+c.dataset.i]);
 if(!pick.length){toast('⚠️ کسی انتخاب نشده',false);return}
 closeM();
 pick.forEach(r=>{const p=P(r.pid);sendSMS(p.phone,smsFill(smsTpl('Age'),{name:p.name,amount:ageOver(r,th),remain:r.total,count:th}))});
 logAct('یادآوری مطالبات بالای '+th+' روز به '+fa(pick.length)+' مشتری');
}

/* ================= پیامک خودکار ================= */
/* ۱) با ثبت فاکتور فروش، پیامک فاکتور برای خریدار ارسال می‌شود
   ۲) یک روز قبل از سررسید چک‌های دریافتی و اقساط، پیامک یادآوری برای مشتری ارسال می‌شود */
function smsAutoOn(k){return DB.settings[k]!==false}
function smsPhoneOk(v){return /^09\d{9}$/.test(smsPhone(v))}
function smsAutoInvoice(inv){
 try{
  if(!smsAutoOn('smsAutoInv'))return;
  const p=P(inv.person);if(!p||!smsPhoneOk(p.phone))return;
  const tot=invTotal(inv),msg=smsFill(smsTpl('Inv'),{name:p.name,no:inv.no,amount:tot,date:inv.date,remain:Math.max(0,tot-invPaid(inv))});
  sendSMS(p.phone,msg);
 }catch(e){console.error('smsAutoInvoice',e)}
}
/* ---- بررسی اتصال گوشی (برای هشدار شروع برنامه و پیش از ارسال خودکار) ---- */
async function gwPing(){const base=gwBase();if(!base||gwMixed(base))return false;try{await fetch(base+'/health',{mode:'no-cors',signal:gwTimeout(4000)});return true}catch(e){return false}}
async function smsStartupCheck(){
 const m=smsMode();
 if(m==='api')return;
 if(m==='gw'&&gwBase()&&await gwPing()){toast('📲 گوشی به برنامه متصل است');return}
 smsConnWarn(!(m==='gw'&&gwBase()));
}
function smsConnWarn(unset){
 const modalOpen=$('modal')&&$('modal').classList.contains('open');
 if(modalOpen){toast('⚠️ گوشی به برنامه متصل نیست — پیامک‌ها ارسال نمی‌شوند',false);return}
 openM(mHead('⚠️ گوشی به برنامه متصل نیست')+'<div class="mbody">'+
  '<div class="notice red" style="margin-bottom:10px"><b>'+(unset?'اتصال گوشی هنوز تنظیم نشده است.':'گوشی پیدا نشد.')+'</b> پیامک‌های برنامه (فاکتور، یادآوری چک و اقساط) از طریق گوشی ارسال می‌شوند و تا برقراری اتصال، ارسال نخواهند شد.</div>'+
  '<div style="font-size:12.5px;line-height:2.1">'+(unset?'۱) در «ابزار ← ارسال پیامک با گوشی» روش «گوشی متصل» را انتخاب کنید و آدرس، نام کاربری و رمز برنامه‌ی SMS Gateway را وارد کنید.<br>':'')+
  '• گوشی و کامپیوتر باید به <b>یک Wi‑Fi</b> وصل باشند.<br>• برنامه‌ی <b>SMS Gateway</b> روی گوشی باز و گزینه‌ی <b>Local Server</b> روشن (Start) باشد.<br>• آدرس IP گوشی ممکن است عوض شده باشد؛ آن را در تنظیمات به‌روز کنید.</div></div>'+
  '<div class="mfoot"><button class="btn p" onclick="smsConnRetry()">🔄 بررسی دوباره</button><button class="btn g" onclick="closeM();nav(\'tools\')">⚙️ تنظیمات اتصال گوشی</button><button class="btn" onclick="closeM()">ادامه بدون اتصال</button></div>');
}
async function smsConnRetry(){closeM();toast('⏳ در حال بررسی اتصال گوشی…');await smsStartupCheck()}
/* ---- ضامن: یادآوری‌های چک و قسط برای ضامن مشتری هم ارسال می‌شود ---- */
function guarOf(p){const g=p&&p.guarantor;return g&&g.name&&smsPhoneOk(g.phone)?g:null}
function smsGuarText(p,g,txt){return String(txt).replace('مشتری محترم '+p.name,'ضامن محترم '+g.name).replace('بدهی شما','بدهی «'+p.name+'»')+'\n(شما ضامن «'+p.name+'» هستید)'}
function smsToGuarantor(p,txt){
 try{
  if(!p||!smsAutoOn('smsGuarRem'))return;
  const g=guarOf(p);if(!g||smsPhone(g.phone)===smsPhone(p.phone))return;
  sendSMS(g.phone,smsGuarText(p,g,txt));
 }catch(e){console.error('smsToGuarantor',e)}
}
/* ---- یادآوری خودکار چک/قسط ---- */
let _remBusy=false;
function smsRemSend(groups,keys,today){
 const sent=DB.smsSent;let n=0;
 groups.forEach(g=>{
  const it=g.items,sum=it.reduce((t,x)=>t+Number(x.amount||0),0),first=it[0];
  let msg;
  if(g.kind==='Late'){
   const late=Math.max(...it.map(x=>x.late));
   msg=smsFill(smsTpl('Late'),{name:g.p.name,no:first.no,amount:sum,due:first.due,late,count:it.length})+(it.length>1?'\n(و '+fa(it.length-1)+' قسط دیگر)':'');
  }else{
   const word=g.kind==='Chq'?'چک':'قسط';
   msg=smsFill(smsTpl(g.kind),{name:g.p.name,no:first.no,amount:sum,due:first.due,count:it.length})+(it.length>1?'\n(و '+fa(it.length-1)+' '+word+' دیگر)':'')+'\n🔔 یادآوری: سررسید '+(first.d===1?'فردا':'امروز')+' است.';
  }
  if(g.okP)sendSMS(g.p.phone,msg);
  if(g.okG){const gu=guarOf(g.p);if(gu&&!(g.okP&&smsPhone(gu.phone)===smsPhone(g.p.phone)))sendSMS(gu.phone,smsGuarText(g.p,gu,msg))}
  n++;
 });
 keys.forEach(k=>{sent[k]=today});
 const cut=jAddD(today,-180);Object.keys(sent).forEach(k=>{if(sent[k]<cut)delete sent[k]});
 if(keys.length)saveDB();
 return n;
}
async function smsAutoRemind(manual){
 if(_remBusy)return 0;
 const mode=smsMode();
 if(!manual&&mode==='link')return 0;
 const onRem=manual||smsAutoOn('smsAutoRem'),onLate=manual||smsAutoOn('smsAutoLate');
 if(!onRem&&!onLate)return 0;
 _remBusy=true;let n=0;
 try{
  if(mode==='gw'&&!(await gwPing())){if(manual)toast('⚠️ گوشی به برنامه متصل نیست؛ ابتدا اتصال را برقرار کنید',false);_remBusy=false;return 0}
  DB.smsSent=DB.smsSent||{};
  const today=jToday(),sent=DB.smsSent,groups={};
  const add=(kind,key,pid,it)=>{
   if(sent[key])return;
   const p=P(pid);if(!p)return;
   const okP=smsPhoneOk(p.phone),okG=smsAutoOn('smsGuarRem')&&!!guarOf(p);if(!okP&&!okG)return;
   const gk=pid+'|'+kind;(groups[gk]=groups[gk]||{kind,p,items:[],keys:[],okP,okG});groups[gk].items.push(it);groups[gk].keys.push(key);
  };
  if(onRem)DB.cheques.forEach(c=>{
   if(c.status!=='جاری'||c.dir!=='rec')return;
   const d=daysDiff(today,jNorm(c.due));if(d!==1&&d!==0)return;
   add('Chq','c:'+c.id+':'+jNorm(c.due),c.person,{no:c.no,amount:c.amount,due:c.due,d});
  });
  DB.installments.forEach(i=>{
   if(i.paid)return;
   const due=jNorm(i.due);if(!due)return;
   const d=daysDiff(today,due);
   /* «مشتریان عادی»: سررسید امروز و معوق ۳ روز به بالا را هشدار ورود به برنامه (با تایید و ارسال گروهی) انجام می‌دهد */
   if(smsAutoOn('smsEntryAlert')&&instGrp(i)==='ig-normal'&&(d===0||d<=-3))return;
   if(onRem&&(d===1||d===0))add('Inst','i:'+i.id+':'+due,i.person,{no:i.no,amount:i.amount,due:i.due,d});
   else if(onLate&&d<=-7)add('Late','l:'+i.id+':'+due,i.person,{no:i.no,amount:i.amount,due:i.due,late:-d});
  });
  const all=Object.values(groups),norm=all.filter(g=>g.kind!=='Late'),late=all.filter(g=>g.kind==='Late');
  const keysOf=gs=>gs.reduce((a,g)=>a.concat(g.keys),[]);
  n+=smsRemSend(norm,keysOf(norm),today);
  if(late.length){
   if(late.length>10&&!manual){
    if(window._lateAsked!==today){window._lateAsked=today;
     confirmM('<b>'+fa(late.length)+'</b> مشتری قسط معوق بیش از یک هفته دارند و یادآوری «موعد پرداخت بدهی» برایشان ارسال نشده است. همین حالا ارسال شود؟',()=>{smsRemSend(late,keysOf(late),today)})}
   }else n+=smsRemSend(late,keysOf(late),today);
  }
  if(manual)toast(n?'📨 یادآوری برای '+fa(n)+' نفر ارسال شد':'موردی برای یادآوری نیست یا قبلاً ارسال شده',!!n);
 }catch(e){console.error('smsAutoRemind',e)}
 _remBusy=false;return n;
}
