/* ================= اصلاح/بازگردانی پرداخت قسط + هشدار و پیامک گروهی هنگام ورود ================= */

/* ---------- ۱) بازگردانی و اصلاح قسطی که اشتباهاً «پرداخت‌شده» ثبت شده ---------- */
/* رسید، تراکنش بانکی و نشانه‌ی ورود گردش بانک را برمی‌دارد و قسط را دوباره «باز» می‌کند */
function instUnpayCore(i){
 const rids=DB.receipts.filter(r=>r.instId===i.id).map(r=>r.id);
 DB.receipts=DB.receipts.filter(r=>r.instId!==i.id);
 DB.accTx=DB.accTx.filter(t=>!rids.includes(t.ref));
 if(DB.bankSeen)Object.keys(DB.bankSeen).forEach(k=>{if(DB.bankSeen[k]===i.id)delete DB.bankSeen[k]});
 i.paid=false;i.paidDate='';delete i.paidMethod;delete i.amountPaid;delete i.bankRef;
}
function instRefreshView(){try{nav(curView||'inst')}catch(e){try{vInst()}catch(_){}}}
function instUnpay(id){
 const i=DB.installments.find(x=>x.id===id);if(!i||!i.paid)return;
 if(lockBlocked(i.paidDate))return;
 confirmM('بازگردانی پرداخت قسط <b>'+fa(i.no)+'</b> — <b>'+esc(PN(i.person))+'</b> (مبلغ '+fm(i.amountPaid||i.amount)+' تومان، '+jShort(i.paidDate)+')؟<br><small>قسط دوباره «باز» می‌شود؛ رسید و تراکنش بانکی مربوط به این پرداخت حذف می‌شود و مانده‌ی حساب مشتری اصلاح می‌گردد. پیام تشکری که قبلاً ارسال شده قابل پس‌گرفتن نیست.</small>',()=>{
  ixInvalidate();
  const j=DB.installments.find(x=>x.id===id);if(!j||!j.paid)return;
  const amt=j.amountPaid||j.amount;
  instUnpayCore(j);
  logAct('بازگردانی پرداخت قسط '+PN(j.person)+' — '+fm(amt));
  saveDB();instRefreshView();toast('↩️ پرداخت قسط بازگردانده شد و قسط دوباره باز است');
 });
}
function instEditPay(id){
 const i=DB.installments.find(x=>x.id===id);if(!i||!i.paid)return;
 if(lockBlocked(i.paidDate))return;
 const rc=DB.receipts.find(r=>r.instId===id),row=(rc&&rc.rows&&rc.rows[0])||{};
 const m0=i.paidMethod||row.method||'cash',acc0=row.acc||'';
 openM(mHead('✏️ اصلاح پرداخت قسط '+fa(i.no)+' — '+esc(PN(i.person)))+'<div class="mbody">'+
  '<div class="notice" style="margin-bottom:8px">مبلغ قسط: <b>'+fm(i.amount)+'</b> تومان — اطلاعات پرداخت را اصلاح کنید یا با «بازگردانی» قسط را دوباره باز کنید.</div>'+
  '<div class="frow"><div class="fg"><label>مبلغ دریافتی (تومان)</label><input id="epAmt" class="money" value="'+fm(i.amountPaid||i.amount)+'"></div>'+
  '<div class="fg"><label>تاریخ پرداخت</label><input id="epDate" value="'+esc(i.paidDate||jToday())+'" style="width:110px"></div>'+
  '<div class="fg"><label>روش</label><select id="epM">'+['cash','card','fish','account'].map(m=>'<option value="'+m+'" '+(m===m0?'selected':'')+'>'+({cash:'نقد',card:'کارت',fish:'فیش',account:'حساب'})[m]+'</option>').join('')+'</select></div>'+
  '<div class="fg"><label>حساب بانکی</label><select id="epAcc">'+DB.accounts.map((a,k)=>'<option value="'+a.id+'" '+((acc0?a.id===acc0:k===0)?'selected':'')+'>'+esc(a.title)+'</option>').join('')+'</select></div></div></div>'+
  '<div class="mfoot"><button class="btn p" onclick="instEditPaySave(\''+id+'\')">💾 ذخیره‌ی اصلاح</button><button class="btn r" onclick="closeM();instUnpay(\''+id+'\')">↩️ بازگردانی (باز کردن قسط)</button><button class="btn" onclick="closeM()">انصراف</button></div>');
}
function instEditPaySave(id){
 const i=DB.installments.find(x=>x.id===id);if(!i||!i.paid){closeM();return}
 const amt=pd($('epAmt').value),date=jNorm($('epDate').value),m=$('epM').value,acc=$('epAcc').value;
 if(!amt){toast('⚠️ مبلغ را وارد کنید',false);return}
 if(!jValid(date)){toast('⚠️ تاریخ نامعتبر است',false);return}
 if(m!=='cash'&&!acc){toast('⚠️ حساب بانکی را انتخاب کنید',false);return}
 if(lockBlocked(date)||lockBlocked(i.paidDate))return;
 const commit=()=>{
  ixInvalidate();
  const j=DB.installments.find(x=>x.id===id);if(!j||!j.paid)return;
  const old=DB.receipts.find(r=>r.instId===id),keepNo=old&&old.no,bref=j.bankRef,desc=old&&old.desc;
  instUnpayCore(j);
  j.paid=true;j.paidDate=date;j.paidMethod=m;j.amountPaid=amt;
  if(bref){j.bankRef=bref;DB.bankSeen=DB.bankSeen||{};DB.bankSeen[bref]=j.id}
  const rid=uid();
  DB.receipts.push({id:rid,instId:j.id,no:keepNo||nextNo('rec'),date,person:j.person,dir:'in',rows:[{method:m,amount:amt,acc}],desc:desc||('پرداخت قسط '+fa(j.no))});
  if(m!=='cash'&&acc)DB.accTx.push({id:uid(),acc,date,type:'in',amount:amt,desc:'قسط '+PN(j.person),ref:rid});
  logAct('اصلاح پرداخت قسط '+PN(j.person)+' — '+fm(amt));
  saveDB();closeM();instRefreshView();toast('✅ پرداخت قسط اصلاح شد');
 };
 if(amt<Number(i.amount))confirmM('مبلغ دریافتی ('+fm(amt)+' ت) کمتر از قسط ('+fm(i.amount)+' ت) است؛ قسط «تسویه‌شده» می‌ماند و مابه‌التفاوت فقط در مانده‌ی حساب مشتری باقی می‌ماند. ادامه می‌دهید؟',commit);
 else commit();
}

/* ---------- ۲) پیامک یادآوری گروهی از لیست اقساط ---------- */
function instSelSMS(){
 const X=ix(),list=[...INSTSEL].map(id=>X.inst.get(id)).filter(i=>i&&!i.paid);
 instBulkSMS(list);
}
function instListSMS(){instBulkSMS((window._instList||[]).filter(i=>!i.paid))}

/* ---------- ۳) هشدار و پیامک گروهی هنگام ورود: «مشتریان عادی» ----------
   • سررسید امروز  • ۳ تا ۶ روز پس از سررسید  • ۷ روز و بیشتر پس از سررسید
   هر قسط در هر مرحله فقط یک‌بار پیامک می‌شود (ثبت در DB.smsSent) */
const EA_TIERS=[
 {k:'g0',ic:'⏰',t:'سررسید امروز',c:'b-o'},
 {k:'g3',ic:'⚠️',t:'۳ روز (یا بیشتر) از سررسید گذشته',c:'b-r'},
 {k:'g7',ic:'⛔',t:'یک هفته (یا بیشتر) از سررسید گذشته',c:'b-r'}
];
function instAlertData(){
 const today=jToday(),sent=DB.smsSent=DB.smsSent||{},byT={g0:{},g3:{},g7:{}};let done=0;
 DB.installments.forEach(i=>{
  if(i.paid||instGrp(i)!=='ig-normal')return;
  const due=jNorm(i.due);if(!due)return;
  const late=daysDiff(due,today);
  const k=late===0?'g0':(late>=3&&late<=6)?'g3':late>=7?'g7':'';if(!k)return;
  const key=k+':'+i.id+':'+due;
  if(sent[key]){done++;return}
  const p=P(i.person);if(!p)return;
  const g=byT[k][p.id]=byT[k][p.id]||{k,p,items:[],keys:[]};
  g.items.push({no:i.no,amount:Number(i.amount)||0,due,late});g.keys.push(key);
 });
 const out={g0:[],g3:[],g7:[],done};
 EA_TIERS.forEach(t=>{out[t.k]=Object.values(byT[t.k]).map(g=>{
  g.items.sort((a,b)=>a.due<b.due?-1:a.due>b.due?1:(a.no||0)-(b.no||0));
  g.sum=g.items.reduce((s,x)=>s+x.amount,0);g.maxLate=Math.max(...g.items.map(x=>x.late));g.okP=smsPhoneOk(g.p.phone);return g
 }).sort((a,b)=>b.maxLate-a.maxLate||(a.p.name<b.p.name?-1:1))});
 return out;
}
function instAlertMsg(g){
 const f=g.items[0],more=g.items.length>1?'\n(و '+fa(g.items.length-1)+' قسط دیگر)':'';
 if(g.k==='g0')return smsFill(smsTpl('Inst'),{name:g.p.name,no:f.no,amount:g.sum,due:f.due,count:g.items.length})+more+'\n🔔 یادآوری: سررسید امروز است.';
 return smsFill(smsTpl('Late'),{name:g.p.name,no:f.no,amount:g.sum,due:f.due,late:g.maxLate,count:g.items.length})+more;
}
function instEntryAlert(manual,tries){
 try{
  if(!manual){
   if(DB.settings.smsEntryAlert===false)return;
   if(DB.settings.entryAlertSkip===jToday())return;
  }
  const mo=$('modal');
  if(mo&&mo.classList.contains('open')){if(!manual&&(tries||0)<40)setTimeout(()=>instEntryAlert(false,(tries||0)+1),3000);return}
  const D=instAlertData(),total=D.g0.length+D.g3.length+D.g7.length;
  /* هنگام ورود فقط وقتی پنجره باز می‌شود که حداقل یک نفرِ دارای شماره‌ی معتبر برای ارسال باشد */
  if(!manual&&![].concat(D.g0,D.g3,D.g7).some(g=>g.okP))return;
  if(!total){if(manual)toast('✅ برای «مشتریان عادی» قسطِ سررسید امروز یا معوق (۳ روز و بیشتر) که پیامک نشده باشد وجود ندارد'+(D.done?' — '+fa(D.done)+' مورد قبلاً پیامک شده':''));return}
  window._ea=[];
  let body='';
  EA_TIERS.forEach(t=>{
   const rows=D[t.k];if(!rows.length)return;
   const sum=rows.reduce((s,g)=>s+g.sum,0);
   body+='<tr><td colspan="6" style="background:#eef3f9;font-weight:800;text-align:right"><label style="cursor:pointer"><input type="checkbox" checked onchange="document.querySelectorAll(\'.ea-ck[data-t=&quot;'+t.k+'&quot;]:not(:disabled)\').forEach(c=>c.checked=this.checked);instEntryCnt()"> '+t.ic+' '+t.t+' — '+fa(rows.length)+' نفر، جمع '+fm(sum)+' تومان</label></td></tr>';
   rows.forEach(g=>{
    const idx=window._ea.push(g)-1;
    body+='<tr><td><input type="checkbox" class="ea-ck" data-t="'+t.k+'" data-i="'+idx+'" '+(g.okP?'checked':'disabled')+' onchange="instEntryCnt()"></td><td class="r">'+esc(g.p.name)+'</td><td style="direction:ltr">'+(g.okP?esc(smsPhone(g.p.phone)):'<span class="bdg b-r">بدون شماره</span>')+'</td><td>'+fa(g.items.length)+'</td><td class="amt">'+fm(g.sum)+'</td><td>'+(g.maxLate>0?'<span class="bdg '+t.c+'">'+fa(g.maxLate)+' روز تأخیر</span>':'<span class="bdg b-o">امروز</span>')+'</td></tr>';
   });
  });
  openM(mHead('🔔 یادآوری اقساط — مشتریان عادی')+'<div class="mbody">'+
   '<div class="notice red" style="margin-bottom:8px"><b>'+fa(total)+' مورد نیازمند یادآوری است</b> (سررسید امروز: '+fa(D.g0.length)+' | ۳ روز گذشته: '+fa(D.g3.length)+' | یک هفته گذشته: '+fa(D.g7.length)+')'+(D.done?' — '+fa(D.done)+' مورد قبلاً پیامک شده است':'')+'</div>'+
   '<div style="overflow:auto;max-height:52vh"><table data-rn="0"><thead><tr><th></th><th>مشتری</th><th>موبایل</th><th>تعداد قسط</th><th>مبلغ (تومان)</th><th>وضعیت</th></tr></thead><tbody>'+body+'</tbody></table></div>'+
   '<div style="font-size:11px;color:var(--mut);margin-top:8px">متن پیامک «سررسید امروز» از قالب اقساط و متن «معوق» از قالب یادآوری قسط معوق (ابزار ← پیامک) گرفته می‌شود. روش ارسال فعلی: <b>'+({api:'سرویس پیامک',gw:'گوشی متصل (Gateway)',link:'صف پیامک روی گوشی'}[smsMode()])+'</b></div></div>'+
   '<div class="mfoot"><button class="btn p" id="eaSend" onclick="instEntrySend()">📨 ارسال پیامک گروهی</button><button class="btn g" onclick="closeM();Fi.grp=\'ig-normal\';Fi.mode=\'due\';nav(\'inst\');setTimeout(()=>vInst(\'list\'),60)">📋 مشاهده در لیست اقساط</button><button class="btn" onclick="instEntrySkipToday()">امروز دیگر نشان نده</button><button class="btn" onclick="closeM()">بعداً</button></div>',true);
  instEntryCnt();
 }catch(e){console.error('instEntryAlert',e)}
}
function instEntryCnt(){
 const n=document.querySelectorAll('.ea-ck:checked').length,b=$('eaSend');
 if(b){b.textContent='📨 ارسال پیامک گروهی ('+fa(n)+' نفر)';b.disabled=!n}
}
function instEntrySkipToday(){DB.settings.entryAlertSkip=jToday();saveDB();closeM();toast('تا فردا این هشدار هنگام ورود نشان داده نمی‌شود (از لیست اقساط هم قابل باز کردن است)')}
function instEntrySend(){
 const pick=[...document.querySelectorAll('.ea-ck:checked')].map(c=>(window._ea||[])[+c.dataset.i]).filter(Boolean);
 if(!pick.length){toast('⚠️ کسی انتخاب نشده',false);return}
 const today=jToday(),sent=DB.smsSent=DB.smsSent||{};
 closeM();
 pick.forEach(g=>{
  const msg=instAlertMsg(g);
  sendSMS(g.p.phone,msg);smsToGuarantor(g.p,msg);
  g.keys.forEach(k=>{sent[k]=today});
 });
 const cut=jAddD(today,-180);Object.keys(sent).forEach(k=>{if(sent[k]<cut)delete sent[k]});
 logAct('یادآوری گروهی اقساط (مشتریان عادی) به '+fa(pick.length)+' نفر');
 saveDB();toast('📨 درخواست ارسال یادآوری به '+fa(pick.length)+' نفر ثبت شد');
}
