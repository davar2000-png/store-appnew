/* ===== ویرایش/حذف گزینه‌های مشخصات و ویرایش/حذف کالا (در همان صفحه‌ی معرفی کالا) ===== */
const PW_OPT={
 brand:{list:'brands',field:'brand',label:'برند'},memory:{list:'memories',field:'memory',label:'حافظه'},ram:{list:'rams',field:'ram',label:'رم'},
 cpuSeries:{list:'cpuSeries',field:'cpuSeries',label:'سری پردازنده'},cpuGen:{list:'cpuGens',field:'cpuGen',label:'نسل پردازنده'},cpuModel:{list:'cpuModels',field:'cpuModel',label:'مدل پردازنده'},
 gpu:{list:'gpus',field:'gpu',label:'پردازنده‌ی گرافیکی'},screen:{list:'screenSizes',field:'screen',label:'صفحه نمایش'},usage:{list:'laptopUsages',field:'usage',label:'کاربری'},cond:{list:'laptopConds',field:'cond',label:'وضعیت'}
};
const PW_OPT_KINDS=['group','brand','model','color',...Object.keys(PW_OPT)];
function pwOptArr(kind){
 const S=PW_OPT[kind];
 return(S.list in LAP_DEF)?lapOpts(S.list):(DB.productOptions[S.list]||(DB.productOptions[S.list]=[]));
}
function pwOptUsage(kind,val){
 if(kind==='group')return DB.products.filter(p=>p.group===val).length;
 if(kind==='color')return DB.products.filter(p=>(p.colors||[]).includes(val)).length+DB.serials.filter(s=>s.color===val).length+DB.invoices.reduce((n,i)=>n+i.lines.filter(l=>l.color===val).length,0);
 if(kind==='model')return DB.products.filter(p=>p.brand===PW.brand&&p.model===val).length;
 return DB.products.filter(p=>p[PW_OPT[kind].field]===val).length;
}
function pwOptModal(title,label,val,hex,cb){
 window._optCb=cb;
 openM(mHead(title)+'<div class="mbody"><div class="fg"><label>'+label+'</label><input id="optIn" value="'+esc(val)+'" style="width:100%" onkeydown="if(event.key===\'Enter\'){optOk()}"></div>'+
  (hex!==null?'<div class="fg"><label>رنگ نمایشی</label><input id="optHex" type="color" value="'+esc(hex)+'" style="width:60px;height:34px;padding:0"></div>':'')+
  '</div><div class="mfoot"><button class="btn p" onclick="optOk()">💾 ذخیره</button><button class="btn" onclick="closeM()">انصراف</button></div>');
 setTimeout(()=>rf('optIn'),30);
}
function optOk(){
 const v=String(($('optIn')||{}).value||'').trim(),h=$('optHex')?$('optHex').value:null,cb=window._optCb;
 if(!v){toast('⚠️ نام را وارد کنید',false);return}
 closeM();if(cb)cb(v,h);
}
function pwOptDone(msg,n){saveDB();if(PW)pwRender();toast('✅ '+msg+(n?' — '+fa(n)+' کالا به‌روز شد':''))}
function pwOptEdit(kind){
 if(!PW||!PW[kind])return;const cur=PW[kind],lc=s=>String(s).toLowerCase();
 if(kind==='group'){
  const g=DB.productGroups.find(x=>x.id===cur);if(!g)return;
  return pwOptModal('✏️ ویرایش گروه کالا','نام گروه',g.name,null,v=>{
   if(DB.productGroups.some(x=>x.id!==g.id&&lc(x.name)===lc(v))){toast('⚠️ گروهی با این نام هست',false);return}
   g.name=v;pwOptDone('نام گروه ویرایش شد');
  });
 }
 if(kind==='color'){
  const c=DB.colors.find(x=>x.id===cur);if(!c)return;
  return pwOptModal('✏️ ویرایش رنگ','نام رنگ',colorEnOf(c),c.hex||'#95a5a6',(v,h)=>{
   if(DB.colors.some(x=>x.id!==c.id&&lc(colorEnOf(x))===lc(v))){toast('⚠️ رنگی با این نام هست',false);return}
   c.name=v;c.enName=lc(v);if(h)c.hex=h;pwOptDone('رنگ ویرایش شد');
  });
 }
 if(kind==='model'){
  return pwOptModal('✏️ ویرایش مدل','نام مدل',cur,null,v=>{
   if(modelsOfBrand(PW.brand).some(m=>m!==cur&&lc(m)===lc(v))){toast('⚠️ مدلی با این نام هست',false);return}
   const pm=(DB.phoneModels||{})[PW.brand]||[],ex=DB.productOptions.models||[];
   [pm,ex].forEach(a=>{const i=a.indexOf(cur);if(i>=0)a[i]=v});
   let n=0;DB.products.forEach(p=>{if(p.brand===PW.brand&&p.model===cur){p.model=v;n++}});
   PW.model=v;pwOptDone('مدل ویرایش شد',n);
  });
 }
 const S=PW_OPT[kind];
 pwOptModal('✏️ ویرایش '+S.label,'نام جدید',cur,null,v=>{
  const arr=pwOptArr(kind);
  if(arr.some(x=>x!==cur&&lc(x)===lc(v))){toast('⚠️ این گزینه قبلاً هست',false);return}
  const i=arr.indexOf(cur);if(i>=0)arr[i]=v;else arr.push(v);
  let n=0;DB.products.forEach(p=>{if(p[S.field]===cur){p[S.field]=v;n++}});
  if(kind==='brand'){const pm=DB.phoneModels||(DB.phoneModels={});if(pm[cur]){const t=pm[v]||[];pm[v]=t.concat(pm[cur].filter(m=>!t.includes(m)));delete pm[cur]}}
  PW[kind]=v;pwOptDone(S.label+' ویرایش شد',n);
 });
}
function pwOptDel(kind){
 if(!PW||!PW[kind])return;const cur=PW[kind];
 if(kind==='group'||kind==='color'){
  const n=pwOptUsage(kind,cur);
  if(n){toast('⛔ این '+(kind==='group'?'گروه':'رنگ')+' در '+fa(n)+' مورد استفاده شده و حذف نمی‌شود',false);return}
  const name=kind==='group'?(DB.productGroups.find(x=>x.id===cur)||{}).name:colorEnOf(DB.colors.find(x=>x.id===cur)||{});
  return confirmM('حذف «'+esc(name)+'» از فهرست؟',()=>{
   if(kind==='group')DB.productGroups=DB.productGroups.filter(x=>x.id!==cur);else DB.colors=DB.colors.filter(x=>x.id!==cur);
   PW[kind]='';pwOptDone('حذف شد');
  });
 }
 const n=pwOptUsage(kind,cur),label=kind==='model'?'مدل':PW_OPT[kind].label;
 confirmM('حذف «'+esc(cur)+'» از فهرست '+label+'؟'+(n?'<br><small>در '+fa(n)+' کالا استفاده شده؛ آن کالاها همان مقدار را نگه می‌دارند و فقط از فهرست انتخاب حذف می‌شود.</small>':''),()=>{
  if(kind==='model'){
   const pm=(DB.phoneModels||{})[PW.brand];if(pm){const i=pm.indexOf(cur);if(i>=0)pm.splice(i,1)}
   if(DB.productOptions.models)DB.productOptions.models=DB.productOptions.models.filter(m=>m!==cur);
  }else{
   const arr=pwOptArr(kind),i=arr.indexOf(cur);if(i>=0)arr.splice(i,1);
   if(kind==='brand'){if(DB.phoneModels)delete DB.phoneModels[cur];PW.model=''}
  }
  PW[kind]='';pwOptDone('حذف شد');
 });
}
/* ---------- ویرایش و حذف خودِ کالا ---------- */
function pwIdentEdit(G,H){
 const p=PR(PW.editPid)||{},used=DB.invoices.some(i=>i.lines.some(l=>l.pid===p.id))||DB.serials.some(s=>s.pid===p.id);
 return H('🔖 کد و پیگیری موجودی')+'<div class="pw-g" style="'+G+'">'+
  '<div class="fg"><label>📦 نحوه پیگیری موجودی</label><select '+(used?'disabled ':'')+'onchange="PW.track=this.value;pwRender()"><option value="serial"'+(PW.track==='serial'?' selected':'')+'>سریالی (هر دستگاه یک سریال)</option><option value="qty"'+(PW.track==='qty'?' selected':'')+'>تعدادی (بدون سریال)</option></select>'+(used?'<small style="color:var(--mut)">کالای دارای فاکتور/سریال قابل تغییر نیست</small>':'')+'</div>'+
  '<div class="fg"><label>🏷️ کد کالا</label><input id="pwCode" dir="ltr" value="'+esc(PW.code)+'" oninput="PW.code=this.value;pwPreviewUpd()"></div>'+
  '<div class="fg" style="justify-content:flex-end"><label class="pw-inl" style="white-space:normal"><input type="checkbox" '+(PW.renameAuto?'checked ':'')+'onchange="PW.renameAuto=this.checked;pwPreviewUpd()"> نام کالا با مشخصات جدید دوباره ساخته شود</label><small style="color:var(--mut)">فاکتورهای قبلی با کد کالا ارجاع دارند و تغییر نمی‌کنند.</small></div></div>';
}
function productEdit(pid){
 const p=PR(pid);if(!p)return;
 const go=()=>{
  const sers=DB.serials.filter(s=>s.pid===pid).map(s=>s.sn),hit=sers.find(sn=>String(p.name).toLowerCase().includes(String(sn).toLowerCase()));
  PW=Object.assign(pwDefault(),{editPid:pid,group:p.group||'',brand:p.brand||'',model:p.model||'',memory:p.memory||'',ram:p.ram||'',cpuSeries:p.cpuSeries||'',cpuGen:p.cpuGen||'',cpuModel:p.cpuModel||'',gpu:p.gpu||'',screen:p.screen||'',usage:p.usage||'',cond:p.cond||'',
   color:(p.colors||[])[0]||'',track:p.track||'qty',snInName:!!hit,sn:hit||'',codeMode:'manual',code:p.code,lastCost:p.lastCost||0,sellPrice:p.sellPrice||0,sellAuto:false,minStock:p.minStock||0,reorder:p.reorder||0,notes:p.notes||'',renameAuto:true});
  window._pwTab=true;pageTitles.newProduct='ویرایش کالا';nav('newProduct');
 };
 if(PW&&!PW.editPid&&(PW.brand||PW.model||PW.sn))confirmM('فرم «معرفی کالای جدید» نیمه‌کاره است. با ویرایش این کالا، آن فرم کنار گذاشته می‌شود؛ ادامه؟',()=>{closeM();go()});
 else go();
}
function pwUpdate(){
 const p=PR(PW.editPid);if(!p){toast('⚠️ کالا پیدا نشد',false);return}
 if(!PW.group){toast('⚠️ گروه کالا را انتخاب کنید',false);return}
 if(!PW.brand){toast('⚠️ برند را انتخاب کنید',false);return}
 if(!PW.model){toast('⚠️ مدل را انتخاب کنید',false);return}
 const cost=pd(PW.lastCost),sell=pd(PW.sellPrice);
 if(cost&&sell-cost>profitCapOf(PW.group)){toast('⛔ سود هر عدد حداکثر '+fm(profitCapOf(PW.group))+' تومان است؛ قیمت فروش را کاهش دهید',false);return}
 const code=String(PW.code||'').trim();
 if(!code){toast('⚠️ کد کالا را وارد کنید',false);return}
 if(DB.products.some(x=>x.id!==p.id&&String(x.code).toLowerCase()===code.toLowerCase())){toast('⚠️ این کد کالا قبلاً استفاده شده',false);return}
 const used=DB.invoices.some(i=>i.lines.some(l=>l.pid===p.id))||DB.serials.some(s=>s.pid===p.id);
 if(PW.track!==p.track&&used){toast('⛔ نحوه‌ی پیگیری کالای دارای سابقه قابل تغییر نیست',false);return}
 let name=p.name;
 if(PW.renameAuto){
  name=pwName();
  if(DB.products.some(x=>x.id!==p.id&&String(x.name).toLowerCase()===name.toLowerCase())){toast('⚠️ کالای دیگری با همین نام وجود دارد؛ مشخصات را عوض کنید یا بازسازی نام را خاموش کنید',false);return}
 }
 const oldColor=(p.colors||[])[0]||'';
 Object.assign(p,{code,name,group:PW.group,brand:PW.brand,model:PW.model,memory:PW.memory||'',ram:PW.ram||'',cpuSeries:PW.cpuSeries||'',cpuGen:PW.cpuGen||'',cpuModel:PW.cpuModel||'',gpu:PW.gpu||'',screen:PW.screen||'',usage:PW.usage||'',cond:PW.cond||'',
  track:PW.track,minStock:Math.max(0,PW.minStock||0),reorder:Math.max(0,PW.reorder||0),lastCost:cost,sellPrice:sell,notes:PW.notes||''});
 if(PW.color&&PW.color!==oldColor){
  p.colors=p.colors||[];
  if(p.colors.length<=1){p.colors=[PW.color];DB.serials.forEach(s=>{if(s.pid===p.id&&s.color===oldColor)s.color=PW.color})}
  else p.colors[0]=PW.color;
 }
 logAct('ویرایش کالا: '+name);saveDB();
 PW=null;window._pwTab=false;pageTitles.newProduct='معرفی کالای جدید';openPages=openPages.filter(x=>x!=='newProduct');
 nav('products');toast('✅ مشخصات کالا ذخیره شد: '+name);
}
function pwDelProduct(){
 if(!PW||!PW.editPid)return;
 productDel(PW.editPid,true);
}
