/* ================= 📘 لایه حسابداری دوطرفه (سند خودکار — مشتق از فاکتور/رسید/چک) ================= */
const COA=[
 ['1101','صندوق','A'],['1102','بانک','A'],['1201','حساب‌های دریافتنی','A'],['1202','اسناد دریافتنی (چک)','A'],['1301','موجودی کالا','A'],
 ['2101','حساب‌های پرداختنی','L'],['2102','اسناد پرداختنی (چک)','L'],
 ['4101','فروش','R'],['4102','برگشت از فروش','R'],['4103','تخفیف فروش','R'],['4201','سایر درآمدها','R'],
 ['3101','سرمایه','Q'],['5101','بهای تمام‌شده کالای فروش‌رفته','E'],['5102','تخفیف خرید','E'],
 ['6101','اجاره','X'],['6102','حقوق و دستمزد','X'],['6103','آب، برق، گاز و تلفن','X'],['6104','حمل و ارسال','X'],['6105','تبلیغات','X'],['6199','سایر هزینه‌ها','X']];
const COA_NAME=Object.fromEntries(COA.map(a=>[a[0],a[1]]));
function jnlBuild(){
 const out=[];let n=0;
 const mk=(date,desc,ref)=>{const e={no:0,date:jNorm(date)||date||'',desc,ref,rows:[]};
  e.dr=(a,v,pr)=>{v=Math.round(v||0);if(!v)return e;e.rows.push(v>0?{a,d:v,c:0,p:pr}:{a,d:0,c:-v,p:pr});return e};
  e.cr=(a,v,pr)=>e.dr(a,-(Math.round(v||0)),pr);return e};
 const acc=(m,dir)=>m==='cash'?'1101':m==='cheque'?(dir==='in'?'1202':'2102'):'1102';
 DB.invoices.forEach(inv=>{
  if(inv.type==='proforma')return;
  const gross=inv.lines.reduce((s,l)=>s+l.qty*l.price,0),disc=pd(inv.discount||0),paid=invPaid(inv),rem=gross-disc-paid;
  const cost=inv.lines.reduce((s,l)=>s+(Number(l.cost)||0)*l.qty,0),pr=inv.person;
  const e=mk(inv.date,invTypeFa(inv.type)+' شماره '+inv.no,{k:'inv',id:inv.id});
  const pays=(inv.pays||[]).filter(x=>x.method!=='installment');
  if(inv.type==='sale'){pays.forEach(x=>e.dr(acc(x.method,'in'),pd(x.amount)));e.dr('1201',rem,pr).dr('4103',disc).cr('4101',gross);e.dr('5101',cost).cr('1301',cost)}
  else if(inv.type==='saleret'){e.dr('4102',gross).cr('4103',disc);pays.forEach(x=>e.cr(acc(x.method,'in'),pd(x.amount)));e.cr('1201',rem,pr);e.dr('1301',cost).cr('5101',cost)}
  else if(inv.type==='buy'){e.dr('1301',gross).cr('5102',disc);pays.forEach(x=>e.cr(acc(x.method,'out'),pd(x.amount)));e.cr('2101',rem,pr)}
  else if(inv.type==='buyret'){pays.forEach(x=>e.dr(acc(x.method,'out'),pd(x.amount)));e.dr('2101',rem,pr).dr('5102',disc).cr('1301',gross)}
  if(e.rows.length)out.push(e);
 });
 DB.receipts.forEach(r=>{
  const e=mk(r.date,'رسید '+(r.dir==='in'?'دریافت':'پرداخت')+' '+(r.no||''),{k:'rec',id:r.id}),tot=r.rows.reduce((s,x)=>s+pd(x.amount),0);
  if(r.dir==='in'){r.rows.forEach(x=>e.dr(acc(x.method,'in'),pd(x.amount)));e.cr('1201',tot,r.person)}
  else{e.dr('2101',tot,r.person);r.rows.forEach(x=>e.cr(acc(x.method,'out'),pd(x.amount)))}
  if(e.rows.length)out.push(e);
 });
 DB.cheques.forEach(c=>{
  if(c.status!=='وصول شده'&&c.status!=='پاس شده')return;
  const tx=DB.accTx.find(x=>x.ref===c.id),e=mk((tx&&tx.date)||c.due,'وصول چک '+(c.no||''),{k:'chq',id:c.id});
  if(c.dir==='rec')e.dr('1102',c.amount).cr('1202',c.amount);else e.dr('2102',c.amount).cr('1102',c.amount);
  if(e.rows.length)out.push(e);
 });
 DB.cheques.forEach(c=>{if(c.status!=='برگشتی')return;
  const e=mk(c.bouncedDate||c.due,'برگشت چک '+(c.no||''),{k:'chqb',id:c.id});
  if(c.dir==='rec')e.dr('1201',c.amount,c.person).cr('1202',c.amount);else e.dr('2102',c.amount).cr('2101',c.amount,c.person);
  if(e.rows.length)out.push(e)});
 const op=DB.opening||{},bankOpen=(DB.accounts||[]).reduce((s,a)=>s+(Number(a.open)||0),0);
 const opP=Object.entries(op.persons||{});
 if(op.cash||op.inventory||bankOpen||opP.length){const e=mk(op.date||'0000/00/00','سند افتتاحیه',{k:'open'});
  let net=(op.cash||0)+bankOpen+(op.inventory||0);
  e.dr('1101',op.cash).dr('1102',bankOpen).dr('1301',op.inventory);
  opP.forEach(([pid,v])=>{e.dr('1201',v.rec,pid).cr('2101',v.pay,pid);net+=(v.rec||0)-(v.pay||0)});
  e.cr('3101',net);out.push(e)}
 DB.cheques.forEach(c=>{if(c.inv||c.rid)return;const e=mk(c.issue||c.due,'چک مستقل/افتتاحیه '+(c.no||''),{k:'chq0',id:c.id});
  if(c.dir==='rec')e.dr('1202',c.amount).cr('3101',c.amount);else e.dr('3101',c.amount).cr('2102',c.amount);if(e.rows.length)out.push(e)});
 DB.accTx.forEach(x=>{if(x.ref||/[→←]/.test(x.desc||''))return;
  const e=mk(x.date,'تراکنش دستی بانک'+(x.desc?' — '+x.desc:''),{k:'bank',id:x.id});
  const k=x.kind||'cap',ctr=k==='inc'?'4201':k.startsWith('e:')?k.slice(2):'3101';
  if(x.type==='in')e.dr('1102',x.amount).cr(ctr,x.amount);else e.dr(ctr,x.amount).cr('1102',x.amount);
  if(e.rows.length)out.push(e)});
 (DB.expenses||[]).forEach(x=>{const e=mk(x.date,'هزینه '+(COA_NAME[x.cat]||'')+(x.desc?' — '+x.desc:''),{k:'exp',id:x.id});
  e.dr(x.cat,x.amount);if(x.method==='credit')e.cr('2101',x.amount,x.person);else e.cr(x.method==='cash'?'1101':'1102',x.amount);out.push(e)});
 out.sort((a,b)=>String(a.date).localeCompare(String(b.date)));
 out.forEach(e=>{e.no=++n;delete e.dr;delete e.cr});
 return out;
}
function trialBal(jn){
 const m={};COA.forEach(a=>m[a[0]]={code:a[0],name:a[1],d:0,c:0});
 (jn||jnlBuild()).forEach(e=>e.rows.forEach(r=>{(m[r.a]=m[r.a]||{code:r.a,name:r.a,d:0,c:0});m[r.a].d+=r.d;m[r.a].c+=r.c}));
 return Object.values(m);
}
function accView(tab,code){
 tab=tab||'tb';const jn=jnlBuild(),tb=trialBal(jn);
 const bal=a=>a.d-a.c,get=c=>tb.find(x=>x.code===c)||{d:0,c:0};
 let sd=0,sc=0;tb.forEach(a=>{sd+=a.d;sc+=a.c});
 const tabs='<div class="toolbar">'+[['tb','⚖️ تراز آزمایشی'],['gl','📗 دفتر معین'],['pl','📈 سود و زیان'],['bs','🏦 ترازنامه'],['jn','📘 دفتر روزنامه']].map(x=>'<button class="btn '+(tab===x[0]?'p':'')+'" onclick="accView(\''+x[0]+'\')">'+x[1]+'</button>').join('')+'</div>';
 let body='';
 if(tab==='pl'){body=plHtml(jn)}else if(tab==='bs'){body=bsHtml(jn)}else if(tab==='tb'){
  const sale=DB.persons.reduce((s,p)=>s+personBalance(p.id).saleDebt,0),buy=DB.persons.reduce((s,p)=>s+personBalance(p.id).buyDebt,0);
  const chk=(n,a,b)=>'<div>'+(a===b?'✅':'❌')+' '+n+': '+fm(a)+' / '+fm(b)+'</div>';
  body='<table data-rn="0"><thead><tr><th>کد</th><th>حساب</th><th>گردش بدهکار</th><th>گردش بستانکار</th><th>مانده</th></tr></thead><tbody>'+
   tb.filter(a=>a.d||a.c).map(a=>'<tr><td>'+fa(a.code)+'</td><td><a href="#" onclick="accView(\'gl\',\''+a.code+'\');return false">'+esc(a.name)+'</a></td><td>'+fm(a.d)+'</td><td>'+fm(a.c)+'</td><td>'+fm(Math.abs(bal(a)))+(bal(a)>0?' بد':bal(a)<0?' بس':'')+'</td></tr>').join('')+
   '<tr style="font-weight:700"><td></td><td>جمع</td><td>'+fm(sd)+'</td><td>'+fm(sc)+'</td><td>'+(sd===sc?'✅ متوازن':'❌ نامتوازن')+'</td></tr></tbody></table>'+
   '<h4 style="margin-top:12px">کنترل با زیرحساب اشخاص (حساب / اشخاص)</h4>'+chk('دریافتنی‌ها',Math.round(bal(get('1201'))),Math.round(sale))+chk('پرداختنی‌ها',Math.round(-bal(get('2101'))),Math.round(buy))+chk('بانک (دفتر / حساب‌های بانکی)',Math.round(bal(get('1102'))),Math.round(DB.accounts.reduce((s,a)=>s+accBal(a),0)))+
   '<small style="color:var(--mut)">فعلاً فقط فاکتور، رسید و وصول چک سند می‌شود؛ تراکنش‌های دستی بانک و افتتاحیه هنوز سند نمی‌شوند.</small>';
 }else if(tab==='gl'){
  code=code||'1101';let run=0;
  const rows=[];jn.forEach(e=>e.rows.filter(r=>r.a===code).forEach(r=>{run+=r.d-r.c;rows.push('<tr><td>'+fa(e.no)+'</td><td>'+jShort(e.date)+'</td><td>'+esc(e.desc)+(r.p?' — '+esc(PN(r.p)):'')+'</td><td>'+fm(r.d)+'</td><td>'+fm(r.c)+'</td><td>'+fm(Math.abs(run))+(run>0?' بد':run<0?' بس':'')+'</td></tr>')}));
  body='<div class="toolbar"><select onchange="accView(\'gl\',this.value)">'+COA.map(a=>'<option value="'+a[0]+'" '+(a[0]===code?'selected':'')+'>'+fa(a[0])+' — '+a[1]+'</option>').join('')+'</select></div>'+
   '<table data-rn="0"><thead><tr><th>سند</th><th>تاریخ</th><th>شرح</th><th>بدهکار</th><th>بستانکار</th><th>مانده</th></tr></thead><tbody>'+(rows.join('')||'<tr><td colspan="6"><div class="empty">گردشی نیست</div></td></tr>')+'</tbody></table>';
 }else{
  body='<table data-rn="0"><thead><tr><th>سند</th><th>تاریخ</th><th>شرح / حساب</th><th>بدهکار</th><th>بستانکار</th></tr></thead><tbody>'+
   jn.slice(-100).reverse().map(e=>'<tr style="background:var(--panel-soft)"><td>'+fa(e.no)+'</td><td>'+jShort(e.date)+'</td><td colspan="3"><b>'+esc(e.desc)+'</b></td></tr>'+e.rows.map(r=>'<tr><td></td><td></td><td>'+(r.c?'&nbsp;&nbsp;&nbsp;&nbsp;':'')+esc(COA_NAME[r.a]||r.a)+'</td><td>'+(r.d?fm(r.d):'')+'</td><td>'+(r.c?fm(r.c):'')+'</td></tr>').join('')).join('')+'</tbody></table>';
 }
 openM(mHead('📘 حسابداری — اسناد خودکار')+'<div class="mbody">'+tabs+body+'</div><div class="mfoot"><button class="btn" onclick="closeM()">بستن</button></div>');
}

