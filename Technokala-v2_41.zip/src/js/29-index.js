/* ===== نمایه‌های سریع (کش‌شده) برای حجم بالای داده =====
   جست‌وجوی خطی در هر ردیف (مثل DB.persons.find) با ده‌ها هزار رکورد برنامه را کند می‌کند.
   هر نمایه جداگانه و فقط به آرایه‌های خودش وابسته است (هویت + طول آرایه)؛ مثلاً افزودن رسید، نقشه‌ی اشخاص را باطل نمی‌کند.
   ixInvalidate() هنگام ذخیره و ورود به هر صفحه، همه را برای ساخت دوباره‌ی تنبل علامت می‌زند. */
const IXC={ep:0,parts:{}},IX_EMPTY=[],IX={};
function ixInvalidate(){IXC.ep++}
const ixA=k=>DB[k]||IX_EMPTY;
function ixPart(key,arrs,build){
 const P=IXC.parts[key];
 if(P&&P.ep===IXC.ep){let ok=true;for(let i=0;i<arrs.length;i++){if(P.a[i]!==arrs[i]||P.n[i]!==arrs[i].length){ok=false;break}}if(ok)return P.v}
 const v=build();IXC.parts[key]={ep:IXC.ep,a:arrs.slice(),n:arrs.map(a=>a.length),v};return v;
}
const ixIdMap=arr=>{const m=new Map();for(let i=0;i<arr.length;i++){const r=arr[i];if(r&&!m.has(r.id))m.set(r.id,r)}return m};
const ixGroup=(arr,key)=>{const m=new Map();for(let i=0;i<arr.length;i++){const r=arr[i],k=r[key];let l=m.get(k);if(!l){l=[];m.set(k,l)}l.push(r)}return m};
const ixDef=(name,arrKey,fn)=>Object.defineProperty(IX,name,{get(){const a=ixA(arrKey);return ixPart(name,[a],()=>fn(a))}});
ixDef('person','persons',ixIdMap);ixDef('product','products',ixIdMap);ixDef('invoice','invoices',ixIdMap);ixDef('color','colors',ixIdMap);ixDef('pgroup','personGroups',ixIdMap);ixDef('inst','installments',ixIdMap);
ixDef('invByPerson','invoices',a=>ixGroup(a,'person'));ixDef('instByPerson','installments',a=>ixGroup(a,'person'));ixDef('chqByPerson','cheques',a=>ixGroup(a,'person'));
ixDef('recByPerson','receipts',a=>ixGroup(a,'person'));ixDef('serByPid','serials',a=>ixGroup(a,'pid'));ixDef('expByPerson','expenses',a=>ixGroup(a,'person'));ixDef('txByAcc','accTx',a=>ixGroup(a,'acc'));
function ix(){return IX}
/* موجودی: تجمیع یک‌باره‌ی خطوط فاکتور */
function ixStock(){
 return ixPart('stock',[ixA('invoices'),ixA('serials')],()=>{
  const sign={buy:1,buyret:-1,sale:-1,saleret:1},all=new Map(),nosid=new Map();
  for(const inv of ixA('invoices')){const sg=sign[inv.type];if(!sg)continue;
   for(const l of inv.lines){const n=sg*Number(l.qty||0);all.set(l.pid,(all.get(l.pid)||0)+n);if(!l.sid)nosid.set(l.pid,(nosid.get(l.pid)||0)+n)}}
  const ser=new Map();for(const s of ixA('serials'))if(s.status==='stock')ser.set(s.pid,(ser.get(s.pid)||0)+1);
  return{all,nosid,ser};
 });
}
/* فاکتورهای غیر پیش‌فاکتور به ترتیب تاریخ/شماره + خطوط هر کالا (برای میانگین موزون) */
function ixSorted(){
 return ixPart('sorted',[ixA('invoices')],()=>ixA('invoices').filter(i=>i.type!=='proforma').slice().sort((a,b)=>String(a.date).localeCompare(String(b.date))||Number(a.no)-Number(b.no)));
}
function ixLinesByPid(){
 return ixPart('linesByPid',[ixA('invoices')],()=>{
  const m=new Map();for(const inv of ixSorted())for(const l of inv.lines){let q=m.get(l.pid);if(!q){q=[];m.set(l.pid,q)}q.push([inv,l])}
  return m;
 });
}
