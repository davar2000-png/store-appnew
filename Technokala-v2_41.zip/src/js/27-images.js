/* ===== تصاویر مدارک: بارگذاری تنبل =====
   تصاویر (کارت ملی، قرارداد، عکس) در store «img» می‌مانند و در دیتابیس فقط ارجاع (img:…) است؛
   هنگام نمایش، همان تصویر خوانده می‌شود. به این ترتیب حافظه و سرعت ذخیره با زیاد شدن مدارک بدتر نمی‌شود. */
const IMG_REF=/^img:[0-9a-z]+-\d+$/,IMGC=new Map(),IMGC_MAX=40,GIF1='data:image/gif;base64,R0lGODlhAQABAAAAACwAAAAAAQABAAA=';
function isImgRef(v){return typeof v==='string'&&v.length<40&&IMG_REF.test(v)}
function imgCachePut(ref,url){IMGC.delete(ref);IMGC.set(ref,url);if(IMGC.size>IMGC_MAX)IMGC.delete(IMGC.keys().next().value)}
async function imgLoad(ref){
 if(!isImgRef(ref))return ref||null;
 const c=IMGC.get(ref);if(c){IMGC.delete(ref);IMGC.set(ref,c);return c}
 const x=await idb.get('img',ref);if(x)imgCachePut(ref,x);return x||null;
}
/* صفت‌های src برای <img>: داده‌ی مستقیم، یا جای‌نگهدار + data-ref که پس از رندر پر می‌شود */
function imgAttrs(v){
 if(!v)return 'src=""';
 if(!isImgRef(v))return 'src="'+esc(v)+'"';
 const c=IMGC.get(v);return c?'src="'+c+'" data-ref="'+v+'" data-ok="1"':'src="'+GIF1+'" data-ref="'+v+'"';
}
/* پیوند دانلود مدرک */
function docLinkHtml(d,label){
 const t=esc(label||d.name);
 if(!isImgRef(d.data))return '<a href="'+esc(d.data||'#')+'" download="'+esc(d.name)+'">'+t+'</a>';
 return '<a href="#" data-ref="'+d.data+'" data-name="'+esc(d.name)+'" onclick="docDl(this);return false">'+t+'</a>';
}
async function docDl(a){
 const u=await imgLoad(a.dataset.ref);if(!u){toast('⚠️ فایل مدرک پیدا نشد (بکاپ بدون تصاویر؟)',false);return}
 const x=document.createElement('a');x.href=u;x.download=a.dataset.name||'مدرک';document.body.appendChild(x);x.click();x.remove();
}
/* پر کردن <img data-ref> های صفحه (پس از هر تغییر DOM، یک‌جا و با تأخیر کم) */
let _imgT=null;
function imgHydrateDom(root){
 const list=(root||document).querySelectorAll('img[data-ref]');
 list.forEach(im=>{
  if(im.dataset.ok==='1')return;const ref=im.dataset.ref;
  const c=IMGC.get(ref);if(c){im.src=c;im.dataset.ok='1';return}
  if(im.dataset.ld==='1')return;im.dataset.ld='1';
  imgLoad(ref).then(u=>{if(u){im.src=u;im.dataset.ok='1'}else im.dataset.ld='0'});
 });
}
function imgWatch(){
 try{new MutationObserver(()=>{try{rnApply()}catch(e){console.error(e)}clearTimeout(_imgT);_imgT=setTimeout(()=>imgHydrateDom(),30)}).observe(document.body,{childList:true,subtree:true})}catch(e){}
}
/* تبدیل data URL های بزرگ شخص/ضامن به ارجاع (پس از ذخیره در store «img») تا حافظه آزاد بماند */
async function slimImgs(){
 let ok=true;
 const slim=async(o,k)=>{
  const v=o[k];if(typeof v!=='string'||v.length<=3000||!v.startsWith('data:'))return;
  let key=IMG_KEY.get(v);if(!key){key=imgKey(v);IMG_KEY.set(v,key)}
  if(!IMG_SAVED.has(key)){if(await idb.put('img',key,v))IMG_SAVED.add(key);else{ok=false;return}}
  imgCachePut(key,v);o[k]=key;IMG_KEY.delete(v);
 };
 if(DB.settings&&DB.settings.shopLogo)await slim(DB.settings,'shopLogo');
 for(const p of DB.persons){
  if(p.photo)await slim(p,'photo');
  if(p.docs)for(const d of p.docs)await slim(d,'data');
  const g=p.guarantor;if(g){if(g.photo)await slim(g,'photo');if(g.docs)for(const d of g.docs)await slim(d,'data')}
 }
 return ok;
}
/* ریز‌تصویر (۷۲ پیکسل) برای آواتار لیست اشخاص: بدون خواندن تصویر کامل */
function makeThumb(url,cb){
 if(!/^data:image\//.test(url||'')){cb('');return}
 try{const im=new Image();im.onload=()=>{try{const s=72/Math.min(im.width,im.height),w=Math.max(1,Math.round(im.width*s)),h=Math.max(1,Math.round(im.height*s)),c=document.createElement('canvas');c.width=72;c.height=72;
  const g=c.getContext('2d');g.fillStyle='#fff';g.fillRect(0,0,72,72);g.drawImage(im,(72-w)/2,(72-h)/2,w,h);cb(c.toDataURL('image/jpeg',0.6))}catch(e){cb('')}};im.onerror=()=>cb('');im.src=url}catch(e){cb('')}
}
/* ---------- بکاپ کامل با تصاویر (.tkb) و بازیابی ---------- */
const TKB_MAGIC='TKB1\n';
async function backupFullBlob(onProgress){
 await saveDB(true);
 const js=JSON.stringify(DB),refs=new Set(js.match(/img:[0-9a-z]+-\d+/g)||[]),list=[...refs];
 const header=JSON.stringify({v:1,dbLen:new Blob([js]).size,imgs:list.map(r=>[r,Number(r.split('-').pop())])});
 let blob=new Blob([TKB_MAGIC,String(new Blob([header]).size)+'\n',header,js]);
 let miss=0;
 for(let i=0;i<list.length;i+=40){
  const part=[];
  for(const r of list.slice(i,i+40)){const x=await idb.get('img',r);if(typeof x==='string'&&x.length===Number(r.split('-').pop()))part.push(x);else{part.push(' '.repeat(Number(r.split('-').pop())));miss++}}
  blob=new Blob([blob,...part]);
  if(onProgress)onProgress(Math.min(list.length,i+40),list.length);
 }
 return{blob,count:list.length,miss};
}
async function backupFullDownload(){
 toast('⏳ ساخت بکاپ کامل با تصاویر…');
 try{
  const r=await backupFullBlob((a,b)=>{const el=$('stLast');if(el)el.textContent='تصاویر '+fa(a)+'/'+fa(b)});
  const a=document.createElement('a');a.href=URL.createObjectURL(r.blob);
  a.download='تکنوکالا-بکاپ-کامل-'+dateToJ(new Date()).replace(/\//g,'-')+'.tkb';a.click();setTimeout(()=>URL.revokeObjectURL(a.href),4000);
  toast(r.miss?'⚠️ بکاپ کامل ساخته شد؛ '+fa(r.miss)+' تصویر در حافظه پیدا نشد':'✅ بکاپ کامل ('+fa(r.count)+' تصویر) ساخته شد',!r.miss);
 }catch(e){console.error(e);toast('❌ ساخت بکاپ کامل ناموفق بود: '+(e&&e.message||e),false)}
}
/* خواندن فایل .tkb: تصاویر وارد store می‌شوند و داده‌ها برگردانده می‌شود */
async function tkbRead(file){
 const head=await file.slice(0,64).text();
 if(!head.startsWith(TKB_MAGIC))throw new Error('فرمت نامعتبر');
 const nl=head.indexOf('\n',TKB_MAGIC.length),hl=Number(head.slice(TKB_MAGIC.length,nl));
 let off=nl+1;
 const header=JSON.parse(await file.slice(off,off+hl).text());off+=hl;
 const d=JSON.parse(await file.slice(off,off+header.dbLen).text());off+=header.dbLen;
 let n=0;
 for(const [ref,len] of header.imgs){const s=await file.slice(off,off+len).text();off+=len;if(s.startsWith('data:')){await idb.put('img',ref,s);IMG_SAVED.add(ref);n++}}
 return{db:d,images:n};
}
