/* ---------- اکسل ---------- */
function xlOut(rows,name){
 if(!rows||!rows.length){toast('⚠️ داده‌ای برای خروجی نیست',false);return}
 try{
  const ws=XLSX.utils.json_to_sheet(rows),wb=XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb,ws,'Data');XLSX.writeFile(wb,name+'.xlsx');toast('📥 '+name+'.xlsx دانلود شد');
 }catch(e){toast('❌ خطا در تولید اکسل',false)}
}
function xlCell(row,...names){
 const entries=Object.entries(row).map(([key,value])=>[key.replace(/[\u200c\u200f\u202a-\u202e]/g,'').replace(/\s+/g,' ').trim(),value]);
 for(const name of names){const key=name.replace(/\s+/g,' ').trim();const found=entries.find(([entry])=>entry===key);if(found)return found[1]}
 return '';
}
function samePersonName(a,b){return String(a||'').replace(/\s+/g,' ').trim()===String(b||'').replace(/\s+/g,' ').trim()}
function xlIn(input,type,grp){
 const f=input.files[0];if(!f)return;
 const r=new FileReader();
 r.onload=e=>{
  try{
   const wb=XLSX.read(new Uint8Array(e.target.result),{type:'array'});
   const rows=XLSX.utils.sheet_to_json(wb.Sheets[wb.SheetNames[0]],{defval:''});
   let n=0,skip=0,newP=0;const planOf={},newInst=[],st={n:0,upd:0,skip:0,newG:0};const _nm=s=>String(s||'').replace(/\s+/g,' ').trim(),pIdx=new Map();DB.persons.forEach(p=>{const k=_nm(p.name);if(!pIdx.has(k))pIdx.set(k,p)});if(type==='persons')ensurePersonGroups();
   rows.forEach(rw=>{
    if(type==='persons'){
     pgImportRow(rw,grp,st);
    }else if(type==='products'){
     const name=rw['نام کالا']||rw['کالا'];if(!name){skip++;return}
     const colNames=String(rw['رنگ‌ها']||'').split(/[,،]/).map(x=>x.trim()).filter(Boolean);
     const cols=colNames.map(cn=>{const c=DB.colors.find(x=>x.name===cn||x.enName===cn);return c?c.id:null}).filter(Boolean);
    DB.products.push({id:uid(),code:'P-'+(++DB.counters.product),name:String(name),brand:rw['برند']||'',group:DB.productGroups[0]?DB.productGroups[0].id:'',track:String(rw['نوع ردیابی']||'سریال‌دار').includes('تعد')?'qty':'serial',minStock:pd(rw['حداقل موجودی']),reorder:pd(rw['نقطه سفارش']),lastCost:pd(rw['قیمت خرید']),sellPrice:pd(rw['قیمت فروش']),colors:cols,notes:'',active:true});n++;
    }else if(type==='serials'){
     const code=String(faDig(rw['کد کالا']||''));const p=DB.products.find(x=>x.code===code||x.name===rw['نام کالا']);
     const sn=String(faDig(rw['سریال']||'')).trim();
     if(!p||p.track!=='serial'||!sn){skip++;return}
    if(DB.serials.some(s=>s.sn===sn)||DB.serials.some(s=>s.pid===p.id)){skip++;return}
     const col=DB.colors.find(c=>c.name===rw['رنگ']||c.enName===rw['رنگ']);
     DB.serials.push({id:uid(),pid:p.id,sn,color:col?col.id:'',cost:pd(rw['قیمت خرید'])||p.lastCost,price:pd(rw['قیمت فروش'])||p.sellPrice,status:'stock',buyInv:'',saleInv:'',date:jToday()});n++;
    }else if(type==='cheques'){
      const amt=pd(xlCell(rw,'مبلغ','مبلغ چک'));if(!amt){skip++;return}
      const personName=xlCell(rw,'طرف حساب','نام طرف حساب','شخص');
      const per=pIdx.get(_nm(personName));
      const dir=String(xlCell(rw,'نوع','جهت')||'دریافتی').includes('پرد')?'paid':'rec';
      const due=jNorm(xlCell(rw,'سررسید','سر رسید','تاریخ سررسید'));if(!due){skip++;return}
      DB.cheques.push({id:uid(),no:String(faDig(xlCell(rw,'شماره چک','شماره'))),dir,person:per?per.id:'',amount:amt,due,issue:jNorm(xlCell(rw,'تاریخ ثبت','تاریخ'))||jToday(),bank:xlCell(rw,'بانک')||'',status:'جاری',inv:'',desc:'ورودی اکسل'});n++;
    }else if(type==='installments'){
     const pn=String(xlCell(rw,'طرف حساب','نام طرف حساب','شخص','نام')).replace(/\s+/g,' ').trim();
     const amt=pd(xlCell(rw,'مبلغ قسط','مبلغ'));
     const due=jNorm(xlCell(rw,'سررسید','سر رسید','تاریخ سررسید','تاریخ سر رسید'));
     if(!pn||!amt||!due){skip++;return}
     let per=pIdx.get(_nm(pn));
     if(!per){const pg=pgroupForInst(grp)||DB.personGroups[0];if(!pg){skip++;return}per={id:uid(),code:++DB.counters.person,name:pn,group:pg.id,groups:[pg.id],phone:'',phone2:'',nationalId:'',job:'',empNo:'',card:'',addr:'',photo:'',docs:[],guarantor:null,notes:'ساخته‌شده هنگام ورود اقساط از اکسل',created:jToday()};DB.persons.push(per);pIdx.set(_nm(pn),per);newP++}
     if(!planOf[per.id])planOf[per.id]=uid();
     const sn=String(faDig(xlCell(rw,'سریال','شماره چک'))).trim(),note=String(xlCell(rw,'توضیحات')||'').trim();
     const it={id:uid(),planId:planOf[per.id],inv:'',person:per.id,no:pd(xlCell(rw,'شماره قسط'))||0,amount:amt,due,paid:false,paidDate:'',desc:(note||'ورودی اکسل')+(sn?' — سریال '+sn:''),grp:grp||'ig-normal'};
     DB.installments.push(it);newInst.push(it);n++;
    }
   });
   if(type==='persons'){n=st.n;skip+=st.skip}
   if(type==='installments'){const byPlan={};newInst.filter(i=>!i.no).forEach(i=>(byPlan[i.planId]=byPlan[i.planId]||[]).push(i));Object.values(byPlan).forEach(l=>l.sort((x,y)=>x.due<y.due?-1:x.due>y.due?1:0).forEach((i,k)=>i.no=k+1))}
   logAct('ورود '+n+' رکورد از اکسل ('+type+')'+(newP?' — '+newP+' شخص جدید':''));saveDB();closeM();if(type==='installments'&&grp)Fi.grp=grp;nav(curView);
   toast('✅ '+fa(n)+' رکورد وارد شد'+(type==='installments'&&grp?' در «'+instGName(grp)+'»':'')+(type==='persons'&&grp?' در گروه «'+esc((DB.personGroups.find(g=>g.id===grp)||{}).name||'')+'»':'')+(type==='persons'&&st.upd?' — '+fa(st.upd)+' شخص موجود کامل/عضو گروه شد':'')+(type==='persons'&&st.newG?' — '+fa(st.newG)+' گروه جدید':'')+(newP?' — '+fa(newP)+' شخص جدید ساخته شد':'')+(skip?' — '+fa(skip)+' ردیف نامعتبر/تکراری رد شد':''));
  }catch(err){console.error(err);toast('❌ خطا در خواندن فایل اکسل: '+(err&&err.message||err),false)}
  input.value='';
 };
 r.readAsArrayBuffer(f);
}
function xlTemplate(){
 const wb=XLSX.utils.book_new();
 XLSX.utils.book_append_sheet(wb,XLSX.utils.json_to_sheet([{'نام':'','موبایل':'','تلفن دوم':'','کد ملی':'','شغل':'','شماره کارمندی':'','شماره کارت':'','آدرس':'','گروه':'','توضیحات':''}]),'اشخاص');
 XLSX.utils.book_append_sheet(wb,XLSX.utils.json_to_sheet([{'نام کالا':'','برند':'','نوع ردیابی':'سریال‌دار','رنگ‌ها':'black, white','حداقل موجودی':'','نقطه سفارش':'','قیمت خرید':'','قیمت فروش':''}]),'کالا');
 XLSX.utils.book_append_sheet(wb,XLSX.utils.json_to_sheet([{'کد کالا':'P-1001','سریال':'','رنگ':'black','قیمت خرید':'','قیمت فروش':''}]),'سریال');
 XLSX.utils.book_append_sheet(wb,XLSX.utils.json_to_sheet([{'نوع':'دریافتی','شماره چک':'','طرف حساب':'','مبلغ':'','سررسید':'۱۴۰۳/۰۶/۰۱','بانک':''}]),'چک');
 XLSX.utils.book_append_sheet(wb,XLSX.utils.json_to_sheet([{'طرف حساب':'','شماره قسط':'','مبلغ قسط':'','سررسید':'۱۴۰۳/۰۶/۰۱'}]),'اقساط');
 XLSX.writeFile(wb,'قالب-ورود-اطلاعات-تکنوکالا.xlsx');toast('📥 قالب اکسل دانلود شد');
}
function xlClaimsTemplate(){
 const wb=XLSX.utils.book_new();
 XLSX.utils.book_append_sheet(wb,XLSX.utils.json_to_sheet([{'نوع':'دریافتی','شماره چک':'','طرف حساب':'','مبلغ':'','تاریخ ثبت':jToday(),'سررسید':jAddD(jToday(),30),'بانک':''}]),'چک‌ها');
 XLSX.utils.book_append_sheet(wb,XLSX.utils.json_to_sheet([{'طرف حساب':'','شماره قسط':'','مبلغ قسط':'','سررسید':jAddM(jToday(),1)}]),'اقساط');
 XLSX.writeFile(wb,'قالب-مطالبات-تکنوکالا.xlsx');toast('📥 قالب مطالبات دانلود شد');
}

