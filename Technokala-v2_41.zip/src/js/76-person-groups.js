/* ===== گروه‌بندی اشخاص و ورود اکسل اشخاص بر اساس گروه ===== */
const PG_STD=[
 ['مشتریان عادی',/^مشتری(ان)? عادی$/],
 ['پرسنل فراجا',/فراجا/],
 ['مستمری بگیران',/مستمری/],
 ['کارمندان دانشگاه آزاد',/دانشگاه\s*آزاد/],
 ['کارمندان دانشگاه محقق اردبیلی',/محقق/],
 ['کارمندان صدا و سیما',/صدا\s*و?\s*سیما|صداوسیما/]
];
/* لیست اقساط ← گروه شخص (برای اشخاصی که هنگام ورود اقساط ساخته می‌شوند) */
const IG_TO_PG={'ig-normal':0,'ig-faraja':1,'ig-refah':2,'ig-azad':3,'ig-uma':4,'ig-seda':5};
function pgNorm(s){return String(s==null?'':s).replace(/ي/g,'ی').replace(/ك/g,'ک').replace(/[\u200c\s]+/g,' ').trim()}
function pgKey(name){const n=pgNorm(name);return PG_STD.findIndex(x=>x[0]===n||x[1].test(n))}
function pgFind(name){
 const n=pgNorm(name),k=pgKey(n);
 return DB.personGroups.find(g=>pgNorm(g.name)===n)||(k>=0?DB.personGroups.find(g=>pgKey(g.name)===k):null)||null;
}
function ensurePersonGroups(){
 let added=0;
 PG_STD.forEach(x=>{if(!pgFind(x[0])){DB.personGroups.push({id:uid(),name:x[0],supplier:false});added++}});
 return added;
}
function pgroupForInst(igid){
 const k=IG_TO_PG[igid];if(k===undefined)return null;
 ensurePersonGroups();return pgFind(PG_STD[k][0]);
}
/* یک ردیف اکسل اشخاص: شخص جدید می‌سازد یا شخص موجود (کد ملی/نام یکسان) را کامل و عضو گروه می‌کند */
function pgImportRow(rw,grpId,st){
 const name=String(xlCell(rw,'نام','نام و نام خانوادگی','نام کامل')||'').replace(/\s+/g,' ').trim();
 if(!name){st.skip++;return}
 let gs=[];
 if(grpId){const g=DB.personGroups.find(x=>x.id===grpId);if(g)gs=[g]}
 else{
  String(xlCell(rw,'گروه')||'').split(/[،,;|\/]/).map(pgNorm).filter(Boolean).forEach(n=>{
   let g=pgFind(n);if(!g){g={id:uid(),name:n,supplier:isSupplierGroup({name:n})};DB.personGroups.push(g);st.newG++}
   if(!gs.includes(g))gs.push(g);
  });
 }
 if(!gs.length)gs=[pgFind('مشتریان عادی')||DB.personGroups[0]];
 if(!gs[0]){st.skip++;return}
 const f=(...k)=>String(faDig(String(xlCell(rw,...k)==null?'':xlCell(rw,...k)))).trim();
 const nid=rfNatId(f('کد ملی','کدملی','شماره ملی')),rec={
  phone:f('موبایل','شماره موبایل','شماره تماس','تلفن'),phone2:f('تلفن دوم'),nationalId:nid||f('کد ملی','کدملی','شماره ملی'),
  job:String(xlCell(rw,'شغل')||'').trim(),empNo:f('شماره کارمندی','شماره پرسنلی'),card:f('شماره کارت'),addr:String(xlCell(rw,'آدرس')||'').trim(),notes:String(xlCell(rw,'توضیحات')||'').trim()};
 const nn=rfNormName(name);
 if(!st.idx){st.idx={nid:new Map(),name:new Map()};DB.persons.forEach(p=>{const a=rfNatId(p.nationalId),b=rfNormName(p.name);if(a&&!st.idx.nid.has(a))st.idx.nid.set(a,p);if(b&&!st.idx.name.has(b))st.idx.name.set(b,p)})}
 const ex=(nid&&st.idx.nid.get(nid))||st.idx.name.get(nn);
 if(ex){
  const cur=(ex.groups&&ex.groups.length?ex.groups:[ex.group]).filter(Boolean),def=pgFind('مشتریان عادی'),onlyDef=def&&cur.every(id=>id===def.id);
  const ids=gs.map(g=>g.id);
  ex.groups=onlyDef&&!ids.includes(def.id)?ids:[...new Set([...cur,...ids])];
  if(onlyDef&&!ids.includes(def.id))ex.group=ids[0];
  Object.keys(rec).forEach(k=>{if(rec[k]&&!ex[k])ex[k]=rec[k]});
  st.upd++;return;
 }
 const np=Object.assign({id:uid(),code:++DB.counters.person,name,group:gs[0].id,groups:gs.map(g=>g.id),phone:'',phone2:'',nationalId:'',job:'',empNo:'',card:'',addr:'',photo:'',docs:[],guarantor:null,notes:'',created:jToday()},rec);
 DB.persons.push(np);if(nid)st.idx.nid.set(nid,np);if(nn)st.idx.name.set(nn,np);
 st.n++;
}
function pgImportPanel(){
 const gs=DB.personGroups,cnt={};DB.persons.forEach(p=>(p.groups&&p.groups.length?p.groups:[p.group]).forEach(id=>cnt[id]=(cnt[id]||0)+1));
 return '<details class="card" style="margin-bottom:10px"><summary style="cursor:pointer;font-weight:800">📤 ورود اکسل اشخاص بر اساس گروه</summary><div style="margin-top:8px">'+
  '<div style="font-size:12px;color:var(--mut);margin-bottom:6px">فایل هر گروه را با دکمه‌ی همان گروه وارد کنید؛ همه‌ی ردیف‌ها عضو آن گروه می‌شوند. ستون‌ها: «نام» (الزامی)، موبایل، کد ملی، تلفن دوم، شغل، شماره کارمندی، شماره کارت، آدرس، توضیحات. شخصِ تکراری (کد ملی یا نام یکسان) دوباره ساخته نمی‌شود؛ فقط کامل و عضو این گروه می‌شود.</div>'+
  '<div class="toolbar" style="flex-wrap:wrap;gap:6px">'+gs.map(g=>'<label class="btn sm" style="cursor:pointer">📤 '+esc(g.name)+' <small>('+fa(cnt[g.id]||0)+')</small><input type="file" accept=".xlsx,.xls" style="display:none" onchange="xlIn(this,\'persons\',\''+g.id+'\')"></label>').join('')+'</div>'+
  '<div class="toolbar" style="margin-top:8px"><button class="btn sm g" onclick="xlPersonsTemplate()">📥 دانلود قالب اکسل اشخاص</button><button class="btn sm" onclick="ensurePersonGroups();saveDB();vPersons();toast(\'✅ گروه‌های استاندارد بررسی شد\')">➕ افزودن گروه‌های استاندارد</button></div></div></details>';
}
function xlPersonsTemplate(){
 const wb=XLSX.utils.book_new();
 XLSX.utils.book_append_sheet(wb,XLSX.utils.json_to_sheet([{'نام':'','موبایل':'','کد ملی':'','تلفن دوم':'','شغل':'','شماره کارمندی':'','شماره کارت':'','آدرس':'','توضیحات':'','گروه':''}]),'اشخاص');
 XLSX.utils.book_append_sheet(wb,XLSX.utils.json_to_sheet(DB.personGroups.map(g=>({'نام گروه‌ها (برای ستون گروه)':g.name}))),'گروه‌ها');
 XLSX.writeFile(wb,'قالب-اشخاص-تکنوکالا.xlsx');toast('📥 قالب اشخاص دانلود شد');
}
