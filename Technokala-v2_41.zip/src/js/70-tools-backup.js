/* ================================================================
   ===== ابزار + قالب‌های پیامک + مرکز پیامک + پشتیبان‌گیری =========
   ================================================================ */
function vTools(){
 $('content').innerHTML=`
 <div class="pgtitle"><h1>🛠️ ابزار، پشتیبان‌گیری و تنظیمات</h1></div>
 <div class="notice">💾 این برنامه <b>بدون سرور</b> کار می‌کند. داده‌ها در حافظه مرورگر (IndexedDB) ذخیره و هر <b>۵ دقیقه</b> به‌صورت خودکار بکاپ گرفته می‌شود. هنگام خروج یا بستن غیرعادی پنجره نیز اسنپ‌شات نجات ثبت می‌شود.</div>
 <div class="card"><h3>⌨️ میانبرهای صفحه‌کلید</h3>
  <div class="kv">
   <span class="k"><b>Ctrl+K</b> جستجوی سراسری</span>
   <span class="k"><b>F2</b> فاکتور فروش</span>
   <span class="k"><b>F9</b> فروش سریع (POS)</span>
   <span class="k"><b>F3</b> اشخاص</span>
   <span class="k"><b>F4</b> معرفی کالا</span>
   <span class="k"><b>F5</b> داشبورد</span>
   <span class="k"><b>F6</b> فاکتورها</span>
   <span class="k"><b>F7</b> چک‌ها</span>
   <span class="k"><b>F8</b> گزارش‌ها</span>
   <span class="k"><b>F12</b> ابزار</span>
   <span class="k"><b>Esc</b> بستن مودال / جستجو</span>
  </div>
 </div>
 <div class="card"><h3>✉️ مرکز پیامک و اطلاع‌رسانی گروهی</h3>
  <div class="toolbar">
   <button class="btn" onclick="smsGroupDebt()">👥 اطلاع بدهی به همه بدهکاران</button>
   <button class="btn o" onclick="smsGroupInst()">📅 یادآوری اقساط معوق و نزدیک سررسید</button>
   <button class="btn" onclick="smsGroupChq()">🏦 یادآوری چک‌های نزدیک سررسید</button>
   <button class="btn p" onclick="smsGroupPay()">🧾 اطلاع‌رسانی آخرین پرداخت‌ها (۷ روز اخیر)</button>
  </div>
  <div style="font-size:11px;color:#7a8a99">پیام‌ها بر اساس قالب‌های زیر ساخته می‌شوند. متغیرها: {shop} {name} {amount} {remain} {date} {due} {no} {late} {count}</div>
 </div>
 <div class="grid2">
 <div class="card"><h3>🔔 پیامک خودکار</h3>
   <label class="pw-inl" style="display:flex;gap:6px;align-items:flex-start;margin-bottom:8px;white-space:normal"><input type="checkbox" id="smAutoInv" ${DB.settings.smsAutoInv!==false?'checked':''}><span>با ثبت <b>فاکتور فروش</b>، پیامک فاکتور برای خریدار ارسال شود</span></label>
   <label class="pw-inl" style="display:flex;gap:6px;align-items:flex-start;margin-bottom:8px;white-space:normal"><input type="checkbox" id="smAutoRem" ${DB.settings.smsAutoRem!==false?'checked':''}><span><b>یک روز قبل از سررسید</b> چک‌های دریافتی و اقساط، پیامک یادآوری برای مشتری ارسال شود</span></label>
   <label class="pw-inl" style="display:flex;gap:6px;align-items:flex-start;margin-bottom:8px;white-space:normal"><input type="checkbox" id="smEntry" ${DB.settings.smsEntryAlert!==false?'checked':''}><span>هنگام <b>ورود به برنامه</b>، اقساط «مشتریان عادی» که <b>امروز سررسید است، ۳ روز یا یک هفته از سررسیدشان گذشته</b> اعلام شود و با یک کلیک پیامک گروهی برایشان ارسال شود (در این حالت ارسال خودکار بی‌صدا برای این گروه انجام نمی‌شود)</span></label>
   <label class="pw-inl" style="display:flex;gap:6px;align-items:flex-start;margin-bottom:8px;white-space:normal"><input type="checkbox" id="smAutoLate"${DB.settings.smsAutoLate!==false?'checked':''}><span>اگر <b>یک هفته از سررسید قسط گذشته</b> و پرداختی آن ثبت نشده باشد، پیامک «موعد پرداخت بدهی شما به فروشگاه» برای مشتری ارسال شود</span></label>
   <label class="pw-inl" style="display:flex;gap:6px;align-items:flex-start;margin-bottom:8px;white-space:normal"><input type="checkbox" id="smGuarRem" ${DB.settings.smsGuarRem!==false?'checked':''}><span>یادآوری چک و قسط برای <b>ضامن مشتری</b> هم ارسال شود (در صورت ثبت نام و موبایل ضامن)</span></label>
   <div style="font-size:11px;color:#7a8a99;line-height:1.9;margin-bottom:8px">یادآوری‌ها فقط وقتی ارسال می‌شوند که برنامه باز باشد (هنگام باز شدن برنامه و هر ۳۰ دقیقه بررسی می‌شود). برای هر چک یا قسط فقط یک بار ارسال می‌شود. متن پیام‌ها از قالب «چک»، «اقساط» و «فاکتور» زیر ساخته می‌شود.</div>
   <div class="toolbar"><button class="btn p" onclick="smsAutoSave()">💾 ذخیره</button><button class="btn o" onclick="smsAutoSave();smsAutoRemind(true)">🔔 بررسی و ارسال یادآوری‌ها همین حالا</button></div>
  </div>
  <div class="card"><h3>✉️ قالب‌های پیامک (قابل ویرایش)</h3>
  <div class="fg" style="margin-bottom:8px"><label>📅 قالب اقساط</label><textarea id="tInst" rows="2" style="width:100%;font-size:11px">${esc(DB.settings.smsTplInst)}</textarea></div>
  <div class="fg" style="margin-bottom:8px"><label>⚠️ قالب بدهی</label><textarea id="tDebt" rows="2" style="width:100%;font-size:11px">${esc(DB.settings.smsTplDebt)}</textarea></div>
  <div class="fg" style="margin-bottom:8px"><label>🏦 قالب چک</label><textarea id="tChq" rows="2" style="width:100%;font-size:11px">${esc(DB.settings.smsTplChq)}</textarea></div>
  <div class="fg" style="margin-bottom:8px"><label>🧾 قالب رسید پرداخت</label><textarea id="tPay" rows="2" style="width:100%;font-size:11px">${esc(DB.settings.smsTplPay)}</textarea></div>
  <div class="fg" style="margin-bottom:8px"><label>📤 قالب فاکتور</label><textarea id="tInv" rows="2" style="width:100%;font-size:11px">${esc(DB.settings.smsTplInv)}</textarea></div>
  <div class="fg" style="margin-bottom:8px"><label>⏰ قالب یادآوری قسط معوق بیش از یک هفته ({late} = روز تأخیر)</label><textarea id="tLate" rows="3" style="width:100%;font-size:11px">${esc(DB.settings.smsTplLate)}</textarea></div>
   <div class="fg" style="margin-bottom:8px"><label>⏳ قالب مطالبات معوق ({amount} = مبلغ معوق، {remain} = مانده کل، {count} = حداقل روز)</label><textarea id="tAge" rows="2" style="width:100%;font-size:11px">${esc(DB.settings.smsTplAge)}</textarea></div>
  <button class="btn p" onclick="smsTplSave()">💾 ذخیره قالب‌ها</button>
 </div>
 <div class="card"><h3>📲 ارسال پیامک با گوشی خودتان</h3>
  <div class="fg" style="margin-bottom:8px"><label>روش ارسال پیامک</label><select id="smMode"><option value="link" ${smsMode()==='link'?'selected':''}>صف پیامک — ارسال با برنامه‌ی پیام گوشی (بدون نصب)</option><option value="gw" ${smsMode()==='gw'?'selected':''}>گوشی متصل — برنامه‌ی SMS Gateway روی اندروید</option><option value="api" ${smsMode()==='api'?'selected':''}>سرویس پیامک (پنل)</option></select></div>
  <div class="fg" style="margin-bottom:8px"><label>آدرس گوشی (IP نمایش‌داده‌شده در برنامه‌ی گوشی، مثل 192.168.1.20:8080)</label><input id="gwUrl" style="width:100%;direction:ltr" value="${esc(DB.settings.gwUrl||'')}"></div>
  <div class="frow"><div class="fg"><label>نام کاربری</label><input id="gwUser" style="direction:ltr" value="${esc(DB.settings.gwUser||'')}"></div><div class="fg"><label>رمز</label><input id="gwPass" type="password" style="direction:ltr" value="${esc(DB.settings.gwPass||'')}"></div></div>
  <div class="toolbar"><button class="btn p" onclick="smsPhoneSaveCfg()">💾 ذخیره</button><button class="btn g" onclick="smsPhoneSaveCfg();smsGwCheck()">🔌 بررسی اتصال</button><button class="btn" onclick="smsPhoneSaveCfg();smsTest()">🧪 تست ارسال</button><button class="btn o" onclick="msgSettingsOpen()">💬 بله، روبیکا و پیام تشکر</button></div>
  <div id="gwStat" style="font-size:12px;line-height:1.9;margin:6px 0 8px;min-height:18px"></div>
  <div style="font-size:11px;color:#7a8a99;line-height:1.9">«صف پیامک»: پیام‌ها آماده می‌شوند و با یک لمس از برنامه‌ی پیام گوشی خودتان (با سیم‌کارت خودتان) فرستاده می‌شوند. «گوشی متصل»: ۱) برنامه‌ی رایگان SMS Gateway for Android را روی گوشی نصب کنید ۲) گزینه‌ی Local Server را روشن و Start بزنید ۳) IP، نام کاربری و رمزی که برنامه نشان می‌دهد را اینجا وارد کنید ۴) «بررسی اتصال» بزنید. کامپیوتر و گوشی باید به یک Wi‑Fi وصل باشند. هزینه‌ی پیامک طبق تعرفه‌ی سیم‌کارت خودتان است.</div>
 </div>
 <div class="card"><h3>✉️ اتصال به SMS Provider</h3>
  <div class="fg" style="margin-bottom:8px"><label>الگوی URL سرویس (شامل {to} و {msg})</label><input id="smUrl" style="width:100%;direction:ltr;font-size:11px" value="${esc(DB.settings.smsUrl)}" placeholder="https://api.kavenegar.com/v1/{KEY}/sms/send.json?receptor={to}&amp;message={msg}"></div>
  <div class="fg" style="margin-bottom:8px"><label>کلید API (جای {KEY})</label><input id="smKey" style="direction:ltr" value="${esc(DB.settings.smsKey)}"></div>
  <div class="toolbar"><button class="btn p" onclick="smsSaveCfg()">💾 ذخیره</button><button class="btn" onclick="smsTest()">🧪 تست ارسال</button></div>
  <div style="font-size:11px;color:#7a8a99">ارسال مستقیم از مرورگر نیازمند پشتیبانی CORS سرویس‌دهنده پیامک است؛ در غیر این صورت از پنل سرویس ارسال کنید.</div>
 </div>

 <div class="card"><h3>�💾 پشتیبان‌گیری</h3>
  <div class="toolbar">
   <button class="btn p" onclick="backupDownload();toast('📥 فایل بکاپ دانلود شد')">⬇️ دانلود بکاپ الان</button>
   <button class="btn g" onclick="snapshot('دستی')">💾 گرفتن اسنپ‌شات</button>
   <button class="btn o" onclick="pickDir()">📂 انتخاب پوشه بکاپ خودکار</button>
   <button class="btn p" onclick="backupFullDownload()" title="شامل تصاویر مدارک (فایل .tkb)">🖼️ بکاپ کامل با تصاویر</button>
   <label class="btn" style="cursor:pointer">♻️ بازیابی از فایل<input type="file" accept=".json,.tkb" style="display:none" onchange="restoreFileEvt(this)"></label>
  </div>
  <button class="btn" onclick="backupDownload();setTimeout(()=>window.open('https://drive.google.com/drive/my-drive','_blank'),600)">☁️ بکاپ + باز کردن Google Drive</button>
  <div class="sec-h">🗃️ اسنپ‌شات‌های ذخیره‌شده</div><div id="snapList">در حال بارگذاری...</div>
 </div>
 <div class="card"><h3>📊 اکسل و قالب‌ها</h3>
  <div class="toolbar">
   <button class="btn" onclick="xlTemplate()">📥 دانلود قالب ورود اطلاعات</button>
   <label class="btn" style="cursor:pointer">👥 ورود اشخاص<input type="file" accept=".xlsx,.xls" style="display:none" onchange="xlIn(this,'persons')"></label>
   <label class="btn" style="cursor:pointer">📱 ورود کالا<input type="file" accept=".xlsx,.xls" style="display:none" onchange="xlIn(this,'products')"></label>
   <label class="btn" style="cursor:pointer">#️⃣ ورود سریال<input type="file" accept=".xlsx,.xls" style="display:none" onchange="xlIn(this,'serials')"></label>
   <label class="btn" style="cursor:pointer">🏦 ورود چک<input type="file" accept=".xlsx,.xls" style="display:none" onchange="xlIn(this,'cheques')"></label>
   <label class="btn" style="cursor:pointer">📅 ورود اقساط<input type="file" accept=".xlsx,.xls" style="display:none" onchange="xlIn(this,'installments')"></label>
  </div>
 </div>
 <div class="card"><h3>⚙️ تنظیمات فروشگاه و یکپارچه‌سازی</h3>
  <div class="frow"><div class="fg"><label>نام فروشگاه (سربرگ چاپ)</label><input id="seName" value="${esc(DB.settings.shopName)}"></div>
  <div class="fg"><label>تلفن</label><input id="seTel" value="${esc(DB.settings.shopTel)}"></div></div>
  <div class="fg" style="margin-bottom:8px"><label>آدرس</label><input id="seAddr" style="width:100%" value="${esc(DB.settings.shopAddr)}"></div>
  <div class="fg" style="margin-bottom:8px"><label>لوگوی فروشگاه (روی فاکتورهای خرید و فروش چاپ می‌شود)</label><div style="display:flex;gap:10px;align-items:center"><img id="seLogoPrev" ${imgAttrs(DB.settings.shopLogo||'')} style="width:56px;height:56px;object-fit:contain;border:1px solid var(--bd);border-radius:8px;background:#fff;${DB.settings.shopLogo?'':'display:none'}" alt=""><label class="btn sm" style="cursor:pointer">📷 انتخاب لوگو<input type="file" accept="image/*" style="display:none" onchange="shopLogoUpload(this)"></label><button class="btn sm r" onclick="shopLogoRemove()">حذف لوگو</button></div></div>
  <div class="fg" style="margin-bottom:8px"><label>متن پایین فاکتور فروش (شرایط گارانتی/مرجوعی/تشکر)</label><textarea id="seFoot" rows="2" style="width:100%">${esc(DB.settings.invFooter||'')}</textarea></div>
  <div class="fg" style="margin-bottom:8px"><label>آدرس Webhook (ارسال فاکتور/مشتری به برنامه خارجی)</label><input id="seHook" style="width:100%;direction:ltr;font-size:11px" value="${esc(DB.settings.webhook)}" placeholder="https://example.com/api/invoice"></div>
  <label style="display:flex;gap:6px;align-items:center;font-size:12px;margin:6px 0"><input type="checkbox" id="seNeg" ${DB.settings.allowNegative?'checked':''}> اجازه فروش با موجودی منفی</label>
  <div class="fg" style="margin:6px 0"><label>روش بهای تمام‌شده کالاهای تعدادی</label><select id="seCost"><option value="avg" ${DB.settings.costMethod!=='last'?'selected':''}>میانگین موزون</option><option value="last" ${DB.settings.costMethod==='last'?'selected':''}>آخرین قیمت خرید</option></select></div>
  <label style="display:flex;gap:6px;align-items:center;font-size:12px;margin:6px 0"><input type="checkbox" id="seSerReq" ${DB.settings.serialRequired?'checked':''}> سریال در فاکتور خرید الزامی باشد</label>
  <button class="btn p" onclick="settingsSave()">💾 ذخیره تنظیمات</button>
 </div>
 ${appLockCardHtml()}
  <div class="card"><h3>🔒 قفل دوره مالی و بازبینی داده</h3>
   <div class="toolbar"><label class="pw-inl" style="gap:8px">بستن دفاتر تا تاریخ:<input id="lockDateIn" style="width:130px" placeholder="۱۴۰۴/۰۶/۳۱" value="${esc(fa((DB.settings.lockDate||'')))}"></label>
   <button class="btn p" onclick="lockSave()">🔒 ثبت قفل</button>
   <button class="btn g" onclick="dataHealth()">🩺 بازبینی سلامت داده</button>
   <button class="btn" onclick="auditView()">📜 ممیزی و ابطال‌شده‌ها</button>
   <button class="btn" onclick="selfTestView()">🧪 تست محاسبات</button>
   <button class="btn" onclick="expView()">💸 هزینه‌ها</button>
   <button class="btn" onclick="openForm()">💼 موجودی اول دوره</button>
   <button class="btn" onclick="openPersons()">👥 مانده اول دوره اشخاص</button>
   <button class="btn o" onclick="fyForm()">📅 سال مالی و بستن سال</button>
   <button class="btn p" onclick="accView()">📘 حسابداری (تراز، دفتر کل و روزنامه)</button></div>
   <small style="color:var(--mut)">فاکتورهای با تاریخ تا این روز قابل ثبت، ویرایش یا حذف نخواهند بود. برای برداشتن قفل، فیلد را خالی کنید.</small></div>
  <div class="card"><h3>📜 لاگ تغییرات</h3>
  <table data-rn="0"><thead><tr><th>زمان</th><th>کاربر</th><th>عملیات</th></tr></thead><tbody>
  ${DB.log.slice(0,25).map(l=>`<tr><td>${esc(l.t)}</td><td>${l.user}</td><td class="r">${esc(l.act)}</td></tr>`).join('')||'<tr><td colspan="3"><div class="empty">لاگی نیست</div></td></tr>'}
  </tbody></table>
  <div class="toolbar" style="margin-top:10px">
   <button class="btn r" onclick="delOpen()">🗑️ حذف اطلاعات (اشخاص، اقساط، چک‌ها، بازه‌ی زمانی، همه)</button>
   <button class="btn" onclick="loadDemo()">🧪 بارگذاری داده نمونه</button>
  </div>
 </div>
 </div>`;
 loadSnapList();
}
/* ✉️ ارسال‌های گروهی مرکز پیامک */
function smsGroupDebt(){
 const list=DB.persons.map(p=>({p,b:personBalance(p.id)})).filter(x=>x.b.saleDebt>0&&x.p.phone);
 if(!list.length){toast('⚠️ بدهکار با شماره ثبت‌شده وجود ندارد',false);return}
 confirmM('ارسال پیامک بدهی به <b>'+fa(list.length)+'</b> مشتری بدهکار؟<br><small>جمع بدهی: '+fm(list.reduce((s,x)=>s+x.b.saleDebt,0))+' تومان</small>',()=>{
  list.forEach(x=>sendSMS(x.p.phone,smsFill(smsTpl('Debt'),{name:x.p.name,amount:x.b.saleDebt})));
  logAct('اطلاع گروهی بدهی به '+fa(list.length)+' مشتری');
  toast('📨 ارسال به '+fa(list.length)+' نفر ثبت شد');
 });
}
function smsGroupInst(){
 const t=jToday();
 const list=DB.installments.filter(i=>!i.paid&&daysDiff(i.due,t)<=10&&daysDiff(i.due,t)>=-365);
 if(!list.length){toast('⚠️ قسط معوق یا نزدیک سررسیدی نیست',false);return}
 const byP={};
 list.forEach(i=>{const p=P(i.person);if(p&&p.phone){if(!byP[p.id])byP[p.id]=[];byP[p.id].push(i)}});
 const ids=Object.keys(byP);
 if(!ids.length){toast('⚠️ هیچ‌یک شماره ثبت‌شده ندارند',false);return}
 confirmM('ارسال یادآوری اقساط به <b>'+fa(ids.length)+'</b> شخص؟',()=>{
  ids.forEach(pid=>{
   const items=byP[pid];const p=P(pid);
   const sum=items.reduce((s,i)=>s+i.amount,0);
   const late=daysDiff(items[0].due,t);
   const msg=smsFill(smsTpl('Inst'),{name:p.name,no:items[0].no,amount:sum,due:items[0].due,count:items.length})+(late>0?'\n⚠️ '+fa(late)+' روز تأخیر':'')+(items.length>1?'\n(و '+fa(items.length-1)+' قسط دیگر)':'');
   sendSMS(p.phone,msg);smsToGuarantor(p,msg);
  });
  toast('📨 ارسال به '+fa(ids.length)+' نفر ثبت شد');
 });
}
function smsGroupChq(){
 const t=jToday();
 const list=DB.cheques.filter(c=>c.status==='جاری'&&daysDiff(t,c.due)<=10&&daysDiff(t,c.due)>=-30);
 if(!list.length){toast('⚠️ چک نزدیک سررسیدی در بازه نیست',false);return}
 const byP={};
 list.forEach(c=>{const p=P(c.person);if(p&&p.phone){if(!byP[p.id])byP[p.id]=[];byP[p.id].push(c)}});
 const ids=Object.keys(byP);
 if(!ids.length){toast('⚠️ هیچ‌یک شماره ثبت‌شده ندارند',false);return}
 confirmM('ارسال یادآوری چک به <b>'+fa(ids.length)+'</b> شخص؟',()=>{
  ids.forEach(pid=>{
   const chs=byP[pid];const p=P(pid);
   const sum=chs.reduce((s,c)=>s+c.amount,0);
   const msg=smsFill(smsTpl('Chq'),{name:p.name,no:chs[0].no,amount:sum,due:chs[0].due,count:chs.length})+(chs.length>1?'\n(و '+fa(chs.length-1)+' چک دیگر)':'');
   sendSMS(p.phone,msg);smsToGuarantor(p,msg);
  });
  toast('📨 ارسال به '+fa(ids.length)+' نفر ثبت شد');
 });
}
function smsGroupPay(){
 const t=jToday();
 const list=DB.receipts.filter(r=>r.dir==='in'&&daysDiff(r.date,t)<=7&&daysDiff(r.date,t)>=0);
 if(!list.length){toast('⚠️ دریافتی در ۷ روز اخیر نیست',false);return}
 const withPhone=list.filter(r=>{const p=P(r.person);return p&&p.phone});
 if(!withPhone.length){toast('⚠️ هیچ‌یک شماره ثبت‌شده ندارند',false);return}
 confirmM('ارسال پیامک تایید دریافت به <b>'+fa(withPhone.length)+'</b> مشتری (دریافت‌های ۷ روز اخیر)؟',()=>{
  withPhone.forEach(r=>{const p=P(r.person);const amt=r.rows.reduce((s,x)=>s+pd(x.amount),0);
   sendSMS(p.phone,smsFill(smsTpl('Pay'),{name:p.name,amount:amt,date:r.date,no:r.no}))});
  toast('📨 ارسال به '+fa(withPhone.length)+' نفر ثبت شد');
 });
}
function smsAutoSave(){DB.settings.smsAutoInv=!!$('smAutoInv').checked;DB.settings.smsAutoRem=!!$('smAutoRem').checked;DB.settings.smsAutoLate=!!$('smAutoLate').checked;DB.settings.smsEntryAlert=!!($('smEntry')||{checked:true}).checked;DB.settings.smsGuarRem=!!$('smGuarRem').checked;saveDB();toast('✅ تنظیمات پیامک خودکار ذخیره شد')}
function smsTplSave(){
 DB.settings.smsTplInst=$('tInst').value;DB.settings.smsTplDebt=$('tDebt').value;
 DB.settings.smsTplChq=$('tChq').value;DB.settings.smsTplPay=$('tPay').value;
 DB.settings.smsTplInv=$('tInv').value;DB.settings.smsTplAge=$('tAge').value;DB.settings.smsTplLate=$('tLate').value;
 saveDB();toast('✅ قالب‌های پیامک ذخیره شد');
}
async function loadSnapList(){
 const el=$('snapList');if(!el)return;
 const snaps=(await snapIndex()).slice().sort((a,b)=>b.t-a.t);
 el.innerHTML=snaps.length?snaps.map(s=>'<div style="display:flex;align-items:center;gap:8px;padding:6px 0;border-bottom:1px dashed #e2e8f0;font-size:12px"><span style="flex:1">'+esc(s.label)+' — '+new Date(s.t).toLocaleString('fa-IR')+'</span><button class="btn sm" onclick="restoreSnap(\'s'+s.t+'\')">♻️ بازیابی</button></div>').join(''):'<div style="color:#7a8a99;font-size:12px">اسنپ‌شاتی نیست</div>';
}
async function restoreSnap(key){
 const s=await idb.get('snap',key);if(!s){toast('یافت نشد',false);return}
 confirmM('بازیابی بکاپ «'+esc(s.label)+'»؟ داده‌های فعلی جایگزین می‌شوند.',async()=>{await snapshot('قبل از بازیابی بکاپ',true);const _c=lkCarry(DB.settings);const _d=snapData(s);await hydrateImgs(_d,false);DB=_d;DB.settings={...defSettings,...DB.settings};_c(DB.settings);migrate(DB);await saveDB();nav(curView);toast('✅ بازیابی شد (وضعیت قبلی هم در اسنپ‌شات‌ها نگه داشته شد)')});
}
function restoreFileEvt(input){
 const f=input.files[0];if(!f)return;
 const done=(d,imgs,name)=>confirmM('بازیابی از فایل «'+esc(name)+'»'+(imgs?' (همراه '+fa(imgs)+' تصویر)':'')+'؟',async()=>{await snapshot('قبل از بازیابی از فایل',true);const _c=lkCarry(DB.settings);await hydrateImgs(d,false);DB=d;DB.settings={...defSettings,...DB.settings};_c(DB.settings);migrate(DB);await saveDB();nav('dash');toast('✅ داده‌ها بازیابی شد (وضعیت قبلی هم در اسنپ‌شات‌ها نگه داشته شد)')});
 const bad=()=>toast('❌ فایل بکاپ معتبر نیست',false);
 const ok=d=>Array.isArray(d.persons)&&Array.isArray(d.products)&&!(d.invoices||[]).some(i=>!i||!Array.isArray(i.lines));
 if(/\.tkb$/i.test(f.name)){
  toast('⏳ خواندن بکاپ کامل…');
  tkbRead(f).then(r=>{if(!ok(r.db))throw 0;done(r.db,r.images,f.name)}).catch(bad).finally(()=>{input.value=''});
  return;
 }
 const r=new FileReader();
 r.onload=e=>{try{const d=JSON.parse(e.target.result);if(!ok(d))throw 0;done(d,0,f.name)}catch(err){bad()}input.value=''};
 r.readAsText(f);
}
async function wipeData(){confirmM('⚠️ تمام داده‌ها پاک می‌شوند. قبلاً بکاپ بگیرید! مطمئن هستید؟',async()=>{await snapshot('قبل از پاک‌سازی کامل',true);const _c=lkCarry(DB.settings);DB=seedDB();_c(DB.settings);['persons','products','serials','invoices','receipts','cheques','installments','accTx','log'].forEach(k=>DB[k]=[]);DB.counters={person:1000,product:1000,sale:1000,buy:1000,rec:1000,pro:1000};await saveDB();nav('dash');toast('🗑️ داده‌ها پاک شد')})}
function loadDemo(){confirmM('داده نمونه بارگذاری شود؟ (موارد تکراری رد می‌شوند)',()=>{const d=seedDB();d.persons.forEach(p=>{if(!DB.persons.some(x=>x.name===p.name)){p.code=++DB.counters.person;DB.persons.push(p)}});d.products.forEach(p=>{if(!DB.products.some(x=>x.name===p.name)){p.code='P-'+(++DB.counters.product);DB.products.push(p)}});d.serials.forEach(s=>{if(!DB.serials.some(x=>x.sn===s.sn)){const src=d.products.find(y=>y.id===s.pid);const np=src&&DB.products.find(x=>x.name===src.name);if(np){s.pid=np.id;DB.serials.push(s)}}});saveDB();toast('✅ داده نمونه بارگذاری شد');nav('dash')})}
function settingsSave(){
 DB.settings.shopName=$('seName').value;DB.settings.shopTel=$('seTel').value;DB.settings.shopAddr=$('seAddr').value;DB.settings.invFooter=($('seFoot')||{}).value||'';
 DB.settings.webhook=$('seHook').value;DB.settings.allowNegative=$('seNeg').checked;DB.settings.costMethod=$('seCost').value;DB.settings.serialRequired=$('seSerReq').checked;
 logAct('تغییر تنظیمات');saveDB();toast('✅ تنظیمات ذخیره شد');
}
function smsSaveCfg(){DB.settings.smsUrl=$('smUrl').value;DB.settings.smsKey=$('smKey').value;saveDB();toast('✅ تنظیمات پیامک ذخیره شد')}
function smsSendApi(to,msg){
 let url=DB.settings.smsUrl;
 if(!url){toast('⚠️ ابتدا سرویس پیامک را در «ابزار» تنظیم کنید',false);return}
 url=url.replace('{KEY}',DB.settings.smsKey||'').replace('{to}',encodeURIComponent(to)).replace('{msg}',encodeURIComponent(msg));
 fetch(url).then(r=>{if(r.ok)toast('✅ پیامک ارسال شد به '+fa(to));else toast('⚠️ پاسخ سرویس: '+r.status,false)}).catch(()=>toast('❌ ارسال ناموفق — CORS/شبکه. از پنل سرویس‌دهنده ارسال کنید',false));
}
function smsTest(){askM('🧪 تست ارسال','شماره‌ی موبایل برای تست:','',to=>sendSMS(faDig(to),'پیام تست تکنوکالا — '+jLong(jToday())),1)}

