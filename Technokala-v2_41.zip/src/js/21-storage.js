/* ---------- ذخیره‌سازی ---------- */
const idb={db:null,
 open(){return new Promise(r=>{try{const q=indexedDB.open('technokala_db',2);q.onupgradeneeded=e=>{const d=e.target.result;['kv','snap','img'].forEach(n=>{if(!d.objectStoreNames.contains(n))d.createObjectStore(n)})};q.onsuccess=e=>{idb.db=e.target.result;r()};q.onerror=()=>r()}catch(e){r()}})},
 keys(st){return new Promise(r=>{if(!idb.db)return r([]);try{const q=idb.db.transaction(st,'readonly').objectStore(st).getAllKeys();q.onsuccess=()=>r(q.result||[]);q.onerror=()=>r([])}catch(e){r([])}})},
 put(st,k,v){return new Promise(r=>{if(!idb.db)return r(false);try{const t=idb.db.transaction(st,'readwrite');t.objectStore(st).put(v,k);t.oncomplete=()=>r(true);t.onerror=()=>r(false);t.onabort=()=>r(false)}catch(e){r(false)}})},
 get(st,k){return new Promise(r=>{if(!idb.db)return r(null);try{const q=idb.db.transaction(st,'readonly').objectStore(st).get(k);q.onsuccess=()=>r(q.result||null);q.onerror=()=>r(null)}catch(e){r(null)}})},
 all(st){return new Promise(r=>{if(!idb.db)return r([]);try{const q=idb.db.transaction(st,'readonly').objectStore(st).getAll();q.onsuccess=()=>r(q.result||[]);q.onerror=()=>r([])}catch(e){r([])}})},
 del(st,k){return new Promise(r=>{if(!idb.db)return r();try{const t=idb.db.transaction(st,'readwrite');t.objectStore(st).delete(k);t.oncomplete=r;t.onerror=r}catch(e){r()}})}};

let DB=null,dirHandle=null,lastSaveT=null,nextSnapT=5*60;
const IMG_KEY=new Map(),IMG_SAVED=new Set();
function imgKey(s){let h=5381;for(let i=0;i<s.length;i++)h=((h<<5)+h+s.charCodeAt(i))|0;return 'img:'+(h>>>0).toString(36)+'-'+s.length}
/* جایگزینی تصاویر بزرگ با ارجاع: دیتابیس، نسخه‌های داخلی و خودنجات همگی فقط ارجاع نگه می‌دارند */
function mkImgRep(found){return (k,v)=>{if(typeof v==='string'&&v.length>3000&&v.startsWith('data:')){let key=IMG_KEY.get(v);if(!key){key=imgKey(v);IMG_KEY.set(v,key)}found[key]=v;return key}return v}}
function collectRefs(o,set){if(!o||typeof o!=='object')return;for(const k of Object.keys(o)){const v=o[k];if(typeof v==='string'){if(/^img:[0-9a-z]+-\d+$/.test(v))set.add(v)}else collectRefs(v,set)}}
/* تصاویر دیگر هنگام شروع بارگذاری نمی‌شوند (بارگذاری تنبل)؛ فقط کلیدهای موجود ثبت و تصاویر بی‌مصرف پاک می‌شوند */
async function hydrateImgs(root,gc){
 try{for(const k of await idb.keys('img'))IMG_SAVED.add(k)}catch(e){}
 if(gc===false)return;
 const refs=new Set();collectRefs(root,refs);
 try{
  const idx=await snapIndex(),keep=new Set(refs);let safe=true;
  for(const m of idx){if(!m.refs)safe=false;else m.refs.forEach(r=>keep.add(r))}
  if(safe)for(const key of await idb.keys('img'))if(!keep.has(key)){await idb.del('img',key);IMG_SAVED.delete(key)}
 }catch(e){}
}
/* کوچک‌سازی عکس‌ها هنگام بارگذاری (حداکثر ۱۲۸۰ پیکسل، JPEG) */
function shrinkImg(url,cb){
 if(!/^data:image\/(jpeg|png|webp|bmp)/.test(url)||url.length<70000){cb(url);return}
 try{const im=new Image();im.onload=()=>{try{const s=Math.min(1,1100/Math.max(im.width,im.height)),c=document.createElement('canvas');c.width=Math.round(im.width*s);c.height=Math.round(im.height*s);
  const g=c.getContext('2d');if(!g){cb(url);return}g.fillStyle='#fff';g.fillRect(0,0,c.width,c.height);g.drawImage(im,0,0,c.width,c.height);
  const o=c.toDataURL('image/jpeg',0.72);cb(o.length<url.length?o:url)}catch(e){cb(url)}};im.onerror=()=>cb(url);im.src=url}catch(e){cb(url)}
}

const defSettings={shopName:'فروشگاه تکنوکالا',smsAutoInv:true,smsAutoRem:true,smsAutoLate:true,smsGuarRem:true,autoLockMin:10,shopTel:'',shopAddr:'',owner:'',allowNegative:false,serialRequired:true,
 smsUrl:'',smsKey:'',webhook:'',backupDirName:'',
 smsTplInst:'{shop}\nمشتری محترم {name}\nقسط {no} به مبلغ {amount} تومان با سررسید {due} می‌باشد. لطفاً تسویه فرمایید.',
 smsTplDebt:'{shop}\nمشتری محترم {name}\nمانده حساب شما {amount} تومان می‌باشد. لطفاً تسویه فرمایید.',
 smsTplChq:'{shop}\nمشتری محترم {name}\nچک شماره {no} به مبلغ {amount} تومان با سررسید {due} می‌باشد. لطفاً اقدام فرمایید.',
 smsTplPay:'{shop}\nمشتری محترم {name}\nدریافت مبلغ {amount} تومان در تاریخ {date} ثبت شد. با تشکر از اعتماد شما',
 smsTplAge:'{shop}\nمشتری محترم {name}\nمبلغ {amount} تومان از مانده حساب شما (مانده کل {remain} تومان) بیش از {count} روز گذشته است. لطفاً تسویه فرمایید.',
 smsTplInv:'{shop}\nمشتری محترم {name}\nفاکتور شماره {no} به مبلغ {amount} تومان در تاریخ {date} صادر شد. مانده: {remain} تومان',
 smsTplLate:'مشتری محترم {name}\nموعد پرداخت بدهی شما به {shop} (قسط {no} به مبلغ {amount} تومان با سررسید {due}) {late} روز گذشته و پرداختی از شما ثبت نشده است. لطفاً هرچه زودتر تسویه فرمایید.'};
const defColorPairs=[['white','#ffffff'],['black','#2d3436'],['blue','#2980d9'],['gold','#d4af37'],['silver','#b2bec3'],['red','#e74c3c'],['green','#27ae60'],['purple','#8e44ad'],['pink','#fd79a8'],['gray','#636e72'],['yellow','#f1c40f'],['orange','#e67e22']];
const defGroups=['مشتری عادی','مشتری ویژه','فروشنده/تامین‌کننده','کارمند'];
const defProductGroups=['Mobile','Laptop','GameConsole','Tablet','Accessories','Other'];
const defProductOptions={brands:['Samsung','Xiaomi','Apple','Huawei','Nokia'],models:[],memories:['64 GB','128 GB','256 GB','512 GB','1 TB'],rams:['4 GB','6 GB','8 GB','12 GB','16 GB'],screenSizes:['13.3 اینچ','14 اینچ','15.6 اینچ','16 اینچ','17.3 اینچ'],consoleUsages:['خانگی','قابل حمل','دستی','سایر'],conditions:['نو','استوک'],gpus:[]};
const defPhoneModels={
 'Samsung':['Galaxy S25','Galaxy S25 Ultra','Galaxy S25 FE','Galaxy S24','Galaxy S24 Ultra','Galaxy A56','Galaxy A55','Galaxy A36','Galaxy A35','Galaxy A16','Galaxy M56','Galaxy M36','Galaxy F56','Galaxy Z Fold 6','Galaxy Z Flip 6','Galaxy Tab S10','Galaxy Tab A10'],
 'Xiaomi':['Xiaomi 15','Xiaomi 15 Ultra','Xiaomi 14','Redmi Note 14','Redmi Note 14 Pro','Redmi Note 13','Redmi 14C','Redmi A5','Poco X7','Poco X6','Poco F7','Poco M7','Xiaomi Pad 7'],
 'Apple':['iPhone 16','iPhone 16 Pro','iPhone 16 Pro Max','iPhone 16e','iPhone 15','iPhone 15 Pro','iPhone 15 Pro Max','iPhone 14','iPhone 14 Pro','iPhone 13','iPhone SE','iPad Air','iPad Pro'],
 'Huawei':['Nova 13','Nova 12','Pura 70','Pura 70 Pro','Mate 70','Mate 70 Pro','Enjoy 70','Y9 Prime'],
 'Nokia':['G42','G22','C32','C22','X30','2660 Flip','8210 4G','105 4G']
};
const defBanks=['ملت','صادرات','ملی','سامان','پاسارگاد','سپه','تجارت','رسالت'];
const DOC_TYPES=['قرارداد','کارت ملی','کارت کارمندی','سند ضمانت','رسید','سایر'];

function seedDB(){
 const db={settings:{...defSettings,demoVersion:'clean-v1'},colors:defColorPairs.map(x=>({id:uid(),name:x[0],enName:x[0],hex:x[1]})),personGroups:defGroups.map(g=>({id:uid(),name:g})),productGroups:defProductGroups.map(g=>({id:uid(),name:g})),productOptions:JSON.parse(JSON.stringify(defProductOptions)),phoneModels:JSON.parse(JSON.stringify(defPhoneModels)),
  persons:[],products:[],serials:[],invoices:[],receipts:[],cheques:[],installments:[],banks:defBanks.map(b=>({id:uid(),name:b})),
  accounts:[],accTx:[],log:[],voided:[],audit:[],expenses:[],counters:{person:1000,product:1000,sale:1000,buy:1000,rec:1000,pro:1000}};
 db.accounts.push({id:uid(),bank:db.banks[0].id,title:'جاری تکنوکالا',accNo:'',card:'',iban:'',open:0});
 return db;
}
function hasUserData(d){
 return (d.persons||[]).length>0||(d.products||[]).length>0||(d.serials||[]).length>0||(d.expenses||[]).length>0||(d.invoices||[]).length>0||(d.cheques||[]).length>0||(d.receipts||[]).length>0||(d.installments||[]).length>0||(d.accTx||[]).length>0||(d.log||[]).length>0;
}
function migrate(d){
 ['persons','products','serials','invoices','receipts','cheques','installments','accTx','log','banks','accounts','colors','personGroups','voided','audit','expenses'].forEach(k=>{if(!Array.isArray(d[k]))d[k]=[]});
 if(!d.counters||typeof d.counters!=='object')d.counters={};
 ['person','product','sale','buy','rec','pro'].forEach(k=>{if(!(d.counters[k]>0))d.counters[k]=1000});
 if(!d.settings||typeof d.settings!=='object')d.settings={};
 d.personGroups.forEach(g=>{if(g.supplier===undefined)g.supplier=/فروشنده|تامین|تأمین/.test(g.name||'')});
  (d.persons||[]).forEach(p=>{const ok=new Set(d.personGroups.map(g=>g.id));let a=(Array.isArray(p.groups)&&p.groups.length?p.groups:[p.group]).filter(x=>x&&ok.has(x));a=[...new Set(a)];if(!a.length&&d.personGroups[0])a=[d.personGroups[0].id];p.groups=a;p.group=a[0]||p.group});
 const productText={
  'موبایل':'Mobile','تبلت':'Tablet','لوازم جانبی':'Accessories','سایر':'Other',
  'سامسونگ':'Samsung','شیامی':'Xiaomi','شیائومی':'Xiaomi','اپل':'Apple','هوآوی':'Huawei','نوکیا':'Nokia',
  '۶۴ گیگ':'64 GB','۱۲۸ گیگ':'128 GB','۲۵۶ گیگ':'256 GB','۵۱۲ گیگ':'512 GB','۱ ترابایت':'1 TB',
  '۴ گیگ':'4 GB','۶ گیگ':'6 GB','۸ گیگ':'8 GB','۱۲ گیگ':'12 GB','۱۶ گیگ':'16 GB'
 };
 d.productGroups=(d.productGroups||[]).map(g=>({...g,name:productText[g.name]||g.name}));
 if(d.productOptions){['brands','models','memories','rams','gpus'].forEach(k=>{if(Array.isArray(d.productOptions[k]))d.productOptions[k]=d.productOptions[k].map(x=>productText[x]||x)})}
 (d.products||[]).forEach(p=>{p.brand=productText[p.brand]||p.brand;p.memory=productText[p.memory]||p.memory;p.ram=productText[p.ram]||p.ram;if(p.group){const group=d.productGroups.find(g=>g.id===p.group);if(group)group.name=productText[group.name]||group.name}});
 if(!Array.isArray(d.productGroups)||!d.productGroups.length)d.productGroups=defProductGroups.map(g=>({id:uid(),name:g}));
 if(!d.productGroups.some(g=>['Laptop','لپ‌تاپ','لپ تاپ'].includes(g.name)))d.productGroups.push({id:uid(),name:'Laptop'});
 if(!d.productGroups.some(g=>['GameConsole','کنسول بازی','کنسول‌بازی'].includes(g.name)))d.productGroups.push({id:uid(),name:'GameConsole'});
 if(!d.productOptions)d.productOptions=JSON.parse(JSON.stringify(defProductOptions));
 if(!d.phoneModels)d.phoneModels={};
 if(Array.isArray(d.phoneModels['شیائومی']))d.phoneModels['شیامی']=[...(d.phoneModels['شیامی']||[]),...d.phoneModels['شیائومی']];
 if(Array.isArray(d.phoneModels['ایفون']))d.phoneModels['اپل']=[...(d.phoneModels['اپل']||[]),...d.phoneModels['ایفون']];
 d.phoneModels=d.phoneModels||{};
 (d.products||[]).forEach(p=>{if(p.brand==='شیائومی')p.brand='شیامی';if(p.brand==='ایفون'||p.brand==='اپل')p.brand='اپل'});
 d.productOptions.brands=[...new Set(d.productOptions.brands.map(b=>b==='شیائومی'?'شیامی':(b==='ایفون'?'اپل':b)))];
 ['brands','models','memories','rams','screenSizes','consoleUsages','conditions','gpus'].forEach(k=>{if(!Array.isArray(d.productOptions[k]))d.productOptions[k]=[]});
 if(!d.productOptions.screenSizes.length)d.productOptions.screenSizes=[...defProductOptions.screenSizes];
 if(!d.productOptions.consoleUsages.length)d.productOptions.consoleUsages=[...defProductOptions.consoleUsages];
 if(!d.productOptions.conditions.length)d.productOptions.conditions=[...defProductOptions.conditions];
 const defaultProductGroup=d.productGroups[0];
 (d.products||[]).forEach(p=>{if(!p.group)p.group=defaultProductGroup.id});
 (d.colors||[]).forEach(c=>{if(!c.hex)c.hex='#95a5a6';if(!c.enName)c.enName=colorEnOf(c)});
 (d.products||[]).forEach(p=>{if(!p.colors)p.colors=[]});
 const serialSeen=new Set();
 d.serials=(d.serials||[]).filter(s=>{const sn=faDig(s.sn||'').trim();if(!sn||serialSeen.has(sn))return false;serialSeen.add(sn);s.sn=sn;return true});
 if(d.settings&&d.settings.allowNegative===undefined)d.settings.allowNegative=false;
 if(d.settings&&d.settings.serialRequired===undefined)d.settings.serialRequired=true;
 (d.installments||[]).forEach(i=>{if(!i.planId)i.planId=i.inv?('inv-'+i.inv):('m-'+(i.id||uid()))});
 if(d.settings){['smsTplInst','smsTplDebt','smsTplChq','smsTplPay','smsTplInv','smsTplAge','smsTplLate'].forEach(k=>{if(!d.settings[k])d.settings[k]=defSettings[k]})}
}

async function saveDB(silent){
  if(!DB)return false;
  try{tsStamp()}catch(e){}
  ixInvalidate();
  /* تصاویر بزرگ شخص/ضامن به ارجاع تبدیل می‌شوند (store «img») تا دیتابیس اصلی سبک بماند */
  let ok=true;
  try{ok=await slimImgs()}catch(e){ok=false}
  let js=JSON.stringify(DB);
  if(js.indexOf('\"data:image')>=0||js.indexOf('\"data:application')>=0){const found={};js=JSON.stringify(DB,mkImgRep(found));for(const key of Object.keys(found)){if(IMG_SAVED.has(key))continue;if(await idb.put('img',key,found[key]))IMG_SAVED.add(key);else{ok=false;break}}}
  if(saveDB._last===js&&ok){return true}
  if(ok)ok=await idb.put('kv','db',js);
  if(ok)saveDB._last=js;
  const b=$('chipBackup');
  if(!ok){
   if(b){b.textContent='⛔ ذخیره ناموفق!';b.className='chip err'}
   if(!saveDB._warned){saveDB._warned=true;toast('⛔ ذخیره‌سازی در مرورگر انجام نشد — همین حالا «دانلود بکاپ» را بزنید',false)}
   return false;
  }
  saveDB._warned=false;
  lastSaveT=new Date();$('stLast').textContent=lastSaveT.toLocaleTimeString('fa-IR');
  if(b&&(!silent||b.classList.contains('err'))){b.textContent='💾 ذخیره شد';b.className='chip ok'}
  return true;
 }
 let saveH=null;
function scheduleSave(){clearTimeout(saveH);saveH=setTimeout(()=>saveDB(true),700)}

const SNAP_AUTO_MAX=12,SNAP_MANUAL_MAX=30;
function isAutoSnap(r){return !!(r&&(r.auto||/^(خودکار|خروج غیرعادی)/.test(r.label||'')))}
function snapsToDelete(all){
 const out=[];
 [[true,SNAP_AUTO_MAX],[false,SNAP_MANUAL_MAX]].forEach(([auto,max])=>{
  const g=all.filter(r=>isAutoSnap(r)===auto).sort((a,b)=>a.t-b.t);
  while(g.length>max)out.push(g.shift());
 });
 return out;
}
/* فهرست سبک اسنپ‌شات‌ها (بدون خواندن محتوای سنگین آن‌ها) */
async function snapIndex(){
 let idx=await idb.get('kv','snapidx');
 if(Array.isArray(idx))return idx;
 idx=[];
 try{for(const k of await idb.keys('snap')){const r=await idb.get('snap',k);if(!r)continue;const refs=new Set();if(r.js){(r.js.match(/img:[0-9a-z]+-\d+/g)||[]).forEach(x=>refs.add(x))}else collectRefs(r.data,refs);idx.push({t:r.t,label:r.label,auto:!!r.auto,refs:[...refs]})}}catch(e){}
 await idb.put('kv','snapidx',idx);return idx;
}
function snapData(r){return r&&(r.js?JSON.parse(r.js):r.data)}
async function trimSnaps(){
 const idx=await snapIndex(),del=snapsToDelete(idx);
 if(!del.length)return;
 for(const r of del)await idb.del('snap','s'+r.t);
 const gone=new Set(del.map(r=>r.t));
 await idb.put('kv','snapidx',idx.filter(r=>!gone.has(r.t)));
}
let lastSnapJs='',lastSnapT=0;
async function snapshot(label,silent,auto){
  if(!DB)return;
  try{await slimImgs()}catch(e){}
  const js=JSON.stringify(DB);
  if(auto&&js===lastSnapJs)return;
  const t=lastSnapT=Math.max(Date.now(),lastSnapT+1);
  const rec={t,label,auto:!!auto,js};
  const ok=await idb.put('snap','s'+t,rec);
  if(ok){
   lastSnapJs=js;
   const idx=await snapIndex();idx.push({t,label,auto:!!auto,refs:[...new Set(js.match(/img:[0-9a-z]+-\d+/g)||[])]});await idb.put('kv','snapidx',idx);
  }
  await trimSnaps();
  await writeDirBackup(label,auto);
  if(!silent)toast(ok?'💾 بکاپ «'+label+'» گرفته شد ('+new Date().toLocaleTimeString('fa-IR')+')':'⚠️ بکاپ داخلی ذخیره نشد — از «دانلود بکاپ» استفاده کنید',ok);
  if(curView==='tools')loadSnapList();
 }
 /* نسخه‌های قدیمی که تصاویر را داخل خود داشتند به ارجاع تبدیل می‌شوند (یک بار) */
 async function migrateSnaps(){
  if(!DB||DB.settings.snapRefs)return;
  try{
   for(const k of await idb.keys('snap')){
    const r=await idb.get('snap',k);if(!r||!r.data)continue;
    const found={},js=JSON.stringify(r.data,mkImgRep(found));
    if(!Object.keys(found).length)continue;
    let ok=true;
    for(const key of Object.keys(found)){if(IMG_SAVED.has(key))continue;if(await idb.put('img',key,found[key]))IMG_SAVED.add(key);else{ok=false;break}}
    if(!ok)continue;
    r.data=JSON.parse(js);await idb.put('snap',k,r);
   }
   DB.settings.snapRefs=true;saveDB(true);
  }catch(e){console.error('migrateSnaps',e)}
 }
 /* بکاپ در پوشه: هر فایل کامل و مستقل است؛ بکاپ‌های خودکار حداکثر ساعتی یک‌بار نوشته می‌شوند و فقط ۱۲ فایل آخر نگه داشته می‌شود */
const DIR_AUTO_MAX=12,DIR_AUTO_GAP=60*60*1000;let _dirAutoT=0;
async function pruneDirBackups(){
 try{
  const names=[];
  for await(const e of dirHandle.values()){if(e.kind==='file'&&/^تکنوکالا-بکاپ-خودکار-.*\.json$/.test(e.name))names.push(e.name)}
  names.sort();
  while(names.length>DIR_AUTO_MAX)await dirHandle.removeEntry(names.shift());
 }catch(e){}
}
async function writeDirBackup(label,auto){
 if(!dirHandle)return;
 if(auto&&Date.now()-_dirAutoT<DIR_AUTO_GAP)return;
 if(!(await dirHandleOk())){const el=$('stDir');if(el)el.textContent=(DB.settings.backupDirName||dirHandle.name)+' — نیاز به تایید دسترسی';return}
 try{
  const isAuto=!!auto||/^هنگام خروج/.test(label||'');
  const name='تکنوکالا-بکاپ-'+(isAuto?'خودکار-':'')+dateToJ(new Date()).replace(/\//g,'-')+'-'+new Date().toTimeString().slice(0,5).replace(':','')+'.json';
  const fh=await dirHandle.getFileHandle(name,{create:true});
  const w=await fh.createWritable();await w.write(JSON.stringify(DB));await w.close();
  if(auto)_dirAutoT=Date.now();
  if(isAuto)await pruneDirBackups();
 }catch(e){const el=$('stDir');if(el)el.textContent=(DB.settings.backupDirName||'')+' — ⚠️ نوشتن بکاپ در پوشه ناموفق بود'}
}
function startAutoBackup(){
 setInterval(()=>{
  nextSnapT--;
  if(nextSnapT<=0){nextSnapT=5*60;snapshot('خودکار (۵ دقیقه‌ای)',true,true)}
  const m=Math.floor(nextSnapT/60),s=nextSnapT%60;
  const el=$('stNext');if(el)el.textContent=p2(m)+':'+p2(s);
 },1000);
}
/* بررسی و درخواست مجدد دسترسی به پوشه بکاپ پس از راه‌اندازی مجدد برنامه */
async function dirHandleOk(){
 if(!dirHandle)return false;
 try{
  const perm=await dirHandle.queryPermission({mode:'readwrite'});
  if(perm==='granted')return true;
  return (await dirHandle.requestPermission({mode:'readwrite'}))==='granted';
 }catch(e){return false}
}
/* بازیابی پوشه بکاپ پس از ری‌استارت: نام پوشه ذخیره شده، ولی handle در حافظه است و از بین می‌رود */
async function restoreDirHandle(){
 if(dirHandle||!DB.settings.backupDirName)return;
 if(typeof window.showDirectoryPicker==='undefined')return;
 try{
  dirHandle=await window.showDirectoryPicker({mode:'readwrite',id:'technokala-backup',startIn:DB.settings.backupDirName});
  if(dirHandle.name!==DB.settings.backupDirName){dirHandle=null;return}
  if(!(await dirHandleOk())){dirHandle=null;return}
  const el=$('stDir');if(el)el.textContent=dirHandle.name;
  toast('✅ پوشه بکاپ «'+dirHandle.name+'» مجدداً متصل شد');
 }catch(e){dirHandle=null}
}
async function pickDir(){
 if(typeof window.showDirectoryPicker==='undefined'){toast('⚠️ این قابلیت داخل کادر آزمایشی غیرفعال است. فایل را دانلود و مستقیم در Edge/Chrome ویندوز باز کنید',false);return}
 try{dirHandle=await window.showDirectoryPicker({mode:'readwrite',id:'technokala-backup'});DB.settings.backupDirName=dirHandle.name;const el=$('stDir');if(el)el.textContent=dirHandle.name;saveDB();toast('✅ پوشه بکاپ: '+dirHandle.name)}catch(e){}
}
function backupDownload(){
 const blob=new Blob([JSON.stringify(DB)],{type:'application/json'});
 const a=document.createElement('a');a.href=URL.createObjectURL(blob);
 a.download='تکنوکالا-بکاپ-'+dateToJ(new Date()).replace(/\//g,'-')+'-'+new Date().toTimeString().slice(0,5).replace(':','')+'.json';
 a.click();setTimeout(()=>URL.revokeObjectURL(a.href),2000);
}
async function exitApp(){
 await snapshot('هنگام خروج');
 const E=window.electronAPI;
 if(E&&E.backupAndClose){
  /* نسخه‌ی ویندوز: اگر پوشه‌ی بکاپ تنظیم نشده، یک نسخه در Documents\Technokala-Backups ذخیره می‌شود */
  if(dirHandle&&E.quit){E.quit();return}
  const nm='تکنوکالا-بکاپ-خودکار-خروج-'+dateToJ(new Date()).replace(/\//g,'-')+'-'+new Date().toTimeString().slice(0,5).replace(':','')+'.json';
  await E.backupAndClose(JSON.stringify(DB),nm);
  return;
 }
 backupDownload();
 toast('✅ بکاپ ذخیره شد؛ برنامه در حال خروج است');
 setTimeout(()=>window.close(),500);
}
window.addEventListener('beforeunload',async()=>{
  if(DB&&idb.db){try{
   const t0=Date.now(),t=idb.db.transaction('snap','readwrite');
   const fd={},jj=JSON.stringify(DB,mkImgRep(fd)),refsOk=Object.keys(fd).every(k=>IMG_SAVED.has(k));
    t.objectStore('snap').put({t:t0,label:'خروج غیرعادی (خودنجات)',auto:true,data:refsOk?JSON.parse(jj):JSON.parse(JSON.stringify(DB))},'s'+t0);
   t.oncomplete=()=>{trimSnaps().catch(()=>{})};
  }catch(e){}}
});

function logAct(act){
 DB.log.unshift({t:new Date().toLocaleString('fa-IR'),user:'مدیر',act});
 if(DB.log.length>300)DB.log.length=300;
}

