/* ================= مرکز اعلان‌های هوشمند ================= */
function notifList(){
 const t=jToday(),out=[];
 DB.installments.filter(i=>!i.paid&&daysDiff(i.due,t)>0).forEach(i=>{
  out.push({ic:'📅',bg:'#fdf0e0',t:'قسط معوق — '+PN(i.person),s:fa(daysDiff(i.due,t))+' روز تأخیر — '+fm(i.amount)+' ت — سررسید '+jShort(i.due),go(){closeM();nav('inst');setTimeout(()=>vInst('open'),60)}});
 });
 DB.cheques.filter(c=>c.status==='جاری'&&jNorm(c.due)<t).forEach(c=>{
  out.push({ic:'🏦',bg:'#fdecea',t:'چک سررسید گذشته — '+PN(c.person),s:fm(c.amount)+' ت — سررسید '+jShort(c.due)+' — شماره '+fa(c.no||'—'),go(){closeM();nav('cheques');setTimeout(()=>vCheques('all'),60)}});
 });
 DB.products.filter(p=>stockOf(p.id)<=p.reorder).forEach(p=>{
  const s=stockOf(p.id);
  out.push({ic:'📦',bg:'#fff8e6',t:'کمبود کالا — '+p.name,s:'موجودی '+fa(s)+' — نقطه سفارش '+fa(p.reorder),go(){closeM();nav('inventory');setTimeout(()=>shortageRep(),60)}});
 });
 DB.cheques.filter(c=>c.status==='جاری'&&daysDiff(t,c.due)>=0&&daysDiff(t,c.due)<=7).forEach(c=>{
  out.push({ic:'⏰',bg:'#e8f1f9',t:'چک نزدیک سررسید — '+PN(c.person),s:fa(daysDiff(t,c.due))+' روز مانده — '+fm(c.amount)+' ت',go(){closeM();nav('cheques');setTimeout(()=>vCheques('all'),60)}});
 });
 return out;
}
function notifCount(){
 const t=jToday();let n=0;
 for(const i of DB.installments)if(!i.paid&&daysDiff(i.due,t)>0)n++;
 for(const c of DB.cheques){if(c.status!=='جاری')continue;if(jNorm(c.due)<t)n++;const d=daysDiff(t,c.due);if(d>=0&&d<=7)n++}
 for(const p of DB.products)if(stockOf(p.id)<=p.reorder)n++;
 return n;
}
let _notifT=null;
function notifDotUpd(){
 clearTimeout(_notifT);
 _notifT=setTimeout(()=>{
  const dot=$('bellDot');if(!dot)return;
  const n=notifCount();
  dot.style.display=n?'flex':'none';
  dot.textContent=n>99?'۹۹+':fa(n);
 },150);
}
function notifOpen(){
 const full=notifList(),list=full.slice(0,300);notifItems=list;
 openM(mHead('🔔 مرکز اعلان‌های هوشمند')+'<div class="mbody" style="padding:0">'+
  (list.length?list.map((x,i)=>'<div class="notif-item" onclick="closeM();notifItems['+i+'].go()"><span class="ni-ic" style="background:'+x.bg+'">'+x.ic+'</span><div><div class="ni-t">'+esc(x.t)+'</div><div class="ni-s">'+esc(x.s)+'</div></div></div>').join('')
   :'<div class="empty"><div class="b">✅</div>هیچ مورد نیازمند توجهی نیست<br><small style="color:var(--mut)">اقساط معوق، چک‌های سررسید‌شده و کالاهای کم‌موجود اینجا نمایش داده می‌شوند</small></div>')+
  (full.length>300?'<div style="padding:10px 16px;font-size:12px;color:var(--mut)">و '+fa(full.length-300)+' مورد دیگر — برای دیدن همه به لیست اقساط/چک‌ها بروید</div>':'')+'</div><div class="mfoot"><button class="btn" onclick="closeM()">بستن</button></div>');
}
let notifItems=[];

