/* ================= تسویه ================= */
const Fs={q:'',dir:''};
function vSettle(){
 let list=DB.receipts.slice().sort((a,b)=>b.date<a.date?-1:1);
 if(Fs.q){const q=faDig(Fs.q);list=list.filter(r=>{const tot=r.rows.reduce((a,x)=>a+pd(x.amount),0);return faDig([PN(r.person),r.date,String(r.no),r.desc||'',String(tot),r.rows.map(x=>METHOD_FA[x.method]).join('، ')].join(' ')).includes(q)||String(r.desc||'').includes(Fs.q)})}
 if(Fs.dir)list=list.filter(r=>r.dir===Fs.dir);
 const _pg_settle=pgSlice('settle',list,JSON.stringify(Fs),vSettle);
 $('content').innerHTML=`
 <div class="pgtitle"><h1>💱 تسویه — دریافت و پرداخت</h1><span class="sub">نقدی، کارت، واریزی، کارتخوان، اقساط، چک، نسیه، ترکیبی + چاپ رسید + پیامک رسید</span></div>
 <div class="card"><div class="searchbar">
  <input id="qIn" placeholder="🔍 شخص، شماره، تاریخ، مبلغ، روش..." value="${esc(Fs.q)}" style="min-width:260px" oninput="Fs.q=this.value;vSettle();rf('qIn')">
  <select onchange="Fs.dir=this.value;vSettle()"><option value="">همه</option><option value="in" ${Fs.dir==='in'?'selected':''}>دریافتی</option><option value="out" ${Fs.dir==='out'?'selected':''}>پرداختی</option></select>
  <button class="btn" onclick="Fs.q='';Fs.dir='';vSettle()">پاک کردن</button>
 </div>
 <div class="toolbar">
  <button class="btn g" onclick="settleForm('in')">＋ دریافت از مشتری</button>
  <button class="btn o" onclick="settleForm('out')">－ پرداخت به فروشنده</button>
  <button class="btn" onclick="xlOut(DB.receipts.map(r=>({'شماره':r.no,'تاریخ':r.date,'جهت':r.dir==='in'?'دریافت':'پرداخت','شخص':PN(r.person),'مبلغ':r.rows.reduce((s,x)=>s+pd(x.amount),0),'روش':r.rows.map(x=>METHOD_FA[x.method]).join('، '),'شرح':r.desc})),'تسویه‌ها-تکنوکالا')">📊 اکسل</button>
 </div>
 ${pgBar('settle','top')}<table data-rn="settle"><thead><tr><th>شماره</th><th>تاریخ</th><th>جهت</th><th>شخص</th><th>روش‌ها</th><th>مبلغ</th><th>شرح</th><th>عملیات</th></tr></thead><tbody>
 ${_pg_settle.map(r=>{const s=r.rows.reduce((a,x)=>a+pd(x.amount),0);return `<tr>
  <td>${fa(r.no)}</td><td>${jShort(r.date)}</td>
  <td><span class="bdg ${r.dir==='in'?'b-g':'b-o'}">${r.dir==='in'?'دریافت':'پرداخت'}</span></td>
  <td class="r">${esc(PN(r.person))}</td>
  <td>${r.rows.map(x=>METHOD_FA[x.method]||x.method).join('، ')}</td>
  <td class="amt ${r.dir==='in'?'pos':'neg'}">${fm(s)}</td><td class="r">${esc(r.desc||'')}</td>
  <td style="white-space:nowrap"><button class="btn sm" onclick="printReceipt('${r.id}','${r.dir==='in'?'rec':'pay'}')">🖨️ رسید</button>
  <button class="btn sm o" onclick="receiptSMS('${r.id}')" title="پیامک رسید">✉️</button>
  <button class="btn sm r" onclick="settleDel('${r.id}')">🗑️</button></td></tr>`}).join('')||'<tr><td colspan="8"><div class="empty">موردی نیست</div></td></tr>'}
 </tbody></table>${pgBar('settle')}</div>`;
}
/* ✉️ پیامک رسید دریافت/پرداخت */
function receiptSMS(id){
 const r=DB.receipts.find(x=>x.id===id);if(!r)return;const p=P(r.person);
 if(!p||!p.phone){toast('⚠️ موبایل شخص ثبت نشده',false);return}
 const amt=r.rows.reduce((s,x)=>s+pd(x.amount),0);
 const msg=smsFill(smsTpl('Pay'),{name:p.name,amount:amt,date:r.date,no:r.no});
 askM('✉️ پیامک رسید','متن پیامک به '+esc(p.name)+' ('+esc(p.phone)+'):',msg,txt=>sendSMS(p.phone,txt));
}
function settleForm(dir,person){
 window._setDir=dir;
 window._sp=[{method:'cash',amount:0,acc:'',chkNo:'',chkBank:'',chkDue:''}];
 openM(mHead(dir==='in'?'💵 دریافت از مشتری':'💸 پرداخت به فروشنده')+'<div class="mbody">'+
 '<div class="frow"><div class="fg"><label>تاریخ</label><input id="stDate" value="'+jToday()+'" style="width:110px"></div>'+
 '<div class="fg"><label>شخص</label><select id="stPerson" onchange="stInstShow()">'+DB.persons.map(p=>'<option value="'+p.id+'" '+(person===p.id?'selected':'')+'>'+esc(p.name)+'</option>').join('')+'</select></div></div>'+
 '<div class="sec-h">📅 اقساط باز این شخص:</div><div id="stInst" style="font-size:11.5px;color:#7a8a99;margin-bottom:8px"></div>'+
 '<table><thead><tr><th>روش</th><th>مبلغ</th><th>حساب</th><th>چک: شماره / بانک / سررسید</th><th></th></tr></thead><tbody id="spTb"></tbody></table>'+
 '<div class="toolbar"><button class="btn sm" onclick="spAdd()">＋ ردیف</button><button class="btn sm g" onclick="spFillDebt()">⚡ بدهی کل → نقد</button></div>'+
 '<div class="fg" style="margin-top:10px"><label>شرح</label><input id="stDesc" style="width:100%"></div>'+
 '<div id="stTot" style="margin-top:8px;font-weight:800"></div></div>'+
 '<div class="mfoot"><button class="btn p" onclick="settleSave()">💾 ثبت و صدور رسید</button><button class="btn" onclick="closeM()">انصراف</button></div>',true);
 spRender();stInstShow();
}
function spFillDebt(){
 const pid=($('stPerson')||{}).value;if(!pid)return;
 const b=personBalance(pid);
 const debt=window._setDir==='in'?b.saleDebt:b.buyDebt;
 if(debt<=0){toast(window._setDir==='in'?'⚠️ این شخص بدهی ندارد':'⚠️ بدهی به این فروشنده نداریم',false);return}
 window._sp=[{method:'cash',amount:debt,acc:'',chkNo:'',chkBank:'',chkDue:''}];
 spRender();toast('✅ مبلغ '+fm(debt)+' تومان (کل بدهی) آماده ثبت است');
}
function stInstShow(){
 const el=$('stInst');if(!el)return;
 const pid=($('stPerson')||{}).value;
 const list=DB.installments.filter(i=>i.person===pid&&!i.paid).sort((a,b)=>a.due<b.due?-1:1);
 el.innerHTML=list.length?list.slice(0,8).map(i=>'قسط '+fa(i.no)+' — سررسید '+jShort(i.due)+' — '+fm(i.amount)+' تومان'+(jNorm(i.due)<=jToday()?' ⚠️':'')).join(' | '):'قسط بازی ندارد';
}
function spAdd(){window._sp.push({method:'cash',amount:0,acc:'',chkNo:'',chkBank:'',chkDue:''});spRender()}
function spDel(i){window._sp.splice(i,1);spRender()}
function spRender(){
 const tb=$('spTb');if(!tb)return;
 tb.innerHTML=window._sp.map((x,i)=>`<tr>
 <td><select onchange="window._sp[${i}].method=this.value;spRender()">${Object.keys(METHOD_FA).map(m=>`<option value="${m}" ${x.method===m?'selected':''}>${METHOD_FA[m]}</option>`).join('')}</select></td>
 <td><input class="money" style="width:130px" value="${fm(x.amount)}" oninput="window._sp[${i}].amount=pd(this.value);spTot()"></td>
 <td><select onchange="window._sp[${i}].acc=this.value"><option value="">—</option>${DB.accounts.map(a=>`<option value="${a.id}">${esc(a.title)}</option>`).join('')}</select></td>
 <td>${x.method==='cheque'?`<input placeholder="شماره" style="width:90px" oninput="window._sp[${i}].chkNo=this.value"><input placeholder="بانک" style="width:70px" oninput="window._sp[${i}].chkBank=this.value"><input placeholder="۱۴۰۳/۰۶/۰۱" style="width:100px" oninput="window._sp[${i}].chkDue=this.value">`:'—'}</td>
 <td><button class="btn sm r" onclick="spDel(${i})">✕</button></td></tr>`).join('');
 spTot();
}
function spTot(){const el=$('stTot');if(!el)return;const s=window._sp.reduce((a,x)=>a+pd(x.amount),0);el.innerHTML='جمع: <span class="pos">'+fm(s)+' تومان</span>'+(window._sp.length>1?' <span class="bdg b-g">ترکیبی</span>':'')}
function settleSave(){
 const date=jNorm(($('stDate')||{}).value);if(!jValid(date)){toast('⚠️ تاریخ نامعتبر',false);return}
 const rows=window._sp.filter(x=>pd(x.amount)>0);if(!rows.length){toast('⚠️ مبلغی وارد نشده',false);return}
 const person=($('stPerson')||{}).value;if(!person){toast('⚠️ شخص را انتخاب کنید',false);return}
 const rid=uid();
 const rec={id:rid,no:nextNo('rec'),date,person,dir:window._setDir,rows:JSON.parse(JSON.stringify(rows)),desc:($('stDesc')||{}).value||''};
 DB.receipts.push(rec);
 rows.forEach(x=>{
  if(x.method==='cheque')DB.cheques.push({id:uid(),no:x.chkNo||'',dir:window._setDir==='in'?'rec':'paid',person,amount:pd(x.amount),due:jNorm(x.chkDue)||jAddD(date,30),issue:date,bank:x.chkBank||'',status:'جاری',inv:'',rid:rid,desc:'رسید '+rec.no});
  if(x.acc&&x.method!=='cheque')DB.accTx.push({id:uid(),acc:x.acc,date,type:window._setDir==='in'?'in':'out',amount:pd(x.amount),desc:'رسید '+rec.no+' — '+PN(person),ref:rid});
 });
 logAct((window._setDir==='in'?'دریافت ':'پرداخت ')+fm(rows.reduce((a,x)=>a+pd(x.amount),0))+' از/به '+PN(person));
 saveDB();closeM();vSettle();
 printReceipt(rid,window._setDir==='in'?'rec':'pay');
}
function settleDel(id){confirmM('حذف این رسید؟ تراکنش بانکی و چک‌های مرتبط نیز حذف می‌شود.',()=>{
 const rc=DB.receipts.find(r=>r.id===id);
 if(rc&&rc.instId){const it=DB.installments.find(x=>x.id===rc.instId);if(it){it.paid=false;it.paidDate='';delete it.paidMethod;delete it.amountPaid}}
 const rch=DB.cheques.filter(c=>c.rid===id).map(c=>c.id);
 DB.cheques=DB.cheques.filter(c=>c.rid!==id);
 DB.receipts=DB.receipts.filter(r=>r.id!==id);DB.accTx=DB.accTx.filter(t=>t.ref!==id&&!rch.includes(t.ref));logAct('حذف رسید');saveDB();vSettle()})}

