/* ===== مشخصات اختصاصی لپ‌تاپ (سری/نسل/مدل پردازنده، گرافیک، صفحه نمایش، کاربری) ===== */
const LAP_DEF={
 cpuSeries:['Core i3','Core i5','Core i7','Core i9','Core Ultra 5','Core Ultra 7','Core Ultra 9','Ryzen 3','Ryzen 5','Ryzen 7','Ryzen 9','Apple M','Celeron','Pentium'],
 cpuGens:['نسل 8','نسل 9','نسل 10','نسل 11','نسل 12','نسل 13','نسل 14','Core Ultra (سری 1)','Ryzen 5000','Ryzen 6000','Ryzen 7000','Ryzen 8000'],
 cpuModels:['Core i3-1215U','Core i5-1235U','Core i5-1335U','Core i7-1255U','Core i7-1355U','Core i5-12450H','Core i7-12700H','Core i7-13700H','Core Ultra 5 125H','Core Ultra 7 155H','Ryzen 5 5500U','Ryzen 5 7530U','Ryzen 7 5700U','Ryzen 7 7735HS','Apple M1','Apple M2','Apple M3'],
 gpus:['Intel UHD Graphics','Intel Iris Xe','Intel Arc','AMD Radeon Graphics','NVIDIA GeForce MX450','GTX 1650','RTX 2050','RTX 3050','RTX 3060','RTX 4050','RTX 4060','RTX 4070','Apple GPU'],
 screenSizes:['13.3 اینچ','14 اینچ','15.6 اینچ','16 اینچ','17.3 اینچ'],
 laptopUsages:['اداری','دانشجویی','گیمینگ','طراحی و گرافیک','مهندسی','سبک و قابل حمل'],
 laptopConds:['نو','استوک']
};
/* قیمت فروش لپ‌تاپ به‌طور خودکار = قیمت خرید + ۲۰ میلیون تومان (و سقف سود لپ‌تاپ همین مقدار است) */
const LAP_MARGIN=20000000;
function profitCapOf(gid){return lapIsGroup(gid)?LAP_MARGIN:MAX_PROFIT}
function lapOpts(k){
 DB.productOptions=DB.productOptions||{};
 if(!Array.isArray(DB.productOptions[k])||!DB.productOptions[k].length)DB.productOptions[k]=[...(LAP_DEF[k]||[])];
 return DB.productOptions[k];
}
function lapIsGroup(gid){const g=(DB.productGroups||[]).find(x=>x.id===gid);return !!g&&/laptop|لپ/i.test(g.name)}
function lapCpu(o){return o.cpuModel||[o.cpuSeries,o.cpuGen].filter(Boolean).join(' ')}
function lapSpecText(p){
 if(!p)return '';
 const a=[];const cpu=lapCpu(p);
 if(cpu)a.push('پردازنده: '+cpu+(p.cpuModel&&p.cpuGen?' ('+p.cpuGen+')':''));
 if(p.gpu)a.push('گرافیک: '+p.gpu);
 if(p.screen)a.push('صفحه: '+p.screen);
 if(p.usage)a.push('کاربری: '+p.usage);
 if(p.cond)a.push('وضعیت: '+p.cond);
 return a.join(' — ');
}
function lapSpecHtml(p){const t=lapSpecText(p);return t?'<div style="font-size:10.5px;color:#4a6b8a">💻 '+esc(t)+'</div>':''}
function lapSearch(p){return [p.cpuSeries,p.cpuGen,p.cpuModel,p.gpu,p.screen,p.usage,p.cond].filter(Boolean).join(' ')}
function lapSection(){
 if(!PW||!lapIsGroup(PW.group))return '';
 const G='display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:10px;margin-bottom:12px';
 const o=k=>lapOpts(k).map(x=>[x,x]),set=f=>'PW.'+f+'=this.value;pwRender()';
 return '<div class="sec-h" style="margin:6px 0 10px">💻 مشخصات لپ‌تاپ</div><div class="pw-g" style="'+G+'">'+
  pwSelect('🧠 سری پردازنده',o('cpuSeries'),PW.cpuSeries,set('cpuSeries'),'cpuSeries')+
  pwSelect('📶 نسل پردازنده',o('cpuGens'),PW.cpuGen,set('cpuGen'),'cpuGen')+
  pwSelect('🔧 مدل پردازنده',o('cpuModels'),PW.cpuModel,set('cpuModel'),'cpuModel')+
  pwSelect('🎮 پردازنده گرافیکی',o('gpus'),PW.gpu,set('gpu'),'gpu')+
  pwSelect('🖥️ صفحه نمایش',o('screenSizes'),PW.screen,set('screen'),'screen')+
  pwSelect('🎯 کاربری',o('laptopUsages'),PW.usage,set('usage'),'usage')+
  pwSelect('🏷️ وضعیت (نو / استوک)',o('laptopConds'),PW.cond,set('cond'),'cond')+'</div>'+
  '<div style="font-size:11.5px;color:var(--mut);margin:-4px 0 10px">💡 برای لپ‌تاپ، قیمت فروش به‌طور خودکار «قیمت خرید + ۲۰ میلیون تومان» محاسبه می‌شود (در قسمت قیمت قابل تغییر است).</div>';
}
/* ویرایش مشخصات لپ‌تاپ‌های ثبت‌شده */
function lapEdit(pid){
 const p=PR(pid);if(!p)return;window._lapPid=pid;
 const f=(id,label,val,list)=>'<div class="fg"><label>'+label+'</label><input id="'+id+'" list="'+id+'L" value="'+esc(val||'')+'"><datalist id="'+id+'L">'+lapOpts(list).map(x=>'<option value="'+esc(x)+'">').join('')+'</datalist></div>';
 openM(mHead('💻 مشخصات لپ‌تاپ — '+esc(p.name))+'<div class="mbody"><div class="frow">'+
  f('lpSer','🧠 سری پردازنده',p.cpuSeries,'cpuSeries')+f('lpGen','📶 نسل پردازنده',p.cpuGen,'cpuGens')+f('lpMod','🔧 مدل پردازنده',p.cpuModel,'cpuModels')+
  f('lpGpu','🎮 پردازنده گرافیکی',p.gpu,'gpus')+f('lpScr','🖥️ صفحه نمایش',p.screen,'screenSizes')+f('lpUse','🎯 کاربری',p.usage,'laptopUsages')+f('lpCond','🏷️ وضعیت (نو / استوک)',p.cond,'laptopConds')+
  '</div><div style="font-size:11px;color:var(--mut);margin-top:6px">مقدار جدید را می‌توانید تایپ کنید؛ به فهرست گزینه‌ها اضافه می‌شود. نام و کد کالا تغییر نمی‌کند.</div></div>'+
  '<div class="mfoot"><button class="btn p" onclick="lapSave()">💾 ذخیره</button><button class="btn" onclick="closeM()">انصراف</button></div>');
}
function lapSave(){
 const p=PR(window._lapPid);if(!p)return;
 const map=[['lpSer','cpuSeries','cpuSeries'],['lpGen','cpuGen','cpuGens'],['lpMod','cpuModel','cpuModels'],['lpGpu','gpu','gpus'],['lpScr','screen','screenSizes'],['lpUse','usage','laptopUsages'],['lpCond','cond','laptopConds']];
 map.forEach(m=>{const v=String($(m[0]).value||'').trim();p[m[1]]=v;if(v){const a=lapOpts(m[2]);if(!a.some(x=>String(x).toLowerCase()===v.toLowerCase()))a.push(v)}});
 logAct('ویرایش مشخصات لپ‌تاپ: '+p.name);saveDB();closeM();try{nav(curView)}catch(e){}toast('✅ مشخصات ذخیره شد');
}
