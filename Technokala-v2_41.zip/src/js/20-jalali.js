/* ---------- تاریخ شمسی (تقویم جلالی — ماه و روز شمسی، نه میلادی) ---------- */
function g2j(gy,gm,gd){var gdm=[0,31,59,90,120,151,181,212,243,273,304,334],jy=(gy<=1600)?0:979;gy-=(gy<=1600)?621:1600;var gy2=(gm>2)?(gy+1):gy;var days=(365*gy)+Math.floor((gy2+3)/4)-Math.floor((gy2+99)/100)+Math.floor((gy2+399)/400)-80+gd+gdm[gm-1];jy+=33*Math.floor(days/12053);days%=12053;jy+=4*Math.floor(days/1461);days%=1461;if(days>365){jy+=Math.floor((days-1)/365);days=(days-1)%365}var jm=(days<186)?1+Math.floor(days/31):7+Math.floor((days-186)/30);var jd=1+((days<186)?(days%31):((days-186)%30));return[jy,jm,jd]}
function j2g(jy,jm,jd){var gy=(jy<=979)?621:1600;jy-=(jy<=979)?0:979;var days=(365*jy)+Math.floor(jy/33)*8+Math.floor(((jy%33)+3)/4)+78+jd+((jm<7)?(jm-1)*31:((jm-7)*30+186));gy+=400*Math.floor(days/146097);days%=146097;if(days>=36524){gy+=100*Math.floor(--days/36524);days%=36524;if(days>=365)days++}gy+=4*Math.floor(days/1461);days%=1461;if(days>=366){gy+=Math.floor((days-1)/365);days=(days-1)%365}var gd=days+1,sal=[0,31,((gy%4===0&&gy%100!==0)||(gy%400===0))?29:28,31,30,31,30,31,31,30,31,30,31],gm;for(gm=1;gm<13&&gd>sal[gm];gm++)gd-=sal[gm];return[gy,gm,gd]}
const p2=n=>String(n).padStart(2,'0');
function dateToJ(d){const j=g2j(d.getFullYear(),d.getMonth()+1,d.getDate());return j[0]+'/'+p2(j[1])+'/'+p2(j[2])}
function jToday(){return dateToJ(new Date())}
const _jnC=new Map();
function jNorm(s){if(!s)return '';const str=typeof s==='string';if(str){const c=_jnC.get(s);if(c!==undefined)return c}const m=faDig(s).trim().match(/^(\d{4})[\/\-\.](\d{1,2})[\/\-\.](\d{1,2})$/);const r=m?m[1]+'/'+p2(+m[2])+'/'+p2(+m[3]):'';if(str){if(_jnC.size>60000)_jnC.clear();_jnC.set(s,r)}return r}
function jToDate(s){const j=jNorm(s);if(!j)return new Date(NaN);const[a,b,c]=j.split('/').map(Number);const g=j2g(a,b,c);return new Date(g[0],g[1]-1,g[2])}
function jIso(s){const d=jToDate(s);if(isNaN(d))return '';return d.getFullYear()+'-'+p2(d.getMonth()+1)+'-'+p2(d.getDate())}
function invoiceDatePicked(value){if(!value)return;const d=new Date(value+'T00:00:00');if(!isNaN(d)){const j=dateToJ(d);$('ivDate').value=j;$('ivDateFa').textContent=fa(j)}}
function jMonthLen(y,m){if(m<1||m>12)return 0;const next=m===12?j2g(y+1,1,1):j2g(y,m+1,1);const current=j2g(y,m,1);return Math.round((new Date(next[0],next[1]-1,next[2])-new Date(current[0],current[1]-1,current[2]))/864e5)}
function jValid(s){const j=jNorm(s);if(!j)return false;const[y,m,d]=j.split('/').map(Number);return m>=1&&m<=12&&d>=1&&d<=jMonthLen(y,m)}
function jAddD(s,n){const dt=jToDate(s);dt.setDate(dt.getDate()+n);return dateToJ(dt)}
function jAddM(s,n){let[y,m,d]=jNorm(s).split('/').map(Number);const t=m+n;y+=Math.floor((t-1)/12);m=((t-1)%12+12)%12+1;d=Math.min(d,jMonthLen(y,m));return y+'/'+p2(m)+'/'+p2(d)}
const JM=['','فروردین','اردیبهشت','خرداد','تیر','مرداد','شهریور','مهر','آبان','آذر','دی','بهمن','اسفند'];
function jLong(s){const j=jNorm(s);if(!j)return '-';const[y,m,d]=j.split('/').map(Number);return fa(d+' '+JM[m]+' '+y)} /* مثال: ۱۲ مرداد ۱۴۰۳ */
function jShort(s){return fa(jNorm(s)||'-')}
function jKey(s){const j=jNorm(s);return j?j.slice(0,7):''}
const _jmC=new Map();
function jToMs(s){const j=jNorm(s);if(!j)return NaN;let v=_jmC.get(j);if(v===undefined){v=jToDate(j).getTime();if(_jmC.size>60000)_jmC.clear();_jmC.set(j,v)}return v}
function daysDiff(a,b){const x=jToMs(a),y=jToMs(b);if(isNaN(x)||isNaN(y))return 0;return Math.round((y-x)/864e5)}

