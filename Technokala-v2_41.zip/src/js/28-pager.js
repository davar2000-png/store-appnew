/* ===== صفحه‌بندی لیست‌های بزرگ =====
   با ده‌ها هزار ردیف، ساختن یک جدول بزرگ در مرورگر چند ثانیه طول می‌کشد؛ فقط یک صفحه (پیش‌فرض ۱۰۰ ردیف) ساخته می‌شود. */
const PGS={};
function pgSlice(key,list,sig,fn,per){
 const S=PGS[key]||(PGS[key]={page:0,per:per||100,sig:''});
 if(fn)S.fn=fn;
 if(S.sig!==sig){S.sig=sig;S.page=0}
 const pages=Math.max(1,Math.ceil(list.length/S.per));
 if(S.page>=pages)S.page=pages-1;if(S.page<0)S.page=0;
 S.total=list.length;
 return list.length<=S.per?list:list.slice(S.page*S.per,(S.page+1)*S.per);
}
function pgBar(key,pos){
 const S=PGS[key];if(!S||S.total<=50)return '';
 const pages=Math.max(1,Math.ceil(S.total/S.per)),a=S.page*S.per+1,b=Math.min(S.total,(S.page+1)*S.per);
 const btn=(l,p,dis)=>'<button class="btn sm" '+(dis?'disabled':'onclick="pgGo(\''+key+'\','+p+')"')+'>'+l+'</button>';
 return '<div class="pager" '+(pos==='top'?'id="pgA_'+key+'"':'')+'>'+btn('⏮',0,S.page===0)+btn('◀ قبلی',S.page-1,S.page===0)+
  '<span>صفحه <input type="number" min="1" max="'+pages+'" value="'+(S.page+1)+'" onchange="pgGo(\''+key+'\',(+this.value||1)-1)" style="width:62px;text-align:center"> از '+fa(pages)+' — ردیف '+fa(a)+' تا '+fa(b)+' از '+fa(S.total)+'</span>'+
  btn('بعدی ▶',S.page+1,S.page>=pages-1)+btn('⏭',pages-1,S.page>=pages-1)+
  '<select onchange="pgPer(\''+key+'\',this.value)" title="تعداد ردیف در هر صفحه">'+[50,100,200,500].map(n=>'<option value="'+n+'" '+(S.per===n?'selected':'')+'>'+fa(n)+' ردیف</option>').join('')+'</select></div>';
}
function pgGo(key,p){
 const S=PGS[key];if(!S)return;
 const pages=Math.max(1,Math.ceil(S.total/S.per));S.page=Math.max(0,Math.min(pages-1,p|0));
 if(S.fn)S.fn();
 try{const a=$('pgA_'+key);if(a&&a.scrollIntoView)a.scrollIntoView()}catch(e){}
}
function pgPer(key,v){const S=PGS[key];if(!S)return;S.per=Math.max(10,+v||100);S.page=0;if(S.fn)S.fn()}
