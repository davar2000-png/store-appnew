/* ================= 📈 سود و زیان، ترازنامه، هزینه‌ها و افتتاحیه ================= */
let accRange={from:'',to:''};
function jnInRange(jn,from,to){from=jNorm(from);to=jNorm(to);return jn.filter(e=>(!from||e.date>=from)&&(!to||e.date<=to))}
function sumAcc(jn){const m={};jn.forEach(e=>e.rows.forEach(r=>{m[r.a]=(m[r.a]||0)+r.d-r.c}));return m}
function plBuild(jn){
 const m=sumAcc(jn),g=c=>m[c]||0;
 const sales=-g('4101'),ret=g('4102'),disc=g('4103'),netSales=sales-ret-disc,cogs=g('5101'),buyDisc=-g('5102'),other=-g('4201');
 const exp=COA.filter(a=>a[2]==='X'&&g(a[0])).map(a=>({code:a[0],name:a[1],v:g(a[0])})),expTotal=exp.reduce((s,x)=>s+x.v,0);
 const gross=netSales-cogs;return{sales,ret,disc,netSales,cogs,gross,buyDisc,other,exp,expTotal,net:gross+buyDisc+other-expTotal};
}
function bsBuild(jn,fs){
 const m=sumAcc(jn),g=c=>m[c]||0,pl=plBuild(jn);
 const A=['1101','1102','1201','1202','1301'].map(c=>({name:COA_NAME[c],v:g(c)})),L=['2101','2102'].map(c=>({name:COA_NAME[c],v:-g(c)}));
 const fsN=jNorm(fs||'');
 const Q=fsN?(()=>{const prev=plBuild(jn.filter(e=>e.date<fsN)).net;return[{name:'سرمایه',v:-g('3101')},{name:'سود (زیان) انباشته سال‌های قبل',v:prev},{name:'سود (زیان) سال مالی جاری',v:pl.net-prev}]})()
  :[{name:'سرمایه',v:-g('3101')},{name:'سود (زیان) دوره',v:pl.net}];

 /* مانده‌ی خلاف ماهیت به سمت مقابل منتقل می‌شود (جمع ترازنامه تغییر نمی‌کند) */
 const rc=(a,from,to,nm)=>{const i=A.findIndex(x=>x.name===COA_NAME[from]);if(i>=0&&A[i].v<0){to.push({name:nm,v:-A[i].v});A[i].v=0}};
 rc(A,'1201',L,'پیش‌دریافت / بستانکاری مشتریان');
 const ip=L.findIndex(x=>x.name===COA_NAME['2101']);if(ip>=0&&L[ip].v<0){A.push({name:'پیش‌پرداخت به تامین‌کنندگان',v:-L[ip].v});L[ip].v=0}
 const sa=A.reduce((s,x)=>s+x.v,0),sl=L.reduce((s,x)=>s+x.v,0),sq=Q.reduce((s,x)=>s+x.v,0);
 return{A,L,Q,sa,sl,sq,balanced:sa===sl+sq};
}
function rangeBar(tab){return '<div class="toolbar"><label class="pw-inl">از<input style="width:100px" id="arF" value="'+esc(fa(accRange.from))+'"></label><label class="pw-inl">تا<input style="width:100px" id="arT" value="'+esc(fa(accRange.to))+'"></label><button class="btn" onclick="accRange={from:faDig($(\'arF\').value),to:faDig($(\'arT\').value)};accView(\''+tab+'\')">اعمال</button><button class="btn" onclick="accRange={from:\'\',to:\'\'};accView(\''+tab+'\')">همه دوره</button>'+(tab==='pl'&&DB.settings.fiscalStart?'<button class="btn" onclick="accRange={from:jNorm(DB.settings.fiscalStart),to:\'\'};accView(\'pl\')">سال مالی جاری</button>':'')+'</div>'}
function plHtml(jn){
 const f=accRange.from,to=accRange.to,r=plBuild(jnInRange(jn,f,to));
 const row=(n,v,b)=>'<tr'+(b?' style="font-weight:700"':'')+'><td>'+n+'</td><td>'+fm(v)+'</td></tr>';
 return rangeBar('pl')+'<table><tbody>'+row('فروش ناخالص',r.sales)+row('− برگشت از فروش',r.ret)+row('− تخفیف فروش',r.disc)+row('فروش خالص',r.netSales,1)+row('− بهای تمام‌شده کالای فروش‌رفته',r.cogs)+row('سود ناخالص',r.gross,1)+row('+ تخفیف خرید',r.buyDisc)+row('+ سایر درآمدها',r.other)+
  r.exp.map(x=>row('− '+x.name,x.v)).join('')+row('سود (زیان) خالص',r.net,1)+'</tbody></table>';
}
function bsHtml(jn){
 const to=accRange.to,b=bsBuild(jnInRange(jn,'',to),DB.settings.fiscalStart);
 const sec=(h,a,s)=>'<tr style="background:var(--panel-soft)"><td colspan="2"><b>'+h+'</b></td></tr>'+a.map(x=>'<tr><td>'+esc(x.name)+'</td><td>'+fm(x.v)+'</td></tr>').join('')+'<tr style="font-weight:700"><td>جمع</td><td>'+fm(s)+'</td></tr>';
 return '<div class="toolbar"><label class="pw-inl">تا تاریخ<input style="width:100px" id="arT" value="'+esc(fa(accRange.to))+'"></label><button class="btn" onclick="accRange={from:\'\',to:faDig($(\'arT\').value)};accView(\'bs\')">اعمال</button></div>'+
  '<table><tbody>'+sec('دارایی‌ها',b.A,b.sa)+sec('بدهی‌ها',b.L,b.sl)+sec('حقوق صاحبان سرمایه',b.Q,b.sq)+'</tbody></table><div style="margin-top:8px">'+(b.balanced?'✅ دارایی‌ها = بدهی‌ها + سرمایه':'❌ ترازنامه متوازن نیست')+'</div>';
}
function expView(){
 const L=(DB.expenses||[]).slice().sort((a,b)=>String(b.date).localeCompare(String(a.date)));
 openM(mHead('💸 هزینه‌ها')+'<div class="mbody"><div class="toolbar"><button class="btn p" onclick="expForm()">➕ ثبت هزینه</button></div>'+
  (L.length?'<table data-rn="0"><thead><tr><th>شماره</th><th>تاریخ</th><th>نوع</th><th>مبلغ</th><th>پرداخت</th><th>شرح</th><th></th></tr></thead><tbody>'+L.slice(0,100).map(x=>'<tr><td>'+fa(x.no)+'</td><td>'+jShort(x.date)+'</td><td>'+esc(COA_NAME[x.cat]||'')+'</td><td>'+fm(x.amount)+'</td><td>'+(x.method==='cash'?'نقد':x.method==='credit'?'نسیه — '+esc(PN(x.person)):'بانک')+'</td><td>'+esc(x.desc||'')+'</td><td><button class="btn r" onclick="expDel(\''+x.id+'\')">🗑️</button></td></tr>').join('')+'</tbody></table>':'<div class="empty">هزینه‌ای ثبت نشده</div>')+
  '</div><div class="mfoot"><button class="btn" onclick="closeM()">بستن</button></div>');
}
function expForm(){
 openM(mHead('➕ ثبت هزینه')+'<div class="mbody"><div class="frow"><div class="fg"><label>تاریخ</label><input id="exD" value="'+jToday()+'" style="width:110px"></div>'+
  '<div class="fg"><label>نوع هزینه</label><select id="exC">'+COA.filter(a=>a[2]==='X').map(a=>'<option value="'+a[0]+'">'+a[1]+'</option>').join('')+'</select></div>'+
  '<div class="fg"><label>مبلغ (تومان)</label><input id="exA" class="money"></div></div><div class="frow">'+
  '<div class="fg"><label>پرداخت از</label><select id="exM"><option value="cash">صندوق</option><option value="bank">بانک</option><option value="credit">نسیه (بدهی به شخص)</option></select></div>'+
  '<div class="fg"><label>شخص (برای نسیه)</label><select id="exP"><option value="">—</option>'+DB.persons.map(p=>'<option value="'+p.id+'">'+esc(p.name)+'</option>').join('')+'</select></div>'+
  '<div class="fg"><label>حساب بانکی</label><select id="exK">'+DB.accounts.map(a=>'<option value="'+a.id+'">'+esc(a.title)+'</option>').join('')+'</select></div>'+
  '<div class="fg"><label>شرح</label><input id="exT"></div></div></div><div class="mfoot"><button class="btn p" onclick="expSave()">ثبت</button><button class="btn" onclick="expView()">انصراف</button></div>');
}
function expSave(){
 const date=jNorm(faDig($('exD').value)),amount=pd($('exA').value),method=$('exM').value,acc=$('exK').value;
 if(!jValid(date)){toast('⚠️ تاریخ معتبر نیست',false);return}
 if(!(amount>0)){toast('⚠️ مبلغ را وارد کنید',false);return}
 if(lockBlocked(date))return;
 if(method==='bank'&&!acc){toast('⚠️ حساب بانکی تعریف نشده',false);return}
 const id=uid(),no=nextNo('exp');
 const per=method==='credit'?$('exP').value:'';if(method==='credit'&&!per){toast('⚠️ برای هزینه نسیه شخص را انتخاب کنید',false);return}
 DB.expenses.push({id,no,date,cat:$('exC').value,amount,method,acc:method==='bank'?acc:'',person:per,desc:$('exT').value.trim()});
 if(method==='bank')DB.accTx.push({id:uid(),acc,date,type:'out',amount,desc:'هزینه '+(COA_NAME[$('exC').value]||''),ref:id});
 logAct('ثبت هزینه '+(COA_NAME[$('exC').value]||'')+' — '+fm(amount));saveDB();expView();toast('✅ هزینه ثبت شد');
}
function expDel(id){
 const x=DB.expenses.find(e=>e.id===id);if(!x||lockBlocked(x.date))return;
 confirmM('حذف هزینه شماره <b>'+fa(x.no)+'</b>؟',()=>{DB.expenses=DB.expenses.filter(e=>e.id!==id);DB.accTx=DB.accTx.filter(t=>t.ref!==id);logAct('حذف هزینه شماره '+x.no+' — '+fm(x.amount));saveDB();expView()});
}
function openForm(){
 const o=DB.opening||{};
 openM(mHead('💼 موجودی اول دوره')+'<div class="mbody"><div class="frow"><div class="fg"><label>تاریخ شروع</label><input id="opD" value="'+esc(fa(o.date||jToday()))+'" style="width:110px"></div>'+
  '<div class="fg"><label>صندوق</label><input id="opC" class="money" value="'+fm(o.cash||0)+'"></div><div class="fg"><label>ارزش موجودی کالا</label><input id="opI" class="money" value="'+fm(o.inventory||0)+'"></div></div>'+
  '<small style="color:var(--mut)">موجودی اول دوره بانک از «مانده اول دوره» حساب‌های بانکی گرفته می‌شود. سرمایه خودکار محاسبه می‌شود.</small></div><div class="mfoot"><button class="btn p" onclick="openSave()">ذخیره</button><button class="btn" onclick="closeM()">بستن</button></div>');
}
function openPersons(){
 const op=(DB.opening||{}).persons||{};
 openM(mHead('👥 مانده اول دوره اشخاص')+'<div class="mbody"><small style="color:var(--mut)">«طلب ما» یعنی شخص به ما بدهکار است؛ «بدهی ما» یعنی ما به او بدهکاریم. این مبالغ در مانده حساب شخص هم اعمال می‌شود.</small>'+
  '<table data-rn="0"><thead><tr><th>شخص</th><th>طلب ما</th><th>بدهی ما</th></tr></thead><tbody>'+DB.persons.map((p,i)=>'<tr><td>'+esc(p.name)+'</td><td><input class="money" id="opr'+i+'" value="'+fm((op[p.id]||{}).rec||0)+'" style="width:110px"></td><td><input class="money" id="opy'+i+'" value="'+fm((op[p.id]||{}).pay||0)+'" style="width:110px"></td></tr>').join('')+'</tbody></table></div>'+
  '<div class="mfoot"><button class="btn p" onclick="openPersonsSave()">ذخیره</button><button class="btn" onclick="closeM()">بستن</button></div>');
}
function openPersonsSave(){
 const m={};DB.persons.forEach((p,i)=>{const rec=pd($('opr'+i).value),pay=pd($('opy'+i).value);if(rec||pay)m[p.id]={rec,pay}});
 DB.opening=Object.assign({date:'',cash:0,inventory:0},DB.opening||{},{persons:m});
 logAct('ثبت مانده اول دوره اشخاص');saveDB();closeM();toast('✅ ذخیره شد');
}

function openSave(){
 const date=jNorm(faDig($('opD').value));if(!jValid(date)){toast('⚠️ تاریخ معتبر نیست',false);return}
 DB.opening=Object.assign({},DB.opening||{},{date,cash:pd($('opC').value),inventory:pd($('opI').value)});logAct('ثبت موجودی اول دوره');saveDB();closeM();toast('✅ ذخیره شد');
}

