/* ===== نسخه‌ی ویندوز (Electron): فقط وقتی فعال می‌شود که برنامه داخل پوسته‌ی دسکتاپ باز شده باشد ===== */
(function(){
 const A=window.desktopAPI;if(!A)return;
 /* ۱) درخواست‌های http به گوشی از طریق برنامه‌ی اصلی انجام می‌شود (بدون محدودیت CORS) */
 const _f=window.fetch.bind(window);
 window.fetch=function(u,o){
  if(typeof u==='string'&&(/^http:\/\//i.test(u)||/^https:\/\/(tapi\.bale\.ai|botapi\.rubika\.ir)\//i.test(u))){
   o=o||{};
   return A.httpFetch(u,{method:o.method||'GET',headers:o.headers||{},body:o.body||null,timeout:/^https:/i.test(u)?20000:8000}).then(r=>{
    if(r.error)throw new TypeError(r.error);
    return new Response([204,205,304].includes(r.status)?null:r.body,{status:r.status});
   });
  }
  return _f(u,o);
 };
 /* ۲) پوشه‌ی بکاپ: جایگزین showDirectoryPicker با دسترسی مستقیم به فایل */
 window.showDirectoryPicker=async function(opt){
  const r=await A.pickDir((opt&&opt.startIn)||'');if(!r)throw new DOMException('cancelled','AbortError');
  return {name:r.name,kind:'directory',
   queryPermission:async()=>'granted',requestPermission:async()=>'granted',
   getFileHandle:async(fn)=>({createWritable:async()=>{let buf='';return{write:async d=>{buf+=d},close:async()=>{await A.writeFile(r.path,fn,buf)}}}}),
   values:async function*(){for(const n of await A.listFiles(r.path))yield{kind:'file',name:n}},
   removeEntry:async n=>{await A.removeFile(r.path,n)}};
 };
})();
