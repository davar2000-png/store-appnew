/* ===== انتخاب و وصول گروهی اقساط ===== */
const INSTSEL=new Set();let _instLast=null;
function instSelInfo(){
 const X=ix();let n=0,sum=0,ppl=new Set();
 INSTSEL.forEach(id=>{const i=X.inst.get(id);if(i&&!i.paid){n++;sum+=Number(i.amount)||0;ppl.add(i.person)}});
 return{n,sum,p:ppl.size};
}
function instSelBarHtml(){
 const f=instSelInfo(),open=(window._instList||[]).filter(i=>!i.paid).length;
 const btn=(c,fn,l,dis)=>'<button class="btn sm '+c+'" '+(dis?'disabled':'onclick="'+fn+'"')+'>'+l+'</button>';
 const gs=instGroups(),sg=window._sdG!==undefined?window._sdG:(Fi.grp||''),sd=window._sdD||jToday(),far=gs.find(g=>g.id==='ig-faraja');
 return '<div class="card" style="margin-bottom:6px;padding:7px 12px;display:flex;gap:8px;align-items:center;flex-wrap:wrap'+(f.n?';border:1px solid #16a34a;background:#f0fdf4':'')+'">'+
  '<b>☑️ وصول گروهی</b>'+
  (f.n?'<span>انتخاب‌شده: <b>'+fa(f.n)+'</b> قسط از <b>'+fa(f.p)+'</b> نفر — جمع <b>'+fm(f.sum)+'</b> تومان</span>'+btn('g','instBulkOpen()','💵 ثبت وصول گروهی…')+btn('','instSelClear()','⬜ پاک کردن انتخاب'):'<span style="font-size:12px;color:var(--mut)">با تیک ردیف‌ها (Shift برای بازه) قسط‌ها را انتخاب کنید</span>')+
  (f.n?btn('o','instSelSMS()','✉️ پیامک گروهی انتخاب‌شده‌ها'):'')+
  btn('o','instListSMS()','✉️ پیامک گروهی نتایج باز ('+fa(open)+')',!open)+
  btn('','instEntryAlert(true)','🔔 اقساط امروز و معوق مشتریان عادی')+
  btn('o','instSelAll()','☑️ همه‌ی نتایج باز ('+fa(open)+')',!open)+
  (far?btn('g','instSelDueFor(\'ig-faraja\')','⚡ '+esc(far.name)+': سررسیدشده‌ها'):'')+
  '<span style="display:flex;gap:4px;align-items:center;font-size:12px">سررسیدشده‌های <select id="sdG" onchange="window._sdG=this.value">'+'<option value="">همه‌ی لیست‌ها</option>'+gs.map(g=>'<option value="'+g.id+'" '+(g.id===sg?'selected':'')+'>'+esc(g.name)+'</option>').join('')+'</select> تا <input id="sdD" value="'+esc(sd)+'" style="width:92px;direction:ltr" onchange="window._sdD=this.value">'+btn('','instSelDue()','انتخاب')+'</span></div>';
}
/* انتخاب قسط‌های باز با سررسید تا تاریخ مشخص (پیش‌فرض: امروز) برای یک لیست یا همه */
function instSelDueFor(gid,cutoff){
 const today=jToday(),cut=jNorm(cutoff||today);
 if(!jValid(cut)){toast('⚠️ تاریخ نامعتبر است',false);return 0}
 INSTSEL.clear();_instLast=null;
 let n=0;DB.installments.forEach(i=>{if(i.paid)return;if(gid&&instGrp(i)!==gid)return;if(jNorm(i.due)<=cut){INSTSEL.add(i.id);n++}});
 Fi.grp=gid||'';Fi.q='';Fi.plan='';Fi.mode=cut===today?'due':'open';
 window._sdG=gid||'';window._sdD=cut;
 vInst('list');
 toast(n?'☑️ '+fa(n)+' قسط سررسیدشده'+(gid?' از «'+instGName(gid)+'»':'')+' انتخاب شد — «ثبت وصول گروهی» را بزنید':'ℹ️ قسط سررسیدشده‌ی بازی پیدا نشد',!!n);
 return n;
}
function instSelDue(){instSelDueFor($('sdG')?$('sdG').value:'',$('sdD')?$('sdD').value:'')}
function instSelUpd(){
 const b=$('instSelBar');if(b)b.innerHTML=instSelBarHtml();
 const h=$('instSelHead');if(h){const ids=window._instPageIds||[];h.checked=ids.length>0&&ids.every(id=>INSTSEL.has(id))}
}
function instSelToggle(id,v,ev){
 const ids=window._instPageIds||[];
 if(ev&&ev.shiftKey&&_instLast&&ids.includes(_instLast)&&ids.includes(id)){
  const a=ids.indexOf(_instLast),b=ids.indexOf(id);
  ids.slice(Math.min(a,b),Math.max(a,b)+1).forEach(x=>v?INSTSEL.add(x):INSTSEL.delete(x));
  _instLast=id;vInst('list');return;
 }
 if(v)INSTSEL.add(id);else INSTSEL.delete(id);
 _instLast=id;instSelUpd();
 const tr=$('instr_'+id);if(tr&&tr.classList)tr.classList.toggle('rowsel',!!v);
}
function instSelPage(v){(window._instPageIds||[]).forEach(id=>v?INSTSEL.add(id):INSTSEL.delete(id));vInst('list')}
function instSelAll(){(window._instList||[]).forEach(i=>{if(!i.paid)INSTSEL.add(i.id)});vInst('list')}
function instSelClear(){INSTSEL.clear();_instLast=null;vInst('list')}
function instBulkOpen(){
 const X=ix(),list=[...INSTSEL].map(id=>X.inst.get(id)).filter(i=>i&&!i.paid).sort((a,b)=>a.due<b.due?-1:a.due>b.due?1:(a.no||0)-(b.no||0));
 if(!list.length){toast('⚠️ قسط بازی انتخاب نشده',false);return}
 const sum=list.reduce((s,i)=>s+Number(i.amount||0),0),ppl=new Set(list.map(i=>i.person)).size;
 openM(mHead('💵 ثبت وصول گروهی اقساط')+'<div class="mbody">'+
  '<div class="notice" style="margin-bottom:10px"><b>'+fa(list.length)+'</b> قسط از <b>'+fa(ppl)+'</b> نفر — جمع <b>'+fm(sum)+'</b> تومان. هر قسط به‌طور کامل (به مبلغ خودش) تسویه می‌شود.</div>'+
  '<div class="frow"><div class="fg"><label>تاریخ وصول</label><input id="bkDate" value="'+jToday()+'" style="width:110px"></div>'+
  '<div class="fg"><label>روش</label><select id="bkM">'+['cash','card','fish','account'].map(m=>'<option value="'+m+'">'+({cash:'نقد',card:'کارت',fish:'فیش',account:'حساب'})[m]+'</option>').join('')+'</select></div>'+
  '<div class="fg"><label>حساب بانکی (غیرنقد)</label><select id="bkAcc">'+DB.accounts.map((a,k)=>'<option value="'+a.id+'" '+(k===0?'selected':'')+'>'+esc(a.title)+'</option>').join('')+'</select></div></div>'+
  '<label style="font-size:12.5px;display:block;margin:6px 0"><input type="checkbox" id="bkThanks" '+(DB.settings.thanksOn!==false?'checked':'')+'> ارسال پیام تشکر به مشتریان (برای هر شخص یک پیام جمع‌شده)</label>'+
  '<div style="max-height:34vh;overflow:auto"><table data-rn="0"><thead><tr><th>شخص</th><th>قسط</th><th>سررسید</th><th>مبلغ</th></tr></thead><tbody>'+
  list.slice(0,60).map(i=>'<tr><td class="r">'+esc(PN(i.person))+'</td><td>'+fa(i.no)+'</td><td>'+jShort(i.due)+'</td><td class="amt">'+fm(i.amount)+'</td></tr>').join('')+
  (list.length>60?'<tr><td colspan="4" style="color:var(--mut)">و '+fa(list.length-60)+' قسط دیگر…</td></tr>':'')+'</tbody></table></div></div>'+
  '<div class="mfoot"><button class="btn p" onclick="instBulkRun()">✅ ثبت وصول '+fa(list.length)+' قسط</button><button class="btn" onclick="closeM()">انصراف</button></div>',true);
}
async function instBulkRun(){
 ixInvalidate();
 const date=jNorm($('bkDate').value)||jToday(),m=$('bkM').value,acc=$('bkAcc').value,thanks=!!$('bkThanks').checked;
 if(!jValid(date)){toast('⚠️ تاریخ نامعتبر است',false);return}
 if(m!=='cash'&&m!=='card'&&m!=='fish'&&m!=='account'){toast('⚠️ روش نامعتبر',false);return}
 if(m!=='cash'&&!acc){toast('⚠️ حساب بانکی را انتخاب کنید',false);return}
 const X=ix(),list=[...INSTSEL].map(id=>X.inst.get(id)).filter(i=>i&&!i.paid).sort((a,b)=>a.due<b.due?-1:a.due>b.due?1:(a.no||0)-(b.no||0));
 if(!list.length){toast('⚠️ قسط بازی انتخاب نشده',false);return}
 try{await snapshot('قبل از وصول گروهی اقساط',true)}catch(e){}
 let sum=0;const th=[];
 list.forEach(i=>{
  const amt=Number(i.amount)||0,inv=i.inv?X.invoice.get(i.inv):null,rid=uid();
  i.paid=true;i.paidDate=date;i.paidMethod=m;i.amountPaid=amt;
  DB.receipts.push({id:rid,instId:i.id,no:nextNo('rec'),date,person:i.person,dir:'in',rows:[{method:m,amount:amt,acc}],desc:'پرداخت قسط '+fa(i.no)+(inv?' — فاکتور '+fa(inv.no):'')+' (وصول گروهی)'});
  if(m!=='cash'&&acc)DB.accTx.push({id:uid(),acc,date,type:'in',amount:amt,desc:'قسط '+PN(i.person),ref:rid});
  sum+=amt;th.push({kind:'ThankInst',person:i.person,amount:amt,no:i.no,date});
 });
 INSTSEL.clear();_instLast=null;
 logAct('وصول گروهی '+list.length+' قسط — '+fm(sum)+' تومان');
 await saveDB();closeM();
 try{nav(curView||'inst')}catch(e){}
 if(thanks){try{msgThanksBatch(th)}catch(e){console.error(e)}}
 toast('✅ '+fa(list.length)+' قسط وصول شد — جمع '+fm(sum)+' تومان');
}
