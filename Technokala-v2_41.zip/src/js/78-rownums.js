/* ===== ستون «ردیف» برای همه‌ی لیست‌ها =====
   جدول‌هایی که با data-rn علامت‌گذاری شده‌اند پس از رندر یک ستون ردیف می‌گیرند.
   data-rn="کلید" یعنی لیست صفحه‌بندی‌شده است و شماره‌ها از شروع صفحه‌ی جاری ادامه پیدا می‌کنند (مثلاً صفحه‌ی ۲ از ۱۰۱). */
function rnApply(root){
 const list=(root||document).querySelectorAll('table[data-rn]');
 list.forEach(t=>{
  if(t.dataset.rnd==='1')return;
  const head=t.tHead&&t.tHead.rows[0]||t.rows[0],bodies=t.tBodies.length?Array.from(t.tBodies):[t];
  if(!head)return;
  t.dataset.rnd='1';
  const key=t.dataset.rn,S=key&&key!=='0'?PGS[key]:null,off=S?S.page*S.per:0;
  const th=document.createElement('th');th.className='rn';th.textContent='ردیف';head.insertBefore(th,head.cells[0]||null);
  let n=off;
  bodies.forEach(b=>Array.from(b.rows).forEach(r=>{
   if(r===head)return;
   if(r.cells.length&&r.cells[0].tagName==='TH'&&r.parentNode===t.tHead)return;
   if(r.cells.length===1&&(r.cells[0].colSpan||1)>1){r.cells[0].colSpan+=1;return}
   const td=document.createElement('td');td.className='rn';td.textContent=fa(++n);r.insertBefore(td,r.cells[0]||null);
  }));
  if(t.tFoot)Array.from(t.tFoot.rows).forEach(r=>{if(r.cells.length)r.cells[0].colSpan=(r.cells[0].colSpan||1)+1});
 });
}
