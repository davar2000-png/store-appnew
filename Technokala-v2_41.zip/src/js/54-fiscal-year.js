/* ================= 📅 سال مالی و بستن سال ================= */
function fyForm(){
 const s=DB.settings,fs=s.fiscalStart||'';
 openM(mHead('📅 سال مالی')+'<div class="mbody"><div class="frow"><div class="fg"><label>شروع سال مالی جاری</label><input id="fyS" value="'+esc(fa(fs))+'" placeholder="۱۴۰۴/۰۱/۰۱" style="width:120px"></div>'+
  '<div class="fg"><label>پایان سال (برای بستن)</label><input id="fyE" placeholder="۱۴۰۴/۱۲/۲۹" style="width:120px"></div></div>'+
  '<small style="color:var(--mut)">با بستن سال: دفاتر تا تاریخ پایان قفل می‌شود، سود آن سال به «سود انباشته» در ترازنامه منتقل می‌شود و سال مالی جدید از روز بعد شروع می‌شود. سندی تغییر نمی‌کند و قفل را می‌توان برداشت.</small></div>'+
  '<div class="mfoot"><button class="btn" onclick="fySave()">💾 فقط ذخیره شروع سال</button><button class="btn r" onclick="fyClose()">🔒 بستن سال مالی</button><button class="btn" onclick="closeM()">انصراف</button></div>');
}
function fySave(){
 const v=faDig($('fyS').value).trim();if(v&&!jValid(v)){toast('⚠️ تاریخ معتبر نیست',false);return}
 DB.settings.fiscalStart=v?jNorm(v):'';logAct('تنظیم شروع سال مالی '+(v?jShort(v):'—'));saveDB();closeM();toast('✅ ذخیره شد');
}
function fyClose(){
 const fs=jNorm(faDig($('fyS').value)),end=jNorm(faDig($('fyE').value));
 if(!jValid(fs)||!jValid(end)){toast('⚠️ تاریخ شروع و پایان سال را معتبر وارد کنید',false);return}
 if(end<fs){toast('⚠️ پایان سال قبل از شروع آن است',false);return}
 const L=jNorm(DB.settings.lockDate||'');if(L&&end<=L){toast('⚠️ دفاتر تا '+jShort(L)+' قبلاً بسته شده است',false);return}
 const net=plBuild(jnInRange(jnlBuild(),fs,end)).net;
 confirmM('بستن سال مالی از <b>'+jShort(fs)+'</b> تا <b>'+jShort(end)+'</b>؟<br>سود (زیان) سال: <b>'+fm(net)+'</b> تومان<br><small>دفاتر تا این تاریخ قفل و سال بعد از '+jShort(jAddD(end,1))+' شروع می‌شود.</small>',()=>{
  DB.settings.lockDate=end;DB.settings.fiscalStart=jAddD(end,1);
  logAct('بستن سال مالی تا '+jShort(end)+' — سود (زیان) '+fm(net));saveDB();toast('🔒 سال مالی بسته شد');
 });
}

