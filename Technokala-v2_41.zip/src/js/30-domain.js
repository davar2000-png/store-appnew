/* ---------- دامنه ---------- */
const P=id=>ix().person.get(id);
const PR=id=>ix().product.get(id);
const PN=id=>{const p=P(id);return p?p.name:'—'};
const GN=id=>{const g=ix().pgroup.get(id);return g?g.name:'—'};
/* هر شخص می‌تواند در چند گروه باشد: groups = آرایه‌ی شناسه‌ها؛ group = گروه اصلی (سازگاری با نسخه‌های قبل) */
const pGroups=p=>Array.isArray(p&&p.groups)&&p.groups.length?p.groups:(p&&p.group?[p.group]:[]);
const inGrp=(p,id)=>pGroups(p).includes(id);
const GNP=p=>{const n=pGroups(p).map(GN).filter(x=>x&&x!=='—');return n.length?n.join('، '):'—'};
const CL=id=>{const c=ix().color.get(id);return c?colorEnOf(c):'—'};
const COLOR_FA_EN={'سفید':'white','مشکی':'black','سیاه':'black','آبی':'blue','طلایی':'gold','نقره‌ای':'silver','نقره':'silver','قرمز':'red','سرخ':'red','سبز':'green','بنفش':'purple','صورتی':'pink','خاکستری':'gray','طوسی':'gray','زرد':'yellow','نارنجی':'orange','قهوه‌ای':'brown','بژ':'beige','فیروزه‌ای':'turquoise','یشمی':'jade','شرابی':'wine','یشمی‌روشن':'lightgreen'};
function colorEnOf(c){
 if(!c)return'';
 if(c.enName)return c.enName;
 const n=String(c.name||'').trim();
 return COLOR_FA_EN[n]||n.toLowerCase().replace(/\s+/g,'-');
}
const CLH=id=>{const c=DB.colors.find(x=>x.id===id);return c?(c.hex||'#95a5a6'):'#95a5a6'};
const ACC=id=>DB.accounts.find(a=>a.id===id);
function nextNo(kind){DB.counters[kind]=(DB.counters[kind]||1000)+1;return DB.counters[kind]}
function stockOf(pid){const p=PR(pid);if(!p)return 0;
 const S=ixStock();
 if(p.track==='serial')return Math.max(0,(S.ser.get(pid)||0)+(S.nosid.get(pid)||0));
 return S.all.get(pid)||0;
}
function stockExcl(pid,invId){const keep=DB.invoices;DB.invoices=keep.filter(i=>i.id!==invId);try{return stockOf(pid)}finally{DB.invoices=keep}}
function refreshLastCost(pids){
 (pids||[]).forEach(pid=>{const p=PR(pid);if(!p)return;let best=null;
  DB.invoices.forEach(inv=>{if(inv.type!=='buy')return;inv.lines.forEach(l=>{if(l.pid!==pid||!(Number(l.price)>0))return;
   if(!best||inv.date>best.date||(inv.date===best.date&&Number(inv.no)>best.no))best={date:inv.date,no:Number(inv.no),price:Number(l.price)}})});
  if(best)p.lastCost=best.price});
}
/* بهای تمام‌شده: میانگین موزون متحرک (پیش‌فرض) یا آخرین خرید — تنظیم «روش بهای تمام‌شده» */
function avgCostOf(pid){
 const p=PR(pid);let q=0,v=0;
 (ixLinesByPid().get(pid)||[]).forEach(([inv,l])=>{
  const n=Number(l.qty||0),a=q>0?v/q:0;
  if(inv.type==='buy'){q+=n;v+=n*Number(l.price||0)}
  else if(inv.type==='sale'||inv.type==='buyret'){const out=Math.min(n,Math.max(q,0));v-=a*out;q-=out}
  else if(inv.type==='saleret'){q+=n;v+=n*(Number(l.cost)||a)}
 });
 return q>0&&v>0?Math.round(v/q):((p&&p.lastCost)||0);
}
function unitCost(p){
 if(!p)return 0;
 if(p.track==='serial'||(DB.settings&&DB.settings.costMethod==='last'))return p.lastCost||0;
 return avgCostOf(p.id)||p.lastCost||0;
}
/* سقف برگشت: فروش (یا خرید) همان شخص منهای برگشت‌های قبلی */
function retRoom(person,pid,kind,exclId){
 const base=kind==='saleret'?'sale':'buy';let q=0;
 (ix().invByPerson.get(person)||[]).forEach(inv=>{
  if(inv.id===exclId)return;
  inv.lines.forEach(l=>{if(l.pid!==pid)return;const n=Number(l.qty||0);
   if(inv.type===base)q+=n;else if(inv.type===kind)q-=n})});
 return q;
}
function soldCostOf(person,pid){
 let q=0,v=0;
 (ix().invByPerson.get(person)||[]).forEach(inv=>{if(inv.type!=='sale')return;
  inv.lines.forEach(l=>{if(l.pid===pid){q+=Number(l.qty||0);v+=Number(l.qty||0)*Number(l.cost||0)}})});
 return q>0?Math.round(v/q):0;
}
function invTotal(inv){return inv.lines.reduce((s,l)=>s+l.qty*l.price,0)-pd(inv.discount||0)}
function invPaid(inv){return (inv.pays||[]).reduce((s,x)=>s+(x.method==='installment'?0:pd(x.amount)),0)}
function invProfit(inv){return inv.lines.reduce((s,l)=>s+(l.price-l.cost)*l.qty,0)}
function personBalance(pid){
 const X=ix();let sale=0,salePaid=0,prof=0,buy=0,buyPaid=0;
 for(const inv of X.invByPerson.get(pid)||IX_EMPTY){
  const t=inv.type;
  if(t==='sale'){sale+=invTotal(inv);salePaid+=invPaid(inv);prof+=invProfit(inv)}
  else if(t==='saleret'){sale-=invTotal(inv);salePaid-=invPaid(inv)}
  else if(t==='buy'){buy+=invTotal(inv);buyPaid+=invPaid(inv)}
  else if(t==='buyret'){buy-=invTotal(inv);buyPaid-=invPaid(inv)}
 }
 for(const r of X.recByPerson.get(pid)||IX_EMPTY){
  if(r.dir!=='in'&&r.dir!=='out')continue;
  const s=r.rows.reduce((a,x)=>a+pd(x.amount),0);
  if(r.dir==='in')salePaid+=s;else buyPaid+=s;
 }
 /* چک برگشتی دوباره بدهی می‌شود */
 for(const c of X.chqByPerson.get(pid)||IX_EMPTY){if(c.status==='برگشتی'){if(c.dir==='rec')sale+=Number(c.amount||0);else buy+=Number(c.amount||0)}}
 const po=((DB.opening||{}).persons||{})[pid]||{};
 for(const x of X.expByPerson.get(pid)||IX_EMPTY){if(x.method==='credit')buy+=x.amount}
 return{saleDebt:sale-salePaid+(po.rec||0),buyDebt:buy-buyPaid+(po.pay||0),profit:prof};
}
function accBal(a){return (a.open||0)+(ix().txByAcc.get(a.id)||IX_EMPTY).reduce((s,t)=>s+(t.type==='in'?1:-1)*t.amount,0)}
function cashBal(){return DB.receipts.reduce((sum,r)=>sum+(r.dir==='in'?1:-1)*r.rows.filter(x=>x.method==='cash').reduce((s,x)=>s+pd(x.amount),0),0)}
function serialStFa(st){return st==='stock'?['b-g','در انبار']:st==='registered'?['b-b','ثبت‌شده خارج از انبار']:st==='sold'?['b-m','فروخته‌شده']:['b-r','برگشتی']}

/* ---------- پیامک: قالب‌ها و پرکننده متغیرها ---------- */
function smsTpl(t){return DB.settings['smsTpl'+t]||''}
function smsFill(tpl,d){
 return String(tpl||'')
  .replace(/{shop}/g,DB.settings.shopName||'')
  .replace(/{name}/g,d.name||'')
  .replace(/{amount}/g,Number(d.amount||0).toLocaleString('en-US'))
  .replace(/{remain}/g,Number(d.remain||0).toLocaleString('en-US'))
  .replace(/{date}/g,d.date?jLong(d.date):'')
  .replace(/{due}/g,d.due?jLong(d.due):'')
  .replace(/{no}/g,String(d.no!=null?d.no:''))
  .replace(/{late}/g,String(d.late||0))
  .replace(/{count}/g,String(d.count||0));
}
/* ---------- یکپارچه‌سازی: Webhook عمومی ---------- */
function webhookPost(obj,label){
 const url=DB.settings.webhook;
 if(!url){toast('⚠️ آدرس Webhook در «ابزار ← تنظیمات» تنظیم نشده',false);return}
 fetch(url,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(obj)})
  .then(r=>{if(r.ok)toast('✅ '+label+' به برنامه خارجی ارسال شد');else toast('⚠️ پاسخ: '+r.status,false)})
  .catch(()=>toast('❌ ارسال ناموفق (CORS/شبکه)',false));
}

/* ---------- مودال ---------- */
function openM(html,wide){$('modal').className='mb open';$('modal').innerHTML='<div class="m'+(wide?' wide':'')+'">'+html+'</div>'}
function closeM(){$('modal').className='mb';$('modal').innerHTML=''}
function askM(title,label,val,cb,rows,okLabel){window._askCb=cb;openM(mHead(title)+'<div class="mbody"><label style="font-size:12px;display:block;margin-bottom:6px">'+label+'</label><textarea id="askTxt" rows="'+(rows||5)+'" style="width:100%"></textarea></div><div class="mfoot"><button class="btn p" onclick="askOk()">'+(okLabel||'📨 ارسال')+'</button><button class="btn" onclick="closeM()">انصراف</button></div>');$('askTxt').value=val||'';setTimeout(()=>{try{$('askTxt').focus()}catch(e){}},50)}
function askOk(){const v=($('askTxt').value||'').trim(),cb=window._askCb;closeM();if(v&&cb)cb(v)}
function mHead(t){return '<div class="mh"><h2>'+t+'</h2><button class="mx" onclick="closeM()">✕</button></div>'}
function confirmM(msg,cb){window._cb=cb;openM(mHead('⚠️ تایید')+'<div class="mbody">'+msg+'</div><div class="mfoot"><button class="btn r" onclick="const cb=window._cb;closeM();if(cb)cb()">بله، انجام بده</button><button class="btn" onclick="closeM()">انصراف</button></div>')}
let _mdBackdrop=false;
$('modal').addEventListener('mousedown',e=>{_mdBackdrop=(e.target.id==='modal')});
$('modal').addEventListener('click',e=>{if(e.target.id==='modal'&&_mdBackdrop)closeM();_mdBackdrop=false});

document.addEventListener('focusin',e=>{if(e.target.classList&&e.target.classList.contains('money'))e.target.value=String((e.target.id==='acOpen'?pdS:pd)(e.target.value)||'')});
document.addEventListener('focusout',e=>{if(e.target.classList&&e.target.classList.contains('money')){const n=(e.target.id==='acOpen'?pdS:pd)(e.target.value);e.target.value=n?n.toLocaleString('en-US'):''}});

