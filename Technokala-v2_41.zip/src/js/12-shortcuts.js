/* ================= میانبرهای صفحه‌کلید ================= */
document.addEventListener('keydown',e=>{
 const tag=(e.target.tagName||'').toLowerCase();
 const typing=tag==='input'||tag==='textarea'||tag==='select';
 /* Ctrl+K جستجوی سراسری — حتی داخل فیلد هم کار می‌کند */
 if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='k'){e.preventDefault();spOpen();return}
 /* Esc: اول مودال، بعد پنل جستجو */
 if(e.key==='Escape'){
  if($('searchPal').classList.contains('open')){spClose();return}
  if($('modal').classList.contains('open')){closeM();return}
  return;
 }
 if(typing||e.ctrlKey||e.metaKey||e.altKey)return;
 if(e.key==='F2'){e.preventDefault();invForm('sale');return}
 if(e.key==='F3'){e.preventDefault();nav('persons');return}
 if(e.key==='F4'){e.preventDefault();nav('products');return}
 if(e.key==='F5'){e.preventDefault();e.preventDefault();nav('dash');return}
 if(e.key==='F6'){e.preventDefault();nav('invoiceList');return}
 if(e.key==='F7'){e.preventDefault();nav('cheques');return}
 if(e.key==='F8'){e.preventDefault();nav('reports');return}
 if(e.key==='F9'){e.preventDefault();posOpen();return}
 if(e.key==='F12'){e.preventDefault();nav('tools');return}
});



