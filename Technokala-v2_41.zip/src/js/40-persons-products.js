/* ================================================================
   ================= داشبورد لحظه‌ای (v1.9) =========================
   ================================================================ */
let ch1=null,ch2=null,ch3=null;
function renderDash(){
 const today=jToday(),mk=jKey(today);
 let saleT=0,profT=0,recT=0,payT=0;
 DB.invoices.forEach(inv=>{if(inv.type!=='sale'||jKey(inv.date)!==mk)return;saleT+=invTotal(inv);profT+=invProfit(inv)});
 DB.receipts.forEach(r=>{if(jNorm(r.date)!==today)return;const s=r.rows.reduce((a,x)=>a+pd(x.amount),0);if(r.dir==='in')recT+=s;else payT+=s});
 let debt=0;DB.persons.forEach(p=>{const b=personBalance(p.id);if(b.saleDebt>0)debt+=b.saleDebt});
 /* اقساط */
 const openInst=DB.installments.filter(i=>!i.paid);
 const instDebt=openInst.reduce((s,i)=>s+i.amount,0);
 const dueInst=openInst.filter(i=>jNorm(i.due)<=today).sort((a,b)=>a.due<b.due?-1:1);
 const nearInst=openInst.filter(i=>jNorm(i.due)>today&&daysDiff(today,i.due)<=10);
 /* چک‌ها */
 const jari=DB.cheques.filter(c=>c.status==='جاری');
 const chqNet=jari.filter(c=>c.dir==='rec').reduce((s,c)=>s+c.amount,0)-jari.filter(c=>c.dir==='paid').reduce((s,c)=>s+c.amount,0);
 const nearChq=jari.filter(c=>{const d=daysDiff(today,c.due);return d<=10&&d>=-365}).sort((a,b)=>a.due<b.due?-1:1);
 const overChq=jari.filter(c=>jNorm(c.due)<today);
 const pendingDeliveries=DB.invoices.filter(i=>i.type==='buy'&&!i.delivered&&daysDiff(i.date,today)>7).sort((a,b)=>daysDiff(b.date,today)-daysDiff(a.date,today));
 /* انبار و بانک */
 const lowP=DB.products.filter(p=>stockOf(p.id)<=p.reorder);
 const bankBal=DB.accounts.reduce((s,a)=>s+accBal(a),0);
 const cash= cashBal();
 /* نمودارها */
 const monthSales={};DB.invoices.forEach(inv=>{if(inv.type!=='sale')return;const k=jKey(inv.date);if(!k)return;if(!monthSales[k])monthSales[k]={s:0,p:0};monthSales[k].s+=invTotal(inv);monthSales[k].p+=invProfit(inv)});
 const keys=Object.keys(monthSales).sort().slice(-6);
 const payMap={};DB.invoices.forEach(inv=>{if(inv.type!=='sale')return;(inv.pays||[]).forEach(x=>{const n=METHOD_FA[x.method]||x.method;payMap[n]=(payMap[n]||0)+pd(x.amount)})});
 const days7=[];for(let i=6;i>=0;i--)days7.push(jAddD(today,-i));
 const rec7=days7.map(d=>DB.receipts.filter(r=>jNorm(r.date)===d&&r.dir==='in').reduce((s,r)=>s+r.rows.reduce((a,x)=>a+pd(x.amount),0),0));
 const pay7=days7.map(d=>DB.receipts.filter(r=>jNorm(r.date)===d&&r.dir==='out').reduce((s,r)=>s+r.rows.reduce((a,x)=>a+pd(x.amount),0),0));
 $('content').innerHTML=`
 <div class="pgtitle"><h1>🏠 داشبورد لحظه‌ای</h1>
  <span class="sub">آخرین به‌روزرسانی: <b id="dashUpd">${new Date().toLocaleTimeString('fa-IR')}</b> — به‌روزرسانی خودکار هر ۶۰ ثانیه</span>
  <button class="btn sm" onclick="renderDash()" title="به‌روزرسانی فوری">🔄 به‌روزرسانی</button>
 </div>
 <div class="statgrid">
  <div class="stat"><div class="l">🧾 فروش امروز</div><div class="v">${fm(saleT)} <small>تومان</small></div></div>
  <div class="stat g"><div class="l">📈 سود امروز</div><div class="v pos">${fm(profT)} <small>تومان</small></div></div>
  <div class="stat g"><div class="l">💵 دریافتی امروز</div><div class="v pos">${fm(recT)}</div></div>
  <div class="stat r"><div class="l">💸 پرداختی امروز</div><div class="v neg">${fm(payT)}</div></div>
  <div class="stat r"><div class="l">⚠️ بدهی مشتریان</div><div class="v neg">${fm(debt)}</div></div>
  <div class="stat o"><div class="l">📌 مانده اقساط باز (بدهی)</div><div class="v">${fm(instDebt)}</div></div>
  <div class="stat ${dueInst.length?'r':'g'}"><div class="l">📅 اقساط سررسیدشده</div><div class="v ${dueInst.length?'neg':''}">${fa(dueInst.length)} عدد / ${fm(dueInst.reduce((a,i)=>a+i.amount,0))}</div></div>
  <div class="stat ${nearChq.length?'o':''}"><div class="l">🏦 چک‌های نزدیک سررسید (۱۰ روز)</div><div class="v">${fa(nearChq.length)} عدد</div></div>
  <div class="stat ${chqNet>=0?'g':'r'}"><div class="l">⚖️ خالص چک‌های جاری</div><div class="v ${chqNet>=0?'pos':'neg'}">${fm(chqNet)}</div></div>
  <div class="stat ${bankBal>=0?'g':'r'}"><div class="l">🏛️ موجودی حساب‌های بانکی</div><div class="v ${bankBal>=0?'pos':'neg'}">${fm(bankBal)}</div></div>
  <div class="stat ${cash>=0?'g':'r'}"><div class="l">💰 موجودی صندوق</div><div class="v ${cash>=0?'pos':'neg'}">${fm(cash)}</div></div>
  <div class="stat r"><div class="l">📦 کالاهای کم‌موجود</div><div class="v">${fa(lowP.length)} قلم</div></div>
  <div class="stat ${overChq.length?'r':''}"><div class="l">⛔ چک‌های سررسیدگذشته</div><div class="v ${overChq.length?'neg':''}">${fa(overChq.length)} فقره</div></div>
 </div>
 ${dueInst.length?`<div class="notice red"><b>🔔 هشدار لحظه‌ای: ${fa(dueInst.length)} قسط سررسیدگذشته و ${fa(overChq.length)} چک سررسیدگذشته دارید!</b></div>`:''}
 ${pendingDeliveries.length?`<div class="notice red"><b>📦 هشدار تحویل کالا: ${fa(pendingDeliveries.length)} فاکتور خرید بیش از ۷ روز است که تحویل آن ثبت نشده.</b> <a href="#" onclick="nav('purchase');return false" style="color:#8a2b20;font-weight:800">مشاهده فاکتورها</a></div>`:''}
 <div class="grid3">
  <div class="card"><h3>📊 فروش و سود ماه‌های اخیر (شمسی)</h3><div style="height:250px"><canvas id="c1"></canvas></div></div>
  <div class="card"><h3>🍩 ترکیب روش‌های دریافت</h3><div style="height:250px"><canvas id="c2"></canvas></div></div>
  <div class="card"><h3>💹 جریان نقدی ۷ روز اخیر</h3><div style="height:250px"><canvas id="c3"></canvas></div></div>
 </div>
 <div class="grid2">
  <div class="card"><h3>📅 اقساط سررسیدشده (${fa(dueInst.length)})</h3>${dueInst.length?`<table><thead><tr><th>شخص</th><th>قسط</th><th>سررسید (شمسی)</th><th>تأخیر</th><th>مبلغ</th><th></th></tr></thead><tbody>${dueInst.slice(0,6).map(i=>{const late=daysDiff(i.due,today);return `<tr><td class="r">${esc(PN(i.person))}</td><td>${fa(i.no)}</td><td class="neg">${jShort(i.due)}</td><td><span class="bdg b-r">${fa(late)} روز</span></td><td class="amt">${fm(i.amount)}</td><td style="white-space:nowrap"><button class="btn sm g" onclick="instPay('${i.id}')">💵 پرداخت</button> <button class="btn sm o" onclick="instSMS('${i.id}')">✉️</button></td></tr>`}).join('')}</tbody></table><div class="toolbar" style="margin-top:8px"><button class="btn sm" onclick="nav('inst')">مشاهده همه →</button></div>`:'<div class="empty"><div class="b">✅</div>اقساط سررسیدشده‌ای وجود ندارد</div>'}</div>
  <div class="card"><h3>🏦 چک‌های نزدیک سررسید (${fa(nearChq.length)})</h3>${nearChq.length?`<table><thead><tr><th>جهت</th><th>شخص</th><th>سررسید (شمسی)</th><th>روز مانده</th><th>روز گذشته</th><th>مبلغ</th></tr></thead><tbody>${nearChq.slice(0,6).map(c=>{const dd=daysDiff(today,c.due),remaining=Math.max(0,dd),past=Math.max(0,-dd);return `<tr><td><span class="bdg ${c.dir==='rec'?'b-g':'b-o'}">${c.dir==='rec'?'دریافتی':'پرداختی'}</span></td><td class="r">${esc(PN(c.person))}</td><td class="${dd<0?'neg':''}">${jShort(c.due)}</td><td>${remaining?'<span class="bdg b-b">'+fa(remaining)+'</span>':'—'}</td><td>${past?'<span class="bdg b-r">'+fa(past)+'</span>':'—'}</td><td class="amt">${fm(c.amount)}</td></tr>`}).join('')}</tbody></table><div class="toolbar" style="margin-top:8px"><button class="btn sm" onclick="nav('cheques')">مشاهده همه →</button></div>`:'<div class="empty"><div class="b">✅</div>چک نزدیک‌سررسیدی نیست</div>'}</div>
 </div>
 <div class="card"><h3>📦 کالاهای کم‌موجود (${fa(lowP.length)})</h3>${lowP.length?`<table data-rn="0"><thead><tr><th>کد</th><th>کالا</th><th>موجودی</th><th>نقطه سفارش</th><th>وضعیت</th></tr></thead><tbody>${lowP.slice(0,8).map(p=>{const s=stockOf(p.id);return `<tr><td>${esc(p.code)}</td><td class="r">${esc(p.name)}</td><td class="amt ${s===0?'neg':''}">${fa(s)}</td><td>${fa(p.reorder)}</td><td>${s===0?'<span class="bdg b-r">ناموجود!</span>':'<span class="bdg b-o">سفارش</span>'}</td></tr>`}).join('')}</tbody></table>`:'<div class="empty"><div class="b">✅</div>همه کالاها در وضعیت نرمال هستند</div>'}</div>`;
 if(window.Chart){Chart.defaults.font.family='Vazirmatn';
  if(ch1){ch1.destroy();ch1=null}if(ch2){ch2.destroy();ch2=null}if(ch3){ch3.destroy();ch3=null}
  ch1=new Chart($('c1'),{type:'bar',data:{labels:keys.map(k=>JM[+k.split('/')[1]]),datasets:[
   {label:'فروش',data:keys.map(k=>monthSales[k].s),backgroundColor:'#1a6fb5',borderRadius:6},
   {label:'سود',data:keys.map(k=>monthSales[k].p),backgroundColor:'#1e9e5a',borderRadius:6}]},
   options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{rtl:true},tooltip:{rtl:true,callbacks:{label:c=>' '+c.dataset.label+': '+fm(c.parsed.y)}}},scales:{y:{ticks:{callback:v=>fm(v)}}}}});
  ch2=new Chart($('c2'),{type:'doughnut',data:{labels:Object.keys(payMap),datasets:[{data:Object.values(payMap),backgroundColor:['#1a6fb5','#1e9e5a','#e67e22','#8e44ad','#c0392b'],borderWidth:3,borderColor:'#fff'}]},options:{responsive:true,maintainAspectRatio:false,cutout:'60%',plugins:{legend:{position:'bottom',rtl:true},tooltip:{rtl:true,callbacks:{label:c=>' '+c.label+': '+fm(c.parsed)}}}}});
  ch3=new Chart($('c3'),{type:'line',data:{labels:days7.map(d=>fa(d.slice(5))),datasets:[
   {label:'دریافت',data:rec7,borderColor:'#1e9e5a',backgroundColor:'rgba(30,158,90,.12)',fill:true,tension:.35},
   {label:'پرداخت',data:pay7,borderColor:'#d64541',backgroundColor:'rgba(214,69,65,.10)',fill:true,tension:.35}]},
   options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{rtl:true},tooltip:{rtl:true,callbacks:{label:c=>' '+c.dataset.label+': '+fm(c.parsed.y)}}},scales:{y:{ticks:{callback:v=>fm(v)}}}}});
 }
 /* به‌روزرسانی خودکار هر ۶۰ ثانیه */
 if(dashInt)clearInterval(dashInt);
 dashInt=setInterval(()=>{if(curView==='dash')renderDash()},60000);
}

/* ================================================================
   ==================== اشخاص (کامل) ===============================
   ================================================================ */
const Fp={q:'',adv:false,grp:'',nat:'',mob:'',job:'',emp:'',card:'',addr:'',debt:'',guar:'any',docs:'any',sort:'code'};
function resetPersonsFilters(){Object.assign(Fp,{q:'',grp:'',nat:'',mob:'',job:'',emp:'',card:'',addr:'',debt:'',guar:'any',docs:'any',sort:'code'})}

/* صفحه‌ی «معرفی اشخاص»: فرم ثبت شخص جدید مستقیم داخل صفحه باز می‌شود (بدون پنجره‌ی تمام‌صفحه)؛ مشاهده، ویرایش و حذف در «لیست اشخاص» */
function vPersonIntro(){
 const last=window._introLast||'';window._introLast=null;
 personForm(null,null,false,true,last);
}
function vPersons(){
 let list=DB.persons.filter(p=>{
  if(Fp.q){const q=faDig(Fp.q);const hay=faDig([p.name,p.code,p.phone,p.phone2,p.nationalId,p.job,p.empNo,p.card,p.addr,p.notes].join(' '));if(!hay.includes(q))return false}
  if(Fp.grp&&!inGrp(p,Fp.grp))return false;
  if(Fp.nat&&!(p.nationalId||'').includes(faDig(Fp.nat)))return false;
  if(Fp.mob&&!(p.phone||'').includes(faDig(Fp.mob))&&!((p.phone2||'').includes(faDig(Fp.mob))))return false;
  if(Fp.job&&!(p.job||'').includes(Fp.job))return false;
  if(Fp.emp&&!(p.empNo||'').includes(faDig(Fp.emp)))return false;
  if(Fp.card&&!(p.card||'').includes(faDig(Fp.card)))return false;
  if(Fp.addr&&!(p.addr||'').includes(Fp.addr))return false;
  const b=personBalance(p.id);
  if(Fp.debt&&b.saleDebt<pd(Fp.debt))return false;
  const hasG=p.guarantor&&p.guarantor.name;
  if(Fp.guar==='yes'&&!hasG)return false;
  if(Fp.guar==='no'&&hasG)return false;
  const hasD=(p.docs||[]).length>0;
  if(Fp.docs==='yes'&&!hasD)return false;
  if(Fp.docs==='no'&&hasD)return false;
  return true;
 });
 if(Fp.sort==='code')list.sort((a,b)=>a.code-b.code);
 if(Fp.sort==='named')list.sort((a,b)=>b.name.localeCompare(a.name,'fa'));
 if(Fp.sort==='name')list.sort((a,b)=>a.name.localeCompare(b.name,'fa'));
 if(Fp.sort==='debtd')list.sort((a,b)=>personBalance(b.id).saleDebt-personBalance(a.id).saleDebt);
 let nSup=0,totDebt=0;
 let nCust=0;DB.persons.forEach(p=>{if(isSupplierPerson(p))nSup++;if(pGroups(p).some(id=>!isSupplierGroup(DB.personGroups.find(g=>g.id===id))))nCust++;const b=personBalance(p.id);if(b.saleDebt>0)totDebt+=b.saleDebt});
 
 const _pg_persons=pgSlice('persons',list,JSON.stringify(Fp),vPersons);
 $('content').innerHTML=`
 <div class="pgtitle"><h1>👥 لیست اشخاص (مشتریان، فروشندگان، ضامن‌ها)</h1><span class="sub">${fa(list.length)} شخص از ${fa(DB.persons.length)}</span></div>
 <div class="statgrid">
  <div class="stat"><div class="l">👥 کل اشخاص</div><div class="v">${fa(DB.persons.length)}</div></div>
  <div class="stat g"><div class="l">🤝 مشتریان</div><div class="v">${fa(nCust)}</div></div>
  <div class="stat o"><div class="l">🏭 فروشندگان</div><div class="v">${fa(nSup)}</div></div>
  <div class="stat r"><div class="l">⚠️ جمع بدهی مشتریان</div><div class="v neg">${fm(totDebt)} <small>تومان</small></div></div>
 </div>
 <div class="card">
 <div class="searchbar">
  <input id="qIn" placeholder="🔍 جستجو: نام، کد، موبایل، کد ملی، شغل، کارت، آدرس..." value="${esc(Fp.q)}" style="min-width:300px" oninput="Fp.q=this.value;vPersons();rf('qIn')">
  <select onchange="Fp.grp=this.value;vPersons()"><option value="">همه گروه‌ها</option>${DB.personGroups.map(g=>`<option value="${g.id}" ${Fp.grp===g.id?'selected':''}>${g.name}</option>`).join('')}</select>
  <select onchange="Fp.sort=this.value;vPersons()"><option value="code" ${Fp.sort==='code'?'selected':''}>مرتب‌سازی: کد</option><option value="name" ${Fp.sort==='name'?'selected':''}>نام (الفبا)</option><option value="named" ${Fp.sort==='named'?'selected':''}>نام (برعکس)</option><option value="debtd" ${Fp.sort==='debtd'?'selected':''}>بیشترین بدهی</option></select>
  <button class="btn o" onclick="Fp.adv=!Fp.adv;vPersons()">${Fp.adv?'▲ بستن':'🔍 جستجوی پیشرفته'}</button>
  <button class="btn" onclick="resetPersonsFilters();vPersons()">پاک کردن فیلترها</button>
 </div>
 ${Fp.adv?`
 <div class="inlbox" style="margin-bottom:12px">
  <b style="font-size:11.5px;color:var(--hd)">🔍 جستجوی پیشرفته چندجانبه — هر فیلد را خالی بگذارید اعمال نمی‌شود:</b>
  <div class="frow" style="margin-top:8px">
   <div class="fg"><label>کد ملی (دقیق/جزئی)</label><input id="fNat" value="${esc(Fp.nat)}" oninput="Fp.nat=this.value;vPersons();rf('fNat')"></div>
   <div class="fg"><label>موبایل / تلفن</label><input id="fMob" value="${esc(Fp.mob)}" oninput="Fp.mob=this.value;vPersons();rf('fMob')"></div>
   <div class="fg"><label>شغل</label><input id="fJob" value="${esc(Fp.job)}" oninput="Fp.job=this.value;vPersons();rf('fJob')"></div>
   <div class="fg"><label>شماره کارمندی</label><input id="fEmp" value="${esc(Fp.emp)}" oninput="Fp.emp=this.value;vPersons();rf('fEmp')"></div>
  </div>
  <div class="frow">
   <div class="fg"><label>شماره کارت بانکی</label><input id="fCard" value="${esc(Fp.card)}" oninput="Fp.card=this.value;vPersons();rf('fCard')"></div>
   <div class="fg"><label>آدرس شامل...</label><input id="fAddr" value="${esc(Fp.addr)}" oninput="Fp.addr=this.value;vPersons();rf('fAddr')"></div>
   <div class="fg"><label>بدهی بیش از (تومان)</label><input id="fDebt" class="money" value="${Fp.debt?pd(Fp.debt).toLocaleString('en-US'):''}" oninput="Fp.debt=this.value;vPersons();rf('fDebt')"></div>
   <div class="fg"><label>وضعیت ضامن</label><select onchange="Fp.guar=this.value;vPersons()"><option value="any">همه</option><option value="yes" ${Fp.guar==='yes'?'selected':''}>ضامن دارد</option><option value="no" ${Fp.guar==='no'?'selected':''}>بدون ضامن</option></select></div>
   <div class="fg"><label>مدارک</label><select onchange="Fp.docs=this.value;vPersons()"><option value="any">همه</option><option value="yes" ${Fp.docs==='yes'?'selected':''}>مدرک دارد</option><option value="no" ${Fp.docs==='no'?'selected':''}>بدون مدرک</option></select></div>
  </div>
 </div>`:''}
 <div class="toolbar">
  <button class="btn p" onclick="personForm()">＋ شخص جدید</button>
  <button class="btn" onclick="personsDirectory()">📋 لیست اشخاص</button>
  <button class="btn" onclick="groupsM()">🗂️ مدیریت گروه‌ها</button>
  <button class="btn g" onclick="personExcelOut()">📊 خروجی اکسل</button>
  <label class="btn" style="cursor:pointer" title="گروه هر شخص از ستون «گروه» فایل خوانده می‌شود">📊 ورود از اکسل (ستون گروه)<input type="file" accept=".xlsx,.xls" style="display:none" onchange="xlIn(this,'persons')"></label>
  <button class="btn" onclick="printPersons()">🖨️ چاپ لیست</button>
 </div>
 ${pgImportPanel()}
 ${pgBar('persons','top')}<table data-rn="persons"><thead><tr><th>کد</th><th>عکس</th><th>نام</th><th>گروه</th><th>موبایل</th><th>کد ملی</th><th>شغل</th><th>مدارک</th><th>ضامن</th><th>مانده حساب (تومان)</th><th>عملیات</th></tr></thead><tbody>
 ${_pg_persons.map(p=>{const b=personBalance(p.id);const nd=(p.docs||[]).length;const hg=p.guarantor&&p.guarantor.name;
  return `<tr>
  <td>${fa(p.code)}</td>
  <td>${(p.thumb||p.photo)?`<img class="avatar zoomable" ${imgAttrs(p.thumb||p.photo)} ${isImgRef(p.photo)?`data-full="${p.photo}"`:''}>`:'<div class="avatar">👤</div>'}</td>
  <td class="r"><b>${esc(p.name)}</b></td>
  <td><span class="bdg b-b">${esc(GNP(p))}</span></td>
  <td>${fa(p.phone||'—')}</td><td>${fa(p.nationalId||'—')}</td><td>${esc(p.job||'—')}</td>
  <td>${nd?'<span class="bdg b-b" title="مشاهده در پرونده">📎 '+fa(nd)+'</span>':'—'}</td>
  <td>${hg?'<span class="bdg b-g" title="'+esc(p.guarantor.name)+'">🛡️ ✓</span>':'—'}</td>
  <td class="amt ${b.saleDebt>0?'neg':b.saleDebt<0?'pos':''}">${fm(b.saleDebt)}</td>
  <td style="white-space:nowrap">
   <button class="btn sm" onclick="personProfile('${p.id}')">👁️ پرونده</button>
   <button class="btn sm" onclick="personForm('${p.id}')">✏️</button>
   <button class="btn sm o" onclick="personForm('${p.id}',null,true)">🛡️ ضامن</button>
   <button class="btn sm" onclick="smsToPerson('${p.id}')">✉️</button>
   <button class="btn sm" onclick="msgIdOpen('${p.id}')" title="شناسه‌ی بله/روبیکا">💬</button>
   <button class="btn sm r" onclick="personDel('${p.id}')">🗑️</button>
  </td></tr>`}).join('')||'<tr><td colspan="11"><div class="empty"><div class="b">👥</div>شخصی با این فیلترها یافت نشد</div></td></tr>'}
 </tbody></table>${pgBar('persons')}</div>`;
}
function personsDirectory(){
 const rows=[...DB.persons].sort((a,b)=>a.code-b.code);
 openM(mHead('📋 لیست اشخاص — دفترچه تماس')+'<div class="mbody"><table data-rn="0"><thead><tr><th>کد</th><th>نام</th><th>گروه</th><th>موبایل</th><th>کد ملی</th><th>شغل</th><th>مانده (تومان)</th></tr></thead><tbody>'+
 rows.map(p=>{const b=personBalance(p.id);return '<tr><td>'+fa(p.code)+'</td><td class="r"><b>'+esc(p.name)+'</b></td><td>'+esc(GNP(p))+'</td><td>'+fa(p.phone||'—')+'</td><td>'+fa(p.nationalId||'—')+'</td><td>'+esc(p.job||'—')+'</td><td class="amt '+(b.saleDebt>0?'neg':'pos')+'">'+fm(b.saleDebt)+'</td></tr>'}).join('')+
 '</tbody></table></div><div class="mfoot"><button class="btn p" onclick="closeM();printPersons()">🖨️ چاپ لیست</button><button class="btn g" onclick="personExcelOut()">📊 اکسل</button><button class="btn" onclick="closeM()">بستن</button></div>',true);
}
function personExcelOut(){
 xlOut(DB.persons.map(p=>({'کد':p.code,'نام':p.name,'گروه':GNP(p),'موبایل':p.phone,'تلفن دوم':p.phone2||'','کد ملی':p.nationalId,'شغل':p.job,'شماره کارمندی':p.empNo,'شماره کارت':p.card,'آدرس':p.addr,'تعداد مدارک':(p.docs||[]).length,'نام ضامن':p.guarantor&&p.guarantor.name?p.guarantor.name:'','تلفن ضامن':p.guarantor&&p.guarantor.phone||'','شغل ضامن':p.guarantor&&p.guarantor.job||'','کد ملی ضامن':p.guarantor&&p.guarantor.nationalId||'','آدرس ضامن':p.guarantor&&p.guarantor.addr||'','توضیحات':p.notes})),'اشخاص-تکنوکالا');
}
function printPersons(){
 printHTML('<h2>لیست اشخاص — '+esc(DB.settings.shopName)+'</h2><p>تاریخ: '+jLong(jToday())+'</p><table data-rn="0"><tr style="background:#eee"><th>کد</th><th>نام</th><th>گروه</th><th>موبایل</th><th>کد ملی</th><th>شغل</th><th>آدرس</th><th>مانده</th></tr>'+
 DB.persons.map(p=>'<tr><td>'+fa(p.code)+'</td><td>'+esc(p.name)+'</td><td>'+esc(GNP(p))+'</td><td>'+fa(p.phone||'')+'</td><td>'+fa(p.nationalId||'')+'</td><td>'+esc(p.job||'')+'</td><td>'+esc(p.addr||'')+'</td><td>'+fm(personBalance(p.id).saleDebt)+'</td></tr>').join('')+'</table>');
}
function personForm(id,after,openGuar,inline,inlineNote){
 window._afterPerson=after||null;
 const p=id?P(id):{code:DB.counters.person+1,name:'',group:DB.personGroups[0]?DB.personGroups[0].id:'',phone:'',phone2:'',nationalId:'',job:'',empNo:'',card:'',addr:'',photo:'',docs:[],guarantor:null,notes:''};
 const g=p.guarantor||{name:'',phone:'',job:'',nationalId:'',addr:'',photo:'',docs:[]};
 window._tmpPhoto=p.photo||'';window._tmpThumb=p.thumb||'';
 window._tmpDocs=JSON.parse(JSON.stringify(p.docs||[]));
 window._tmpGuarPhoto=g.photo||'';
 window._tmpGuarDocs=JSON.parse(JSON.stringify(g.docs||[]));
 const docTypeSel=idd=>'<select id="'+idd+'" style="min-width:120px">'+DOC_TYPES.map(t=>'<option>'+t+'</option>').join('')+'</select>';
 const _title=id?'✏️ ویرایش شخص — '+esc(p.name):'＋ ثبت شخص جدید';
 const _bodyHtml=
 '<div class="mbody"><div class="pe-layout"><div>'+
 '<div class="pe-top"><div class="pe-ph">'+photoBox('phPrev',p.photo)+'<div class="toolbar" style="justify-content:center"><label class="btn sm" style="cursor:pointer">📷 بارگذاری تصویر<input type="file" accept="image/*" style="display:none" onchange="readImg(this,\'phPrev\',\'_tmpPhoto\')"></label><button class="btn sm r" onclick="window._tmpPhoto=\'\';$(\'phPrev\').removeAttribute(\'src\')">حذف عکس</button></div></div><div class="pe-main">'+
 '<div class="frow"><div class="fg"><label>کد (خودکار)</label><input value="'+fa(p.code)+'" disabled style="background:#f4f8fb;width:80px"></div>'+
 '<div class="fg"><label>نام و نام خانوادگی / نام شرکت *</label><input id="peName" value="'+esc(p.name)+'" style="min-width:210px"></div>'+
 '<div class="fg"><label>گروه‌ها <small style="color:var(--mut);font-weight:400">(می‌توانید چند گروه انتخاب کنید)</small></label><div style="display:flex;gap:6px;align-items:flex-start"><div id="peGroups" class="pe-grps" style="flex:1">'+peGrpHtml(pGroups(p))+'</div><button type="button" class="btn sm" title="افزودن / ویرایش / حذف گروه‌ها" onclick="grpPanelToggle()">⚙️ مدیریت</button></div></div></div>'+
 '<div id="grpPanel" style="display:none"></div></div></div>'+
 '<div class="frow"><div class="fg"><label>موبایل</label><input id="pePhone" value="'+esc(p.phone)+'" style="direction:ltr"></div>'+
 '<div class="fg"><label>تلفن ثابت</label><input id="pePhone2" value="'+esc(p.phone2||'')+'" style="direction:ltr"></div>'+ 
 '<div class="fg"><label>کد ملی (۱۰ رقم)</label><input id="peNat" value="'+esc(p.nationalId)+'" maxlength="10" style="direction:ltr" placeholder="۱۰ رقمی"></div></div>'+
 '<div class="frow"><div class="fg"><label>شغل</label><input id="peJob" value="'+esc(p.job)+'"></div>'+
 '<div class="fg"><label>شماره کارمندی</label><input id="peEmp" value="'+esc(p.empNo)+'" style="direction:ltr"></div>'+
 '<div class="fg"><label>شماره کارت بانکی</label><input id="peCard" class="money" value="'+esc(p.card)+'" style="direction:ltr" placeholder="۱۶ رقم"></div></div>'+
 '<div class="fg" style="margin-bottom:8px"><label>آدرس کامل</label><textarea id="peAddr" rows="2" style="width:100%">'+esc(p.addr)+'</textarea></div>'+ 
 '<div class="frow"><div class="fg" style="flex:1"><label>آدرس سایت</label><input id="peWebsite" value="'+esc(p.website||'')+'" style="width:100%" placeholder="https://example.com"></div>'+
 '<div class="fg" style="flex:1"><label>توضیحات</label><input id="peNotes" value="'+esc(p.notes||'')+'" style="width:100%"></div></div>'+
 '<div class="sec-h">📎 مدارک شخص (قرارداد، کارت ملی، کارت کارمندی و ...)</div>'+
 '<div class="frow" style="align-items:center;margin-bottom:6px">'+docTypeSel('docType')+'<label class="btn sm p" style="cursor:pointer">📎 بارگذاری مدرک<input type="file" style="display:none" onchange="personDocEvt(this)"></label></div>'+
 '<div id="docList"></div>'+
 '</div><div>'+
 '<div id="guarSec" class="inlbox">'+
 '<div class="sec-h" style="margin-top:0">🛡️ مشخصات ضامن <span style="font-weight:400;font-size:10.5px;color:var(--mut)">(ثبت / ویرایش / حذف — تصویر، شغل، تلفن تماس، آدرس و مدارک)</span></div>'+
 '<div class="pe-gtop"><div class="pe-ph">'+photoBox('gPhPrev',g.photo)+'<div class="toolbar" style="justify-content:center"><label class="btn sm" style="cursor:pointer">📷 بارگذاری تصویر ضامن<input type="file" accept="image/*" style="display:none" onchange="readImg(this,\'gPhPrev\',\'_tmpGuarPhoto\')"></label><button class="btn sm r" onclick="window._tmpGuarPhoto=\'\';$(\'gPhPrev\').removeAttribute(\'src\')">حذف عکس</button></div></div><div class="pe-main">'+
 '<div class="frow"><div class="fg"><label>نام ضامن</label><input id="gName" value="'+esc(g.name)+'"></div>'+
 '<div class="fg"><label>تلفن تماس</label><input id="gPhone" value="'+esc(g.phone||'')+'" style="direction:ltr"></div>'+
 '<div class="fg"><label>شغل ضامن</label><input id="gJob" value="'+esc(g.job||'')+'"></div>'+
 '<div class="fg"><label>کد ملی ضامن</label><input id="gNat" value="'+esc(g.nationalId||'')+'" maxlength="10" style="direction:ltr"></div></div></div></div>'+
 '<div class="fg" style="margin-bottom:8px"><label>آدرس ضامن</label><textarea id="gAddr" rows="2" style="width:100%">'+esc(g.addr||'')+'</textarea></div>'+
 '<div class="frow" style="align-items:center;margin-bottom:6px">'+docTypeSel('gdocType')+'<label class="btn sm p" style="cursor:pointer">📎 مدرک ضامن<input type="file" style="display:none" onchange="guarDocEvt(this)"></label>'+
 '<button class="btn sm r" onclick="clearGuar()">🗑️ حذف اطلاعات ضامن</button></div>'+
 '<div id="gdocList"></div></div></div></div>'+
 '<input type="hidden" id="peId" value="'+(id||'')+'">'+
 '</div>';
 if(inline){
  /* نمایش مستقیم در خود صفحه (بدون پنجره‌ی تمام‌صفحه) */
  $('content').innerHTML='<div class="pgtitle"><h1>👥 معرفی اشخاص</h1><span class="sub">ثبت مشتری، فروشنده و سایر اشخاص — مشاهده، ویرایش و حذف در «لیست اشخاص»</span></div>'+
   (inlineNote?'<div class="notice" style="background:#e9f8ee;border:1px solid #9ad7b0;border-radius:8px;padding:10px 14px;margin-bottom:12px;font-size:13px">✅ «'+esc(inlineNote)+'» ثبت شد. می‌توانید شخص بعدی را وارد کنید.</div>':'')+
   '<div class="card pwtab pe-inl">'+_bodyHtml.replace('<div class="mbody">','<div class="pe-inl-body">')+
   '<div class="pwtab-foot"><button class="btn p" onclick="personSave()">💾 ذخیره شخص</button><button type="button" class="btn o" onclick="vPersonIntro()">🔄 فرم خالی</button></div></div>';
  renderDocChips();renderGuarDocs();
  setTimeout(()=>{if(curView==='personIntro')rf('peName')},60);
  return;
 }
 openM(mHead(_title)+_bodyHtml+
 '<div class="mfoot"><button class="btn p" onclick="personSave()">💾 ذخیره شخص</button><button class="btn" onclick="closeM()">انصراف</button></div>');
 {const mm=document.querySelector('#modal .m');if(mm){mm.classList.add('pwfull');$('modal').classList.add('pwfull')}}
 renderDocChips();renderGuarDocs();
 if(openGuar){const gs=$('guarSec');if(gs){gs.classList.add('hl');gs.scrollIntoView({behavior:'smooth',block:'center'})}}
}
function clearGuar(){['gName','gPhone','gJob','gNat','gAddr'].forEach(x=>{const el=$(x);if(el)el.value=''});window._tmpGuarPhoto='';const gp=$('gPhPrev');if(gp)gp.removeAttribute('src');window._tmpGuarDocs=[];renderGuarDocs();toast('اطلاعات ضامن پاک شد — با ذخیره، ضامن حذف می‌شود')}
function renderDocChips(){const el=$('docList');if(!el)return;el.innerHTML=window._tmpDocs.map((d,i)=>{const isNationalCard=d.type==='کارت ملی'&&(String(d.data||'').startsWith('data:image/')||isImgRef(d.data));if(isNationalCard)return '<div class="doc-card-preview"><b>تصویر کارت ملی</b><img id="docImg'+i+'" '+imgAttrs(d.data)+' alt="تصویر کارت ملی"><div class="doc-zoom-box"><span>زوم</span><input type="range" min="1" max="3" step="0.05" value="'+(d.zoom||1)+'" oninput="docZoom('+i+',this.value)"><span id="docZoomValue'+i+'">'+(d.zoom||1)+'x</span><button class="btn sm" onclick="docZoom('+i+',1)">بازنشانی</button></div><div>'+docLinkHtml(d,'دانلود تصویر')+'<button style="border:none;background:none;color:#c0392b;cursor:pointer;margin-right:8px" onclick="window._tmpDocs.splice('+i+',1);renderDocChips()">حذف</button></div></div>';return '<span class="docchip"><b>['+esc(d.type||'سایر')+']</b> '+docLinkHtml(d)+'<button style="border:none;background:none;color:#c0392b;cursor:pointer" onclick="window._tmpDocs.splice('+i+',1);renderDocChips()">✕</button></span>'}).join('')||'<span style="color:#7a8a99;font-size:11px">مدرکی بارگذاری نشده</span>'}
function docZoom(index,value){const zoom=Math.max(1,Math.min(3,Number(value)||1)),doc=window._tmpDocs[index],img=$('docImg'+index),label=$('docZoomValue'+index);if(!doc||!img)return;doc.zoom=zoom;img.style.transform='scale('+zoom+')';img.style.transformOrigin='center center';if(label)label.textContent=zoom.toFixed(2)+'x'}
function renderGuarDocs(){const el=$('gdocList');if(!el)return;el.innerHTML=window._tmpGuarDocs.map((d,i)=>'<span class="docchip"><b>['+esc(d.type||'سایر')+']</b> '+docLinkHtml(d)+'<button style="border:none;background:none;color:#c0392b;cursor:pointer" onclick="window._tmpGuarDocs.splice('+i+',1);renderGuarDocs()">✕</button></span>').join('')||'<span style="color:#7a8a99;font-size:11px">مدرکی نیست</span>'}
function personDocEvt(input){const f=input.files[0];if(!f)return;const tp=($('docType')||{}).value||'سایر';const r=new FileReader();r.onload=e=>shrinkImg(e.target.result,u=>{window._tmpDocs.push({id:uid(),type:tp,name:f.name,data:u});renderDocChips()});r.readAsDataURL(f);input.value=''}
function guarDocEvt(input){const f=input.files[0];if(!f)return;const tp=($('gdocType')||{}).value||'سایر';const r=new FileReader();r.onload=e=>shrinkImg(e.target.result,u=>{window._tmpGuarDocs.push({id:uid(),type:tp,name:f.name,data:u});renderGuarDocs()});r.readAsDataURL(f);input.value=''}
function photoBox(id,src){return '<div class="phbox"><img'+(id?' id="'+id+'"':'')+' class="zoomable" alt="" title="برای بزرگ‌نمایی، موس را روی تصویر نگه دارید" '+imgAttrs(src)+'><span class="ph-ph">👤<small>بدون تصویر</small></span></div>'}
(function(){
 let box=null;
 function ensure(){if(!box){box=document.createElement('div');box.id='phZoom';box.innerHTML='<img alt="">';document.body.appendChild(box)}return box}
 function hide(){if(box)box.style.display='none'}
 function place(t){
  const b=ensure(),r=t.getBoundingClientRect(),w=b.offsetWidth,h=b.offsetHeight;
  let x=r.left+r.width/2-w/2,y=r.top+r.height/2-h/2;
  x=Math.max(8,Math.min(innerWidth-w-8,x));y=Math.max(8,Math.min(innerHeight-h-8,y));
  b.style.left=x+'px';b.style.top=y+'px'}
 document.addEventListener('mouseover',e=>{
  const t=e.target;
  if(!(t instanceof HTMLImageElement)||!t.classList.contains('zoomable')){hide();return}
  const src=t.getAttribute('src');if(!src){hide();return}
  const b=ensure(),zi=b.firstChild;
  zi.onload=()=>{if(b.style.display==='block')place(t)};
  zi.src=src;b.style.display='block';place(t);
   const full=t.dataset&&t.dataset.full;if(full)imgLoad(full).then(u=>{if(u&&b.style.display==='block')zi.src=u})});
 document.addEventListener('mouseout',e=>{const t=e.target;if(t instanceof HTMLImageElement&&t.classList.contains('zoomable'))hide()});
 document.addEventListener('mousedown',hide);
 window.addEventListener('scroll',hide,true);
 window.addEventListener('blur',hide);
})();
function readImg(input,previewId,slot){const f=input.files[0];if(!f)return;const r=new FileReader();r.onload=e=>shrinkImg(e.target.result,u=>{window[slot]=u;if(slot==='_tmpPhoto')makeThumb(u,t=>{window._tmpThumb=t});const img=$(previewId);if(img){img.style.display='';img.src=u;img.dataset.ok='1'}});r.readAsDataURL(f);input.value=''}
function personSave(){
 const name=$('peName').value.trim();if(!name){toast('⚠️ نام را وارد کنید',false);return}
 const id=$('peId').value;
 const nat=faDig($('peNat').value).trim();
 if(nat&&!/^\d{10}$/.test(nat)){toast('⚠️ کد ملی باید دقیقاً ۱۰ رقم باشد',false);return}
 if(nat&&DB.persons.some(x=>x.nationalId===nat&&x.id!==id))toast('⚠️ این کد ملی قبلاً برای شخص دیگری ثبت شده است',false);
 const card=faDig($('peCard').value).replace(/[^\d]/g,'');
 const gName=$('gName').value.trim();
 const guar=gName?{name:gName,phone:faDig($('gPhone').value),job:$('gJob').value,nationalId:faDig($('gNat').value).trim(),addr:$('gAddr').value,photo:window._tmpGuarPhoto,docs:window._tmpGuarDocs}:null;
 const gs=peGrpGet();if(!gs.length){toast('⚠️ حداقل یک گروه را انتخاب کنید',false);return}
  const obj={name,group:gs[0],groups:gs,phone:faDig($('pePhone').value),phone2:faDig($('pePhone2').value),nationalId:nat,job:$('peJob').value,empNo:faDig($('peEmp').value),card,addr:$('peAddr').value,website:$('peWebsite').value,notes:$('peNotes').value,photo:window._tmpPhoto,thumb:window._tmpPhoto?(window._tmpThumb||''):'',docs:window._tmpDocs,guarantor:guar};
 if(id){Object.assign(P(id),obj);logAct('ویرایش شخص: '+name)}
 else{DB.persons.push({id:uid(),code:++DB.counters.person,created:jToday(),...obj});logAct('ثبت شخص جدید: '+name)}
 saveDB();closeM();const af=window._afterPerson;window._afterPerson=null;
 const refresh=()=>{if(curView==='personIntro'){if(!id)window._introLast=name;vPersonIntro()}else vPersons()};
  if(af){const np=DB.persons[DB.persons.length-1];af(np);refresh()}else refresh();
 toast('✅ «'+name+'» ذخیره شد');
}
function personDel(id){const p=P(id);if(!p)return;
 const used=DB.invoices.some(i=>i.person===id)||DB.receipts.some(r=>r.person===id)||DB.cheques.some(c=>c.person===id)||DB.installments.some(i=>i.person===id);
 if(used){toast('⚠️ این شخص در اسناد مالی (فاکتور/رسید/چک/قسط) استفاده شده و حذف آن ممکن نیست',false);return}
 confirmM('حذف «'+esc(p.name)+'» و تمام اطلاعات پرونده (عکس، مدارک، ضامن)؟',()=>{
  DB.persons=DB.persons.filter(x=>x.id!==id);logAct('حذف شخص: '+p.name);saveDB();vPersons();toast('🗑️ حذف شد');});}
/* ===== مدیریت گروه اشخاص (داخل خود فرم/پنجره، بدون prompt) ===== */
/* انتخاب چند گروه برای یک شخص */
function peGrpHtml(sel){sel=sel||[];return DB.personGroups.map(g=>'<label class="pe-grp"><input type="checkbox" value="'+g.id+'" '+(sel.includes(g.id)?'checked':'')+'><span>'+esc(g.name)+(isSupplierGroup(g)?' 🏭':'')+'</span></label>').join('')}
function peGrpGet(){return [...document.querySelectorAll('#peGroups input:checked')].map(x=>x.value)}
function isSupplierGroup(g){return !!g&&(g.supplier===true||(g.supplier===undefined&&/فروشنده|تامین|تأمین|supplier|vendor/i.test(g.name||'')))}
function grpRowsHtml(){
 return DB.personGroups.map(g=>{
  const n=DB.persons.filter(p=>inGrp(p,g.id)).length;
  return '<div class="grp-row"><input class="grp-in" id="gn_'+g.id+'" value="'+esc(g.name)+'" onkeydown="if(event.key===\'Enter\'){event.preventDefault();grpRenSave(\''+g.id+'\')}">'+
   '<label class="pw-inl" title="در فاکتور خرید، اعضای این گروه به‌عنوان فروشنده/تأمین‌کننده نمایش داده می‌شوند"><input type="checkbox" '+(isSupplierGroup(g)?'checked ':'')+'onchange="grpSupSet(\''+g.id+'\',this.checked)"> تأمین‌کننده</label>'+
   '<span class="grp-n">'+fa(n)+' عضو</span>'+
   '<button type="button" class="btn sm g" onclick="grpRenSave(\''+g.id+'\')">✔️ ذخیره نام</button>'+
   '<button type="button" class="btn sm r" onclick="grpDelIn(this,\''+g.id+'\')">🗑️ حذف</button></div>'}).join('')||'<div style="color:#7a8a99;font-size:12px">گروهی وجود ندارد</div>';
}
function grpPanelHtml(){
 return '<div class="grp-add"><input id="ngName" placeholder="نام گروه جدید…" onkeydown="if(event.key===\'Enter\'){event.preventDefault();grpAdd()}"><button type="button" class="btn sm p" onclick="grpAdd()">＋ افزودن گروه</button></div>'+grpRowsHtml();
}
function grpPanelToggle(){
 const p=$('grpPanel');if(!p)return;
 if(p.style.display==='none'){p.innerHTML=grpPanelHtml();p.style.display='block';setTimeout(()=>rf('ngName'),30)}
 else p.style.display='none';
}
function grpRefresh(){
 const p=$('grpPanel');if(p&&p.style.display!=='none')p.innerHTML=grpPanelHtml();
 const m=$('grpModalBody');if(m)m.innerHTML=grpPanelHtml();
 const gbox=$('peGroups');if(gbox){const cur=peGrpGet();gbox.innerHTML=peGrpHtml(cur.filter(id=>DB.personGroups.some(g=>g.id===id)))}
 if(curView==='persons'){try{vPersons()}catch(e){}}
}
function grpAdd(){
 const el=$('ngName'),n=((el&&el.value)||'').trim();
 if(!n){toast('⚠️ نام گروه را وارد کنید',false);return}
 if(DB.personGroups.some(g=>g.name.trim().toLowerCase()===n.toLowerCase())){toast('⚠️ این گروه قبلاً وجود دارد',false);return}
 const g={id:uid(),name:n,supplier:isSupplierGroup({name:n})};
 DB.personGroups.push(g);logAct('گروه جدید: '+n);saveDB();grpRefresh();
 {const c=peGrpGet();c.push(g.id);const gbox=$('peGroups');if(gbox)gbox.innerHTML=peGrpHtml(c)}
 rf('ngName');toast('✅ گروه «'+n+'» اضافه شد');
}
function grpRenSave(id){
 const g=DB.personGroups.find(x=>x.id===id),el=$('gn_'+id);if(!g||!el)return;
 const n=el.value.trim();
 if(!n){toast('⚠️ نام گروه نمی‌تواند خالی باشد',false);el.value=g.name;return}
 if(n===g.name){toast('نام تغییری نکرده است');return}
 if(DB.personGroups.some(x=>x.id!==id&&x.name.trim().toLowerCase()===n.toLowerCase())){toast('⚠️ گروه دیگری با این نام وجود دارد',false);return}
 const old=g.name;g.name=n;
 if(g.supplier===undefined)g.supplier=isSupplierGroup({name:old});
 logAct('ویرایش گروه: '+old+' → '+n);saveDB();grpRefresh();toast('✅ نام گروه تغییر کرد');
}
function grpSupSet(id,on){
 const g=DB.personGroups.find(x=>x.id===id);if(!g)return;
 g.supplier=!!on;logAct('گروه «'+g.name+'»: '+(on?'تأمین‌کننده':'غیر تأمین‌کننده'));saveDB();grpRefresh();
}
/* حذف دو مرحله‌ای (بدون پنجره‌ی تأیید تا فرم باز بماند) */
function grpDelIn(btn,id){
 const g=DB.personGroups.find(x=>x.id===id);if(!g)return;
 const cnt=DB.persons.filter(p=>inGrp(p,id)).length;
 if(cnt){toast('⚠️ این گروه '+fa(cnt)+' عضو دارد؛ ابتدا اعضا را به گروه دیگری منتقل کنید',false);return}
 if(DB.personGroups.length<=1){toast('⚠️ حداقل یک گروه باید باقی بماند',false);return}
 if(btn&&btn.dataset.arm!=='1'){
  btn.dataset.arm='1';btn.textContent='⚠️ تأیید حذف';
  setTimeout(()=>{if(btn&&btn.isConnected&&btn.dataset.arm==='1'){btn.dataset.arm='';btn.textContent='🗑️ حذف'}},3500);
  return}
 DB.personGroups=DB.personGroups.filter(x=>x.id!==id);
 logAct('حذف گروه: '+g.name);saveDB();grpRefresh();toast('🗑️ گروه «'+g.name+'» حذف شد');
}
function groupsM(){
 openM(mHead('🗂️ گروه‌بندی اشخاص')+'<div class="mbody"><div id="grpModalBody">'+grpPanelHtml()+'</div></div><div class="mfoot"><button class="btn" onclick="closeM()">بستن</button></div>');
}
function personProfile(pid){
 const p=P(pid);if(!p)return;const b=personBalance(pid);
 const invs=DB.invoices.filter(i=>i.person===pid).sort((a,c)=>c.date<a.date?-1:1);
 const recs=DB.receipts.filter(r=>r.person===pid);
 const chqs=DB.cheques.filter(c=>c.person===pid);
 const insts=DB.installments.filter(i=>i.person===pid&&!i.paid);
 const prods={};DB.invoices.forEach(inv=>{if(inv.person===pid&&inv.type==='buy')inv.lines.forEach(l=>{prods[l.pid]=(prods[l.pid]||0)+l.qty})});
 const g=p.guarantor;
 let h='<div class="mbody">';
 h+='<div style="text-align:center;margin-bottom:10px">'+photoBox('',p.photo)+'</div>';
 h+='<div class="kv" style="margin-bottom:12px">'+
  '<span class="k">کد: <b>'+fa(p.code)+'</b></span><span class="k">گروه: <b>'+esc(GNP(p))+'</b></span>'+
  '<span class="k">موبایل: <b>'+fa(p.phone||'-')+'</b></span><span class="k">تلفن دوم: <b>'+fa(p.phone2||'-')+'</b></span>'+
  '<span class="k">کد ملی: <b>'+fa(p.nationalId||'-')+'</b></span><span class="k">شغل: <b>'+esc(p.job||'-')+'</b></span>'+
  '<span class="k">شماره کارمندی: <b>'+fa(p.empNo||'-')+'</b></span><span class="k">کارت بانکی: <b>'+fa(p.card||'-')+'</b></span>'+
  '<span class="k">آدرس: <b>'+esc(p.addr||'-')+'</b></span>'+
  (p.created?'<span class="k">تاریخ ثبت: <b>'+jShort(p.created)+'</b></span>':'')+
  (p.notes?'<span class="k">توضیحات: <b>'+esc(p.notes)+'</b></span>':'')+'</div>';
 h+='<div class="kv" style="margin-bottom:12px"><span class="k">مانده حساب (بدهی به فروشگاه): <b class="'+(b.saleDebt>0?'neg':'pos')+'">'+fm(b.saleDebt)+' تومان</b></span><span class="k">سود خالص از این شخص: <b class="pos">'+fm(b.profit)+'</b></span></div>';
 if((p.docs||[]).length)h+='<div class="sec-h">📎 مدارک شخص ('+fa(p.docs.length)+')</div><div class="kv">'+p.docs.map(d=>'<span class="docchip"><b>['+esc(d.type||'سایر')+']</b> '+docLinkHtml(d)+'</span>').join('')+'</div>';
 if(g&&g.name)h+='<div class="sec-h">🛡️ ضامن</div><div class="kv"><span class="k">نام: <b>'+esc(g.name)+'</b></span><span class="k">تلفن: <b>'+fa(g.phone||'-')+'</b></span><span class="k">شغل: <b>'+esc(g.job||'-')+'</b></span><span class="k">کد ملی: <b>'+fa(g.nationalId||'-')+'</b></span><span class="k">آدرس: <b>'+esc(g.addr||'-')+'</b></span></div>'+
  ((g.docs||[]).length?'<div class="kv" style="margin-top:6px">'+g.docs.map(d=>'<span class="docchip"><b>['+esc(d.type||'سایر')+']</b> '+docLinkHtml(d)+'</span>').join('')+'</div>':'');
 h+='<div class="sec-h">🧾 فاکتورها ('+fa(invs.length)+')</div>'+(invs.length?`<table data-rn="0"><thead><tr><th>تاریخ</th><th>نوع</th><th>شماره</th><th>مبلغ</th><th>پرداخت</th><th>مانده</th></tr></thead><tbody>${invs.map(i=>`<tr><td>${jShort(i.date)}</td><td><span class="bdg ${i.type==='sale'?'b-g':i.type==='buy'?'b-o':'b-m'}">${invTypeFa(i.type)}</span></td><td>${fa(i.no)}</td><td class="amt">${fm(invTotal(i))}</td><td class="amt">${fm(invPaid(i))}</td><td class="amt ${invTotal(i)-invPaid(i)>0?'neg':'pos'}">${fm(invTotal(i)-invPaid(i))}</td></tr>`).join('')}</tbody></table>`:'<div class="empty">فاکتوری نیست</div>');
 h+='<div class="sec-h">💱 دریافت/پرداخت‌ها</div>'+(recs.length?`<table data-rn="0"><thead><tr><th>تاریخ</th><th>جهت</th><th>مبلغ</th><th>شرح</th></tr></thead><tbody>${recs.map(r=>`<tr><td>${jShort(r.date)}</td><td>${r.dir==='in'?'<span class="bdg b-g">دریافت</span>':'<span class="bdg b-o">پرداخت</span>'}</td><td class="amt">${fm(r.rows.reduce((s,x)=>s+pd(x.amount),0))}</td><td class="r">${esc(r.desc||'')}</td></tr>`).join('')}</tbody></table>`:'<div class="empty">موردی نیست</div>');
 h+='<div class="sec-h">🏦 چک‌ها</div>'+(chqs.length?`<table data-rn="0"><thead><tr><th>جهت</th><th>شماره</th><th>سررسید</th><th>مبلغ</th><th>وضعیت</th></tr></thead><tbody>${chqs.map(c=>`<tr><td>${c.dir==='rec'?'دریافتی':'پرداختی'}</td><td>${fa(c.no)}</td><td>${jShort(c.due)}</td><td class="amt">${fm(c.amount)}</td><td><span class="bdg ${chqCls(c.status)}">${c.status}</span></td></tr>`).join('')}</tbody></table>`:'<div class="empty">چکی نیست</div>');
 h+='<div class="sec-h">📅 اقساط باز</div>'+(insts.length?`<table data-rn="0"><thead><tr><th>قسط</th><th>سررسید</th><th>مبلغ</th></tr></thead><tbody>${insts.map(i=>`<tr><td>${fa(i.no)}</td><td class="${jNorm(i.due)<=jToday()?'neg':''}">${jShort(i.due)}</td><td class="amt">${fm(i.amount)}</td></tr>`).join('')}</tbody></table>`:'<div class="empty">قسط بازی نیست</div>');
 if(Object.keys(prods).length)h+='<div class="sec-h">📱 کالاهای خریداری‌شده از این فروشنده</div><div class="kv">'+Object.entries(prods).map(([pid,q])=>'<span class="k">'+esc(PR(pid)?PR(pid).name:'?')+': <b>'+fa(q)+'</b></span>').join('')+'</div>';
 h+='</div>';
 openM(mHead('👁️ پرونده: '+esc(p.name))+h+
 '<div class="mfoot"><button class="btn p" onclick="printStatement(\''+pid+'\')">🖨️ چاپ صورت حساب</button><button class="btn" onclick="closeM();personForm(\''+pid+'\')">✏️ ویرایش</button><button class="btn o" onclick="smsToPerson(\''+pid+'\')">✉️ پیامک</button><button class="btn" onclick="msgIdOpen(\''+pid+'\')">💬 بله/روبیکا</button><button class="btn" onclick="sendCustomerOuter(\''+pid+'\')">📤 ارسال به برنامه خارجی</button><button class="btn" onclick="closeM()">بستن</button></div>',true);
}
/* 📤 ارسال اطلاعات مشتری به برنامه خارجی (Integration) */
function sendCustomerOuter(pid){
 const p=P(pid);if(!p)return;const b=personBalance(pid);
 const data={shop:DB.settings.shopName,type:'customer',customer:{
  code:p.code,name:p.name,group:GNP(p),phone:p.phone,phone2:p.phone2||'',
  nationalId:p.nationalId,job:p.job,empNo:p.empNo||'',card:p.card,addr:p.addr,
  notes:p.notes||'',balance:b.saleDebt,profit:b.profit,created:p.created||'',
  guarantor:p.guarantor&&p.guarantor.name?{name:p.guarantor.name,phone:p.guarantor.phone,job:p.guarantor.job}:null,
  openInstallments:DB.installments.filter(i=>i.person===pid&&!i.paid).length,
  openCheques:DB.cheques.filter(c=>c.person===pid&&c.status==='جاری').length}};
 openM(mHead('📤 ارسال اطلاعات مشتری — یکپارچه‌سازی')+'<div class="mbody">'+
 '<div class="fg"><label>JSON اطلاعات مشتری</label><textarea rows="9" style="width:100%;direction:ltr;font-size:11px" id="whJson">'+esc(JSON.stringify(data,null,1))+'</textarea></div>'+
 '<div class="frow" style="margin-top:8px"><button class="btn" onclick="navigator.clipboard.writeText($(\'whJson\').value).then(()=>toast(\'📋 کپی شد\'))">📋 کپی</button>'+
 '<button class="btn p" onclick="webhookPost(JSON.parse($(\'whJson\').value),\'اطلاعات مشتری\')">🌐 ارسال به Webhook</button>'+
 '<button class="btn o" onclick="smsToPerson(\''+pid+'\')">✉️ پیامک به مشتری</button></div>'+
 '<div style="font-size:11px;color:#7a8a99;margin-top:8px">آدرس Webhook در «ابزار ← تنظیمات» تعریف می‌شود.</div></div>'+
 '<div class="mfoot"><button class="btn" onclick="closeM()">بستن</button></div>');
}
/* ✉️ پیامک بدهی (با قالب قابل ویرایش) */
function smsToPerson(pid){const p=P(pid);if(!p)return;const b=personBalance(pid);
 if(!p.phone){toast('⚠️ شماره موبایل ثبت نشده',false);return}
 const msg=smsFill(smsTpl('Debt'),{name:p.name,amount:Math.max(0,b.saleDebt)});
 askM('✉️ پیامک بدهی','متن پیامک به '+esc(p.name)+' ('+esc(p.phone)+'):',msg,txt=>sendSMS(p.phone,txt));}

/* ================================================================
   ==================== کالا (معرفی کالا) ========================
   ================================================================ */
const Fpr={q:'',grp:'',brand:'',sort:'name'};
let PW=null; /* وضعیت ویزارد معرفی کالا */

/* ---- نام ترکیبی خودکار کالا ---- */
function buildProductName(g,brand,model,memory,ram,color,sn,lap){
 const parts=[];
 const grp=(DB.productGroups.find(x=>x.id===g)||{}).name||'';
 if(grp)parts.push(grp);
 if(brand)parts.push(brand);
 if(model)parts.push(pwModelBase(model));
 if(lap&&lapIsGroup(g)){const cpu=lapCpu(lap).replace(/^(core|intel|amd)\s+/i,'').trim();if(cpu)parts.push(cpu);const gp=String(lap.gpu||'').replace(/^(nvidia\s+geforce|nvidia|amd\s+radeon|intel)\s+/i,'').trim();if(gp)parts.push(gp);if(lap.cond==='استوک')parts.push('stock')}
 if(memory)parts.push(String(memory).replace(/\s*GB/gi,'').replace(/\s*گیگابایت/g,'').trim()+'g');
 if(ram)parts.push(String(ram).replace(/\s*GB/gi,'').replace(/\s*گیگابایت/g,'').trim()+'g');
 if(color){
  const cn=colorEnOf(DB.colors.find(x=>x.id===color));
  if(cn)parts.push(cn);
 }
 if(sn)parts.push('sn'+sn);
 return parts.filter(Boolean).join(' ').toLowerCase();
}
function pwModelBase(m){
 return String(m||'').replace(/^(galaxy|iphone|ipad|redmi|poco|nova|mate|pura|enjoy)\s+/i,'').trim();
}
/* ---- مدل‌های یک برند ---- */
function modelsOfBrand(brand){
 const arr=(DB.phoneModels||{})[brand]||[];
 const extra=(DB.productOptions.models||[]).filter(m=>!arr.includes(m));
 return [...arr,...extra];
}
/* ================= معرفی کالای جدید (فرم تک‌صفحه‌ای) ================= */
/* کد خودکار: بعدی بعد از آخرین شمارنده که با هیچ کد دستی تداخل نداشته باشد */
function nextProductCode(){
 let n=Number(DB.counters.product)||1000;
 const used=new Set(DB.products.map(p=>String(p.code).toLowerCase()));
 do{n++}while(used.has('p-'+n));
 return{n,code:'P-'+n};
}
function pwDefault(){return{group:'',brand:'',model:'',memory:'',ram:'',color:'',cpuSeries:'',cpuGen:'',cpuModel:'',gpu:'',screen:'',usage:'',cond:'',sn:'',track:'serial',snInName:true,
  codeMode:'auto',code:'',lastCost:0,sellPrice:0,markup:10,sellAuto:true,
  minStock:0,reorder:0,notes:'',adding:'',dupPid:'',dupKeep:false,editPid:'',renameAuto:true}}
/* معرفی کالای جدید: در یک تب جدید بالای برنامه باز می‌شود (فرم هنگام رفتن به تب‌های دیگر حفظ می‌شود).
   اگر پنجره‌ی دیگری باز باشد، مثل قبل به‌صورت پنجره‌ی شناور باز می‌شود. */
function productWizard(fresh){
 const inModal=!!($('modal')&&$('modal').classList&&$('modal').classList.contains('open'));
 if(inModal){PW=pwDefault();window._pwTab=false;pwRender();return}
 if(!PW||fresh===true||PW.editPid)PW=pwDefault();
 pageTitles.newProduct='معرفی کالای جدید';window._pwTab=true;nav('newProduct');
}
function vNewProduct(){if(!PW)PW=pwDefault();window._pwTab=true;pwRender()}
function pwReset(){PW=pwDefault();pwRender()}
function pwCancel(){PW=null;pageTitles.newProduct='معرفی کالای جدید';if(window._pwTab){window._pwTab=false;openPages=openPages.filter(x=>x!=='newProduct');nav(openPages.includes('products')?'products':(openPages[openPages.length-1]||'products'))}else closeM()}
function pwName(){
 return buildProductName(PW.group,PW.brand,PW.model,PW.memory,PW.ram,PW.color,(PW.snInName&&PW.track==='serial')?faDig(PW.sn).trim():'',{cpuSeries:PW.cpuSeries,cpuGen:PW.cpuGen,cpuModel:PW.cpuModel,gpu:PW.gpu,cond:PW.cond});
}
/* سقف سود هر عدد کالا (تومان) — در قیمت‌گذاری خودکار و دستی اعمال می‌شود */
const MAX_PROFIT=10000000;
function capProfit(cost,pct){const c=pd(cost)||0,pr=c*(Number(pct)||0)/100;return Math.round(Math.min(pr,MAX_PROFIT))}
/* محاسبه خودکار قیمت فروش = خرید + درصد سود (حداکثر ۱۰ میلیون سود) */
function pwCalcSell(){
 PW.sellPrice=Math.round(pd(PW.lastCost))+(lapIsGroup(PW.group)?(pd(PW.lastCost)?LAP_MARGIN:0):capProfit(PW.lastCost,PW.markup));
 const el=$('pwSell');if(el)el.value=PW.sellPrice?PW.sellPrice.toLocaleString('en-US'):'';
}
function pwBuyIn(v){
 PW.lastCost=pd(v);
 if(PW.sellAuto)pwCalcSell();
 pwPreviewUpd();
}
function pwSellIn(v){
 PW.sellPrice=pd(v);PW.sellAuto=false;
 const c=$('pwAuto');if(c)c.checked=false;
 pwPreviewUpd();
}
function pwMarkIn(v){
 PW.markup=pd(v);
 if(PW.sellAuto)pwCalcSell();
 pwPreviewUpd();
}
function pwAutoToggle(on){
 PW.sellAuto=!!on;
 if(on)pwCalcSell();
 pwPreviewUpd();
}
/* ---- افزودن گزینه جدید (بدون prompt؛ داخل خود فرم) ---- */
function pwAddOpen(kind){
 if(kind==='model'&&!PW.brand){toast('⚠️ ابتدا برند را انتخاب کنید',false);return}
 PW.adding=kind;pwRender();
 setTimeout(()=>rf('pwAddIn'),30);
}
function pwAddCancel(){PW.adding='';pwRender()}
function pwAddOk(){
 const name=((($('pwAddIn')||{}).value)||'').trim();
 if(!name){toast('⚠️ نام را وارد کنید',false);return}
 const kind=PW.adding,low=name.toLowerCase();
 if(kind==='group'){
  const ex=DB.productGroups.find(g=>g.name.toLowerCase()===low);
  if(ex)PW.group=ex.id;
  else{const g={id:uid(),name};DB.productGroups.push(g);PW.group=g.id}
 }else if(kind==='color'){
  const en=String(COLOR_FA_EN[name]||name).toLowerCase();
  const ex=DB.colors.find(c=>String(c.enName||c.name).toLowerCase()===en||c.name===name);
  if(ex)PW.color=ex.id;
  else{const c={id:uid(),name,enName:en,hex:(($('pwAddHex')||{}).value)||'#95a5a6'};DB.colors.push(c);PW.color=c.id}
 }else if(kind==='model'){
  DB.phoneModels=DB.phoneModels||{};
  const arr=DB.phoneModels[PW.brand]||(DB.phoneModels[PW.brand]=[]);
  const ex=modelsOfBrand(PW.brand).find(m=>m.toLowerCase()===low);
  if(ex)PW.model=ex;else{arr.push(name);PW.model=name}
 }else{
  const key={brand:'brands',memory:'memories',ram:'rams',cpuSeries:'cpuSeries',cpuGen:'cpuGens',cpuModel:'cpuModels',gpu:'gpus',screen:'screenSizes',usage:'laptopUsages',cond:'laptopConds'}[kind];
  const arr=DB.productOptions[key]||(DB.productOptions[key]=[]);
  const ex=arr.find(m=>String(m).toLowerCase()===low);
  const val=ex||name;
  if(!ex)arr.push(name);
  if(kind==='brand'){DB.phoneModels=DB.phoneModels||{};if(!DB.phoneModels[val])DB.phoneModels[val]=[];PW.model=''}
  PW[kind]=val;
 }
 PW.adding='';saveDB();pwRender();
}
function pwAddBar(){
 if(!PW.adding)return '';
 const t={group:'گروه کالای جدید',brand:'برند جدید',model:'مدل جدید برای برند «'+PW.brand+'»',memory:'حافظه جدید (مثلاً 512 GB)',ram:'رم جدید (مثلاً 12 GB)',color:'رنگ جدید (نام انگلیسی یا فارسی)',cpuSeries:'سری پردازنده‌ی جدید (مثلاً Core i7)',cpuGen:'نسل پردازنده‌ی جدید (مثلاً نسل 13)',cpuModel:'مدل پردازنده‌ی جدید (مثلاً Core i7-1355U)',gpu:'پردازنده‌ی گرافیکی جدید (مثلاً RTX 4060)',screen:'اندازه‌ی صفحه نمایش (مثلاً 15.6 اینچ)',usage:'کاربری جدید (مثلاً گیمینگ)',cond:'وضعیت جدید (مثلاً بازبسته‌بندی)'}[PW.adding]||'';
 return '<div class="notice" style="display:flex;gap:6px;align-items:center;flex-wrap:wrap;margin-bottom:12px"><b>＋ '+esc(t)+':</b>'+
  '<input id="pwAddIn" style="min-width:190px" onkeydown="if(event.key===\'Enter\'){event.preventDefault();pwAddOk()}">'+
  (PW.adding==='color'?'<input id="pwAddHex" type="color" value="#95a5a6" title="رنگ نمایشی" style="padding:0;width:38px;height:32px">':'')+
  '<button type="button" class="btn sm g" onclick="pwAddOk()">ثبت گزینه</button><button type="button" class="btn sm" onclick="pwAddCancel()">انصراف</button></div>';
}
/* ---- ساخت یک انتخابگر با دکمه ＋ ---- */
function pwSelect(label,items,cur,onchange,addKind,disabled,dot){
 const opts='<option value="">— انتخاب —</option>'+items.map(it=>'<option value="'+esc(it[0])+'"'+(String(cur)===String(it[0])?' selected':'')+'>'+esc(it[1])+'</option>').join('');
 return '<div class="fg"><label>'+label+'</label><div style="display:flex;gap:4px;align-items:center">'+(dot||'')+
  '<select style="flex:1;min-width:0"'+(disabled?' disabled':'')+' onchange="'+onchange+'">'+opts+'</select>'+
  '<button type="button" class="btn sm" title="افزودن گزینه جدید"'+(disabled?' disabled':'')+' onclick="pwAddOpen(\''+addKind+'\')">＋</button>'+(PW_OPT_KINDS.includes(addKind)?'<button type="button" class="btn sm" title="ویرایش گزینه‌ی انتخاب‌شده" '+((disabled||!cur)?'disabled ':'')+'onclick="pwOptEdit(\''+addKind+'\')">✏️</button><button type="button" class="btn sm r" title="حذف گزینه‌ی انتخاب‌شده از فهرست" '+((disabled||!cur)?'disabled ':'')+'onclick="pwOptDel(\''+addKind+'\')">🗑️</button>':'')+'</div></div>';
}
function pwRender(){
 if(!PW)return;
 const G='display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:10px;margin-bottom:12px';
 const H=t=>'<div class="sec-h" style="margin:6px 0 10px">'+t+'</div>';
 const groups=DB.productGroups.map(g=>[g.id,g.name]);
 const brands=(DB.productOptions.brands||[]).map(b=>[b,b]);
 const models=PW.brand?modelsOfBrand(PW.brand).map(m=>[m,m]):[];
 const mems=(DB.productOptions.memories||[]).map(m=>[m,m]);
 const rams=(DB.productOptions.rams||[]).map(m=>[m,m]);
 const cols=DB.colors.map(c=>[c.id,colorEnOf(c)]);
 const dot='<span style="width:16px;height:16px;border-radius:50%;border:1px solid #bbb;flex:none;background:'+(PW.color?CLH(PW.color):'#eee')+'"></span>';
 let dup='';
 if(PW.dupPid){
  const p=PR(PW.dupPid);
  if(p)dup='<div class="notice red" style="margin-bottom:12px">کالایی با همین نام قبلاً با کد <b dir="ltr">'+esc(p.code)+'</b> ثبت شده است. می‌توانید فقط این سریال را به همان کالا اضافه کنید، یا مشخصات کالا را تغییر دهید.<div style="margin-top:8px"><button type="button" class="btn sm g" onclick="pwCommit(\''+p.id+'\','+(PW.dupKeep?'true':'false')+')">✅ ثبت این سریال برای همان کالا</button></div></div>';
 }
 const specs=H('📋 مشخصات کالا')+'<div class="pw-g" style="'+G+'">'+
  pwSelect('گروه کالا *',groups,PW.group,"PW.group=this.value;if(PW.sellAuto&&pd(PW.lastCost))pwCalcSell();pwRender()",'group')+
  pwSelect('برند *',brands,PW.brand,"PW.brand=this.value;PW.model='';pwRender()",'brand')+
  pwSelect('مدل *',models,PW.model,"PW.model=this.value;pwRender()",'model',!PW.brand)+
  pwSelect('💾 حافظه داخلی',mems,PW.memory,"PW.memory=this.value;pwRender()",'memory')+
  pwSelect('⚡ رم (RAM)',rams,PW.ram,"PW.ram=this.value;pwRender()",'ram')+
  pwSelect('🎨 رنگ',cols,PW.color,"PW.color=this.value;pwRender()",'color',false,dot)+'</div>';
 let ident=H('🔖 کد و سریال')+'<div class="pw-g" style="'+G+'">'+
  '<div class="fg"><label>📦 نحوه پیگیری موجودی</label><select onchange="PW.track=this.value;pwRender()"><option value="serial"'+(PW.track==='serial'?' selected':'')+'>سریالی (هر دستگاه یک سریال)</option><option value="qty"'+(PW.track==='qty'?' selected':'')+'>تعدادی (بدون سریال)</option></select></div>'+
  (PW.track==='serial'
   ?'<div class="fg"><label>#️⃣ شماره سریال دستگاه *</label><input id="pwSn" dir="ltr" placeholder="IMEI / سریال (Enter = ثبت و بعدی)" value="'+esc(PW.sn)+'" oninput="PW.sn=this.value;PW.dupPid=\'\';pwPreviewUpd()" onkeydown="if(event.key===\'Enter\'){event.preventDefault();pwSave(true)}"></div>'
   :'<div class="fg"><label>📦 موجودی</label><input readonly style="background:#f3f7fb" value="۰ — با فاکتور خرید اضافه می‌شود"></div>')+
  '<div class="fg"><label>🏷️ کد کالا</label><div style="display:flex;gap:14px;align-items:center;flex-wrap:wrap;margin-bottom:4px">'+
   '<label class="pw-inl"><input type="radio" name="pwCm" '+(PW.codeMode==='auto'?'checked ':'')+'onchange="PW.codeMode=\'auto\';pwRender()"> خودکار</label>'+
   '<label class="pw-inl"><input type="radio" name="pwCm" '+(PW.codeMode==='manual'?'checked ':'')+'onchange="PW.codeMode=\'manual\';pwRender();setTimeout(()=>rf(\'pwCode\'),30)"> دستی</label></div>'+
   (PW.codeMode==='auto'
    ?'<input readonly dir="ltr" style="background:#f3f7fb" value="'+esc(nextProductCode().code)+'">'
    :'<input id="pwCode" dir="ltr" placeholder="مثلاً A56-256" value="'+esc(PW.code)+'" oninput="PW.code=this.value;PW.dupPid=\'\';pwPreviewUpd()">')+'</div>'+
  (PW.track==='serial'?'<div class="fg" style="justify-content:flex-end"><label class="pw-inl" style="white-space:normal"><input type="checkbox" '+(PW.snInName?'checked ':'')+'onchange="PW.snInName=this.checked;pwPreviewUpd()"> سریال اختصاصی در انتهای نام کالا</label><small style="color:var(--mut)">هر موبایل با سریال خودش یک کالای مجزا (با کد جدا) ثبت می‌شود. برای ثبت چند دستگاه هم‌مدل زیر یک کالا، تیک را بردارید.</small></div>':'')+
  '</div>';
 if(PW.editPid)ident=pwIdentEdit(G,H);
 const price=H('💰 قیمت‌گذاری')+'<div class="pw-g" style="'+G+'">'+
  '<div class="fg"><label>💰 قیمت خرید (تومان)</label><input id="pwBuy" class="money" inputmode="numeric" placeholder="0" value="'+(PW.lastCost?Number(PW.lastCost).toLocaleString('en-US'):'')+'" oninput="pwBuyIn(this.value)"></div>'+
  '<div class="fg"><label>🏷️ قیمت فروش (تومان)</label><input id="pwSell" class="money" inputmode="numeric" placeholder="0" value="'+(PW.sellPrice?Number(PW.sellPrice).toLocaleString('en-US'):'')+'" oninput="pwSellIn(this.value)"></div>'+
  '<div class="fg"><label>درصد سود خودکار</label><div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap"><input id="pwMk" style="width:70px" inputmode="decimal" value="'+esc(String(PW.markup))+'" oninput="pwMarkIn(this.value)"><span>٪</span>'+
   '<label class="pw-inl"><input id="pwAuto" type="checkbox" '+(PW.sellAuto?'checked ':'')+'onchange="pwAutoToggle(this.checked)"> فروش = خرید + سود</label></div></div></div>'+
  '<div class="pw-g" style="'+G+'">'+
  '<div class="fg"><label>🔻 حداقل موجودی (هشدار کمبود)</label><input inputmode="numeric" value="'+fa(PW.minStock||0)+'" oninput="PW.minStock=Math.max(0,pd(this.value)||0)"></div>'+
  '<div class="fg"><label>🔁 نقطه سفارش مجدد</label><input inputmode="numeric" value="'+fa(PW.reorder||0)+'" oninput="PW.reorder=Math.max(0,pd(this.value)||0)"></div>'+
  '<div class="fg"><label>📝 توضیحات (اختیاری)</label><input value="'+esc(PW.notes||'')+'" oninput="PW.notes=this.value"></div></div>';
const _body=(PW.editPid?'<div class="notice" style="margin-bottom:12px">✏️ ویرایش مشخصات کالا — تغییرات فقط روی خودِ کالا اثر می‌گذارد؛ فاکتورها و موجودی قبلی دست‌نخورده می‌مانند.</div>':'<div class="notice" style="margin-bottom:12px">ℹ️ معرفی کالا فقط «تعریف کالا» است و <b>موجودی ایجاد نمی‌کند</b>. موجودی تنها با ثبت <b>فاکتور خرید از فروشنده</b> به انبار اضافه می‌شود.</div>')+pwAddBar()+dup+'<div class="pw-layout"><div>'+specs+lapSection()+ident+price+'</div><div class="pw-preview" id="pwPreview"></div></div>';
 const _foot=PW.editPid?'<button type="button" class="btn g" onclick="pwSave(false)">💾 ذخیره‌ی تغییرات</button><button type="button" class="btn r" onclick="pwDelProduct()">🗑️ حذف کالا</button><button type="button" class="btn" onclick="pwCancel()">انصراف</button>':'<button type="button" class="btn g" onclick="pwSave(false)">✅ ثبت کالا</button><button type="button" class="btn p" onclick="pwSave(true)">➕ ثبت و کالای بعدی</button><button type="button" class="btn" onclick="pwCancel()">انصراف</button>';
 if(window._pwTab){
  if(curView!=='newProduct')return;
  $('content').innerHTML='<div class="pgtitle"><h1>'+(PW.editPid?'✏️ ویرایش کالا':'📱 معرفی کالای جدید')+'</h1><span class="sub">این صفحه یک تب است؛ می‌توانید به تب‌های دیگر بروید و فرم نگه داشته می‌شود</span></div><div class="card pwtab">'+_body+'<div class="pwtab-foot">'+_foot+(PW.editPid?'':'<button type="button" class="btn o" onclick="pwReset()">🔄 فرم خالی</button>')+'</div></div>';
 }else{
  openM(mHead(PW.editPid?'✏️ ویرایش کالا':'📱 معرفی کالای جدید')+'<div class="mbody">'+_body+'</div><div class="mfoot">'+_foot+'</div>');
  const mm=document.querySelector('#modal .m');if(mm){mm.classList.add('pwfull');$('modal').classList.add('pwfull')}
 }
 pwPreviewUpd();
}
/* ---- پیش‌نمایش نام، کد و سود ---- */
function pwPreviewUpd(){
 const el=$('pwPreview');if(!el||!PW)return;
 const name=(PW.editPid&&!PW.renameAuto)?((PR(PW.editPid)||{}).name||''):pwName(),cost=pd(PW.lastCost),sell=pd(PW.sellPrice),profit=sell-cost;
 const code=PW.codeMode==='auto'?nextProductCode().code:(String(PW.code||'').trim()||'—');
 const pct=cost?(profit/cost*100):0,over=cost&&profit>profitCapOf(PW.group);
 el.innerHTML='<div class="pw-pl">نام کالا:</div><div class="pw-pv" dir="ltr" style="text-align:right">'+(esc(name)||'<span style="color:#9aa">گزینه‌ها را انتخاب کنید…</span>')+'</div>'+
  '<div class="pw-pl" style="margin-top:6px">کد کالا:</div><div class="pw-pv" style="font-family:monospace" dir="ltr">'+esc(code)+'</div>'+
  (PW.track==='serial'&&PW.sn?'<div class="pw-pl" style="margin-top:6px">سریال:</div><div class="pw-pv" style="font-family:monospace" dir="ltr">'+esc(PW.sn)+'</div>':'')+
  ((cost||sell)?'<div class="pw-pl" style="margin-top:6px">سود هر عدد:</div><div class="pw-pv" style="color:'+(profit<0?'var(--red)':'var(--grn)')+'">'+fm(profit)+' تومان'+(cost?' ('+fa(pct.toFixed(1)).replace('.','٫')+'٪)':'')+'</div>'+(over?'<div style="color:var(--red);font-size:11.5px;margin-top:4px">⛔ سود هر عدد نباید بیشتر از '+fm(profitCapOf(PW.group))+' تومان باشد (الان '+fm(profit-profitCapOf(PW.group))+' تومان بیشتر است)</div>':''):'');
}
/* ---- آیکون گروه کالا ---- */
function pwGroupIcon(n){
 const s=String(n||'').toLowerCase();
 if(s.includes('mobile')||s.includes('موبایل')||s.includes('گوشی'))return'📱';
 if(s.includes('laptop')||s.includes('لپ'))return'💻';
 if(s.includes('console')||s.includes('کنسول'))return'🎮';
 if(s.includes('tablet')||s.includes('تبلت'))return'📲';
 if(s.includes('access')||s.includes('جانبی'))return'🎧';
 return'📦';
}
/* ---- ثبت کالا ---- */
function pwSave(keep){
 if(!PW)return;
 if(PW.editPid){pwUpdate();return}
 PW.dupPid='';
 if(!PW.group){toast('⚠️ گروه کالا را انتخاب کنید',false);return}
 if(!PW.brand){toast('⚠️ برند را انتخاب کنید',false);return}
 if(!PW.model){toast('⚠️ مدل را انتخاب کنید',false);return}
 {const c=pd(PW.lastCost),sl=pd(PW.sellPrice);if(c&&sl-c>profitCapOf(PW.group)){toast('⛔ سود هر عدد حداکثر '+fm(profitCapOf(PW.group))+' تومان است؛ قیمت فروش را کاهش دهید',false);return}}
 const sn=faDig(PW.sn).trim();
 if(PW.track==='serial'){
  if(!sn){toast('⚠️ شماره سریال را وارد کنید',false);return}
  if(DB.serials.some(x=>x.sn===sn)){toast('⚠️ این سریال قبلاً ثبت شده',false);return}
 }
 const name=pwName();
 const ex=DB.products.find(p=>String(p.name).toLowerCase()===name.toLowerCase());
 if(ex){
  if(PW.track==='serial'&&ex.track==='serial'){PW.dupPid=ex.id;PW.dupKeep=!!keep;pwRender();return}
  toast('⚠️ کالایی با همین نام قبلاً ثبت شده (کد '+ex.code+')',false);return;
 }
 if(PW.codeMode==='manual'){
  const c=String(PW.code||'').trim();
  if(!c){toast('⚠️ کد کالا را وارد کنید',false);return}
  if(DB.products.some(p=>String(p.code).toLowerCase()===c.toLowerCase())){toast('⚠️ این کد کالا قبلاً استفاده شده',false);return}
 }
 pwCommit('',keep);
}
function pwCommit(existingPid,keep){
 if(!PW)return;
 const sn=faDig(PW.sn).trim(),cost=pd(PW.lastCost),sell=pd(PW.sellPrice);
 if(PW.track==='serial'&&DB.serials.some(x=>x.sn===sn)){toast('⚠️ این سریال قبلاً ثبت شده',false);return}
 let pid=existingPid,name;
 if(existingPid){
  const p=PR(existingPid);if(!p)return;
  name=p.name;
  if(!p.lastCost&&cost)p.lastCost=cost;
  if(!p.sellPrice&&sell)p.sellPrice=sell;
  if(PW.color&&!(p.colors||[]).includes(PW.color))(p.colors=p.colors||[]).push(PW.color);
 }else{
  name=pwName();
  let code;
  if(PW.codeMode==='manual')code=String(PW.code||'').trim();
  else{const nx=nextProductCode();DB.counters.product=nx.n;code=nx.code}
  pid=uid();
  DB.products.push({id:pid,code,name,group:PW.group,brand:PW.brand,model:PW.model,memory:PW.memory,ram:PW.ram,cpuSeries:PW.cpuSeries||'',cpuGen:PW.cpuGen||'',cpuModel:PW.cpuModel||'',gpu:PW.gpu||'',screen:PW.screen||'',usage:PW.usage||'',cond:PW.cond||'',colors:PW.color?[PW.color]:[],track:PW.track,minStock:Math.max(0,PW.minStock||0),reorder:Math.max(0,PW.reorder||0),lastCost:cost,sellPrice:sell,notes:PW.notes||'',active:true});
 }
 const pr=PR(pid);
 if(PW.track==='serial'){
  DB.serials.push({id:uid(),pid,sn,color:PW.color||'',cost:cost||pr.lastCost||0,price:sell||pr.sellPrice||0,status:'registered',introduced:true,buyInv:'',saleInv:'',date:jToday()});
 }
 logAct((existingPid?'افزودن سریال به کالا: ':'معرفی کالا: ')+name);
 saveDB();
toast('✅ '+(existingPid?'سریال برای کالای موجود ثبت شد: ':'کالا معرفی شد: ')+name+' — موجودی ۰ (با فاکتور خرید به انبار می‌آید)');
 if(keep){PW.sn='';PW.code='';PW.minStock=0;PW.dupPid='';PW.adding='';pwRender();setTimeout(()=>rf('pwSn'),30)}
 else{PW=null;if(window._pwTab){window._pwTab=false;openPages=openPages.filter(x=>x!=='newProduct');nav('products');return}closeM()}
 if(curView==='products')vProducts();
}
/* ---- حذف کالا ---- */
function productDel(pid,fromEdit){
 const p=PR(pid);if(!p)return;
 if(DB.invoices.some(i=>i.lines.some(l=>l.pid===pid))){toast('⛔ این کالا در فاکتورها استفاده شده و حذف نمی‌شود (برای حذف، ابتدا فاکتورهای مربوط را حذف کنید)',false);return}
 const inUse=DB.invoices.some(i=>i.lines.some(l=>l.pid===pid))||DB.serials.some(s=>s.pid===pid);
 const msg=inUse?'⚠️ این کالا در فاکتورها یا سریال‌ها استفاده شده است. حذف آن ممکن است گزارش‌ها را تحت تأثیر قرار دهد.':'';
 confirmM('حذف کالای «'+esc(p.name)+'»؟ '+msg,async()=>{
  DB.products=DB.products.filter(x=>x.id!==pid);
  DB.serials=DB.serials.filter(s=>s.pid!==pid);
  logAct('حذف کالا: '+p.name);
  await saveDB();closeM();if(fromEdit){PW=null;window._pwTab=false;pageTitles.newProduct='معرفی کالای جدید';openPages=openPages.filter(x=>x!=='newProduct');nav('products')}else vProducts();toast('🗑️ کالا حذف شد');
 });
}
/* ---- ویرایش سریال‌های یک کالا ---- */
function serialsM(pid){
 const p=PR(pid);if(!p)return;
 const list=DB.serials.filter(s=>s.pid===pid);
 openM(mHead('#️⃣ سریال‌های کالا: '+esc(p.name))+'<div class="mbody">'+
 '<div class="frow"><div class="fg"><label>#️⃣ ثبت سریال جدید (موجودی با فاکتور خرید اضافه می‌شود)</label><div style="display:flex;gap:4px"><input id="newSn" dir="ltr" placeholder="IMEI / سریال" style="flex:1"><button class="btn sm g" onclick="serialAdd(\''+pid+'\')">＋ افزودن</button></div></div></div>'+
 '<table data-rn="0"><thead><tr><th>سریال</th><th>رنگ</th><th>قیمت خرید</th><th>قیمت فروش</th><th>وضعیت</th><th></th></tr></thead><tbody>'+
  (list.map(s=>{const st=serialStFa(s.status);return '<tr><td style="font-family:monospace" dir="ltr">'+esc(s.sn)+'</td><td>'+(s.color?'<span class="sw" style="background:'+CLH(s.color)+'"></span> '+esc(CL(s.color)):'—')+'</td><td class="amt">'+fm(s.cost)+'</td><td class="amt">'+fm(s.price)+'</td><td><span class="bdg '+st[0]+'">'+st[1]+'</span></td><td>'+((s.status==='stock'||s.status==='registered')?'<button class="btn sm r" onclick="serialDel(\''+s.id+'\')">🗑️</button>':'')+'</td></tr>'}).join('')||'<tr><td colspan="6"><div class="empty">سریالی ثبت نشده</div></td></tr>')+
 '</tbody></table></div><div class="mfoot"><button class="btn" onclick="closeM()">بستن</button></div>',true);
}
function serialAdd(pid){
 const el=$('newSn');if(!el)return;
 const sn=(el.value||'').trim();
 if(!sn){toast('⚠️ سریال را وارد کنید',false);return}
 if(DB.serials.some(s=>s.sn===sn)){toast('⚠️ این سریال قبلاً ثبت شده',false);return}
 const p=PR(pid);
DB.serials.push({id:uid(),pid,sn,color:(p.colors||[])[0]||'',cost:p.lastCost||0,price:p.sellPrice||0,status:'registered',introduced:true,buyInv:'',saleInv:'',date:jToday()});
  saveDB();serialsM(pid);toast('✅ سریال ثبت شد (خارج از انبار تا ثبت فاکتور خرید)');
}
function serialDel(sid){
 const s=DB.serials.find(x=>x.id===sid);if(!s)return;
 if(s.status==='sold'){toast('⚠️ این سریال فروخته شده و حذف آن ممکن نیست؛ ابتدا فاکتور فروش را حذف یا برگشت بزنید',false);return}
 confirmM('حذف سریال «'+esc(s.sn)+'»؟',async()=>{DB.serials=DB.serials.filter(x=>x.id!==sid);await saveDB();serialsM(s.pid);toast('🗑️ سریال حذف شد')});
}
/* ---- گزارش کمبود ---- */
function shortageRep(){
 _shortList=DB.products.filter(p=>stockOf(p.id)<=p.reorder).map(p=>({'کد':p.code,'کالا':p.name,'موجودی':stockOf(p.id),'حداقل':p.minStock,'نقطه سفارش':p.reorder,'وضعیت':stockOf(p.id)<=p.minStock?'کمبود':'سفارش','پیشنهاد سفارش':Math.max(0,Math.max(p.minStock,p.reorder)*2-stockOf(p.id))}));
 openM(mHead('⚠️ گزارش کمبود کالا')+'<div class="mbody"><table data-rn="0"><thead><tr><th>کد</th><th>کالا</th><th>موجودی</th><th>حداقل</th><th>نقطه سفارش</th><th>وضعیت</th><th>پیشنهاد سفارش</th></tr></thead><tbody>'+
 _shortList.map(p=>'<tr><td>'+esc(p['کد'])+'</td><td class="r">'+esc(p['کالا'])+'</td><td class="amt neg">'+fa(p['موجودی'])+'</td><td>'+fa(p['حداقل'])+'</td><td>'+fa(p['نقطه سفارش'])+'</td><td>'+(p['وضعیت']==='کمبود'?'<span class="bdg b-r">کمبود!</span>':'<span class="bdg b-o">سفارش</span>')+'</td><td class="amt pos">'+fa(p['پیشنهاد سفارش'])+'</td></tr>').join('')+'</tbody></table></div><div class="mfoot"><button class="btn p" onclick="xlOut(window._shortList,\'کمبود-کالا\')">📊 اکسل</button><button class="btn" style="background:#fff" onclick="printModalTable(\'گزارش کمبود کالا\')">🖨️ چاپ</button><button class="btn" onclick="closeM()">بستن</button></div>');
}
/* ---- کنترل موجودی ---- */
function stockControl(){
 const rows=DB.products.map(p=>{const s=stockOf(p.id);return{p,s,need:Math.max(0,Math.max(p.minStock,p.reorder)*2-s)}});
 const low=rows.filter(x=>x.s<=x.p.reorder).sort((a,b)=>a.s-b.s);
 window._scXL=low.map(x=>({'کد':x.p.code,'کالا':x.p.name,'موجودی':x.s,'حداقل':x.p.minStock,'نقطه سفارش':x.p.reorder,'پیشنهاد سفارش':x.need}));
 openM(mHead('🎛️ کنترل موجودی')+'<div class="mbody">'+
 '<div class="notice">تنظیم فعلی: <b>'+(DB.settings.allowNegative?'فروش با موجودی منفی مجاز است':'جلوگیری از فروش با موجودی منفی')+'</b> — <label style="cursor:pointer"><input type="checkbox" '+(DB.settings.allowNegative?'checked':'')+' onchange="DB.settings.allowNegative=this.checked;saveDB();stockControl()"> اجازه فروش با موجودی منفی</label></div>'+
 '<h3 style="font-size:12px">📦 اقلام نیازمند سفارش (به ترتیب کمبود)</h3>'+
 '<table data-rn="0"><thead><tr><th>کد</th><th>کالا</th><th>موجودی</th><th>حداقل</th><th>نقطه سفارش</th><th>وضعیت</th><th>پیشنهاد سفارش</th></tr></thead><tbody>'+
 (low.map(x=>'<tr><td>'+esc(x.p.code)+'</td><td class="r">'+esc(x.p.name)+'</td><td class="amt '+(x.s===0?'neg':'')+'">'+fa(x.s)+'</td><td>'+fa(x.p.minStock)+'</td><td>'+fa(x.p.reorder)+'</td><td>'+(x.s<=x.p.minStock?'<span class="bdg b-r">کمبود!</span>':'<span class="bdg b-o">سفارش</span>')+'</td><td class="amt pos">'+fa(x.need)+' عدد</td></tr>').join('')||'<tr><td colspan="7"><div class="empty">✅ همه اقلام در وضعیت نرمال هستند</div></td></tr>')+
 '</tbody></table></div><div class="mfoot"><button class="btn g" onclick="xlOut(window._scXL,\'کنترل-موجودی\')">📊 اکسل</button><button class="btn p" onclick="printModalTable(\'کنترل موجودی — اقلام نیازمند سفارش\')">🖨️ چاپ</button><button class="btn" onclick="closeM()">بستن</button></div>',true);
}
/* ---- لیست کالاهای معرفی‌شده (صفحه اصلی معرفی کالا) ---- */
function vProducts(){
 const all=DB.products;
 let list=all.filter(p=>{
  if(Fpr.q){const q=faDig(Fpr.q);if(!(faDig([p.code,p.name,p.brand,p.model,p.memory,p.ram,lapSearch(p)].join(' ')).includes(q)))return false}
  if(Fpr.grp&&p.group!==Fpr.grp)return false;
  if(Fpr.brand&&p.brand!==Fpr.brand)return false;
  return true;
 });
 if(Fpr.sort==='code')list.sort((a,b)=>String(a.code).localeCompare(String(b.code),undefined,{numeric:true}));
 else if(Fpr.sort==='named')list.sort((a,b)=>b.name.localeCompare(a.name,'fa'));
 else list.sort((a,b)=>a.name.localeCompare(b.name,'fa'));
 let totVal=0,lowN=0,outN=0;
 all.forEach(p=>{const s=stockOf(p.id);totVal+=s*unitCost(p);if(s<=p.reorder)lowN++;if(s===0)outN++});
 const tQty=all.reduce((t,p)=>t+stockOf(p.id),0);
 const _pg_products=pgSlice('products',list,JSON.stringify(Fpr),vProducts);
 $('content').innerHTML=`
 <div class="pgtitle"><h1>📱 معرفی کالا</h1><span class="sub">${fa(all.length)} قلم کالا — ${fa(tQty)} عدد در انبار</span>
  <button class="btn p" onclick="productWizard()">➕ معرفی کالای جدید</button>
 </div>
 <div class="statgrid">
  <div class="stat"><div class="l">📱 تعداد کالا</div><div class="v">${fa(all.length)} قلم</div></div>
  <div class="stat g"><div class="l">📦 مجموع موجودی انبار</div><div class="v">${fa(tQty)} عدد</div></div>
  <div class="stat o"><div class="l">💰 موجودی ریالی انبار (فی خرید)</div><div class="v">${fm(totVal)} <small>تومان</small></div></div>
  <div class="stat r"><div class="l">⚠️ زیر نقطه سفارش / ناموجود</div><div class="v">${fa(lowN+outN)} قلم</div></div>
 </div>
 <div class="card">
  <div class="searchbar">
   <input id="qIn" placeholder="🔍 کد / نام / برند / مدل..." value="${esc(Fpr.q)}" oninput="Fpr.q=this.value;vProducts();rf('qIn')">
   <select onchange="Fpr.grp=this.value;vProducts()"><option value="">همه گروه‌ها</option>${DB.productGroups.map(g=>'<option value="'+g.id+'" '+(Fpr.grp===g.id?'selected':'')+'>'+esc(g.name)+'</option>').join('')}</select>
   <select onchange="Fpr.brand=this.value;vProducts()"><option value="">همه برندها</option>${[...new Set(all.map(p=>p.brand).filter(Boolean))].map(b=>'<option '+(Fpr.brand===b?'selected':'')+'>'+esc(b)+'</option>').join('')}</select>
   <select onchange="Fpr.sort=this.value;vProducts()"><option value="name" ${Fpr.sort==='name'?'selected':''}>مرتب: نام (الفبا)</option><option value="named" ${Fpr.sort==='named'?'selected':''}>مرتب: نام (معکوس)</option><option value="code" ${Fpr.sort==='code'?'selected':''}>مرتب: کد</option></select>
   <button class="btn" onclick="Fpr.q='';Fpr.grp='';Fpr.brand='';vProducts()">پاک کردن</button>
  </div>
  <div class="toolbar" style="flex-wrap:wrap;gap:8px;margin-top:10px">
   <button class="btn o" onclick="stockControl()">📦 کنترل موجودی</button>
   <button class="btn o" onclick="shortageRep()">⚠️ گزارش کمبود</button>
   <button class="btn g" onclick="nav('inventory')">🏬 انبار و موجودی</button>
   <button class="btn g" onclick="vReports()">📊 گزارش‌ها</button>
  </div>
 </div>
 ${pgBar('products','top')}<table data-rn="products"><thead><tr><th>کد</th><th>نام کالا</th><th>گروه</th><th>موجودی</th><th>قیمت خرید</th><th>قیمت فروش</th><th>موجودی ریالی</th><th>وضعیت</th><th>عملیات</th></tr></thead><tbody>
 ${_pg_products.map(p=>{const s=stockOf(p.id);const st=s<=p.minStock?['b-r','کمبود']:s<=p.reorder?['b-o','سفارش']:['b-g','نرمال'];const grp=(DB.productGroups.find(g=>g.id===p.group)||{}).name||'—';return `<tr><td>${esc(p.code)}</td><td class="r"><b>${esc(p.name)}</b><div style="font-size:10.5px;color:#7a8a99">${esc([p.brand,p.model,p.memory,p.ram].filter(Boolean).join(' • '))}</div>${lapSpecHtml(p)}</td><td><span class="bdg b-b">${esc(grp)}</span></td><td class="amt" style="font-size:13px">${fa(s)}</td><td class="amt">${fm(p.lastCost)}</td><td class="amt">${fm(p.sellPrice)}</td><td class="amt">${fm(s*p.lastCost)}</td><td><span class="bdg ${st[0]}">${st[1]}</span></td><td style="white-space:nowrap"><button class="btn sm" title="ویرایش همه‌ی مشخصات / حذف" onclick="productEdit('${p.id}')">✏️</button> ${lapIsGroup(p.group)?`<button class="btn sm" title="مشخصات لپ‌تاپ" onclick="lapEdit('${p.id}')">💻</button> `:''}<button class="btn sm" title="سریال‌ها" onclick="serialsM('${p.id}')">#️⃣</button> <button class="btn sm r" title="حذف" onclick="productDel('${p.id}')">🗑️</button></td></tr>`}).join('')||'<tr><td colspan="9"><div class="empty"><div class="b">📱</div>کالایی یافت نشد — روی «معرفی کالای جدید» بزنید</div></td></tr>'}
 </tbody>
 <tfoot><tr style="background:#f4f8fb;font-weight:800"><td colspan="3">جمع (${fa(list.length)} قلم)</td><td class="amt">${fa(list.reduce((t,p)=>t+stockOf(p.id),0))}</td><td colspan="2">—</td><td class="amt">${fm(list.reduce((t,p)=>t+stockOf(p.id)*p.lastCost,0))}</td><td colspan="2"></td></tr></tfoot>
 </table>${pgBar('products')}`;
}
/* ===== لیست کالا: همه‌ی کالاها (موجود، ناموجود و زیر نقطه سفارش) ===== */
const Fpl={q:'',grp:'',brand:'',stock:'',sort:'name'};
function plStatus(p){const s=stockOf(p.id);return s<=0?['b-r','ناموجود']:s<=p.reorder?['b-o','کم‌موجودی']:['b-g','موجود']}
function plFiltered(){
 const q=faDig(Fpl.q||'').toLowerCase();
 const list=DB.products.filter(p=>{
  const s=stockOf(p.id);
  if(q&&!faDig([p.code,p.name,p.brand,p.model,p.memory,p.ram,lapSearch(p)].join(' ')).toLowerCase().includes(q))return false;
  if(Fpl.grp&&p.group!==Fpl.grp)return false;
  if(Fpl.brand&&p.brand!==Fpl.brand)return false;
  if(Fpl.stock==='in'&&!(s>0))return false;
  if(Fpl.stock==='out'&&!(s<=0))return false;
  if(Fpl.stock==='low'&&!(s>0&&s<=p.reorder))return false;
  return true;
 });
 if(Fpl.sort==='code')list.sort((a,b)=>String(a.code).localeCompare(String(b.code),undefined,{numeric:true}));
 else if(Fpl.sort==='stock')list.sort((a,b)=>stockOf(b.id)-stockOf(a.id));
 else if(Fpl.sort==='stockasc')list.sort((a,b)=>stockOf(a.id)-stockOf(b.id));
 else list.sort((a,b)=>a.name.localeCompare(b.name,'fa'));
 return list;
}
function vProductList(){
 const all=DB.products,list=plFiltered();
 let nIn=0,nOut=0,nLow=0,tQty=0,tVal=0;
 all.forEach(p=>{const s=stockOf(p.id);if(s>0){nIn++;tQty+=s;tVal+=s*unitCost(p);if(s<=p.reorder)nLow++}else nOut++});
 const sel=(k,v,t)=>'<option value="'+v+'" '+(Fpl[k]===v?'selected':'')+'>'+t+'</option>';
 const _pg_productlist=pgSlice('productlist',list,JSON.stringify(Fpl),vProductList);
 $('content').innerHTML=`
 <div class="pgtitle"><h1>📦 لیست کالا</h1><span class="sub">همه‌ی کالاها — ${fa(all.length)} قلم</span></div>
 <div class="statgrid">
  <div class="stat"><div class="l">📱 کل کالاها</div><div class="v">${fa(all.length)} قلم</div></div>
  <div class="stat g"><div class="l">✅ موجود در انبار</div><div class="v">${fa(nIn)} قلم <small>(${fa(tQty)} عدد)</small></div></div>
  <div class="stat r"><div class="l">⛔ ناموجود</div><div class="v">${fa(nOut)} قلم</div></div>
  <div class="stat o"><div class="l">💰 موجودی ریالی (فی خرید)</div><div class="v">${fm(tVal)} <small>تومان</small></div></div>
 </div>
 <div class="card">
  <div class="searchbar">
   <input id="plQ" placeholder="🔍 کد / نام / برند / مدل / حافظه..." value="${esc(Fpl.q)}" style="min-width:250px" oninput="Fpl.q=this.value;vProductList();rf('plQ')">
   <select onchange="Fpl.stock=this.value;vProductList()">${sel('stock','','همه (موجود و ناموجود)')}${sel('stock','in','فقط موجود')}${sel('stock','out','فقط ناموجود')}${sel('stock','low','کم‌موجودی (زیر نقطه سفارش)')}</select>
   <select onchange="Fpl.grp=this.value;vProductList()"><option value="">همه گروه‌ها</option>${DB.productGroups.map(g=>'<option value="'+g.id+'" '+(Fpl.grp===g.id?'selected':'')+'>'+esc(g.name)+'</option>').join('')}</select>
   <select onchange="Fpl.brand=this.value;vProductList()"><option value="">همه برندها</option>${[...new Set(all.map(p=>p.brand).filter(Boolean))].map(b=>'<option '+(Fpl.brand===b?'selected':'')+'>'+esc(b)+'</option>').join('')}</select>
   <select onchange="Fpl.sort=this.value;vProductList()">${sel('sort','name','مرتب: نام')}${sel('sort','code','مرتب: کد')}${sel('sort','stock','مرتب: بیشترین موجودی')}${sel('sort','stockasc','مرتب: کمترین موجودی')}</select>
   <button class="btn" onclick="Fpl.q='';Fpl.grp='';Fpl.brand='';Fpl.stock='';vProductList()">پاک کردن</button>
   <button class="btn g" onclick="plExcel()">📊 خروجی اکسل</button>
  </div>
  ${pgBar('productlist','top')}<table data-rn="productlist"><thead><tr><th>کد</th><th>نام کالا</th><th>گروه</th><th>موجودی</th><th>قیمت خرید</th><th>قیمت فروش</th><th>موجودی ریالی</th><th>وضعیت</th><th>سریال‌ها</th></tr></thead><tbody>
  ${_pg_productlist.map(p=>{const s=stockOf(p.id),st=plStatus(p),grp=(DB.productGroups.find(g=>g.id===p.group)||{}).name||'—';return `<tr><td>${esc(p.code)}</td><td class="r"><b>${esc(p.name)}</b><div style="font-size:10.5px;color:#7a8a99">${esc([p.brand,p.model,p.memory,p.ram].filter(Boolean).join(' • '))}</div>${lapSpecHtml(p)}</td><td><span class="bdg b-b">${esc(grp)}</span></td><td class="amt ${s<=0?'neg':''}" style="font-size:13px">${fa(s)}</td><td class="amt">${fm(p.lastCost)}</td><td class="amt">${fm(p.sellPrice)}</td><td class="amt">${fm(Math.max(0,s)*p.lastCost)}</td><td><span class="bdg ${st[0]}">${st[1]}</span></td><td>${p.track==='serial'?`<button class="btn sm" onclick="serialsM('${p.id}')">#️⃣ مشاهده</button>`:'—'}</td></tr>`}).join('')||'<tr><td colspan="9"><div class="empty"><div class="b">📦</div>کالایی یافت نشد</div></td></tr>'}
  </tbody>
  <tfoot><tr style="background:#f4f8fb;font-weight:800"><td colspan="3">جمع (${fa(list.length)} قلم)</td><td class="amt">${fa(list.reduce((t,p)=>t+Math.max(0,stockOf(p.id)),0))}</td><td colspan="2">—</td><td class="amt">${fm(list.reduce((t,p)=>t+Math.max(0,stockOf(p.id))*p.lastCost,0))}</td><td colspan="2"></td></tr></tfoot>
  </table>${pgBar('productlist')}</div>`;
}
function plExcel(){xlOut(plFiltered().map(p=>({'کد':p.code,'نام کالا':p.name,'برند':p.brand||'','مدل':p.model||'','گروه':(DB.productGroups.find(g=>g.id===p.group)||{}).name||'','موجودی':stockOf(p.id),'قیمت خرید':p.lastCost||0,'قیمت فروش':p.sellPrice||0,'وضعیت':plStatus(p)[1]})),'لیست-کالا-تکنوکالا')}
/* ---- کالاهای یک فروشنده ---- */
function supplierProducts(pid){
 pid=pid||'';
 const m={};
 DB.invoices.forEach(inv=>{
  if(inv.type!=='buy'&&inv.type!=='buyret')return;
  if(pid&&inv.person!==pid)return;
  const sign=inv.type==='buy'?1:-1;
  inv.lines.forEach(l=>{
   m[l.pid]=m[l.pid]||{q:0,amt:0,n:0,last:'',lastCost:0,prs:{}};
   const o=m[l.pid];
   if(sign>0){o.q+=l.qty;o.amt+=l.qty*l.price;o.n++;if(inv.date>o.last){o.last=inv.date;o.lastCost=l.price}}
   else{o.q-=l.qty;o.amt-=l.qty*l.price}
   o.prs[inv.person]=1;
  });
 });
 const entries=Object.entries(m).filter(([pid2,o])=>o.n>0||o.q!==0);
 window._sprodXL=entries.map(([pid2,o])=>{const pr=PR(pid2)||{};return{'کد':pr.code||'','کالا':pr.name||'?','فروشنده(ها)':Object.keys(o.prs).map(PN).join('، '),'جمع تعداد خرید':o.q,'جمع مبلغ':o.amt,'تعداد فاکتور':o.n,'آخرین خرید':o.last,'آخرین قیمت خرید':o.lastCost,'موجودی فعلی':stockOf(pid2)}});
 let tQ=0,tA=0;
 openM(mHead('🚚 کالاهای یک فروشنده')+'<div class="mbody">'+
 '<div class="frow"><div class="fg"><label>فروشنده را انتخاب کنید</label><select onchange="supplierProducts(this.value)" style="min-width:260px"><option value="">— همه فروشندگان —</option>'+DB.persons.map(pp=>'<option value="'+pp.id+'" '+(pid===pp.id?'selected':'')+'>'+esc(pp.name)+'</option>').join('')+'</select></div></div>'+
 (entries.length?'<table data-rn="0"><thead><tr><th>کد</th><th>کالا</th>'+(pid?'':'<th>فروشنده(ها)</th>')+'<th>جمع تعداد خرید</th><th>جمع مبلغ</th><th>تعداد فاکتور</th><th>آخرین خرید</th><th>آخرین قیمت خرید</th><th>موجودی فعلی</th></tr></thead><tbody>'+
 entries.map(([pid2,o])=>{const pr=PR(pid2)||{};tQ+=o.q;tA+=o.amt;return '<tr><td>'+esc(pr.code||'?')+'</td><td class="r"><b>'+esc(pr.name||'?')+'</b></td>'+
  (pid?'':'<td class="r">'+Object.keys(o.prs).map(ppn=>esc(PN(ppn))).join('، ')+'</td>')+
  '<td class="amt">'+fa(o.q)+'</td><td class="amt">'+fm(o.amt)+'</td><td>'+fa(o.n)+'</td><td>'+jShort(o.last)+'</td><td class="amt">'+fm(o.lastCost)+'</td><td class="amt">'+fa(stockOf(pid2))+'</td></tr>'}).join('')+
 '<tr style="background:#f4f8fb;font-weight:800"><td colspan="'+(pid?2:3)+'">جمع</td><td>'+fa(tQ)+'</td><td>'+fm(tA)+'</td><td colspan="4"></td></tr>'+
 '</tbody></table>':'<div class="empty">'+(pid?'از این فروشنده خریدی ثبت نشده':'هیچ خریدی ثبت نشده')+'</div>')+
 '</div><div class="mfoot">'+(pid?'<button class="btn o" onclick="settleForm(\'out\',\''+pid+'\')">💸 پرداخت به این فروشنده</button>':'')+'<button class="btn g" onclick="xlOut(window._sprodXL,\'کالاهای-فروشنده\')">📊 اکسل</button><button class="btn p" onclick="printModalTable(\'کالاهای یک فروشنده\')">🖨️ چاپ</button><button class="btn" onclick="closeM()">بستن</button></div>',true);
}
/* ---- فروشندگان یک کالا ---- */
function suppliersOfProduct(pid){
 pid=pid||'';
 const m={};
 DB.invoices.forEach(inv=>{
  const sign=inv.type==='buy'?1:(inv.type==='buyret'?-1:0);if(!sign)return;
  inv.lines.forEach(l=>{
   if(pid&&l.pid!==pid)return;
   m[inv.person]=m[inv.person]||{n:0,q:0,amt:0,last:''};
   const o=m[inv.person];
   if(sign>0){o.n++;o.q+=l.qty;o.amt+=l.qty*l.price;if(inv.date>o.last)o.last=inv.date}
   else{o.q-=l.qty;o.amt-=l.qty*l.price}
  });
 });
 const entries=Object.entries(m);
 window._supXL=entries.map(([per,o])=>({'فروشنده':PN(per),'تعداد فاکتور خرید':o.n,'جمع تعداد':o.q,'جمع مبلغ خرید':o.amt,'آخرین خرید':o.last}));
 let totQ=0,totA=0;
 openM(mHead(pid?'🚚 فروشندگان کالای: '+esc((PR(pid)||{}).name||''):'🚚 فروشندگان (همه کالاها)')+'<div class="mbody">'+
 '<div class="frow"><div class="fg"><label>کالا را انتخاب کنید</label><select onchange="suppliersOfProduct(this.value)" style="min-width:280px"><option value="">— همه کالاها —</option>'+DB.products.map(p=>'<option value="'+p.id+'" '+(pid===p.id?'selected':'')+'>'+esc(p.code+' — '+p.name)+'</option>').join('')+'</select></div></div>'+
 (entries.length?'<table data-rn="0"><thead><tr><th>فروشنده</th><th>تعداد فاکتور خرید</th><th>جمع تعداد</th><th>جمع مبلغ خرید</th><th>آخرین خرید</th><th>عملیات</th></tr></thead><tbody>'+
 entries.map(([per,o])=>{totQ+=o.q;totA+=o.amt;return '<tr><td class="r"><b>'+esc(PN(per))+'</b></td><td>'+fa(o.n)+'</td><td class="amt">'+fa(o.q)+'</td><td class="amt">'+fm(o.amt)+'</td><td>'+jShort(o.last)+'</td><td style="white-space:nowrap"><button class="btn sm" onclick="closeM();personProfile(\''+per+'\')">👁️ پرونده</button><button class="btn sm o" onclick="settleForm(\'out\',\''+per+'\')">💸 پرداخت</button></td></tr>'}).join('')+
 '<tr style="background:#f4f8fb;font-weight:800"><td>جمع</td><td></td><td>'+fa(totQ)+'</td><td>'+fm(totA)+'</td><td colspan="2"></td></tr></tbody></table>':'<div class="empty">برای این کالا خریدی ثبت نشده</div>')+
 '</div><div class="mfoot"><button class="btn g" onclick="xlOut(window._supXL,\'فروشندگان-کالا\')">📊 اکسل</button><button class="btn p" onclick="printModalTable(\'فروشندگان یک کالا\')">🖨️ چاپ</button><button class="btn" onclick="closeM()">بستن</button></div>',true);
}
