/* ================= جستجوی سراسری هوشمند (Ctrl+K) ================= */
let spItems=[],spSel=-1;
function spNorm(s){return faDig(String(s==null?'':s)).toLowerCase()}
function spMatch(q,txt){return spNorm(txt).includes(q)}
function spOpen(){
 const p=$('searchPal');if(!p)return;
 p.classList.add('open');const inp=$('spInput');inp.value='';spSearch('');rf('spInput');
}
function spClose(){const p=$('searchPal');if(p)p.classList.remove('open')}
function spBuild(q){
 if(!DB)return[];
 const out=[];
 DB.persons.forEach(p=>{
  if(spMatch(q,p.name)||spMatch(q,p.phone)||spMatch(q,p.code)||spMatch(q,p.nationalId)){
   const b=personBalance(p.id);
   out.push({ic:'👤',t:p.name,s:'کد '+fa(p.code)+' — '+(p.phone?'موبایل '+fa(p.phone)+' — ':'')+(b.saleDebt>0?'بدهی '+fm(b.saleDebt)+' ت':'بدون بدهی'),kind:'شخص',go(){closeM();spClose();nav('persons');setTimeout(()=>{Fp.q=p.name;vPersons();rf('qIn')},60)}});
  } });
 DB.products.forEach(p=>{
  if(spMatch(q,p.name)||spMatch(q,p.code)||spMatch(q,p.brand)){
   out.push({ic:'📱',t:p.name,s:'کد '+fa(p.code)+' — موجودی '+fa(stockOf(p.id))+' — قیمت '+fm(p.sellPrice)+' ت',kind:'کالا',go(){closeM();spClose();nav('products');setTimeout(()=>{Fpr.q=p.name;vProducts();rf('qIn')},60)}});
  } });
 DB.serials.forEach(s=>{
  if(spMatch(q,s.sn)){
   const p=PR(s.pid);
   out.push({ic:'#️⃣',t:'سریال '+fa(s.sn),s:(p?p.name:'?')+' — '+serialStFa(s.status)[1],kind:'سریال',go(){closeM();nav('inventory');setTimeout(()=>stockControl(),60)}});
  } });
 DB.invoices.forEach(inv=>{
  if(spMatch(q,inv.no)||spMatch(q,PN(inv.person))){
   out.push({ic:'🧾',t:invTypeFa(inv.type)+' شماره '+fa(inv.no),s:PN(inv.person)+' — '+jShort(inv.date)+' — '+fm(invTotal(inv))+' ت',kind:'فاکتور',go(){closeM();spClose();invView(inv.id)}});
  } });
 DB.cheques.forEach(c=>{
  if(spMatch(q,c.no)||spMatch(q,PN(c.person))){
   out.push({ic:'🏦',t:'چک '+fa(c.no||'—'),s:PN(c.person)+' — '+jShort(c.due)+' — '+fm(c.amount)+' ت — '+c.status,kind:'چک',go(){closeM();spClose();nav('cheques');setTimeout(()=>vCheques('all'),60)}});
  } });
 DB.installments.forEach(i=>{
  if(spMatch(q,PN(i.person))){
   out.push({ic:'📅',t:'قسط '+PN(i.person),s:'سررسید '+jShort(i.due)+' — '+fm(i.amount)+' ت — '+(i.paid?'پرداخت‌شده':'باز'),kind:'قسط',go(){closeM();spClose();nav('inst');setTimeout(()=>vInst('open'),60)}});
  } });
 return out.slice(0,40);
}
function spSearch(v){
 const q=spNorm(v).trim();
 spItems=q?spBuild(q):[];
 spSel=-1;
 const el=$('spList');
 if(!q){el.innerHTML='<div class="sp-empty">⌨️ برای جستجو در همه لیست‌ها تایپ کنید<br><small>مشتری · کالا · سریال · فاکتور · چک · قسط</small></div>';return}
 if(!spItems.length){el.innerHTML='<div class="sp-empty">🔍 نتیجه‌ای برای «'+esc(v)+'» یافت نشد</div>';return}
 el.innerHTML=spItems.map((x,i)=>'<div class="sp-item'+(i===spSel?' sel':'')+'" onmouseenter="spSel='+i+';spRenderSel()" onclick="spRun('+i+')"><span class="sp-ic">'+x.ic+'</span><div><div class="sp-t">'+esc(x.t)+'</div><div class="sp-meta">'+esc(x.s)+'</div></div><span class="sp-kind">'+x.kind+'</span></div>').join('');
}
function spRenderSel(){
 [...document.querySelectorAll('#spList .sp-item')].forEach((el,i)=>el.classList.toggle('sel',i===spSel));
}
function spRun(i){
 const it=spItems[i];if(!it)return;
 spClose();it.go();
}
function spKey(e){
 if(e.key==='Escape'){spClose();return}
 if(e.key==='ArrowDown'||e.key==='ArrowUp'){
  e.preventDefault();
  if(!spItems.length)return;
  spSel=(spSel+(e.key==='ArrowDown'?1:-1)+spItems.length)%spItems.length;
  spRenderSel();
  const el=document.querySelectorAll('#spList .sp-item')[spSel];
  if(el)el.scrollIntoView({block:'nearest'});
 }else if(e.key==='Enter'){
  e.preventDefault();
  if(spSel>=0&&spItems[spSel])spRun(spSel);
  else if(spItems.length)spRun(0);
 }
}

