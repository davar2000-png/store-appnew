/* ================= گروه‌بندی لیست اقساط ================= */
const IG_DEF=[['ig-normal','مشتریان عادی'],['ig-faraja','پرسنل فراجا'],['ig-refah','مستمری بگیران رفاه'],['ig-azad','کارکنان دانشگاه آزاد'],['ig-uma','کارکنان دانشگاه محقق اردبیلی'],['ig-seda','کارکنان صدا و سیما']];
function instGroups(){
 if(!Array.isArray(DB.instGroups))DB.instGroups=IG_DEF.map(x=>({id:x[0],name:x[1]}));
 if(!DB.instGroups.some(g=>g.id==='ig-normal'))DB.instGroups.unshift({id:'ig-normal',name:IG_DEF[0][1]});
 return DB.instGroups;
}
function instGrp(i){const gs=instGroups();return i.grp&&gs.some(g=>g.id===i.grp)?i.grp:'ig-normal'}
function instGName(id){const g=instGroups().find(x=>x.id===id);return g?g.name:'—'}
function instInGrp(i){return !Fi.grp||instGrp(i)===Fi.grp}
function instSetGrp(id,view){Fi.grp=id;Fi.plan='';vInst(view||'list')}
function instGrpBar(view){
 const gs=instGroups(),cnt={};DB.installments.forEach(i=>{const k=instGrp(i);cnt[k]=(cnt[k]||0)+1});
 const chip=(id,label,n)=>'<button class="btn sm '+((Fi.grp||'')===id?'p':'')+'" onclick="instSetGrp(\''+id+'\',\''+view+'\')">'+label+' ('+fa(n)+')</button>';
 let h='<div class="card"><div class="toolbar" style="flex-wrap:wrap;gap:6px">'+chip('','📚 همه',DB.installments.length)+gs.map(g=>chip(g.id,esc(g.name),cnt[g.id]||0)).join('')+'<button class="btn sm g" onclick="instGrpAdd()">➕ لیست جدید</button>';
 if(Fi.grp){h+='<button class="btn sm" onclick="instGrpRename()">✏️ تغییر نام</button>';if(Fi.grp!=='ig-normal')h+='<button class="btn sm r" onclick="instGrpDel()">🗑️ حذف لیست</button>'}
 h+='</div>';
 return h+'</div>';
}
function instGrpTools(){
 const gs=instGroups();let h='<details class="card" style="margin-bottom:10px"><summary style="cursor:pointer;font-weight:800">📤 ورود اکسل برای هر لیست، انتقال و گردش بانک رفاه</summary><div style="margin-top:8px">';

  h+='<div style="font-size:12px;color:var(--mut);margin:4px 0 4px">📤 ورود اکسل برای هر لیست (جدا از هم):</div><div class="toolbar" style="flex-wrap:wrap;gap:6px">'+gs.map(g=>'<label class="btn sm" style="cursor:pointer">📤 '+esc(g.name)+'<input type="file" accept=".xlsx,.xls" style="display:none" onchange="xlIn(this,\'installments\',\''+g.id+'\')"></label>').join('')+'</div>';
  h+='<div style="font-size:11px;color:var(--mut);margin-top:6px;line-height:1.9">ستون‌های اکسل: «طرف حساب» (یا «نام طرف حساب»)، «مبلغ» (یا «مبلغ قسط»)، «سررسید» (یا «تاریخ سر رسید»)؛ اختیاری: «شماره قسط»، «سریال»، «توضیحات». شخصِ ناموجود به‌طور خودکار ساخته می‌شود.</div>';
  h+='<div class="toolbar" style="margin-top:6px;flex-wrap:wrap;gap:6px"><button class="btn sm o" onclick="instMoveFiltered()">📂 انتقال نتایج فعلی به لیست دیگر…</button><label class="btn sm g" style="cursor:pointer">🏦 ورود گردش حساب بانک رفاه (وصول خودکار اقساط)<input type="file" accept=".xls,.xlsx" style="display:none" onchange="rfFile(this)"></label></div>';
  return h+'</div></details>';
}
function instGrpAdd(){
 askM('➕ لیست اقساط جدید','نام لیست:','',nm=>{
  nm=nm.replace(/\s+/g,' ').trim();if(!nm)return;
  if(instGroups().some(g=>g.name===nm)){toast('⚠️ لیستی با این نام وجود دارد',false);return}
  const id='ig-'+uid();DB.instGroups.push({id,name:nm});logAct('ایجاد لیست اقساط: '+nm);saveDB();Fi.grp=id;vInst(window._instTab||'list');toast('✅ لیست «'+nm+'» ساخته شد');
 },1,'💾 ذخیره');
}
function instGrpRename(){
 const g=instGroups().find(x=>x.id===Fi.grp);if(!g)return;
 askM('✏️ تغییر نام لیست','نام جدید:',g.name,nm=>{
  nm=nm.replace(/\s+/g,' ').trim();if(!nm)return;
  if(instGroups().some(x=>x.id!==g.id&&x.name===nm)){toast('⚠️ لیستی با این نام وجود دارد',false);return}
  g.name=nm;logAct('تغییر نام لیست اقساط: '+nm);saveDB();vInst(window._instTab||'list');
 },1,'💾 ذخیره');
}
function instGrpDel(){
 const g=instGroups().find(x=>x.id===Fi.grp);if(!g||g.id==='ig-normal')return;
 const n=DB.installments.filter(i=>instGrp(i)===g.id).length;
 confirmM('حذف لیست «'+esc(g.name)+'»؟<br><b>'+fa(n)+'</b> قسط این لیست حذف نمی‌شود و به «'+esc(instGName('ig-normal'))+'» منتقل می‌شود.',()=>{
  DB.installments.forEach(i=>{if(instGrp(i)===g.id)i.grp='ig-normal'});
  DB.instGroups=DB.instGroups.filter(x=>x.id!==g.id);Fi.grp='';logAct('حذف لیست اقساط: '+g.name);saveDB();vInst(window._instTab||'list');
 });
}
function instMoveOpen(ids){
 if(!ids.length){toast('⚠️ قسطی برای انتقال نیست',false);return}
 window._mvIds=ids;
 openM(mHead('📂 انتقال به لیست دیگر')+'<div class="mbody"><div style="margin-bottom:8px"><b>'+fa(ids.length)+'</b> قسط منتقل می‌شود. به کدام لیست؟</div><select id="mvG" style="min-width:260px">'+instGroups().map(g=>'<option value="'+g.id+'">'+esc(g.name)+'</option>').join('')+'</select></div><div class="mfoot"><button class="btn p" onclick="instMoveDo()">📂 انتقال</button><button class="btn" onclick="closeM()">انصراف</button></div>');
}
function instMoveDo(){
 const g=$('mvG').value,set=new Set(window._mvIds||[]);let n=0;
 DB.installments.forEach(i=>{if(set.has(i.id)){i.grp=g;n++}});
 closeM();logAct('انتقال '+n+' قسط به لیست «'+instGName(g)+'»');saveDB();vInst(window._instTab||'list');toast('✅ '+fa(n)+' قسط به «'+instGName(g)+'» منتقل شد');
}
function instMovePlan(id){const i=DB.installments.find(x=>x.id===id);if(!i)return;const k=planKey(i);instMoveOpen(DB.installments.filter(x=>planKey(x)===k).map(x=>x.id))}
function instMoveFiltered(){instMoveOpen((window._instList||[]).map(i=>i.id))}
