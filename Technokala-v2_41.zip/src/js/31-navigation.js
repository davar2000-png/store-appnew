/* ================= ناوبری ================= */
let curView='dash';
let dashInt=null;
const pageTitles={dash:'داشبورد',personIntro:'معرفی اشخاص',persons:'لیست اشخاص',productList:'لیست کالا',instList:'لیست اقساط',products:'معرفی کالا',newProduct:'معرفی کالای جدید',inventory:'انبار',purchase:'خرید',sales:'فروش',invoiceList:'لیست فاکتورها',settle:'تسویه حساب',cheques:'چک‌ها',inst:'اقساط',bank:'بانک و حساب‌ها',reports:'گزارش‌ها',tools:'ابزار و پشتیبان‌گیری'};
let openPages=['dash'];
function toggleNavGroup(button){button.closest('.nav-section').classList.toggle('open')}
function openReport(type){curRep=type;nav('reports')}
function renderPageTabs(){
 const el=$('pageTabs');if(!el)return;
 el.innerHTML=openPages.map(v=>'<button class="page-tab '+(v===curView?'on':'')+'" onclick="nav(\''+v+'\')"><span class="tab-label">'+esc(pageTitles[v]||v)+'</span>'+(openPages.length>1?'<span class="tab-close" onclick="event.stopPropagation();closePage(\''+v+'\')" title="بستن صفحه">×</span>':'')+'</button>').join('');
}
function closePage(v){
 const index=openPages.indexOf(v);if(index<0)return;
 openPages.splice(index,1);
 if(!openPages.length)openPages.push('dash');
 if(curView===v){const next=openPages[Math.min(index,openPages.length-1)];nav(next);return}
 renderPageTabs();
}
function nav(v){ixInvalidate();
 try{window.scrollTo(0,0)}catch(e){}
 if(dashInt&&v!=='dash'){clearInterval(dashInt);dashInt=null}
 if(!openPages.includes(v))openPages.push(v);
 curView=v;
 document.querySelectorAll('.nav-i').forEach(n=>n.classList.toggle('on',n.dataset.v===v));renderPageTabs();
 ({dash:renderDash,personIntro:vPersonIntro,persons:vPersons,productList:vProductList,instList:()=>vInst('list'),products:vProducts,newProduct:vNewProduct,inventory:vInventory,purchase:vPurchase,sales:vSales,invoiceList:vInvoiceList,settle:vSettle,cheques:vFinanceHub,inst:vFinanceHub,bank:vBank,reports:vReports,tools:vTools})[v]();
 notifDotUpd();
}

