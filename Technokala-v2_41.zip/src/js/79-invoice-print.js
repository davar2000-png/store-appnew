/* ===== چاپ فاکتور: قالب حرفه‌ای، لوگوی فروشگاه، فاکتور خرید A5 افقی، پیش‌نمایش پیش از چاپ ===== */
const PRINT_FONT="Tahoma,'Segoe UI','Vazirmatn','DejaVu Sans',sans-serif";
/* ---------- لوگوی فروشگاه ---------- */
async function shopLogoData(){const v=DB.settings&&DB.settings.shopLogo;if(!v)return '';return isImgRef(v)?((await imgLoad(v))||''):v}
function shopLogoUpload(input){
 const f=input.files[0];if(!f)return;const r=new FileReader();
 r.onload=e=>{
  const im=new Image();
  im.onload=async()=>{
   try{
    const s=Math.min(1,420/Math.max(im.width,im.height)),w=Math.max(1,Math.round(im.width*s)),h=Math.max(1,Math.round(im.height*s)),c=document.createElement('canvas');c.width=w;c.height=h;
    c.getContext('2d').drawImage(im,0,0,w,h);
    let u=c.toDataURL('image/png');if(u.length>350000)u=c.toDataURL('image/jpeg',0.86);
    DB.settings.shopLogo=u;await saveDB();const p=$('seLogoPrev');if(p){p.style.display='';p.src=u;p.dataset.ok='1'}
    toast('✅ لوگوی فروشگاه ذخیره شد؛ روی فاکتورهای خرید و فروش چاپ می‌شود');
   }catch(err){toast('❌ لوگو خوانده نشد',false)}
  };
  im.onerror=()=>toast('❌ فایل تصویر معتبر نیست',false);im.src=e.target.result;
 };
 r.readAsDataURL(f);input.value='';
}
function shopLogoRemove(){DB.settings.shopLogo='';saveDB();const p=$('seLogoPrev');if(p)p.style.display='none';toast('🗑️ لوگو حذف شد')}
/* ---------- سند چاپی ---------- */
function printPaper(inv,size){
 const buy=inv&&(inv.type==='buy'||inv.type==='buyret');
 if(buy)return{size:'A5',landscape:true};
 return{size:size==='A5'?'A5':'A4',landscape:false};
}
function printDocHtml(body,o){
 const pg=(o.size==='58mm'||o.size==='80mm')?o.size+' auto':o.size+(o.landscape?' landscape':'');
 return '<!doctype html><html dir="rtl" lang="fa"><head><meta charset="utf-8"><title>'+esc(o.title||'چاپ')+'</title><style>@page{size:'+pg+';margin:'+(o.margin||'8mm')+'}'+(o.css||'')+'</style></head><body class="'+esc(o.cls||'')+'">'+body+'</body></html>';
}
const INV_CSS=`*{box-sizing:border-box}
body{margin:0;font-family:${PRINT_FONT};font-size:12px;color:#161d29;direction:rtl;-webkit-print-color-adjust:exact;print-color-adjust:exact}
body.a4{--w:210mm}body.a5{--w:148mm}body.a5l{--w:210mm}
@media screen{body{background:#cfd6e2;padding:14px 0}.sheet{background:#fff;margin:0 auto;box-shadow:0 6px 26px rgba(15,40,90,.3);padding:8mm;width:var(--w);min-height:calc(var(--w)*1.41)}body.a5l .sheet{min-height:calc(var(--w)*.707)}}
.hd{display:flex;justify-content:space-between;align-items:stretch;gap:12px;border-bottom:2.5px solid #0f4cc2;padding-bottom:6px;margin-bottom:6px}
.brand{display:flex;align-items:center;gap:10px}
.logo{width:60px;height:60px;object-fit:contain;border-radius:8px}
.logo.ph{display:flex;align-items:center;justify-content:center;background:linear-gradient(160deg,#0f4cc2,#0c8fc4);color:#fff;font-size:28px;font-weight:bold}
.shop{font-size:19px;font-weight:bold;color:#0a2a6e}
.sub{font-size:11.5px;color:#2c3645;font-weight:600}
.doc{min-width:58mm;text-align:center;border:1.5px solid #0f4cc2;border-radius:8px;overflow:hidden}
.doc .ttl{background:#0f4cc2;color:#fff;font-size:16px;font-weight:bold;padding:4px 8px}
.doc .meta{display:grid;grid-template-columns:auto 1fr;gap:2px 8px;padding:5px 8px;text-align:right;font-size:12px}
.doc .meta span{color:#3a4452;font-weight:600}
.parties{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:6px}
.box{border:1px solid #bfc5cf;border-radius:7px;padding:5px 8px}
.box h4{margin:0 0 3px;font-size:12px;color:#222b38;border-bottom:1px dashed #bfc5cf;padding-bottom:2px}
.box div{line-height:1.65}.box b{color:#0a2a6e;font-size:12.5px}
table.items{width:100%;border-collapse:collapse;margin:0 0 6px;page-break-inside:auto}
table.items th{background:#e1e4e9;color:#161d29;font-weight:bold;padding:4px 5px;font-size:11.5px;border:1px solid #b3bac5}
table.items td{border:1px solid #c5cad3;padding:4px 5px;text-align:center;font-size:12px}
table.items tr:nth-child(even) td{background:#f3f4f6}
table.items td.n{text-align:right}table.items td small{display:block;color:#2c3645;font-size:10.5px;font-weight:600}
tr{page-break-inside:avoid}
.dense table.items td{padding:1.5px 4px;font-size:11px}.dense table.items th{padding:2px 4px;font-size:11px}.dense table.items td small{display:inline;margin-right:6px;font-size:10.5px}
.sum{display:flex;gap:8px;margin-bottom:6px;align-items:stretch}
.pays{flex:1;border:1px solid #bfc5cf;border-radius:7px;padding:5px 8px;font-size:12px}
.pays h4{margin:0 0 3px;font-size:12px;color:#222b38}
.tot{min-width:70mm;border:1px solid #9aa2af;border-radius:7px;overflow:hidden;font-size:12px}
.tot div{display:flex;justify-content:space-between;padding:3px 8px}
.tot div:nth-child(even){background:#f3f4f6}
.tot .big{background:#d9dde3!important;color:#0b1220;font-weight:bold;font-size:13.5px}
.tot .rem{background:#e9ebef!important;font-weight:bold;font-size:12.5px}
.inst{border:1px solid #bfc5cf;border-radius:7px;margin-bottom:6px;overflow:hidden}
.inst h4{margin:0;padding:3px 8px;background:#e1e4e9;color:#161d29;font-size:11.5px;display:flex;justify-content:space-between}
table.ig{width:100%;border-collapse:collapse}
table.ig th{background:#eceef1;color:#161d29;font-size:11px;padding:2px 3px;border:1px solid #c5cad3}
table.ig td{border:1px solid #c5cad3;padding:2px 3px;text-align:center;font-size:11.5px;height:5.6mm}
table.ig td.no{background:#f3f4f6;color:#222b38;font-weight:bold;width:9mm}
.acct{background:#f1f2f4;border-radius:6px;padding:4px 8px;margin-bottom:6px;font-size:11.5px}
.note{border:1px solid #bfc5cf;background:#fafafa;border-radius:6px;padding:4px 8px;margin-bottom:6px;font-size:11.5px;min-height:12mm}
.terms{font-size:11px;color:#2c3645;margin-bottom:6px;line-height:1.7;font-weight:600}
.sign{display:flex;gap:8px;margin-top:4px}
.sign div{flex:1;border:1px solid #bfc5cf;border-radius:6px;height:16mm;padding:3px 6px;font-size:11px;color:#2c3645;font-weight:600}
.thx{text-align:center;color:#0f4cc2;font-weight:bold;margin-top:6px;font-size:12.5px}
.tight .note{min-height:9mm}.tight .sign div{height:12mm}.tight .terms{margin-bottom:3px}.tight .acct{margin-bottom:4px}
.a5l .hd{padding-bottom:3px;margin-bottom:3px;border-bottom-width:2px}.a5l .logo{width:40px;height:40px}.a5l .shop{font-size:14.5px}.a5l .sub{font-size:10.5px}.a5l .doc .ttl{font-size:12.5px;padding:2px 6px}.a5l .doc .meta{padding:3px 6px;font-size:11px}
.a5l .parties{gap:6px;margin-bottom:3px}.a5l .box{padding:2px 6px}.a5l .box h4{margin:0 0 1px;padding-bottom:1px;font-size:10.5px}.a5l .box div{line-height:1.35;font-size:10.5px}.a5l .box b{font-size:11px}.a5l .box .addr{display:none}
.a5l table.items{margin-bottom:3px}.a5l table.items td{padding:1.5px 3px;font-size:10.5px}.a5l table.items th{padding:2px 3px;font-size:10.5px}.a5l table.items td small{display:none}
.a5l .sum{margin-bottom:3px;gap:6px}.a5l .pays{padding:2px 6px;font-size:10.5px}.a5l .pays h4{margin:0 0 1px;font-size:10.5px}.a5l .tot{font-size:10.5px}.a5l .tot div{padding:1.5px 6px}.a5l .tot .big{font-size:11.5px}.a5l .tot .rem{font-size:11px}
.a5l .sign{margin-top:2px}.a5l .sign div{height:9mm;font-size:10px;padding:2px 5px}.a5l .terms,.a5l .note,.a5l .acct,.a5l .thx{display:none}
.a5 .note{min-height:8mm}.a5 .shop{font-size:15px}.a5 .logo{width:44px;height:44px}.a5 .box .addr{display:none}.a5 body{font-size:11px}.a5 table.items td{font-size:10.5px;padding:3px 3px}.a5 table.items th{font-size:10.5px}.a5 .terms{display:none}.a5 .inst h4{font-size:10.5px}.a5 table.ig td{height:4.8mm;font-size:10.5px}.a5 table.ig th{font-size:10px}.a5 .sub,.a5 .box div,.a5 .pays,.a5 .tot{font-size:10.5px}`;
const _inv=(h,k)=>'<div><span style="color:#333;font-weight:700">'+h+':</span> '+k+'</div>';
function invoiceBodyHtml(inv,logo,paper){
 const s=DB.settings,p=P(inv.person)||{},buy=inv.type==='buy'||inv.type==='buyret',isSale=!buy,title=invTypeFa(inv.type);
 const t=invTotal(inv),paid=invPaid(inv),rem=t-paid,g=p.guarantor,b=personBalance(inv.person);
 const shop={name:s.shopName||'—',tel:s.shopTel||'',addr:s.shopAddr||''};
 const per={name:p.name||'—',tel:[p.phone,p.phone2].filter(Boolean).join('، '),nid:p.nationalId||'',addr:p.addr||''};
 const seller=isSale?{...shop,nid:''}:per,buyer=isSale?per:{...shop,nid:''};
 const box=(h,o)=>'<div class="box"><h4>'+h+'</h4><div><b>'+esc(o.name)+'</b></div>'+(o.tel?_inv('تلفن',fa(o.tel)):'')+(o.nid?_inv('کد ملی',fa(o.nid)):'')+(o.addr?'<div class="addr"><span style="color:#333;font-weight:700">نشانی:</span> '+esc(o.addr)+'</div>':'')+'</div>';
 const insts=isSale?DB.installments.filter(i=>i.inv===inv.id).sort((a,c)=>a.due<c.due?-1:a.due>c.due?1:(a.no||0)-(c.no||0)):[];
 const nl=inv.lines.length,dense=nl>6||insts.length>24;
 let h='<div class="sheet'+(dense?' dense':'')+(nl>10?' xd':'')+'">';
 h+='<div class="hd"><div class="brand">'+(logo?'<img class="logo" src="'+logo+'" alt="">':'<div class="logo ph">'+esc(String(shop.name).trim().charAt(0)||'ت')+'</div>')+
  '<div><div class="shop">'+esc(shop.name)+'</div>'+(shop.addr?'<div class="sub">'+esc(shop.addr)+'</div>':'')+(shop.tel?'<div class="sub">تلفن: '+fa(shop.tel)+'</div>':'')+'</div></div>'+
  '<div class="doc"><div class="ttl">'+title+'</div><div class="meta"><span>شماره</span><b>'+fa(inv.no)+'</b><span>تاریخ</span><b>'+jLong(inv.date)+'</b></div></div></div>';
 h+='<div class="parties">'+box(isSale?'فروشنده':'فروشنده (تأمین‌کننده)',seller)+box(isSale?'خریدار':'خریدار',buyer)+'</div>';
 h+='<table class="items"><thead><tr><th style="width:7mm">ردیف</th><th>شرح کالا</th><th style="width:15mm">رنگ</th><th style="width:34mm">سریال / IMEI</th><th style="width:11mm">تعداد</th><th style="width:25mm">قیمت واحد (تومان)</th><th style="width:27mm">مبلغ (تومان)</th></tr></thead><tbody>'+
  inv.lines.map((l,i)=>{const sr=l.sid?(DB.serials.find(x=>x.id===l.sid)||{}).sn:(l.sn||''),pr=PR(l.pid)||{},sp=(typeof lapSpecText==='function')?lapSpecText(pr):'';
   return '<tr><td>'+fa(i+1)+'</td><td class="n"><b>'+esc(pr.name||'')+'</b>'+(pr.brand&&!String(pr.name||'').toLowerCase().includes(String(pr.brand).toLowerCase())?' — '+esc(pr.brand):'')+(sp?'<small>'+esc(sp)+'</small>':'')+'</td><td>'+esc(CL(l.color))+'</td><td style="direction:ltr">'+(sr?fa(sr):'—')+'</td><td>'+fa(l.qty)+'</td><td>'+fm(l.price)+'</td><td>'+fm(l.qty*l.price)+'</td></tr>'}).join('')+'</tbody></table>';
 const methods=(inv.pays||[]).filter(x=>x.method!=='installment').map(x=>(METHOD_FA[x.method]||x.method)+': <b>'+fm(pd(x.amount))+'</b>'+(x.method==='cheque'?' <small>(سررسید '+jShort(x.chkDue)+')</small>':''));
 const instSum=insts.reduce((a,i)=>a+Number(i.amount||0),0);
 h+='<div class="sum"><div class="pays"><h4>روش تسویه</h4>'+(methods.length?methods.map(m=>'<div>'+m+'</div>').join(''):'<div style="color:#889">—</div>')+
  (insts.length?'<div>اقساط: <b>'+fm(instSum)+'</b> <small>('+fa(insts.length)+' قسط)</small></div>':'')+'</div>'+
  '<div class="tot"><div><span>جمع کل</span><span>'+fm(t+pd(inv.discount))+'</span></div>'+(pd(inv.discount)?'<div><span>تخفیف</span><span>'+fm(pd(inv.discount))+'</span></div>':'')+
  '<div class="big"><span>قابل پرداخت</span><span>'+fm(t)+' تومان</span></div><div><span>پرداخت‌شده</span><span>'+fm(paid)+'</span></div><div class="rem"><span>مانده</span><span>'+fm(rem)+'</span></div></div></div>';
 if(insts.length){
  const n=insts.length,k=n<=6?1:n<=12?2:n<=18?3:4,rows=Math.ceil(n/k);
  let tb='<table class="ig"><thead><tr>'+Array.from({length:k},()=>'<th>قسط</th><th>سررسید</th><th>مبلغ (تومان)</th>').join('')+'</tr></thead><tbody>';
  for(let r=0;r<rows;r++){tb+='<tr>';for(let c=0;c<k;c++){const i=insts[c*rows+r];tb+=i?'<td class="no">'+fa(i.no)+'</td><td>'+jShort(i.due)+'</td><td>'+fm(i.amount)+'</td>':'<td class="no"></td><td></td><td></td>'}tb+='</tr>'}
  h+='<div class="inst"><h4><span>📅 برنامه‌ی اقساط — '+fa(n)+' قسط</span><span>اولین سررسید: '+jShort(insts[0].due)+' | آخرین: '+jShort(insts[n-1].due)+'</span></h4>'+tb+'</tbody></table></div>';
 }
 const chqs=isSale?DB.cheques.filter(c=>c.inv===inv.id&&c.dir==='rec').sort((a,c)=>a.due<c.due?-1:a.due>c.due?1:0):[];
 if(chqs.length){
  const n=chqs.length,k=n<=6?1:n<=12?2:3,rows=Math.ceil(n/k),bank=[chqs[0].bank,chqs[0].branch].filter(Boolean).join(' / ');
  let tb='<table class="ig"><thead><tr>'+Array.from({length:k},()=>'<th>ردیف</th><th>سریال چک</th><th>سررسید</th><th>مبلغ (تومان)</th>').join('')+'</tr></thead><tbody>';
  for(let r=0;r<rows;r++){tb+='<tr>';for(let c=0;c<k;c++){const i=c*rows+r,q=chqs[i];tb+=q?'<td class="no">'+fa(i+1)+'</td><td style="direction:ltr">'+esc(fa(q.no||''))+'</td><td>'+jShort(q.due)+'</td><td>'+fm(q.amount)+'</td>':'<td class="no"></td><td></td><td></td><td></td>'}tb+='</tr>'}
  h+='<div class="inst"><h4><span>🏦 برنامه‌ی چک‌ها — '+fa(n)+' چک'+(bank?' ('+esc(bank)+')':'')+'</span><span>جمع: '+fm(chqs.reduce((a,q)=>a+Number(q.amount||0),0))+' تومان | اولین سررسید: '+jShort(chqs[0].due)+'</span></h4>'+tb+'</tbody></table></div>';
 }
 if(isSale&&inv.type!=='proforma'&&inv.type!=='saleret'){
  const before=b.saleDebt-rem;
  h+='<div class="acct"><b>وضعیت حساب شما:</b> مانده‌ی بدهی قبل از این فاکتور: <b>'+fm(before)+'</b> تومان | مانده‌ی کل پس از این فاکتور: <b>'+fm(b.saleDebt)+'</b> تومان'+((g&&g.name)?' | <b>ضامن:</b> '+esc(g.name)+(g.phone?' ('+fa(g.phone)+')':''):'')+'</div>';
 }
 const dtxt=inv.desc&&String(inv.desc).trim()?esc(inv.desc).replace(/\n/g,'<br>'):'';
 if(isSale)h+='<div class="note"><b>توضیحات:</b> '+dtxt+'</div>';
 else if(dtxt)h+='<div class="note"><b>توضیحات:</b> '+dtxt+'</div>';
 const foot=String(s.invFooter||'').trim();
 h+='<div class="terms">'+(foot?esc(foot).replace(/\n/g,'<br>'):(isSale?'کالاهای فوق تحویل خریدار شد. این فاکتور فقط با مهر و امضای فروشگاه معتبر است. شرایط گارانتی و مرجوعی طبق قوانین فروشگاه است.':'کالاهای فوق تحویل شد و مبلغ آن طبق شرایط تسویه‌ی فوق به تأمین‌کننده پرداخت/ثبت می‌شود.'))+'</div>';
 h+='<div class="sign"><div>مهر و امضای '+(isSale?'فروشنده':'خریدار')+'</div><div>امضای '+(isSale?'خریدار':'فروشنده (تأمین‌کننده)')+'</div>'+((isSale&&g&&g.name&&insts.length)?'<div>امضای ضامن</div>':'')+'</div>';
 if(isSale)h+='<div class="thx">از خرید شما سپاسگزاریم — '+esc(shop.name)+'</div>';
 return h+'</div>';
}
async function invoiceDoc(id,size){
 const inv=DB.invoices.find(i=>i.id===id);if(!inv)return null;
 const paper=printPaper(inv,size),logo=await shopLogoData();
 const cls=paper.landscape?'a5l':(paper.size==='A5'?'a5':'a4');
 return{doc:printDocHtml(invoiceBodyHtml(inv,logo,paper),{size:paper.size,landscape:paper.landscape,title:invTypeFa(inv.type)+' '+fa(inv.no),css:INV_CSS,cls,margin:paper.landscape?'6mm':'8mm'}),paper,title:invTypeFa(inv.type)+' شماره '+fa(inv.no)};
}
async function printInvoice(type,id,size){
 const r=await invoiceDoc(id,size);if(!r)return;
 printPreview(r.doc,{title:r.title,size:r.paper.size,landscape:r.paper.landscape});
}
/* دکمه‌های چاپ هر فاکتور: خرید فقط A5 افقی؛ فروش A4 و A5 */
function invPrintBtns(i){
 const t=i.type;
 if(t==='buy'||t==='buyret')return '<button class="btn sm p" title="فاکتور خرید فقط روی A5 افقی چاپ می‌شود" onclick="printInvoice(\''+t+'\',\''+i.id+'\',\'A5\')">🖨️ A5 افقی</button>';
 return '<button class="btn sm p" onclick="printInvoice(\''+t+'\',\''+i.id+'\',\'A4\')">🖨️ A4</button> <button class="btn sm" onclick="printInvoice(\''+t+'\',\''+i.id+'\',\'A5\')">A5</button>';
}
/* ---------- پیش‌نمایش پیش از چاپ ---------- */
function printNow(doc){
 const w=window.open('','_blank');
 if(!w){toast('⚠️ پنجره‌ی چاپ باز نشد (Pop-up مسدود است)',false);return false}
 w.document.write(doc+'<script>setTimeout(function(){window.print()},500)<\/script>');w.document.close();return true;
}
function printPreview(doc,o){
 o=o||{};window._ppv={doc,o};
 const lab=(o.size==='58mm'||o.size==='80mm')?'رسید '+o.size:o.size+(o.landscape?' افقی':' عمودی');
 openM(mHead('🖨️ پیش‌نمایش چاپ — '+esc(o.title||''))+
  '<div class="mbody" style="padding:0;display:flex;flex-direction:column;background:#cfd6e2;min-height:0"><div style="display:flex;gap:10px;align-items:center;padding:6px 14px;background:#fff;border-bottom:1px solid var(--bd);font-size:12.5px;flex-wrap:wrap">'+
  '<span>کاغذ: <b id="ppvPaper">'+esc(lab)+'</b></span><span>بزرگ‌نمایی: <select id="ppvZoom" onchange="ppvZoom(this.value)"><option value="0.6">۶۰٪</option><option value="0.8" selected>۸۰٪</option><option value="1">۱۰۰٪</option><option value="1.25">۱۲۵٪</option></select></span>'+
  '<span style="color:var(--mut);font-size:11.5px">پیش‌نمایش قبل از ارسال به چاپگر؛ با «چاپ» پنجره‌ی چاپگر باز می‌شود.</span></div>'+
  '<iframe id="ppvFrame" title="پیش‌نمایش" style="flex:1;min-height:60vh;width:100%;border:0;background:#cfd6e2"></iframe></div>'+
  '<div class="mfoot"><button class="btn p" onclick="ppvPrint()">🖨️ چاپ</button><button class="btn" onclick="closeM()">بستن</button></div>',true);
 try{const mm=document.querySelector('#modal .m');if(mm){mm.classList.add('pwfull');$('modal').classList.add('pwfull')}}catch(e){}
 const f=$('ppvFrame');if(f){f.onload=()=>ppvZoom($('ppvZoom')?$('ppvZoom').value:'0.8');f.srcdoc=doc}
}
function ppvZoom(v){try{const f=$('ppvFrame');if(f&&f.contentDocument&&f.contentDocument.body)f.contentDocument.body.style.zoom=v}catch(e){}}
function ppvPrint(){if(window._ppv)printNow(window._ppv.doc)}
/* چاپ عمومی (گزارش‌ها، لیست‌ها، رسیدها): اول پیش‌نمایش */
function printHTMLPreview(bodyHtml,size){
 let css;
 if(size==='58mm'||size==='80mm'){
  const wdt=size==='58mm'?'58mm':'80mm';
  css='body{font-family:'+PRINT_FONT+';direction:rtl;padding:2mm;font-size:9px;width:'+wdt+';margin:0 auto}table{border-collapse:collapse;width:100%;margin:4px 0;font-size:8.5px}th,td{border:1px solid #bbb;padding:2px 3px;text-align:center}th{background:#f0f0f0}.h{border-bottom:1px dashed #333;padding-bottom:4px;margin-bottom:5px}h2{margin:2px 0;font-size:11px}p{margin:3px 0;font-size:9px}@media screen{body{background:#fff;box-shadow:0 4px 20px rgba(0,0,0,.25);margin:14px auto}}';
  printPreview(printDocHtml(bodyHtml,{size,title:'چاپ',css,margin:'1mm'}),{title:'رسید',size});return;
 }
 css='body{font-family:'+PRINT_FONT+';direction:rtl;padding:'+(size==='A5'?'6px':'10px')+';font-size:'+(size==='A5'?'11px':'12.5px')+'}table{border-collapse:collapse;width:100%;margin:8px 0}th,td{border:1px solid #999;padding:5px;text-align:center}th{background:#f0f0f0}.h{display:flex;justify-content:space-between;border-bottom:2px solid #333;padding-bottom:8px;margin-bottom:10px}h2{margin:4px 0}tr{page-break-inside:avoid}@media screen{body{background:#fff;box-shadow:0 4px 20px rgba(0,0,0,.25);margin:14px auto;max-width:'+(size==='A5'?'148mm':'210mm')+'}}';
 printPreview(printDocHtml(bodyHtml,{size:size||'A4',title:'چاپ',css,margin:'10mm'}),{title:'چاپ',size:size||'A4'});
}
