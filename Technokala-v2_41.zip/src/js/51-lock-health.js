/* ================= 🔒 قفل دوره مالی + 🩺 بازبینی سلامت داده ================= */
function lockBlocked(date){
 const L=jNorm((DB.settings||{}).lockDate||'');
 if(!L||!date)return false;
 const d=jNorm(date);
 if(d&&d<=L){toast('🔒 دوره مالی تا '+jShort(L)+' بسته است؛ ثبت/ویرایش/حذف مجاز نیست',false);return true}
 return false;
}
function lockSave(){
 const v=($('lockDateIn').value||'').trim();
 if(v&&!jValid(v)){toast('⚠️ تاریخ معتبر نیست (مثال: ۱۴۰۴/۰۶/۳۱)',false);return}
 DB.settings.lockDate=v?jNorm(v):'';
 logAct(v?'قفل دوره مالی تا '+jShort(v):'برداشتن قفل دوره مالی');
 saveDB();toast(v?'🔒 دوره تا '+jShort(v)+' قفل شد':'🔓 قفل دوره برداشته شد');
}
function dataHealth(){
 const out=[],add=(lvl,msg)=>out.push({lvl,msg});
 const grp={sale:'sale',saleret:'sale',buy:'buy',buyret:'buy',proforma:'pro'};
 const seen={};
 DB.invoices.forEach(inv=>{
  const g=grp[inv.type]||inv.type,k=g+'#'+inv.no;
  if(seen[k])add('⛔','شماره فاکتور تکراری: '+fa(inv.no)+' ('+invTypeFa(inv.type)+')');seen[k]=1;
  if(inv.person&&!DB.persons.some(p=>p.id===inv.person))add('⛔','فاکتور '+fa(inv.no)+': شخص حذف‌شده');
  (inv.lines||[]).forEach(l=>{if(!PR(l.pid))add('⛔','فاکتور '+fa(inv.no)+': کالای حذف‌شده');
   if(!(l.qty>0))add('⚠️','فاکتور '+fa(inv.no)+': تعداد صفر/نامعتبر');
   if(inv.type==='sale'&&l.cost===undefined)add('⚠️','فاکتور '+fa(inv.no)+': قیمت تمام‌شده ثبت نشده (سود نادرست)')});
  if(invPaid(inv)>invTotal(inv)&&inv.type!=='proforma')add('⚠️','فاکتور '+fa(inv.no)+': پرداختی بیشتر از مبلغ فاکتور');
  if(inv.date&&!jValid(inv.date))add('⛔','فاکتور '+fa(inv.no)+': تاریخ نامعتبر');
  if((inv.lines||[]).some(l=>!Number.isInteger(Number(l.price))))add('⚠️','فاکتور '+fa(inv.no)+': قیمت غیرصحیح (اعشاری)');
 });
 const ids=new Set(DB.invoices.map(i=>i.id));
 DB.cheques.forEach(c=>{if(c.inv&&!ids.has(c.inv))add('⛔','چک '+fa(c.no||'—')+': فاکتور مرتبط وجود ندارد')});
 DB.installments.forEach(i=>{if(i.inv&&!ids.has(i.inv))add('⛔','قسط '+PN(i.person)+': فاکتور مرتبط وجود ندارد')});
 DB.serials.forEach(s=>{
  if(s.status==='sold'&&s.saleInv&&!ids.has(s.saleInv))add('⛔','سریال '+fa(s.sn)+': فاکتور فروش وجود ندارد');
  if(s.status==='stock'&&s.buyInv&&!ids.has(s.buyInv))add('⛔','سریال '+fa(s.sn)+': فاکتور خرید وجود ندارد');
 });
 DB.products.forEach(p=>{if(p.track!=='serial'&&stockOf(p.id)<0)add('⚠️','موجودی منفی: '+p.name+' ('+fa(stockOf(p.id))+')')});
 const mx={sale:0,buy:0,pro:0};
 DB.invoices.forEach(i=>{const g=grp[i.type];if(g&&Number(i.no)>mx[g])mx[g]=Number(i.no)});
 Object.keys(mx).forEach(g=>{if(mx[g]>(DB.counters[g]||0))add('⛔','شمارنده «'+g+'» کمتر از بزرگ‌ترین شماره ثبت‌شده است')});
 openM(mHead('🩺 بازبینی سلامت داده')+'<div class="mbody">'+(out.length?
  '<div style="margin-bottom:8px"><b>'+fa(out.length)+'</b> مورد یافت شد</div>'+out.slice(0,200).map(x=>'<div style="padding:5px 0;border-bottom:1px solid var(--bd)">'+x.lvl+' '+esc(x.msg)+'</div>').join('')
  :'<div class="empty"><div class="b">✅</div>مشکلی یافت نشد</div>')+'</div><div class="mfoot"><button class="btn" onclick="closeM()">بستن</button></div>');
}

