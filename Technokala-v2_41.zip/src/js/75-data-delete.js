/* ===== حذف اطلاعات: بخش‌بندی، بازه‌ی تاریخ/ساعت، پیش‌نمایش، و تأیید با رمز ثابت ===== */
const TS_COLS=['persons','products','serials','invoices','receipts','cheques','installments','accTx','expenses'];
/* زمان ثبت هر رکورد در برنامه (برای حذف بر اساس تاریخ و ساعت). رکوردهای قدیمیِ پیش از این قابلیت زمان ندارند (۰). */
function tsStamp(){
 if(!DB)return;
 if(!DB._ts||typeof DB._ts!=='object'){DB._ts={};DB._tsInit=Date.now();TS_COLS.forEach(k=>(DB[k]||[]).forEach(r=>{if(r&&r.id)DB._ts[r.id]=0}))}
 const now=Date.now();
 TS_COLS.forEach(k=>(DB[k]||[]).forEach(r=>{if(r&&r.id&&DB._ts[r.id]===undefined)DB._ts[r.id]=now}));
}
const DEL_CATS=[['persons','👥 لیست اشخاص'],['installments','📅 لیست اقساط'],['cheques','🧾 لیست چک‌ها'],['invoices','📄 فاکتورها (خرید/فروش/برگشت/پیش‌فاکتور)'],['products','📱 کالاها']];
function delEpoch(jd,t,end){
 const d=jToDate(jd);if(isNaN(d))return NaN;
 const m=String(faDig(t||'')).match(/^(\d{1,2}):(\d{2})$/);
 const h=m?Number(m[1]):(end?23:0),mi=m?Number(m[2]):(end?59:0);
 if(h>23||mi>59)return NaN;
 return new Date(d.getFullYear(),d.getMonth(),d.getDate(),h,mi,end&&!m?59:0,end&&!m?999:0).getTime();
}
/* بازه‌ی فعال یا پیام خطا */
function delRange(o){
 const from=o.from?jNorm(o.from):'',to=o.to?jNorm(o.to):'';
 if(o.from&&!jValid(from))return{err:'تاریخ شروع نامعتبر است (مثل 1405/07/10)'};
 if(o.to&&!jValid(to))return{err:'تاریخ پایان نامعتبر است'};
 if(!from&&!to)return{all:true};
 const f=from||to,t=to||from;
 if(f>t)return{err:'تاریخ شروع بعد از تاریخ پایان است'};
 if(o.basis==='ts'){const a=delEpoch(f,o.fromT,false),b=delEpoch(t,o.toT,true);if(isNaN(a)||isNaN(b))return{err:'ساعت نامعتبر است (مثل 14:30)'};if(a>b)return{err:'زمان شروع بعد از زمان پایان است'};return{a,b}}
 return{fj:f,tj:t};
}
function delTs(id){return(DB._ts&&DB._ts[id])||0}
function delIn(kind,r,o,R){
 if(R.all)return true;
 if(o.basis==='ts'){const t=delTs(r.id);return t>0&&t>=R.a&&t<=R.b}
 const d=({persons:r.created,installments:r.due,cheques:r.due,invoices:r.date,products:r.created})[kind];const j=d?jNorm(d):'';
 if(!j)return false;
 return(!R.fj||j>=R.fj)&&(!R.tj||j<=R.tj);
}
/* برنامه‌ی حذف: چه چیزهایی حذف می‌شود و چه چیزهایی به‌خاطر وابستگی محافظت می‌شوند */
function delPlan(o){
 const R=delRange(o);if(R.err)return{err:R.err};
 const cats=new Set(o.cats||[]);
 const P={cats:[...cats],all:cats.has('all'),persons:new Set(),installments:new Set(),cheques:new Set(),invoices:new Set(),products:new Set(),receipts:new Set(),accTx:new Set(),serials:new Set(),prot:{persons:[],invoices:[],products:[]},noTime:0,sample:{}};
 if(P.all)return P;
 const stamped=(k)=>(DB[k]||[]).filter(r=>delTs(r.id)===0).length;
 if(o.basis==='ts'&&!R.all)P.noTime=[...cats].reduce((s,c)=>s+stamped(c),0);
 /* ۱) فاکتورها */
 if(cats.has('invoices')){
  let sel=DB.invoices.filter(i=>delIn('invoices',i,o,R));
  sel=sel.filter(i=>{if(lockBlocked(i.date)){P.prot.invoices.push({id:i.id,why:'قفل تاریخ'});return false}return true});
  let ids=new Set(sel.map(i=>i.id));
  /* فاکتور خرید/فروشی که برگشتِ حذف‌نشده دارد محافظت می‌شود */
  sel.slice().forEach(i=>{
   if(i.type!=='sale'&&i.type!=='buy')return;const rk=i.type==='sale'?'saleret':'buyret',pids=new Set(i.lines.map(l=>l.pid));
   if(DB.invoices.some(x=>x.type===rk&&x.person===i.person&&!ids.has(x.id)&&x.lines.some(l=>pids.has(l.pid)))){ids.delete(i.id);P.prot.invoices.push({id:i.id,why:'برگشتِ ثبت‌شده دارد'})}
  });
  /* موجودی کالای تعدادی نباید منفی شود */
  if(!DB.settings.allowNegative){
   for(let it=0;it<4;it++){
    const keep=DB.invoices;DB.invoices=keep.filter(i=>!ids.has(i.id));let bad=new Set();
    try{ids.size&&[...new Set(sel.filter(i=>ids.has(i.id)&&i.type==='buy').flatMap(i=>i.lines.filter(l=>!l.sid).map(l=>l.pid)))].forEach(pid=>{const p=PR(pid);if(p&&p.track!=='serial'&&stockOf(pid)<0)bad.add(pid)})}finally{DB.invoices=keep}
    if(!bad.size)break;
    sel.filter(i=>ids.has(i.id)&&i.type==='buy'&&i.lines.some(l=>bad.has(l.pid))).forEach(i=>{ids.delete(i.id);P.prot.invoices.push({id:i.id,why:'موجودی کالا منفی می‌شود'})});
   }
  }
  ids.forEach(id=>P.invoices.add(id));
 }
 /* ۲) اقساط و چک‌ها */
 if(cats.has('installments'))DB.installments.forEach(i=>{if(delIn('installments',i,o,R))P.installments.add(i.id)});
 if(cats.has('cheques'))DB.cheques.forEach(c=>{if(delIn('cheques',c,o,R))P.cheques.add(c.id)});
 DB.installments.forEach(i=>{if(i.inv&&P.invoices.has(i.inv))P.installments.add(i.id)});
 DB.cheques.forEach(c=>{if(c.inv&&P.invoices.has(c.inv))P.cheques.add(c.id)});
 /* ۳) اشخاص */
 if(cats.has('persons')){
  DB.persons.filter(p=>delIn('persons',p,o,R)).forEach(p=>{
   const hasInv=DB.invoices.some(i=>i.person===p.id&&!P.invoices.has(i.id));
   const hasDep=!o.cascade&&(DB.installments.some(i=>i.person===p.id&&!P.installments.has(i.id))||DB.cheques.some(c=>c.person===p.id&&!P.cheques.has(c.id))||DB.receipts.some(r=>r.person===p.id));
   if(hasInv||hasDep){P.prot.persons.push({id:p.id,why:hasInv?'فاکتور دارد':'اقساط/چک/رسید دارد'});return}
   P.persons.add(p.id);
  });
  if(o.cascade){
   DB.installments.forEach(i=>{if(P.persons.has(i.person))P.installments.add(i.id)});
   DB.cheques.forEach(c=>{if(P.persons.has(c.person))P.cheques.add(c.id)});
   DB.receipts.forEach(r=>{if(P.persons.has(r.person))P.receipts.add(r.id)});
  }
 }
 /* ۴) کالاها */
 if(cats.has('products')){
  DB.products.filter(p=>delIn('products',p,o,R)).forEach(p=>{
   if(DB.invoices.some(i=>!P.invoices.has(i.id)&&i.lines.some(l=>l.pid===p.id))){P.prot.products.push({id:p.id,why:'در فاکتور استفاده شده'});return}
   P.products.add(p.id);
  });
  DB.serials.forEach(s=>{if(P.products.has(s.pid))P.serials.add(s.id)});
 }
 /* ۵) وابسته‌ها: رسیدِ قسط‌های حذف‌شده و تراکنش‌های بانکی مرتبط */
 DB.receipts.forEach(r=>{if(r.instId&&P.installments.has(r.instId))P.receipts.add(r.id)});
 DB.accTx.forEach(t=>{if(P.invoices.has(t.ref)||P.cheques.has(t.ref)||P.receipts.has(t.ref))P.accTx.add(t.id)});
 /* نمونه‌ی نام‌ها برای پیش‌نمایش */
 const smp=(k,f)=>[...P[k]].slice(0,6).map(id=>{const r=DB[k].find(x=>x.id===id);return r?f(r):''}).filter(Boolean);
 P.sample={persons:smp('persons',p=>p.name),installments:smp('installments',i=>PN(i.person)+' — '+jShort(i.due)+' — '+fm(i.amount)),cheques:smp('cheques',c=>'چک '+(c.no||'—')+' — '+PN(c.person)+' — '+jShort(c.due)),invoices:smp('invoices',i=>invTypeFa(i.type)+' '+fa(i.no)+' — '+PN(i.person)),products:smp('products',p=>p.name)};
 return P;
}
function delCounts(P){
 if(P.all)return[['کلیه‌ی اطلاعات (اشخاص، کالا، فاکتور، اقساط، چک، رسید، تراکنش و ...)',1]];
 return[['اشخاص',P.persons.size],['فاکتورها',P.invoices.size],['اقساط',P.installments.size],['چک‌ها',P.cheques.size],['کالاها',P.products.size],['سریال‌ها',P.serials.size],['رسیدها',P.receipts.size],['تراکنش‌های بانکی',P.accTx.size]].filter(x=>x[1]>0);
}
function delTotal(P){return P.all?1:P.persons.size+P.invoices.size+P.installments.size+P.cheques.size+P.products.size+P.serials.size+P.receipts.size+P.accTx.size}
/* اجرا */
function delInvoiceCore(inv){
 const id=inv.id;
 if(inv.type==='buyret')inv.lines.forEach(l=>{const s=l.sid&&DB.serials.find(x=>x.id===l.sid);if(s&&s.status==='returned')s.status='stock'});
 if(inv.type==='saleret')inv.lines.forEach(l=>{const s=l.sid&&DB.serials.find(x=>x.id===l.sid);if(s&&s.status==='stock'){const so=DB.invoices.filter(x=>x.type==='sale'&&x.id!==id&&x.lines.some(y=>y.sid===s.id)).pop();if(so){s.status='sold';s.saleInv=so.id}}});
 DB.serials.forEach(s=>{
  if(s.saleInv===id){s.status='stock';s.saleInv=''}
  if(s.buyInv===id){if(s.status==='sold')return;if(s.introduced){s.status='registered';s.buyInv=''}else s._drop=1}
 });
 DB.serials=DB.serials.filter(s=>!s._drop);
}
function wipeCore(){
 const _c=lkCarry(DB.settings);DB=seedDB();_c(DB.settings);
 ['persons','products','serials','invoices','receipts','cheques','installments','accTx','log'].forEach(k=>DB[k]=[]);
 DB.counters={person:1000,product:1000,sale:1000,buy:1000,rec:1000,pro:1000};DB._ts={};DB._tsInit=Date.now();
}
function delApply(P){ixInvalidate();
 if(P.all){wipeCore();return}
 const prio={saleret:0,buyret:0,sale:1,buy:1,proforma:2};
 const invs=DB.invoices.filter(i=>P.invoices.has(i.id)).sort((a,b)=>(prio[a.type]||0)-(prio[b.type]||0));
 const buyPids=[...new Set(invs.filter(i=>i.type==='buy').flatMap(i=>i.lines.map(l=>l.pid)))];
 invs.forEach(i=>delInvoiceCore(i));
 /* مجموعه‌ی نهایی قسط‌ها برای پاک‌سازی نشانه‌های ورود گردش بانک */
 const instIds=P.installments;
 DB.invoices=DB.invoices.filter(i=>!P.invoices.has(i.id));
 DB.installments=DB.installments.filter(i=>!instIds.has(i.id));
 DB.cheques=DB.cheques.filter(c=>!P.cheques.has(c.id));
 DB.receipts=DB.receipts.filter(r=>!P.receipts.has(r.id));
 DB.accTx=DB.accTx.filter(t=>!P.accTx.has(t.id));
 DB.persons=DB.persons.filter(p=>!P.persons.has(p.id));
 DB.serials=DB.serials.filter(s=>!P.serials.has(s.id));
 DB.products=DB.products.filter(p=>!P.products.has(p.id));
 if(DB.bankSeen)Object.keys(DB.bankSeen).forEach(k=>{if(instIds.has(DB.bankSeen[k]))delete DB.bankSeen[k]});
 if(buyPids.length)try{refreshLastCost(buyPids.filter(pid=>PR(pid)))}catch(e){}
 if(DB._ts){const live=new Set();TS_COLS.forEach(k=>(DB[k]||[]).forEach(r=>r&&r.id&&live.add(r.id)));Object.keys(DB._ts).forEach(id=>{if(!live.has(id))delete DB._ts[id]})}
}
/* ---------- رمز ثابت حذف (به‌جای کد پیامکی) ----------
   رمز فقط به‌صورت هش PBKDF2 (همان روش قفل برنامه) ذخیره می‌شود و با «پاک کردن کل داده‌ها» هم از بین نمی‌رود. */
function delPassIsSet(){return !!(DB.settings&&DB.settings.delPass&&DB.settings.delPass.hash)}
async function delPassSet(pw,pw2){
 if(!lkOk())return{err:'رمزنگاری در این محیط در دسترس نیست'};
 pw=String(pw||'');
 if(pw.length<4)return{err:'رمز باید حداقل ۴ کاراکتر باشد'};
 if(pw!==String(pw2||''))return{err:'رمز و تکرار آن یکسان نیست'};
 DB.settings.delPass=await lkMake(pw);window._delFail=null;
 try{logAct('تعریف/تغییر رمز حذف اطلاعات')}catch(e){}
 try{await saveDB()}catch(e){}
 return{ok:true};
}
async function delPassCheck(pw){
 if(!delPassIsSet())return{err:'ابتدا رمز حذف را تعریف کنید'};
 const F=window._delFail||(window._delFail={n:0,until:0});
 if(Date.now()<F.until)return{err:'تلاش‌های اشتباه زیاد بود؛ '+fa(Math.ceil((F.until-Date.now())/1000))+' ثانیه دیگر دوباره امتحان کنید'};
 if(await lkCheck(DB.settings.delPass,String(pw||''))){window._delFail=null;return{ok:true}}
 F.n++;if(F.n>=5){F.n=0;F.until=Date.now()+60000;return{err:'رمز اشتباه است — به‌دلیل ۵ تلاش اشتباه، ۶۰ ثانیه قفل شد'}}
 return{err:'رمز اشتباه است ('+fa(5-F.n)+' تلاش دیگر)'};
}
async function delPassChange(oldPw,pw,pw2){
 const c=await delPassCheck(oldPw);if(c.err)return c;
 return delPassSet(pw,pw2);
}
/* فراموشی رمز: با رمز قفل برنامه (اگر تعریف شده) */
async function delPassReset(lockPw,pw,pw2){
 if(!DB.settings.appLock)return{err:'قفل برنامه تعریف نشده؛ برای بازنشانی رمز باید از بکاپ بازیابی کنید'};
 if(!(await lkCheck(DB.settings.appLock,String(lockPw||''))))return{err:'رمز قفل برنامه اشتباه است'};
 return delPassSet(pw,pw2);
}
/* ---------- رابط کاربری ---------- */
function delRead(){
 const cats=[];DEL_CATS.forEach(c=>{if($('dl_'+c[0]).checked)cats.push(c[0])});
 if($('dl_all').checked)return{cats:['all'],basis:'doc',from:'',to:'',fromT:'',toT:'',cascade:false};
 return{cats,basis:$('dlBasis').value,from:$('dlFrom').value.trim(),to:$('dlTo').value.trim(),fromT:$('dlFromT').value.trim(),toT:$('dlToT').value.trim(),cascade:!!$('dlCascade').checked};
}
function delVerifyHtml(){
 if(!delPassIsSet())return '<div class="sec-h">۳) تعریف رمز حذف (یک‌بار)</div><div class="notice" style="margin-bottom:8px">برای حذف اطلاعات یک رمز ثابت تعریف کنید. این رمز را به کسی ندهید؛ بدون آن هیچ حذفی انجام نمی‌شود.</div>'+
  '<div class="frow"><div class="fg"><label>رمز حذف</label><input id="dlPass1" type="password" autocomplete="new-password" style="direction:ltr"></div><div class="fg"><label>تکرار رمز</label><input id="dlPass2" type="password" autocomplete="new-password" style="direction:ltr"></div>'+
  '<div class="fg"><label>&nbsp;</label><button class="btn o" onclick="delPassDefine()">💾 ذخیره‌ی رمز</button></div></div>';
 return '<div class="sec-h">۳) تأیید با رمز حذف</div><div class="frow"><div class="fg"><label>رمز حذف</label><input id="dlPass" type="password" autocomplete="off" style="direction:ltr" onkeydown="if(event.key===\'Enter\')delRun()"></div>'+
  '<div class="fg"><label>&nbsp;</label><button class="btn r" onclick="delRun()">🗑️ تأیید و حذف</button></div>'+
  '<div class="fg"><label>&nbsp;</label><button class="btn sm" onclick="delPassChangeOpen()">🔑 تغییر/فراموشی رمز</button></div></div>';
}
function delOpen(){
 const ck=(id,l)=>'<label style="display:block;margin:4px 0;font-size:13px"><input type="checkbox" id="'+id+'" onchange="delUiSync()"> '+l+'</label>';
 openM(mHead('🗑️ حذف اطلاعات')+'<div class="mbody">'+
  '<div class="notice red" style="margin-bottom:10px">حذف قابل برگشت از بکاپ است: پیش از اجرا یک اسنپ‌شات «قبل از حذف اطلاعات» گرفته می‌شود. اجرای حذف فقط با رمز حذف ممکن است.</div>'+
  '<div class="sec-h">۱) چه چیزی حذف شود؟</div>'+DEL_CATS.map(c=>ck('dl_'+c[0],c[1])).join('')+
  '<label style="display:block;margin:8px 0 4px;font-size:13px;color:#b91c1c;font-weight:800"><input type="checkbox" id="dl_all" onchange="delUiSync()"> ⚠️ کلیه‌ی اطلاعات (بازنشانی کامل برنامه)</label>'+
  '<div id="dlRange"><div class="sec-h" style="margin-top:12px">۲) بازه‌ی تاریخ و ساعت (اختیاری — خالی = همه‌ی موارد دسته)</div>'+
  '<div class="frow"><div class="fg"><label>بر اساس</label><select id="dlBasis" onchange="delUiSync()"><option value="doc">تاریخ خودِ سند (سررسید قسط/چک، تاریخ فاکتور، تاریخ ثبت شخص)</option><option value="ts">زمان ثبت در برنامه (تاریخ و ساعت)</option></select></div></div>'+
  '<div class="frow"><div class="fg"><label>از تاریخ</label><input id="dlFrom" placeholder="1405/07/10" style="direction:ltr"></div><div class="fg" id="dlFromTW"><label>از ساعت</label><input id="dlFromT" placeholder="08:30" style="direction:ltr;width:90px"></div>'+
  '<div class="fg"><label>تا تاریخ (خالی = همان روز)</label><input id="dlTo" placeholder="1405/07/10" style="direction:ltr"></div><div class="fg" id="dlToTW"><label>تا ساعت</label><input id="dlToT" placeholder="17:00" style="direction:ltr;width:90px"></div></div>'+
  '<div class="toolbar"><button class="btn sm" onclick="$(\'dlFrom\').value=jToday();$(\'dlTo\').value=\'\'">امروز</button></div>'+
  '<div id="dlTsNote" style="font-size:11px;color:var(--mut);margin-top:4px">در حالت «زمان ثبت»، رکوردهایی که پیش از نسخه‌ی ۲.۳۲ ثبت شده‌اند زمان ثبت ندارند و پیدا نمی‌شوند؛ برای آن‌ها «تاریخ خودِ سند» را انتخاب کنید.</div>'+
  '<label style="display:block;margin-top:8px;font-size:12.5px"><input type="checkbox" id="dlCascade" checked> با حذف شخص، اقساط، چک‌ها و رسیدهای او هم حذف شوند (شخصِ دارای فاکتور حذف نمی‌شود مگر فاکتورهایش هم انتخاب شود)</label></div>'+
  '<div class="toolbar" style="margin-top:12px"><button class="btn p" onclick="delPreview()">🔍 پیش‌نمایش موارد حذف</button></div>'+
  '<div id="dlPrev" style="margin-top:10px"></div>'+
  '<div id="dlVerify" style="display:none;margin-top:12px;border-top:1px dashed var(--bd);padding-top:10px"><div id="dlVerifyBody">'+delVerifyHtml()+'</div><div id="dlMsg" style="font-size:12px;margin-top:6px"></div></div>'+
  '</div><div class="mfoot"><button class="btn" onclick="closeM()">بستن</button></div>',true);
 delUiSync();
}
async function delPassDefine(){
 const r=await delPassSet($('dlPass1').value,$('dlPass2').value);
 if(r.err){$('dlMsg').innerHTML='<span style="color:#b91c1c">❌ '+esc(r.err)+'</span>';return}
 $('dlVerifyBody').innerHTML=delVerifyHtml();$('dlMsg').innerHTML='✅ رمز حذف ذخیره شد؛ اکنون رمز را وارد و «تأیید و حذف» را بزنید.';
}
function delPassChangeOpen(){
 openM(mHead('🔑 تغییر رمز حذف')+'<div class="mbody"><div class="sec-h">تغییر با رمز فعلی</div>'+
  '<div class="frow"><div class="fg"><label>رمز فعلی</label><input id="dcOld" type="password" style="direction:ltr"></div><div class="fg"><label>رمز جدید</label><input id="dcNew" type="password" style="direction:ltr"></div><div class="fg"><label>تکرار رمز جدید</label><input id="dcNew2" type="password" style="direction:ltr"></div></div>'+
  '<button class="btn p" onclick="delPassChangeDo(false)">💾 تغییر رمز</button>'+
  '<div class="sec-h" style="margin-top:14px">فراموش کرده‌اید؟ (با رمز قفل برنامه)</div>'+
  '<div class="frow"><div class="fg"><label>رمز قفل برنامه</label><input id="dcLock" type="password" style="direction:ltr"></div></div>'+
  '<button class="btn o" onclick="delPassChangeDo(true)">♻️ بازنشانی رمز (با رمز جدید بالا)</button>'+
  '<div id="dcMsg" style="font-size:12px;margin-top:8px"></div></div><div class="mfoot"><button class="btn" onclick="delOpen()">بازگشت</button></div>');
}
async function delPassChangeDo(reset){
 const r=reset?await delPassReset($('dcLock').value,$('dcNew').value,$('dcNew2').value):await delPassChange($('dcOld').value,$('dcNew').value,$('dcNew2').value);
 $('dcMsg').innerHTML=r.err?'<span style="color:#b91c1c">❌ '+esc(r.err)+'</span>':'✅ رمز حذف تغییر کرد';
}
function delUiSync(){
 const all=$('dl_all').checked;
 DEL_CATS.forEach(c=>{$('dl_'+c[0]).disabled=all;if(all)$('dl_'+c[0]).checked=false});
 const r=$('dlRange');if(r)r.style.display=all?'none':'';
 const ts=$('dlBasis')&&$('dlBasis').value==='ts';
 ['dlFromTW','dlToTW','dlTsNote'].forEach(id=>{const e=$(id);if(e)e.style.display=ts?'':'none'});
 const v=$('dlVerify');if(v&&$('dlPrev'))$('dlPrev').innerHTML='',v.style.display='none';
 
}
function delPreview(){
 const o=delRead();
 if(!o.cats.length){toast('⚠️ حداقل یک دسته را انتخاب کنید',false);return}
 const P=delPlan(o);if(P.err){toast('⚠️ '+P.err,false);return}
 const cnt=delCounts(P),tot=delTotal(P);
 let h='';
 if(P.all)h='<div class="notice red"><b>⚠️ تمام اطلاعات برنامه (اشخاص، کالاها، فاکتورها، اقساط، چک‌ها، رسیدها، تراکنش‌ها و لاگ) پاک و برنامه بازنشانی می‌شود.</b></div>';
 else if(!tot)h='<div class="notice">هیچ موردی با این شرایط پیدا نشد.</div>';
 else h='<table><thead><tr><th>نوع</th><th>تعداد حذف‌شونده</th></tr></thead><tbody>'+cnt.map(c=>'<tr><td class="r">'+c[0]+'</td><td><b>'+fa(c[1])+'</b></td></tr>').join('')+'</tbody></table>';
 if(!P.all){
  const sm=[['persons','اشخاص'],['invoices','فاکتورها'],['installments','اقساط'],['cheques','چک‌ها'],['products','کالاها']].filter(x=>(P.sample[x[0]]||[]).length);
  if(sm.length)h+='<div style="font-size:11.5px;color:var(--mut);margin-top:6px;line-height:1.9">'+sm.map(x=>'<b>'+x[1]+':</b> '+P.sample[x[0]].map(esc).join(' | ')+(P[x[0]].size>6?' …':'')).join('<br>')+'</div>';
  const pr=P.prot;const pn=pr.persons.length+pr.invoices.length+pr.products.length;
  if(pn)h+='<div class="notice" style="margin-top:8px">🛡️ <b>'+fa(pn)+' مورد محافظت شد و حذف نمی‌شود:</b> '+[pr.persons.length?fa(pr.persons.length)+' شخص (وابسته)':'',pr.invoices.length?fa(pr.invoices.length)+' فاکتور (برگشت/قفل/موجودی)':'',pr.products.length?fa(pr.products.length)+' کالا (در فاکتور استفاده شده)':''].filter(Boolean).join('، ')+'</div>';
  if(P.noTime)h+='<div style="font-size:11px;color:var(--mut);margin-top:6px">ℹ️ '+fa(P.noTime)+' رکورد قدیمی زمان ثبت ندارد و در این روش پیدا نمی‌شود.</div>';
 }
 $('dlPrev').innerHTML=h;
 $('dlVerify').style.display=(P.all||tot)?'':'none';
 $('dlMsg').textContent='';
}
async function delRun(){
 const o=delRead(),chk=await delPassCheck($('dlPass')?$('dlPass').value:'');
 if(chk.err){$('dlMsg').innerHTML='<span style="color:#b91c1c">❌ '+esc(chk.err)+'</span>';return}
 const P=delPlan(o);if(P.err){toast('⚠️ '+P.err,false);return}
 const tot=delTotal(P);if(!tot){toast('هیچ موردی برای حذف نیست',false);return}
 try{await snapshot('قبل از حذف اطلاعات',true)}catch(e){}
 const cnt=delCounts(P);delApply(P);
 try{auditPush('حذف اطلاعات: '+cnt.map(c=>c[0]+' '+c[1]).join('، '),null,null)}catch(e){}
 logAct('حذف اطلاعات — '+cnt.map(c=>c[0]+': '+c[1]).join('، '));
 await saveDB();closeM();try{nav(P.all?'dash':curView)}catch(e){}
 toast('🗑️ حذف شد — '+cnt.map(c=>c[0]+' '+fa(c[1])).join('، '));
}
