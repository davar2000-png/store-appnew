// تست‌های سطح DOM با jsdom: ستون ردیف، تب «معرفی کالای جدید»، بستن ناخواسته‌ی پنجره، پیش‌نمایش چاپ، فاکتورها
const test=require("node:test"),assert=require("node:assert");
const H=require("./domharness.js");
const skip=!H.available&&"jsdom نصب نیست";
const rows=(doc,sel)=>Array.from(doc.querySelectorAll(sel||"#content table tbody tr"));
const fa=n=>String(n).replace(/\d/g,d=>"۰۱۲۳۴۵۶۷۸۹"[d]);

test("ستون «ردیف» در لیست‌ها و ادامه‌ی شماره‌ها در صفحه‌های بعد",{skip},()=>H.dom(async A=>{
 const {R,doc,w}=A;
 R(`const g=DB.personGroups[0];for(let k=0;k<250;k++)DB.persons.push({id:'P'+k,code:2000+k,name:'شخص '+k,group:g.id,groups:[g.id],phone:'0912'+(1000000+k),photo:'',docs:[],guarantor:null});
   for(let k=0;k<230;k++)DB.installments.push({id:'I'+k,planId:'p',inv:'',person:'P'+(k%250),no:1,amount:1000+k,due:'1405/0'+(1+k%9)+'/1'+(k%9),paid:k%5===0,paidDate:'',grp:'ig-normal'})`);
 R("resetPersonsFilters();PGS.persons=undefined;vPersons()");await A.wait(30);
 let th=doc.querySelector("#content table thead tr").cells;
 assert.equal(th[0].textContent.trim(),"ردیف");
 let rs=rows(doc);assert.equal(rs.length,100);assert.equal(rs[0].cells[0].textContent.trim(),fa(1));assert.equal(rs[99].cells[0].textContent.trim(),fa(100));
 R("pgGo('persons',1)");await A.wait(30);rs=rows(doc);assert.equal(rs[0].cells[0].textContent.trim(),fa(101),"صفحه‌ی ۲ از ۱۰۱ شروع می‌شود");assert.equal(rs.length,100);
 R("pgGo('persons',2)");await A.wait(30);rs=rows(doc);assert.equal(rs.length,50);assert.equal(rs[49].cells[0].textContent.trim(),fa(250));
 // هر ردیف دقیقاً یک سلول بیشتر از قبل دارد و ستون‌ها هم‌تراز هستند
 assert.equal(rows(doc)[0].cells.length,doc.querySelector("#content table thead tr").cells.length);
 // اقساط: ستون ردیف قبل از ستون انتخاب
 R("Fi.grp='';Fi.mode='';Fi.q='';PGS.instlist=undefined;vInst('list')");await A.wait(30);
 th=doc.querySelector("#content table thead tr").cells;assert.equal(th[0].textContent.trim(),"ردیف");
 rs=rows(doc);assert.equal(rs[0].cells[0].textContent.trim(),fa(1));assert.equal(rs[0].cells.length,th.length);
 assert.ok(rs.some(r=>r.cells[1]&&r.cells[1].querySelector('input[type=checkbox]')),"ستون انتخاب بعد از ستون ردیف هنوز هست");
 R("pgGo('instlist',2)");await A.wait(30);assert.equal(rows(doc)[0].cells[0].textContent.trim(),fa(201));
 // ردیف خالی (colspan) سالم می‌ماند
 R("Fi.q='zzzz-none';vInst('list')");await A.wait(30);const empty=rows(doc);assert.equal(empty.length,1);assert.equal(empty[0].cells.length,1);assert.equal(empty[0].cells[0].colSpan,11);
 R("Fi.q=''");
 // چک‌ها، کالاها، فاکتورها، رسیدها
 for(const v of["vProducts()","vProductList()","vSettle()","vCheques('all')","instWarnView()","instPlansView()","instRepView()"]){
  R("Fi.grp='';"+v);await A.wait(20);const t=doc.querySelector("#content table[data-rn]");
  if(t){const h=t.tHead?t.tHead.rows[0]:t.rows[0];assert.equal(h.cells[0].textContent.trim(),"ردیف",v)}
 }

}));

test("معرفی کالای جدید در تب جدید باز می‌شود و هنگام جابه‌جایی بین تب‌ها حفظ می‌شود",{skip},()=>H.dom(async A=>{
 const {R,doc,w}=A;
 R("openPages=['dash'];nav('products')");await A.wait(20);
 R("productWizard()");await A.wait(30);
 assert.equal(R("curView"),"newProduct");assert.ok(R("openPages.includes('newProduct')"));
 const tabs=doc.getElementById("pageTabs")||doc.querySelector(".ptabs,.page-tabs,#ptabs");
 const txt=(tabs?tabs.textContent:doc.body.textContent);assert.ok(txt.includes("معرفی کالای جدید"),"تب در نوار بالا است");
 assert.ok(doc.querySelector("#content .pwtab"),"فرم داخل صفحه (نه پنجره‌ی شناور) نمایش داده می‌شود");
 assert.ok(!doc.getElementById("modal").classList.contains("open"),"پنجره‌ی شناور باز نیست");
 assert.ok(doc.querySelector("#content .pwtab-foot button.btn.p"),"دکمه‌ی ثبت در صفحه");
 // پر کردن و رفتن به تب‌های دیگر
 R("PW.brand='Samsung';PW.model='A55';PW.memory='128 GB';PW.lastCost=1234");
 R("nav('persons')");await A.wait(20);assert.ok(R("openPages.includes('newProduct')"),"تب باز می‌ماند");assert.ok(!doc.querySelector("#content .pwtab"));
 R("nav('invoiceList')");await A.wait(20);R("nav('newProduct')");await A.wait(30);
 assert.equal(R("PW.brand"),"Samsung");assert.equal(R("PW.lastCost"),1234,"فرم حفظ شده");assert.ok(doc.querySelector("#content .pwtab"));
 // دوباره زدن «معرفی کالای جدید» فرم نیمه‌کاره را ادامه می‌دهد؛ «فرم خالی» پاک می‌کند
 R("nav('products')");await A.wait(20);R("productWizard()");await A.wait(20);assert.equal(R("PW.brand"),"Samsung");
 R("pwReset()");await A.wait(20);assert.equal(R("PW.brand"),"");
 // انصراف: تب بسته می‌شود
 R("pwCancel()");await A.wait(20);assert.ok(!R("openPages.includes('newProduct')"));assert.equal(R("PW"),null);
 // ثبت کالا از تب: تب بسته و لیست کالاها باز می‌شود
 R("productWizard()");await A.wait(20);
 R(`Object.assign(PW,{group:DB.productGroups[0].id,brand:'Xiaomi',model:'Note 13',memory:'256 GB',ram:'8 GB',track:'qty',lastCost:5000000,sellPrice:5500000,minStock:0,reorder:0})`);
 const n0=R("DB.products.length");R("pwSave(false)");await A.wait(50);
 assert.equal(R("DB.products.length"),n0+1,R("__t.slice(-2).join('|')"));assert.ok(!R("openPages.includes('newProduct')"));assert.equal(R("curView"),"products");

}));

test("کشیدن موس داخل کادر (انتخاب عدد) پنجره را نمی‌بندد؛ کلیک روی پس‌زمینه می‌بندد",{skip},()=>H.dom(async A=>{
 const {R,doc,w}=A;
 R("openM('<div class=\"mbody\"><input id=\"zz\" value=\"1234567\"></div>')");
 const modal=doc.getElementById("modal"),inp=doc.getElementById("zz");
 assert.ok(modal.classList.contains("open"));
 const ev=(t,type)=>t.dispatchEvent(new w.MouseEvent(type,{bubbles:true}));
 // mousedown داخل کادر، mouseup و click روی پس‌زمینه (حالت کشیدن موس برای انتخاب متن)
 ev(inp,"mousedown");ev(modal,"mouseup");ev(modal,"click");
 assert.ok(modal.classList.contains("open"),"انتخاب متن باعث بسته شدن نشد");
 // کلیک واقعی روی پس‌زمینه
 ev(modal,"mousedown");ev(modal,"mouseup");ev(modal,"click");
 assert.ok(!modal.classList.contains("open"),"کلیک روی پس‌زمینه می‌بندد");

}));

const seedInv=`(()=>{const g=DB.personGroups[0];
 DB.settings.shopName='تکنوکالا';DB.settings.shopTel='04533123456';DB.settings.shopAddr='اردبیل';
 DB.settings.shopLogo='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==';
 DB.persons.push({id:'c1',code:1,name:'علی محمدی',group:g.id,groups:[g.id],phone:'09121234567',nationalId:'1651876924',addr:'اردبیل',guarantor:{name:'حسین کریمی',phone:'09141112233'}});
 DB.persons.push({id:'v1',code:2,name:'شرکت پخش',group:g.id,groups:[g.id],phone:'02188776655'});
 for(let k=1;k<=6;k++)DB.products.push({id:'p'+k,code:'P-'+k,name:'samsung a55 '+k,brand:'Samsung',model:'A55',track:'qty',group:DB.productGroups[0].id,lastCost:5e6,sellPrice:6e6,colors:[]});
 const lines=n=>Array.from({length:n},(_,k)=>({pid:'p'+(k+1),sid:'',sn:'',color:'',qty:1,price:6e6,cost:5e6}));
 DB.invoices.push({id:'s1',type:'sale',no:1201,date:'1405/07/25',person:'c1',discount:0,desc:'',lines:lines(4),pays:[{method:'cash',amount:4e6},{method:'installment',amount:20e6}]});
 for(let q=1;q<=24;q++)DB.installments.push({id:'s1i'+q,planId:'s1',inv:'s1',person:'c1',no:q,amount:833333,due:jAddM('1405/08/25',q-1),paid:false,paidDate:''});
 DB.invoices.push({id:'b1',type:'buy',no:901,date:'1405/07/22',person:'v1',discount:0,desc:'',lines:lines(5),pays:[{method:'cash',amount:30e6}]});
})()`;

test("پیش‌نمایش چاپ فاکتور: لوگو، ۲۴ قسط روی A4، خرید فقط A5 افقی، چاپ از داخل پیش‌نمایش",{skip},()=>H.dom(async A=>{
 const {R,doc,w}=A;R(seedInv);
 // فروش A4
 await R("printInvoice('sale','s1','A4')");await A.wait(30);
 assert.ok(doc.getElementById("modal").classList.contains("open"),"پیش‌نمایش باز شد");
 const fr=doc.getElementById("ppvFrame");assert.ok(fr,"قاب پیش‌نمایش");
 let src=fr.getAttribute("srcdoc");
 assert.ok(src.includes("@page{size:A4;"),"کاغذ A4");assert.ok(!/A4 landscape/.test(src));
 assert.ok(src.includes('<img class="logo" src="data:image/png'),"لوگوی فروشگاه چاپ می‌شود");
 assert.ok(src.includes("فروش")&&src.includes("۱۲۰۱"));
 assert.equal((src.match(/<td class="no">/g)||[]).length,24,"۲۴ قسط در همان برگ");
 assert.ok(src.includes("برنامه‌ی اقساط")&&src.includes("امضای ضامن"));
 assert.ok(/class="note"><b>توضیحات:<\/b>/.test(src),"بخش توضیحات همیشه در فاکتور فروش هست (حتی خالی)");
 const fs2=R("INV_CSS").match(/font-size:[0-9.]+px/g).map(x=>parseFloat(x.slice(10)));assert.ok(Math.min(...fs2)>=10,"هیچ فونتی ریزتر از ۱۰px نیست: "+Math.min(...fs2));
 assert.ok(!src.includes("installment:"),"برچسب انگلیسی روش پرداخت دیده نمی‌شود");
 assert.match(doc.getElementById("ppvPaper").textContent,/A4 عمودی/);
 // پیش‌نمایش در قاب واقعاً بارگذاری می‌شود
 await A.wait(80);const cd=fr.contentDocument;if(cd&&cd.querySelector&&cd.querySelector(".sheet"))assert.ok(cd.querySelectorAll("table.ig td.no").length>=24,"قاب پیش‌نمایش هم ۲۴ قسط را نشان می‌دهد");
 // چاپ از داخل پیش‌نمایش: پنجره‌ی چاپ با خودکار-print باز می‌شود
 let written="",opened=0;w.open=()=>{opened++;return{document:{write:s=>{written+=s},close(){}}}};
 R("ppvPrint()");assert.equal(opened,1);assert.ok(written.includes("window.print()")&&written.includes("@page{size:A4"));
 R("closeM()");assert.ok(!doc.getElementById("modal").classList.contains("open"));
 // فروش A5
 await R("printInvoice('sale','s1','A5')");await A.wait(20);assert.ok(doc.getElementById("ppvFrame").getAttribute("srcdoc").includes("@page{size:A5;"));R("closeM()");
 // خرید: هر اندازه‌ای بخواهید، A5 افقی
 await R("printInvoice('buy','b1','A4')");await A.wait(20);
 src=doc.getElementById("ppvFrame").getAttribute("srcdoc");
 assert.ok(src.includes("@page{size:A5 landscape;"),"فاکتور خرید A5 افقی");assert.ok(src.includes('class="a5l"'));assert.ok(!src.includes("برنامه‌ی اقساط")&&!src.includes("امضای ضامن"));
 assert.match(doc.getElementById("ppvPaper").textContent,/A5 افقی/);R("closeM()");
 // دکمه‌های چاپ
 assert.ok(R("invPrintBtns(DB.invoices.find(i=>i.id==='b1'))").includes("A5 افقی")&&!R("invPrintBtns(DB.invoices.find(i=>i.id==='b1'))").includes("'A4'"),"خرید فقط یک دکمه‌ی A5 افقی");
 assert.ok(R("invPrintBtns(DB.invoices.find(i=>i.id==='s1'))").includes("'A4'"));
 R("invView('b1')");let m=doc.getElementById("modal").innerHTML;assert.ok(m.includes("چاپ A5 افقی")&&!m.includes("چاپ A4")&&!m.includes("printThermal"),"نمای فاکتور خرید");R("closeM()");
 R("invView('s1')");m=doc.getElementById("modal").innerHTML;assert.ok(m.includes("چاپ A4")&&m.includes("printThermal"),"نمای فاکتور فروش");R("closeM()");
 // چاپ عمومی (گزارش‌ها) هم اول پیش‌نمایش می‌دهد
 R("printHTML('<h2>گزارش</h2>','A4')");assert.ok(doc.getElementById("modal").classList.contains("open"));assert.ok(doc.getElementById("ppvFrame").getAttribute("srcdoc").includes("گزارش"));R("closeM()");
 // بدون لوگو: نشانک جایگزین (اولین حرف نام فروشگاه)
 R("DB.settings.shopLogo=''");await R("printInvoice('sale','s1','A4')");await A.wait(20);
 assert.ok(doc.getElementById("ppvFrame").getAttribute("srcdoc").includes('class="logo ph">ت<'));
}));

test("تنظیمات: لوگوی فروشگاه (نمایش و حذف) و متن پایین فاکتور",{skip},()=>H.dom(async A=>{
 const {R,doc}=A;R(seedInv);
 R("vTools()");await A.wait(30);
 const prev=doc.getElementById("seLogoPrev");assert.ok(prev,"پیش‌نمایش لوگو در تنظیمات");assert.ok(doc.getElementById("seFoot"),"متن پایین فاکتور");
 assert.ok(doc.querySelector('input[type=file][onchange*="shopLogoUpload"]'));
 doc.getElementById("seFoot").value="گارانتی ۱۸ ماهه — مرجوعی تا ۷ روز";
 R("typeof stSaveShop==='function'?stSaveShop():0");
 R("shopLogoRemove()");assert.equal(R("DB.settings.shopLogo"),"");
 R("DB.settings.invFooter='گارانتی ۱۸ ماهه — مرجوعی تا ۷ روز'");
 await R("printInvoice('sale','s1','A4')");await A.wait(20);
 assert.ok(doc.getElementById("ppvFrame").getAttribute("srcdoc").includes("گارانتی ۱۸ ماهه"),"متن پایین فاکتور چاپ می‌شود");
}));

test("ویرایش گزینه‌ها و کالا از رابط: دکمه‌های ✏️ و 🗑️ کنار هر مشخصه و ✏️ در لیست کالاها",{skip},()=>H.dom(async A=>{
 const {R,doc}=A;
 R("productWizard()");await A.wait(30);
 R("PW.group=DB.productGroups[0].id;PW.brand='Apple';pwRender()");await A.wait(30);
 const sel=doc.querySelector("#content .pwtab");
 assert.ok(sel.querySelector('button[onclick*="pwOptEdit(\'brand\')"]'),"✏️ برند");assert.ok(sel.querySelector('button[onclick*="pwOptDel(\'brand\')"]'),"🗑️ برند");
 assert.ok(sel.querySelector('button[onclick*="pwOptEdit(\'model\')"]')&&sel.querySelector('button[onclick*="pwOptEdit(\'memory\')"]')&&sel.querySelector('button[onclick*="pwOptEdit(\'ram\')"]'));
 assert.ok(!sel.querySelector('button[onclick*="pwOptEdit(\'brand\')"]').disabled,"با انتخاب مقدار فعال است");
 R("PW.brand='';pwRender()");await A.wait(20);assert.ok(doc.querySelector('#content .pwtab button[onclick*="pwOptEdit(\'brand\')"]').disabled,"بدون انتخاب غیرفعال است");
 // پنجره‌ی ویرایش با مقدار فعلی پر می‌شود
 R("PW.brand='Apple';pwOptEdit('brand')");await A.wait(20);assert.equal(doc.getElementById("optIn").value,"Apple");R("closeM()");
 // صفحه‌ی ویرایش کالا: عنوان، دکمه‌ی حذف، فیلد کد
 R(`DB.products.push({id:'pe',code:'P-77',name:'apple iphone',brand:'Apple',model:'iPhone 13',track:'qty',group:DB.productGroups[0].id,lastCost:3e7,sellPrice:3.3e7,colors:[],memory:'128 GB',ram:'4 GB'})`);
 R("vProducts()");await A.wait(30);assert.ok(doc.querySelector('#content button[onclick*="productEdit(\'pe\')"]'),"✏️ در لیست کالاها");
 R("productEdit('pe')");await A.wait(20);assert.ok(doc.getElementById("modal").innerHTML.includes("نیمه‌کاره"),"فرم نیمه‌کاره قبل از جایگزینی تأیید می‌گیرد");R("closeM();PW=null;productEdit('pe')");await A.wait(30);
 const pg=doc.querySelector("#content .pwtab");assert.ok(pg);assert.ok(doc.querySelector("#content .pgtitle h1").textContent.includes("ویرایش کالا"));
 assert.ok(pg.querySelector('button[onclick="pwDelProduct()"]'),"حذف کالا");assert.equal(pg.querySelector("#pwCode").value,"P-77");
 assert.ok(!pg.querySelector("#pwSn"),"فیلد سریال در ویرایش نیست");assert.ok(!pg.querySelector('button[onclick="pwReset()"]'));
 const tabs=doc.body.textContent;assert.ok(tabs.includes("ویرایش کالا"),"تب با عنوان ویرایش کالا");
 // بسته‌شدن با «انصراف»
 R("pwCancel()");await A.wait(20);assert.notEqual(R("curView"),"newProduct");assert.ok(!R("openPages.includes('newProduct')"));
}));

test("فاکتور خرید در رابط: ستون رنگ قابل انتخاب نیست",{skip},()=>H.dom(async A=>{
 const {R,doc}=A;
 R(`const c=DB.colors[0].id;DB.products.push({id:'pk',code:'P-9',name:'xiaomi',brand:'Xiaomi',model:'N',track:'qty',group:DB.productGroups[0].id,lastCost:1e6,sellPrice:1.2e6,colors:[c]});`);
 R("window._invKind='buy';window.L=[{pid:'pk',sid:'',sn:'',color:DB.colors[0].id,qty:1,price:1e6,cost:1e6,sellAtBuy:0}];");
 const cell=R("rowColorCell(0,window.L[0])");const holder=doc.createElement("table");holder.innerHTML="<tr>"+cell+"</tr>";
 assert.ok(!holder.querySelector("select"),"فقط نمایش");assert.ok(holder.querySelector("#rcw_0").textContent.trim().length>0);
}));

test("«معرفی اشخاص»: فرم شخص جدید مستقیم داخل صفحه (بدون پنجره‌ی تمام‌صفحه) باز می‌شود",{skip},()=>H.dom(async A=>{
 const {R,doc}=A;
 R("closeM();nav('personIntro')");await A.wait(100);
 assert.ok(doc.querySelector("#content #peName"),"فیلد نام در خود صفحه است");
 assert.ok(doc.querySelector("#content #pePhone")&&doc.querySelector("#content #gName"),"فیلدهای شخص و ضامن در صفحه هستند");
 assert.ok(!doc.getElementById("modal").classList.contains("open"),"پنجره‌ی مودال باز نیست");
 assert.ok(!doc.getElementById("modal").classList.contains("pwfull"),"حالت تمام‌صفحه نیست");
 // ذخیره: شخص ساخته می‌شود و فرم خالیِ بعدی با پیام موفقیت نمایش داده می‌شود
 const n0=Number(R("DB.persons.length"));
 R("document.getElementById('peName').value='تست درون‌صفحه‌ای';personSave()");await A.wait(100);
 assert.equal(Number(R("DB.persons.length")),n0+1);
 assert.ok(doc.querySelector("#content #peName"),"بعد از ذخیره دوباره فرم درون صفحه است");
 assert.equal(doc.querySelector("#content #peName").value,"","فرم خالی است");
 assert.ok(doc.querySelector("#content").textContent.includes("تست درون‌صفحه‌ای"),"پیام ثبت موفق");
 assert.ok(!doc.getElementById("modal").classList.contains("open"));
 // فرم‌های «لیست اشخاص» هنوز به‌صورت پنجره باز می‌شوند
 R("nav('persons');personForm()");await A.wait(50);
 assert.ok(doc.getElementById("modal").classList.contains("open"));R("closeM()");
}));
