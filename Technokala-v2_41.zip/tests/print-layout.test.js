// بررسی چیدمان چاپ با WeasyPrint (اختیاری): فروش با ۲۴ قسط روی یک برگ A4، خرید روی A5 افقی
// نیازمندی: python3 + pip install weasyprint  (اگر نصب نباشد تست رد می‌شود). فونت آزمون DejaVu است که پهن‌تر از Tahoma است؛ پس نتیجه محافظه‌کارانه است.
const test=require("node:test"),assert=require("node:assert"),fs=require("fs"),vm=require("vm"),path=require("path"),os=require("os"),cp=require("child_process");
const py=cp.spawnSync("python3",["-c","import weasyprint"],{encoding:"utf8"});
const skip=py.status!==0&&"weasyprint نصب نیست";
const html=fs.readFileSync(path.join(__dirname,"../dist/app.html"),"utf8"),m=html.match(/<script>([\s\S]*)<\/script>\s*<\/body>/);
const mk=()=>new Proxy(function(){},{get:(t,k)=>k===Symbol.iterator?function*(){}:k===Symbol.toPrimitive?()=>"":mk(),apply:()=>mk(),construct:()=>mk(),set:()=>true});
async function build(){
 const ctx={document:mk(),indexedDB:undefined,localStorage:{getItem(){return null},setItem(){}},navigator:{},console,setTimeout:(f)=>setTimeout(f,1),setInterval:()=>0,clearTimeout(){},addEventListener(){},location:{protocol:"file:"},AbortController,Chart:Object.assign(function(){},{defaults:{font:{},plugins:{},color:""}}),alert(){},prompt(){return""},confirm(){return true},fetch(){}};
 ctx.window=ctx;vm.createContext(ctx);
 try{vm.runInContext(fs.readFileSync(path.join(__dirname,"../desktop/app/assets/libs/xlsx.full.min.js"),"utf8"),ctx);vm.runInContext(m[1],ctx)}catch(e){}
 await new Promise(r=>setTimeout(r,250));
 const R=c=>vm.runInContext(c,ctx);
 R(`DB=seedDB();saveDB=async()=>{};toast=()=>{};DB.settings.shopName='تکنوکالا — فروشگاه موبایل و لپ‌تاپ';DB.settings.shopTel='04533123456';DB.settings.shopAddr='اردبیل، خیابان امام، پاساژ فناوری، طبقه‌ی همکف، پلاک ۱۲';
  DB.settings.shopLogo='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==';
  const g=DB.personGroups[0];DB.persons.push({id:'c1',code:1,name:'علی‌اکبر محمدی‌نژاد',group:g.id,groups:[g.id],phone:'09121234567',phone2:'09351234567',nationalId:'1651876924',addr:'اردبیل، خیابان شریعتی، کوچه‌ی گل‌ها، پلاک ۴۵',guarantor:{name:'حسین کریمی',phone:'09141112233'}});
  DB.persons.push({id:'v1',code:2,name:'شرکت پخش البرز',group:g.id,groups:[g.id],phone:'02188776655',addr:'تهران، میدان ولیعصر'});
  for(let k=1;k<=14;k++)DB.products.push({id:'p'+k,code:'P-'+(1000+k),name:(k%3===0?'laptop asus tuf f15 i7-12700h rtx 3050 512g 16g black':'samsung galaxy a55 256g 8g black')+' '+k,brand:k%3===0?'Asus':'Samsung',model:'M'+k,track:'serial',group:DB.productGroups[0].id,lastCost:5e6,sellPrice:6e6,colors:[],cpuModel:k%3===0?'Core i7-12700H':'',gpu:k%3===0?'RTX 3050':'',usage:k%3===0?'گیمینگ':'',screen:k%3===0?'15.6 اینچ':''});`);
 const lines=n=>Array.from({length:n},(_,k)=>({pid:'p'+(k+1),sid:'',sn:'3567'+String(81234567890+k),color:'',qty:1+(k%2),price:6000000+k*250000,cost:5e6}));
 const sale=(n,ni,id)=>{R(`DB.invoices.push({id:'${id}',type:'sale',no:1200+${n},date:'1405/07/25',person:'c1',discount:500000,desc:'تحویل حضوری — گارانتی ۱۸ ماهه',lines:${JSON.stringify(lines(n))},pays:[{method:'cash',amount:3000000},{method:'installment',amount:20000000}]});
  for(let q=1;q<=${ni};q++)DB.installments.push({id:'${id}i'+q,planId:'${id}',inv:'${id}',person:'c1',no:q,amount:Math.round(20000000/${ni}),due:jAddM('1405/08/25',q-1),paid:false,paidDate:''})`)};
 const buy=(n,id)=>R(`DB.invoices.push({id:'${id}',type:'buy',no:${900+n},date:'1405/07/22',person:'v1',discount:0,desc:'',lines:${JSON.stringify(lines(n))},pays:[{method:'cash',amount:20000000},{method:'cheque',amount:9000000,chkNo:'7100',chkDue:'1405/09/01'}]})`);
 sale(8,24,"s8");sale(10,24,"s10");sale(14,24,"s14");sale(8,36,"s8x36");sale(3,12,"s3");buy(5,"b5");buy(8,"b8");buy(14,"b14");
 return R;
}
async function pages(R,id,size){
 const r=await R(`invoiceDoc('${id}','${size}')`);
 const f=path.join(os.tmpdir(),"tk-print-"+id+"-"+size+".html");fs.writeFileSync(f,r.doc);
 const o=cp.spawnSync("python3",["-c","import sys,weasyprint;print(len(weasyprint.HTML(filename=sys.argv[1]).render().pages))",f],{encoding:"utf8"});
 return{n:Number(o.stdout.trim().split("\n").pop()),doc:r.doc,paper:r.paper};
}
test("فاکتور فروش با ۲۴ قسط (و حتی ۳۶ قسط) روی یک برگ A4 جا می‌شود",{skip},async()=>{
 const R=await build();
 for(const [id,what] of [["s8","۸ قلم + ۲۴ قسط"],["s10","۱۰ قلم + ۲۴ قسط"],["s8x36","۸ قلم + ۳۶ قسط"],["s3","۳ قلم + ۱۲ قسط"]]){
  const r=await pages(R,id,"A4");assert.equal(r.n,1,what+" باید یک برگ باشد، "+r.n+" برگ شد");assert.equal(r.paper.size,"A4");
 }
 const big=await pages(R,"s14","A4");assert.ok(big.n<=2,"۱۴ قلم + ۲۴ قسط حداکثر دو برگ: "+big.n);
 const a5=await pages(R,"s8","A5");assert.ok(a5.n<=3,"نسخه‌ی A5 فروش (فشرده): "+a5.n+" برگ");
});
test("فاکتور خرید روی A5 افقی و تک‌برگ",{skip},async()=>{
 const R=await build();
 for(const id of["b5","b8","b14"]){const r=await pages(R,id,"A4");assert.deepEqual(r.paper,{size:"A5",landscape:true});assert.ok(id==="b14"?r.n<=2:r.n===1,id+": "+r.n+" برگ")}
});
