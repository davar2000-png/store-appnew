// اجرا: node --test   (پس از python3 build.py)
const test=require("node:test"),assert=require("node:assert"),fs=require("fs"),vm=require("vm"),path=require("path");
const html=fs.readFileSync(path.join(__dirname,"../dist/app.html"),"utf8");
const m=html.match(/<script>([\s\S]*)<\/script>\s*<\/body>/);
const mk=()=>new Proxy(function(){},{get:(t,k)=>k===Symbol.iterator?function*(){}:k===Symbol.toPrimitive?()=>"":mk(),apply:()=>mk(),construct:()=>mk(),set:()=>true});
const ctx={document:mk(),indexedDB:undefined,localStorage:{getItem(){return null},setItem(){}},navigator:{},console,setTimeout:()=>0,setInterval:()=>0,clearTimeout(){},addEventListener(){},Chart:Object.assign(function(){},{defaults:{font:{},plugins:{},color:""}}),XLSX:{},alert(){},prompt(){return""},confirm(){return true},fetch(){}};
ctx.window=ctx;vm.createContext(ctx);
process.on("uncaughtException",()=>{});process.on("unhandledRejection",()=>{});   // init async با stub مرورگر خطا می‌دهد؛ بی‌اثر است
try{vm.runInContext(m[1],ctx)}catch(e){}
for(const r of vm.runInContext("selfTests()",ctx))test(r.n,()=>assert.ok(r.ok,JSON.stringify([r.a,r.e])));
