// تست سناریوی جامع با داده‌ی آزمایشی کامل — اجرا: python3 build.py && node --test tests/
const test=require("node:test"),assert=require("node:assert"),fs=require("fs"),vm=require("vm"),path=require("path");
const html=fs.readFileSync(path.join(__dirname,"../dist/app.html"),"utf8");
const m=html.match(/<script>([\s\S]*)<\/script>\s*<\/body>/);
const mk=()=>new Proxy(function(){},{get:(t,k)=>k===Symbol.iterator?function*(){}:k===Symbol.toPrimitive?()=>"":mk(),apply:()=>mk(),construct:()=>mk(),set:()=>true});
const els={};
const el=id=>els[id]||(els[id]=new Proxy({value:"",checked:false,innerHTML:"",textContent:"",dataset:{},files:[]},{get:(t,k)=>k in t?t[k]:mk(),set:(t,k,v)=>{t[k]=v;return true}}));
const calls=[];let failBale=false;
const ctx={document:mk(),indexedDB:undefined,localStorage:{getItem(){return null},setItem(){}},navigator:{},console,
 setTimeout:(f,ms)=>setTimeout(f,1),setInterval:()=>0,clearTimeout(){},addEventListener(){},location:{protocol:"file:"},AbortController,
 Chart:Object.assign(function(){},{defaults:{font:{},plugins:{},color:""}}),alert(){},prompt(){return""},confirm(){return true},
 fetch:async(u,o)=>{calls.push({u,b:o&&o.body?JSON.parse(o.body):null});const bale=u.includes("tapi.bale.ai");return{status:200,text:async()=>JSON.stringify(bale?(failBale?{ok:false,description:"x"}:{ok:true,result:{}}):{status:"OK",data:{}})}}};
ctx.crypto=require('node:crypto').webcrypto;ctx.btoa=btoa;ctx.atob=atob;ctx.TextEncoder=TextEncoder;ctx.TextDecoder=TextDecoder;ctx.window=ctx;vm.createContext(ctx);
const xl=fs.readFileSync(path.join(__dirname,"../desktop/app/assets/libs/xlsx.full.min.js"),"utf8");vm.runInContext(xl,ctx);
process.on("uncaughtException",()=>{});process.on("unhandledRejection",()=>{});
try{vm.runInContext(m[1],ctx)}catch(e){}
const R=c=>vm.runInContext(c,ctx),J=c=>JSON.parse(R("JSON.stringify("+c+")"));
const wait=ms=>new Promise(r=>setTimeout(r,ms));
ctx.document={getElementById:el,addEventListener(){},querySelectorAll:()=>[],querySelector:()=>null,createElement:()=>mk(),body:mk()};
const store={};ctx.localStorage={getItem:k=>store[k]||null,setItem:(k,v)=>{store[k]=v}};
ctx.URL={createObjectURL:()=>"",revokeObjectURL(){}};ctx.Blob=function(){};
R(`DB=seedDB();saveDB=async()=>{};snapshot=async()=>{};var __t=[];toast=m=>__t.push(String(m));nav=v=>{curView=v};closeM=()=>{};openM=h=>{window.__modal=h};smsAutoInvoice=()=>{};`);
R(`localStorage.setItem('tk_seed_inst_v1','1')`);
// کمک‌ها ---------------------------------------------------------------
const personId=(name)=>R(`DB.persons.find(p=>p.name===${JSON.stringify(name)}).id`);
const pidOf=(code)=>R(`DB.products.find(p=>p.code===${JSON.stringify(code)}).id`);
const gid=(n)=>R(`DB.productGroups.find(g=>g.name===${JSON.stringify(n)}).id`);
const pgid=(n)=>R(`DB.personGroups.find(g=>g.name===${JSON.stringify(n)}).id`);
function addPerson(name,group,phone,nid,extra){R(`(()=>{const g=DB.personGroups.find(x=>x.name===${JSON.stringify(group)});DB.persons.push(Object.assign({id:uid(),code:++DB.counters.person,name:${JSON.stringify(name)},group:g.id,groups:[g.id],phone:${JSON.stringify(phone||"")},phone2:'',nationalId:${JSON.stringify(nid||"")},job:'',empNo:'',card:'',addr:'',photo:'',docs:[],guarantor:null,notes:'',created:jToday()},${JSON.stringify(extra||{})}))})()`)}
function newProduct(o){R(`productWizard();Object.assign(PW,${JSON.stringify(o)});`);R(`pwSave(false)`)}
function invoice(d){R(`doSaveInvoice(Object.assign({id:'',group:'',disc:0,desc:'',pays:[],plan:null,checkPlan:null},${JSON.stringify(d)}))`)}
const lastInv=()=>J(`DB.invoices[DB.invoices.length-1]`);
const sum=a=>a.reduce((s,x)=>s+x,0);

let ACC;
test("۱) وضعیت اولیه: پایگاه داده‌ی تمیز",()=>{
 assert.equal(R("DB.products.length"),0);assert.equal(R("DB.invoices.length"),0);assert.equal(R("DB.persons.length"),0);
 ACC=R("DB.accounts[0].id");assert.ok(ACC);
});

test("۲) اشخاص آزمایشی در گروه‌های مختلف",()=>{
 addPerson("شرکت پخش تهران","فروشنده/تامین‌کننده","09120000001");
 addPerson("فروشگاه دیجی‌سپهر","فروشنده/تامین‌کننده","09120000002");
 addPerson("علی رضایی","مشتری عادی","09121234567","1651876924");
 addPerson("مریم کاظمی","مشتری عادی","09351234567","0012345678");
 addPerson("حسین احمدی","مشتری عادی","09141234567","2811234567");
 addPerson("رضا نوری","مشتری ویژه","09151234567","");
 addPerson("سارا محمدی","کارمند","09161234567","");
 assert.equal(R("DB.persons.length"),7);
 assert.equal(R(`isSupplierPerson(DB.persons.find(p=>p.name==="شرکت پخش تهران"))`),true);
 assert.equal(R(`isSupplierPerson(DB.persons.find(p=>p.name==="علی رضایی"))`),false);
});

test("۳) تعریف کالا از مسیر ویزارد: موبایل، لپ‌تاپ با مشخصات، کالای تعدادی",()=>{
 const base={track:"serial",snInName:false,codeMode:"auto",markup:10,sellAuto:false};
 newProduct({...base,group:gid("Mobile"),brand:"Samsung",model:"Galaxy A15",memory:"128 GB",ram:"4 GB",sn:"INTRO-A15"});
 newProduct({...base,group:gid("Mobile"),brand:"Xiaomi",model:"Redmi Note 13",memory:"256 GB",ram:"8 GB",sn:"INTRO-N13"});
 newProduct({...base,group:gid("Mobile"),brand:"Apple",model:"iPhone 13",memory:"128 GB",ram:"4 GB",sn:"INTRO-I13"});
 newProduct({...base,group:gid("Laptop"),brand:"Asus",model:"TUF F15",memory:"512 GB",ram:"16 GB",sn:"INTRO-TUF",cpuSeries:"Core i7",cpuGen:"نسل 12",cpuModel:"Core i7-12700H",gpu:"RTX 3050",screen:"15.6 اینچ",usage:"گیمینگ",cond:"استوک"});
 newProduct({track:"qty",codeMode:"auto",markup:10,sellAuto:false,group:gid("Laptop"),brand:"Lenovo",model:"IdeaPad 3",memory:"256 GB",ram:"8 GB",cpuSeries:"Core i5",cpuGen:"نسل 11",gpu:"Intel Iris Xe",screen:"15.6 اینچ",usage:"اداری",cond:"نو"});
 newProduct({track:"qty",codeMode:"auto",markup:10,sellAuto:false,group:gid("Accessories"),brand:"Samsung",model:"Cable USB-C"});
 assert.equal(R("DB.products.length"),6,JSON.stringify(R("__t.slice(-3)")));
 const tuf=J(`DB.products.find(p=>/tuf/i.test(p.name))`);
 assert.equal(tuf.cpuModel,"Core i7-12700H");assert.equal(tuf.gpu,"RTX 3050");assert.equal(tuf.usage,"گیمینگ");
 assert.match(tuf.name,/i7-12700h/);assert.match(tuf.name,/rtx 3050/);assert.equal(tuf.cond,"استوک");assert.match(tuf.name,/stock/);
 const idea=J(`DB.products.find(p=>/ideapad/i.test(p.name))`);assert.equal(idea.cond,"نو");assert.doesNotMatch(idea.name,/stock/);
 const mob=J(`DB.products.find(p=>/a15/i.test(p.name))`);assert.equal(mob.cpuModel,"");
 assert.equal(R("DB.products.every(p=>stockOf(p.id)===0)"),true,"معرفی کالا نباید موجودی بسازد");
});

test("۴) قفل‌های اعتبارسنجی کالا: برند/مدل/سریال تکراری/سقف سود",()=>{
 R("__t.length=0;productWizard();PW.group=DB.productGroups[0].id;pwSave(false)");assert.match(R("__t[__t.length-1]"),/برند/);
 R("__t.length=0;productWizard();Object.assign(PW,{group:DB.productGroups[0].id,brand:'X',model:'Y',track:'serial',sn:'INTRO-A15',snInName:false});pwSave(false)");assert.match(R("__t[__t.length-1]"),/سریال.*ثبت/);
 R("__t.length=0;productWizard();Object.assign(PW,{group:DB.productGroups[0].id,brand:'X',model:'Y',track:'qty',lastCost:1000000,sellPrice:50000000});pwSave(false)");assert.match(R("__t[__t.length-1]"),/سود/);
 assert.equal(R("DB.products.length"),6);
});

test("۵) فاکتورهای خرید: نقدی، چک و نسیه؛ موجودی و بدهی فروشنده",()=>{
 const v1=personId("شرکت پخش تهران"),v2=personId("فروشگاه دیجی‌سپهر");
 const A15=pidOf("P-1001"),N13=pidOf("P-1002"),I13=pidOf("P-1003"),TUF=pidOf("P-1004"),IDEA=pidOf("P-1005"),CAB=pidOf("P-1006");
 const ln=(pid,sn,price,sell)=>({pid,sid:"",sn,color:"",qty:1,price,cost:price,sellAtBuy:sell||0});
 invoice({kind:"buy",date:"1405/07/01",person:v1,lines:[1,2,3,4,5].map(i=>ln(A15,"A15-"+i,5000000,5800000)),pays:[{method:"cash",amount:10000000},{method:"cheque",amount:15000000,chkNo:"7100",chkBank:"ملت",chkDue:"1405/09/01",chkCount:3}]});
 assert.equal(R(`stockOf('${A15}')`),5);
 assert.equal(R(`DB.cheques.filter(c=>c.dir==='paid').length`),3);
 assert.equal(sum(J(`DB.cheques.filter(c=>c.dir==='paid').map(c=>c.amount)`)),15000000);
 invoice({kind:"buy",date:"1405/07/02",person:v1,lines:[1,2,3].map(i=>ln(TUF,"TUF-"+i,30000000,36000000)).concat([{pid:CAB,sid:"",sn:"",color:"",qty:50,price:100000,cost:100000,sellAtBuy:0},{pid:IDEA,sid:"",sn:"",color:"",qty:10,price:20000000,cost:20000000,sellAtBuy:0}]),pays:[]});
 assert.equal(R(`stockOf('${TUF}')`),3);assert.equal(R(`stockOf('${CAB}')`),50);assert.equal(R(`stockOf('${IDEA}')`),10);
 assert.equal(J(`personBalance('${v1}')`).buyDebt,(25000000+3*30000000+5000000+200000000)-0-25000000+25000000-25000000+0-0 || J(`personBalance('${v1}')`).buyDebt);
 invoice({kind:"buy",date:"1405/07/03",person:v2,lines:[1,2,3,4].map(i=>ln(N13,"N13-"+i,9000000,10500000)).concat([1,2].map(i=>ln(I13,"I13-"+i,30000000,34000000))),pays:[{method:"cash",amount:96000000}]});
 assert.equal(R(`stockOf('${N13}')`),4);assert.equal(R(`stockOf('${I13}')`),2);
 assert.equal(J(`personBalance('${v2}')`).buyDebt,0,"خرید کاملاً نقدی بدهی نمی‌سازد");
 assert.equal(R(`DB.serials.filter(s=>s.status==='stock').length`),5+3+4+2);
 assert.equal(R(`DB.products.find(p=>p.id==='${A15}').lastCost`),5000000);
});

test("۶) فاکتور فروش نقدی + سود + سریال فروخته‌شده",()=>{
 const A15=pidOf("P-1001"),c=personId("علی رضایی");
 invoice({kind:"sale",date:"1405/07/10",person:c,lines:[{pid:A15,sid:R(`DB.serials.find(s=>s.sn==='A15-1').id`),sn:"A15-1",color:"",qty:1,price:5800000,cost:0,sellAtBuy:0}],pays:[{method:"cash",amount:5800000}]});
 const inv=lastInv();
 assert.equal(R(`invTotal(DB.invoices[DB.invoices.length-1])`),5800000);
 assert.equal(R(`invPaid(DB.invoices[DB.invoices.length-1])`),5800000);
 assert.equal(R(`DB.serials.find(s=>s.sn==='A15-1').status`),"sold");
 assert.equal(R(`stockOf('${A15}')`),4);
 assert.equal(J(`personBalance('${c}')`).saleDebt,0);
 assert.ok(R(`invProfit(DB.invoices[DB.invoices.length-1])`)>0);
});

test("۷) فروش اقساطی: طرح ۶ قسطی",()=>{
 const TUF=pidOf("P-1004"),c=personId("مریم کاظمی");
 const items=[1,2,3,4,5,6].map(n=>({no:n,due:R(`jAddM('1405/08/01',${n-1})`),amount:5000000}));
 invoice({kind:"sale",date:"1405/07/11",person:c,lines:[{pid:TUF,sid:R(`DB.serials.find(s=>s.sn==='TUF-1').id`),sn:"TUF-1",color:"",qty:1,price:36000000,cost:0,sellAtBuy:0}],pays:[{method:"cash",amount:6000000},{method:"installment",amount:30000000}],plan:{count:6,gap:1,first:"1405/08/01",items}});
 assert.equal(R(`DB.installments.filter(i=>i.person==='${c}').length`),6);
 assert.equal(sum(J(`DB.installments.filter(i=>i.person==='${c}').map(i=>i.amount)`)),30000000);
 assert.equal(J(`personBalance('${c}')`).saleDebt,30000000,"مانده‌ی مشتری = بخش اقساطی");
 assert.equal(R(`invPaid(DB.invoices[DB.invoices.length-1])`),6000000,"قسط جزو پرداختی نیست");
});

test("۸) فروش با چک (۳ چک) و فروش با طرح چک (۴ چک) و تراکنش بانکی",()=>{
 const N13=pidOf("P-1002"),CAB=pidOf("P-1006"),I13=pidOf("P-1003"),IDEA=pidOf("P-1005");
 const h=personId("حسین احمدی"),r=personId("رضا نوری"),sa=personId("سارا محمدی");
 invoice({kind:"sale",date:"1405/07/12",person:h,lines:[{pid:N13,sid:R(`DB.serials.find(s=>s.sn==='N13-1').id`),sn:"N13-1",color:"",qty:1,price:10500000,cost:0,sellAtBuy:0},{pid:CAB,sid:"",sn:"",color:"",qty:5,price:150000,cost:0,sellAtBuy:0}],pays:[{method:"cheque",amount:11250000,chkNo:"5000",chkBank:"ملی",chkDue:"1405/09/10",chkCount:3}]});
 assert.equal(R(`DB.cheques.filter(c=>c.person==='${h}'&&c.dir==='rec').length`),3);
 assert.equal(sum(J(`DB.cheques.filter(c=>c.person==='${h}').map(c=>c.amount)`)),11250000);
 const serials=[1,2,3,4].map(n=>({no:n,serial:"1206/"+(123450+n),amount:10000000,due:R(`jAddM('1405/10/01',${n-1})`)}));
 invoice({kind:"sale",date:"1405/07/13",person:r,lines:[{pid:I13,sid:R(`DB.serials.find(s=>s.sn==='I13-1').id`),sn:"I13-1",color:"",qty:1,price:45000000,cost:0,sellAtBuy:0}],pays:[{method:"cash",amount:5000000}],checkPlan:{count:4,startSerial:"1206/123451",prefix:"1206",startSuffix:123451,bank:"ملت",branch:"مرکزی",first:"1405/10/01",items:serials}});
 assert.equal(R(`DB.cheques.filter(c=>c.person==='${r}').length`),4);
 const before=R("DB.accTx.length");
 invoice({kind:"sale",date:"1405/07/14",person:sa,lines:[{pid:IDEA,sid:"",sn:"",color:"",qty:2,price:24000000,cost:0,sellAtBuy:0}],pays:[{method:"account",amount:48000000,acc:ACC}]});
 assert.equal(R("DB.accTx.length"),before+1);
 const tx=J("DB.accTx[DB.accTx.length-1]");assert.equal(tx.type,"in");assert.equal(tx.amount,48000000);
 assert.equal(R(`stockOf('${IDEA}')`),8);
});

test("۹) پیش‌فاکتور اثری بر موجودی/مانده ندارد؛ برگشت از فروش و خرید",()=>{
 const A15=pidOf("P-1001"),c=personId("علی رضایی"),v1=personId("شرکت پخش تهران");
 const st0=R(`stockOf('${A15}')`),bal0=J(`personBalance('${c}')`).saleDebt;
 invoice({kind:"proforma",date:"1405/07/15",person:c,lines:[{pid:A15,sid:"",sn:"",color:"",qty:3,price:5900000,cost:0,sellAtBuy:0}],pays:[]});
 assert.equal(R(`stockOf('${A15}')`),st0);assert.equal(J(`personBalance('${c}')`).saleDebt,bal0);
 invoice({kind:"saleret",date:"1405/07/16",person:c,lines:[{pid:A15,sid:R(`DB.serials.find(s=>s.sn==='A15-1').id`),sn:"A15-1",color:"",qty:1,price:5800000,cost:0,sellAtBuy:0}],pays:[]});
 assert.equal(R(`DB.serials.find(s=>s.sn==='A15-1').status`),"stock");assert.equal(R(`stockOf('${A15}')`),st0+1);
 invoice({kind:"buyret",date:"1405/07/17",person:v1,lines:[{pid:A15,sid:R(`DB.serials.find(s=>s.sn==='A15-5').id`),sn:"A15-5",color:"",qty:1,price:5000000,cost:0,sellAtBuy:0}],pays:[]});
 assert.equal(R(`DB.serials.find(s=>s.sn==='A15-5').status`),"returned");assert.equal(R(`stockOf('${A15}')`),st0);
});

test("۱۰) پرداخت قسط با ثبت رسید و ورودی بانک؛ پیام تشکر بله/روبیکا/پیامک",async()=>{
 R(`DB.settings.baleToken='BT';DB.settings.rubikaToken='RT';DB.settings.allMsgOn=true;DB.settings.thanksOn=true;globalThis.__raw=[];sendSMSRaw=(to,m)=>{__raw.push([to,m])}`);
 R(`(()=>{const p=DB.persons.find(x=>x.name==='مریم کاظمی');p.baleId='900';p.rubikaId='b0900'})()`);
 const c=personId("مریم کاظمی"),inst=J(`DB.installments.filter(i=>i.person==='${c}').sort((a,b)=>a.no-b.no)[0]`);
 el("ipAmt").value="5,000,000";el("ipDate").value="1405/08/01";el("ipM").value="account";el("ipAcc").value=ACC;
 calls.length=0;const tx0=R("DB.accTx.length"),rc0=R("DB.receipts.length");
 R(`instPaySave('${inst.id}')`);await wait(1500);
 assert.equal(R(`DB.installments.find(i=>i.id==='${inst.id}').paid`),true);
 assert.equal(R("DB.receipts.length"),rc0+1);assert.equal(R("DB.accTx.length"),tx0+1);
 assert.equal(calls.filter(x=>/sendMessage$/.test(x.u)).length,2,"بله و روبیکا هر کدام یک پیام تشکر");
 assert.equal(R("__raw.length"),1,"پیامک هم یک بار");
 assert.equal(J(`personBalance('${c}')`).saleDebt,25000000);
});

test("۱۱) چرخه‌ی چک: وصول (با حساب)، برگشتی، تغییر مجدد؛ پیام تشکر فقط یک بار",async()=>{
 const h=personId("حسین احمدی");R(`(()=>{const p=DB.persons.find(x=>x.name==='حسین احمدی');p.baleId='901'})()`);
 const chqs=J(`DB.cheques.filter(c=>c.person==='${h}'&&c.dir==='rec').sort((a,b)=>a.due<b.due?-1:1)`);
 el("chAcc").value=ACC;calls.length=0;
 R(`chequeSt2('${chqs[0].id}','وصول شده')`);await wait(900);
 assert.equal(R(`DB.cheques.find(c=>c.id==='${chqs[0].id}').status`),"وصول شده");
 assert.equal(calls.filter(x=>/bale/.test(x.u)&&/sendMessage$/.test(x.u)).length,1);
 calls.length=0;R(`chequeSt2('${chqs[0].id}','وصول شده')`);await wait(300);assert.equal(calls.length,0,"وصول مجدد پیام تکراری نمی‌سازد");
 const before=J(`personBalance('${h}')`).saleDebt;
 R(`chequeSt2('${chqs[1].id}','برگشتی')`);
 assert.equal(R(`DB.cheques.find(c=>c.id==='${chqs[1].id}').status`),"برگشتی");
 assert.ok(J(`personBalance('${h}')`).saleDebt>=before,"برگشت چک بدهی را برمی‌گرداند");
 calls.length=0;
});

test("۱۲) لیست‌های اقساط: گروه‌بندی، انتقال، ورود اکسل کاربر (۷۷۱ قسط)",async()=>{
 assert.equal(R("instGroups().length"),6);
 const c=personId("مریم کاظمی");
 R(`instMoveOpen(DB.installments.filter(i=>i.person==='${c}').map(i=>i.id))`);el("mvG").value="ig-faraja";R("instMoveDo()");
 assert.equal(R(`DB.installments.filter(i=>instGrp(i)==='ig-faraja').length`),6);
 const buf=fs.readFileSync(path.join(__dirname,"data/installments.xlsx"));
 ctx.FileReader=function(){this.readAsArrayBuffer=function(){this.onload({target:{result:buf}})}};
 const n0=R("DB.installments.length"),p0=R("DB.persons.length");
 R(`xlIn({files:[{}],value:''},'installments','ig-azad')`);
 assert.equal(R("DB.installments.length"),n0+771);assert.equal(R(`DB.installments.filter(i=>instGrp(i)==='ig-azad').length`),771);
 assert.equal(R("DB.persons.length"),p0+100);
 assert.equal(sum(J(`DB.installments.filter(i=>instGrp(i)==='ig-azad').map(i=>i.amount)`)),5122049000);
 R(`instGrpAdd`);R(`askM=(t,l,v,cb)=>cb('لیست آزمایشی')`);R("instGrpAdd()");assert.equal(R("instGroups().length"),7);
 const nid=R("Fi.grp");R(`confirmM=(m,cb)=>cb()`);R("instGrpDel()");assert.equal(R("instGroups().length"),6);R("Fi.grp=''");
});

test("۱۳) گردش حساب بانک رفاه: تطبیق، وصول، جلوگیری از وصول تکراری",async()=>{
 const buf=fs.readFileSync(path.join(__dirname,"data/refah-statement.xls"));
 ctx.FileReader=function(){this.readAsArrayBuffer=function(){this.onload({target:{result:buf}})}};
 R(`globalThis.__res=rfParse(XLSX.read(new Uint8Array(${JSON.stringify([...buf])}),{type:'array'}))`);
 assert.equal(R("__res.rows.length"),141);assert.equal(R("__res.other"),18);
 // مستمری‌بگیران آزمایشی: شخص با کد ملی + قسط هم‌مبلغ در لیست رفاه
 R(`(()=>{const g=DB.personGroups[0];let k=0;const made={};__res.rows.forEach((r,j)=>{const key=r.idn||r.name;let p=made[key];if(!p){k++;p={id:'PR'+k,code:9000+k,name:r.name,group:g.id,groups:[g.id],phone:'',nationalId:r.idn,baleId:''};DB.persons.push(p);made[key]=p}
   DB.installments.push({id:'RI'+j,planId:'pl'+p.id,inv:'',person:p.id,no:1,amount:Math.round(r.amt/10),due:'1405/07/'+String(10+(j%20)).padStart(2,'0'),paid:false,paidDate:'',desc:'',grp:'ig-refah'})})})()`);
 R(`rfFile({files:[{name:'x.xls'}],value:''})`);
 assert.equal(R(`_rf.rows.filter(r=>r.status==='ok').length`),141,"همه با کد ملی و مبلغ منطبق می‌شوند");
 el("rfThanks").checked=false;el("rfAcc").value=ACC;
 R("rfCommit()");await wait(200);
 assert.equal(R(`DB.installments.filter(i=>i.id.startsWith('RI')&&i.paid).length`),141);
 R(`rfFile({files:[{name:'x.xls'}],value:''})`);
 assert.equal(R(`_rf.rows.filter(r=>r.status==='dup').length`),141);assert.equal(R(`_rf.rows.filter(r=>r.chk).length`),0);
 R("closeM()");
});

test("۱۴) متن کامل فاکتور و ارسال سه‌پلتفرمی",async()=>{
 const c=personId("مریم کاظمی");
 R(`(()=>{const p=DB.persons.find(x=>x.name==='مریم کاظمی');p.baleId='900';p.rubikaId='b0900'})()`);
 const iv=R(`DB.invoices.find(i=>i.person==='${c}'&&i.type==='sale').id`);
 const t=R(`invText(DB.invoices.find(i=>i.id==='${iv}'))`);
 for(const k of["شماره","مریم کاظمی","پردازنده","جمع کل","مانده","اقساط","وضعیت: استوک"])assert.ok(t.includes(k),"در متن فاکتور نیست: "+k);
 assert.match(t,/tuf/i);assert.match(t,/rtx 3050/i);
 R(`msgInvoiceOpen('${iv}')`);el("mi_bale").checked=true;el("mi_rubika").checked=true;el("mi_sms").checked=true;el("miTxt").value=t;
 calls.length=0;R("globalThis.__raw.length=0");R("msgInvoiceSend()");await wait(1500);
 assert.equal(calls.filter(x=>/sendMessage$/.test(x.u)).length,2);assert.equal(R("__raw.length"),1);
 calls.length=0;R("globalThis.__raw.length=0;sendSMS('09351234567','یادآوری')");await wait(900);
 assert.equal(calls.filter(x=>/sendMessage$/.test(x.u)).length,2);assert.equal(R("__raw.length"),1);
});

test("۱۵) دفتر کل: همه‌ی اسناد متوازن، ترازنامه متوازن، مانده‌ها با دفتر یکی",()=>{
 const jn=R("jnlBuild()");
 assert.equal(R("jnlBuild().every(e=>e.rows.reduce((s,r)=>s+r.d-r.c,0)===0)"),true);
 const tb=R("(()=>{const t=trialBal(jnlBuild());const B=c=>{const a=t.find(x=>x.code===c);return a?a.d-a.c:0};return JSON.stringify({ar:B('1201'),ap:-B('2101'),inv:B('1301')})})()");
 const b=JSON.parse(tb);
 const ar=sum(J("DB.persons.map(p=>personBalance(p.id).saleDebt)")),ap=sum(J("DB.persons.map(p=>personBalance(p.id).buyDebt)"));
 assert.equal(b.ar,ar,"دریافتنی‌ها = مجموع مانده‌ی مشتریان");assert.equal(b.ap,ap,"پرداختنی‌ها = مجموع مانده‌ی فروشندگان");
 assert.equal(R("bsBuild(jnlBuild()).balanced"),true);
 // موجودی هر کالا = تعداد سریال‌های موجود
 assert.equal(R(`DB.products.filter(p=>p.track==='serial').every(p=>stockOf(p.id)===DB.serials.filter(s=>s.pid===p.id&&s.status==='stock').length)`),true);
});

test("۱۶) رندر همه‌ی صفحه‌ها و زیرتب‌ها روی داده‌ی کامل بدون خطا",()=>{
 const views=["dash","personIntro","persons","productList","instList","products","inventory","purchase","sales","invoiceList","settle","cheques","inst","bank","reports","tools"];
 for(const v of views){assert.doesNotThrow(()=>R(`nav=undefined;0`)&&0,v);}
 R(`nav=function(v){curView=v;({dash:renderDash,personIntro:vPersonIntro,persons:vPersons,productList:vProductList,instList:()=>vInst('list'),products:vProducts,inventory:vInventory,purchase:vPurchase,sales:vSales,invoiceList:vInvoiceList,settle:vSettle,cheques:vFinanceHub,inst:vFinanceHub,bank:vBank,reports:vReports,tools:vTools})[v]()}`);
 for(const v of views)assert.doesNotThrow(()=>R(`nav('${v}')`),"نمای "+v);
 for(const t of["list","warn","plans","rep","reg"])for(const g of["","ig-normal","ig-faraja","ig-refah","ig-azad"])assert.doesNotThrow(()=>R(`Fi.grp='${g}';vInst('${t}')`),"قسط/"+t+"/"+g);
 R("Fi.grp=''");
 for(const t of["accounts","tx","cheques","transfer"])try{R(`vBank('${t}')`)}catch(e){assert.fail("بانک/"+t+": "+e.message)}
});

test("۱۷) بکاپ و بازیابی: رفت‌وبرگشت JSON بدون از دست رفتن داده",()=>{
 const snap=R("JSON.stringify(DB)"),cnt=J("({p:DB.products.length,pe:DB.persons.length,i:DB.invoices.length,c:DB.cheques.length,in:DB.installments.length,s:DB.serials.length,r:DB.receipts.length,tx:DB.accTx.length})");
 R(`globalThis.__bak=JSON.parse(${JSON.stringify(snap)});migrate(__bak)`);
 const c2=J("({p:__bak.products.length,pe:__bak.persons.length,i:__bak.invoices.length,c:__bak.cheques.length,in:__bak.installments.length,s:__bak.serials.length,r:__bak.receipts.length,tx:__bak.accTx.length})");
 assert.deepEqual(c2,cnt);
 assert.equal(R("__bak.instGroups.length"),6);assert.ok(R("__bak.bankSeen&&Object.keys(__bak.bankSeen).length")>0);
 R("migrate(__bak)");assert.deepEqual(J("({p:__bak.products.length,i:__bak.invoices.length})"),{p:cnt.p,i:cnt.i},"migrate تکراری بی‌اثر است");
});

test("۱۸) تست‌های داخلی برنامه (selfTests) همچنان سالم‌اند",()=>{
 const rs=J("selfTests()");assert.ok(rs.length>=40);const bad=rs.filter(x=>!x.ok);assert.deepEqual(bad,[]);
});

test("۱۹) لپ‌تاپ: وضعیت نو/استوک و قیمت فروش خودکار = خرید + ۲۰ میلیون",()=>{
 assert.deepEqual(J("lapOpts('laptopConds')"),["نو","استوک"]);
 // ویزارد: لپ‌تاپ
 R(`productWizard();Object.assign(PW,{group:'${gid("Laptop")}',sellAuto:true,markup:10});pwBuyIn('30,000,000')`);
 assert.equal(R("PW.sellPrice"),50000000,"لپ‌تاپ: ۳۰ میلیون خرید → ۵۰ میلیون فروش");
 R(`PW.group='${gid("Mobile")}';pwBuyIn('30,000,000')`);assert.equal(R("PW.sellPrice"),33000000,"موبایل: ۱۰٪ سود");
 R(`PW.group='${gid("Mobile")}';pwBuyIn('150,000,000')`);assert.equal(R("PW.sellPrice"),160000000,"موبایل: سقف سود ۱۰ میلیون");
 // با تغییر گروه به لپ‌تاپ، قیمت دوباره حساب می‌شود
 R(`PW.sellAuto=true;PW.lastCost=30000000;PW.group='${gid("Mobile")}';pwCalcSell();PW.group='${gid("Laptop")}';pwCalcSell()`);assert.equal(R("PW.sellPrice"),50000000);
 // سقف سود لپ‌تاپ ۲۰ میلیون است
 R("__t.length=0;productWizard();Object.assign(PW,{group:'"+gid("Laptop")+"',brand:'HP',model:'Probook',track:'qty',lastCost:30000000,sellPrice:50000001});pwSave(false)");
 assert.match(R("__t[__t.length-1]"),/سود/);
 R("__t.length=0;productWizard();Object.assign(PW,{group:'"+gid("Laptop")+"',brand:'HP',model:'Probook',track:'qty',lastCost:30000000,sellPrice:50000000,cond:'استوک'});pwSave(false)");
 const hp=J("DB.products.find(p=>/probook/i.test(p.name))");assert.equal(hp.sellPrice,50000000);assert.equal(hp.cond,"استوک");assert.match(hp.name,/stock/);
 // فاکتور خرید: قیمت فروش هنگام خرید خودکار = خرید + ۲۰ میلیون، تا وقتی دستی تغییر نکرده
 R(`window._invKind='buy';window.L=[{pid:'',sid:'',sn:'',color:'',qty:1,price:0,cost:0,sellAtBuy:0}];rowAddRenderAll=()=>{};recalc=()=>{};`);
 R(`rowProdChange({value:'${hp.id}'},0)`);
 assert.equal(R("window.L[0].sellAtBuy"),R("window.L[0].price")+20000000);
 el("rp_0").value="35,000,000";el("rq_0").value="1";R("rowUpd(0)");assert.equal(R("window.L[0].sellAtBuy"),55000000);
 R("window.L[0].sellManual=1");el("rp_0").value="40,000,000";el("rsl_0").value="52,000,000";R("rowUpd(0)");assert.equal(R("window.L[0].sellAtBuy"),52000000,"قیمت دستی بازنویسی نمی‌شود");
 // موبایل در فاکتور خرید: بدون ۲۰ میلیون
 R(`window.L=[{pid:'',sid:'',sn:'',color:'',qty:1,price:0,cost:0,sellAtBuy:0}];rowProdChange({value:'${pidOf("P-1001")}'},0)`);
 assert.ok(R("window.L[0].sellAtBuy")-R("window.L[0].price")<20000000);
 // ویرایش مشخصات لپ‌تاپ ثبت‌شده شامل وضعیت
 R(`lapEdit('${hp.id}')`);el("lpCond").value="نو";el("lpUse").value="اداری";R("lapSave()");
 assert.equal(R(`DB.products.find(p=>p.id==='${hp.id}').cond`),"نو");
 assert.match(R(`lapSpecText(DB.products.find(p=>p.id==='${hp.id}'))`),/وضعیت: نو/);
});

test("۲۰) صفحه‌ی اقساط: بالای صفحه (گزارش‌ها) ثابت، لیست اشخاص اسکرول‌شونده",()=>{
 R("Fi.grp='';vInst('list')");const h=el("content").innerHTML;
 const iF=h.indexOf('class="inst-fixed"'),iS=h.indexOf('class="statgrid"'),iT=h.indexOf('<table'),iTab=h.indexOf('class="tabs'),iSb=h.indexOf('class="searchbar"');
 assert.ok(iF>=0&&iS>iF,"آمار داخل بخش ثابت");assert.ok(iT>iF,"جدول بعد از بخش ثابت");assert.ok(iSb>iF&&iSb<iT,"جستجو داخل بخش ثابت");
 const fixedEnd=h.indexOf("</details>");assert.ok(h.indexOf('<details',iF)>iF&&h.indexOf('<details',iF)<iT,"ابزارهای ورود اکسل در بخش جمع‌شونده");
 assert.ok(html.includes(".inst-fixed{position:sticky"),"CSS چسبیده (sticky)");
 assert.ok(h.includes("rfFile(this)")&&h.includes("xlIn(this,'installments','ig-faraja')"),"دکمه‌های ورود اکسل و گردش بانک");
});

test("۲۱) گردش بانک: تمام‌صفحه، فیلتر وضعیت‌ها، مرتب‌سازی، بدون پرش اسکرول",()=>{
 const buf=fs.readFileSync(path.join(__dirname,"data/refah-statement.xls"));
 ctx.FileReader=function(){this.readAsArrayBuffer=function(){this.onload({target:{result:buf}})}};
 // هر بار یک ردیف متفاوت: ۴۰ مبلغ متفاوت، ۱۰ نام تقریبی، ۱۰ شخص ناموجود
 R(`DB.persons=DB.persons.filter(p=>!p.id.startsWith('PR'));DB.installments=DB.installments.filter(i=>!i.id.startsWith('RI')&&!i.id.startsWith('RZ'));DB.bankSeen={};
  globalThis.__res2=rfParse(XLSX.read(new Uint8Array(${JSON.stringify([...buf])}),{type:'array'}));
  (()=>{const g=DB.personGroups[0];let k=0;const made={};__res2.rows.forEach((r,j)=>{const key=r.idn||r.name;let p=made[key];
   if(j%14===0&&!p){return}  // شخص یافت نشد
   if(!p){k++;p={id:'PR'+k,code:9500+k,name:(j%11===0?r.name+' خانوادگی':r.name),group:g.id,groups:[g.id],phone:'',nationalId:(j%11===0?'':r.idn)};DB.persons.push(p);made[key]=p}
   DB.installments.push({id:'RZ'+j,planId:'pl'+p.id,inv:'',person:p.id,no:1,amount:Math.round(r.amt/10)+(j%3===0?777000:0),due:'1405/07/1'+(j%9),paid:false,paidDate:'',desc:'',grp:'ig-refah'})})})()`);
 R(`rfFile({files:[{name:'x.xls'}],value:''})`);
 const cnt=J(`(()=>{const c={};_rf.rows.forEach(r=>c[r.status]=(c[r.status]||0)+1);return c})()`);
 assert.ok(cnt.ok>0&&cnt.diff>0&&cnt.noperson>0,JSON.stringify(cnt));
 // تمام‌صفحه
 assert.match(String(R("window.__modal")),/rfTop/);assert.ok(String(R("window.__modal")).includes('id="rfScroll"'));
 // فیلتر: فقط مبلغ متفاوت و شخص یافت نشد
 R(`['ok','maybe','none','dup'].forEach(k=>rfFilter(k,false))`);
 assert.equal(R(`rfView().every(x=>['diff','noperson'].includes(x.r.status))`),true);
 assert.equal(R("rfView().length"),(cnt.diff||0)+(cnt.noperson||0));
 // نام تقریبی
 R(`['ok','maybe','diff','none','noperson','dup'].forEach(k=>rfFilter(k,k==='maybe'))`);assert.equal(R("rfView().length"),cnt.maybe||0);
 R(`['ok','maybe','diff','none','noperson','dup'].forEach(k=>rfFilter(k,true))`);assert.equal(R("rfView().length"),R("_rf.rows.length"));
 // مرتب‌سازی
 el("rfSort").value="amount";el("rfDir").value="desc";R("rfSort()");
 const am=J("rfView().map(x=>x.r.toman)");assert.deepEqual(am,[...am].sort((a,b)=>b-a));
 el("rfSort").value="name";el("rfDir").value="asc";R("rfSort()");
 const nm=J("rfView().map(x=>rfNormName(x.r.name))");assert.deepEqual(nm,[...nm].sort());
 el("rfSort").value="status";R("rfSort()");const st=J("rfView().map(x=>RF_ORDER.indexOf(x.r.status))");assert.deepEqual(st,[...st].sort((a,b)=>a-b));
 el("rfSort").value="date";R("rfSort()");const dt=J("rfView().map(x=>x.r.date)");assert.deepEqual(dt,[...dt].sort());
 el("rfSort").value="diff";el("rfDir").value="desc";R("rfSort()");const df=J("rfView().map(x=>rfDiff(x.r))");assert.deepEqual(df,[...df].sort((a,b)=>b-a));
 // جستجو
 R("_rf.q='فرناز';rfRender()");assert.ok(R("rfView().length")>=1&&R("rfView().every(x=>rfNormName(x.r.name).includes(rfNormName('فرناز')))"));R("_rf.q='';rfRender()");
 // اسکرول حفظ می‌شود (فیلتر/تیک/انتخاب)
 el("rfScroll").scrollTop=321;R("rfFilter('ok',true)");assert.equal(el("rfScroll").scrollTop,321);
 const k0=R(`_rf.rows.findIndex(r=>r.status==='diff')`);
 R(`rfChk(${k0},true)`);assert.equal(el("rfScroll").scrollTop,321);assert.equal(R(`_rf.rows[${k0}].chk`),true);
 const k1=R(`_rf.rows.findIndex(r=>r.cands.length>1)`);if(k1>=0){R(`rfSel(${k1},_rf.rows[${k1}].cands[1].id)`);assert.equal(el("rfScroll").scrollTop,321)}
 // انتخاب همه‌ی نمایش‌داده‌شده فقط ردیف‌های دارای قسط و غیرتکراری
 R("rfAll(false)");assert.equal(R("_rf.rows.filter(r=>r.chk).length"),0);
 R("rfAll(true)");assert.equal(R("_rf.rows.filter(r=>r.chk).every(r=>r.sel&&r.status!=='dup')"),true);assert.ok(R("_rf.rows.filter(r=>r.chk).length")>0);
 R("rfAll(false)");R("closeM()");
});

/* ===================== حذف اطلاعات (بخش‌بندی، بازه‌ی زمانی، کد پیامکی) ===================== */
const resetDelUi=()=>{["persons","installments","cheques","invoices","products","all"].forEach(k=>el("dl_"+k).checked=false);el("dlCascade").checked=true;el("dlBasis").value="doc";["dlFrom","dlTo","dlFromT","dlToT","dlCode"].forEach(k=>el(k).value="")};
const sandbox=()=>R(`DB=JSON.parse(globalThis.__snapDel);globalThis.__sms=[];sendSMSRaw=(to,m)=>{__sms.push([to,m])};globalThis.__snapN=0;snapshot=async()=>{__snapN++};nav=v=>{curView=v};delete DB._ts;tsStamp()`);
const smsCode=()=>{const m=R("__sms[__sms.length-1][1]").match(/: (\d{6})/);return m&&m[1]};
test("۲۲) زمان ثبت رکوردها (تاریخ و ساعت) و بازه‌ی تاریخ/ساعت",()=>{
 R("globalThis.__snapDel=JSON.stringify(DB)");sandbox();
 assert.ok(R("Object.keys(DB._ts).length")>100);assert.equal(R("Object.values(DB._ts).every(v=>v===0)"),true,"رکوردهای قدیمی زمان ندارند");
 R(`DB.installments.push({id:'NEW1',planId:'x',inv:'',person:'${personId("علی رضایی")}',no:1,amount:1111,due:'1405/12/01',paid:false,paidDate:''},{id:'NEW2',planId:'x',inv:'',person:'${personId("علی رضایی")}',no:2,amount:2222,due:'1405/12/02',paid:false,paidDate:''});tsStamp()`);
 assert.ok(R("DB._ts.NEW1")>0);
 R(`DB._ts.NEW1=${"delEpoch('1405/07/10','14:30')"};DB._ts.NEW2=delEpoch('1405/07/10','16:45')`);
 const pl=(o)=>J(`(()=>{const P=delPlan(${JSON.stringify(Object.assign({cats:["installments"],basis:"ts",cascade:true},o))});return P.err?{err:P.err}:{i:[...P.installments]}})()`);
 assert.deepEqual(pl({from:"1405/07/10",fromT:"14:00",toT:"15:00"}).i,["NEW1"]);
 assert.deepEqual(pl({from:"1405/07/10",fromT:"16:00",toT:"17:00"}).i,["NEW2"]);
 assert.deepEqual(pl({from:"1405/07/10"}).i.sort(),["NEW1","NEW2"],"بدون ساعت = کل روز");
 assert.deepEqual(pl({from:"1405/07/10",fromT:"14:31",toT:"16:44"}).i,[]);
 assert.deepEqual(pl({from:"1405/07/09",to:"1405/07/11"}).i.sort(),["NEW1","NEW2"]);
 assert.deepEqual(pl({from:"1405/07/11"}).i,[]);
 assert.match(pl({from:"1405/13/40"}).err,/نامعتبر/);assert.match(pl({from:"1405/07/10",to:"1405/07/01"}).err,/بعد/);assert.match(pl({from:"1405/07/10",fromT:"99:99"}).err,/ساعت/);
});

test("۲۳) حذف بر اساس تاریخ سند: چک‌ها با وابسته‌ها، اقساط، اشخاص (وابستگی و محافظت)",()=>{
 sandbox();
 const h=personId("حسین احمدی");
 const P=J(`(()=>{const P=delPlan({cats:['cheques'],basis:'doc',from:'1405/09/10'});return{c:[...P.cheques].length,tx:[...P.accTx].length,ids:[...P.cheques].every(id=>DB.cheques.find(c=>c.id===id).due==='1405/09/10')}})()`);
 assert.ok(P.c>=1&&P.ids,"چک‌های روز مشخص (فقط همان تاریخ)");assert.ok(P.tx>=1,"تراکنش بانکی چک وصول‌شده هم حذف می‌شود");
 // اشخاص: شخص دارای فاکتور محافظت می‌شود؛ شخص بدون فاکتور با وابسته‌ها حذف می‌شود
 R(`DB.persons.push({id:'PX',code:9999,name:'شخص بدون فاکتور',group:DB.personGroups[0].id,groups:[DB.personGroups[0].id],phone:'',created:'1390/05/05'},{id:'PY',code:9998,name:'شخص دارای فاکتور',group:DB.personGroups[0].id,groups:[DB.personGroups[0].id],phone:'',created:'1390/05/05'});
  DB.installments.push({id:'XI',planId:'q',inv:'',person:'PX',no:1,amount:5,due:'1405/12/01',paid:false,paidDate:''});DB.cheques.push({id:'XC',no:'1',dir:'rec',person:'PX',amount:5,due:'1405/12/01',status:'جاری'});
  DB.invoices.push({id:'XV',type:'proforma',no:'PF9',date:'1390/05/05',person:'PY',lines:[],pays:[],discount:0});tsStamp()`);
 let r=J(`(()=>{const P=delPlan({cats:['persons'],basis:'doc',from:'1390/05/05',cascade:true});return{p:[...P.persons],i:[...P.installments],c:[...P.cheques],prot:P.prot.persons.map(x=>x.id)}})()`);
 assert.deepEqual(r.p,["PX"]);assert.deepEqual(r.i,["XI"]);assert.deepEqual(r.c,["XC"]);assert.deepEqual(r.prot,["PY"]);
 r=J(`(()=>{const P=delPlan({cats:['persons'],basis:'doc',from:'1390/05/05',cascade:false});return{p:[...P.persons],prot:P.prot.persons.map(x=>x.id).sort()}})()`);
 assert.deepEqual(r.p,[]);assert.deepEqual(r.prot,["PX","PY"],"بدون آبشاری شخص دارای وابسته محافظت می‌شود");
 // اگر فاکتور هم انتخاب شود شخص دوم هم حذف می‌شود
 r=J(`(()=>{const P=delPlan({cats:['persons','invoices'],basis:'doc',from:'1390/05/05',cascade:true});return{p:[...P.persons].sort(),v:[...P.invoices]}})()`);
 assert.deepEqual(r.p,["PX","PY"]);assert.deepEqual(r.v,["XV"]);
});

test("۲۴) حذف فاکتور: برگرداندن سریال‌ها، حذف اقساط/چک/تراکنش وابسته، حفظ ترازنامه، محافظت برگشت‌ها",()=>{
 sandbox();
 const mar=personId("مریم کاظمی"),ali=personId("علی رضایی");
 // فاکتور فروش علی (۱۴۰۵/۰۷/۱۰) برگشتِ ثبت‌شده دارد ← محافظت
 let r=J(`(()=>{const P=delPlan({cats:['invoices'],basis:'doc',from:'1405/07/10',to:'1405/07/10'});return{v:[...P.invoices].map(id=>DB.invoices.find(i=>i.id===id).person),prot:P.prot.invoices.map(x=>x.why)}})()`);
 assert.ok(!r.v.includes(ali)&&r.prot.some(w=>/برگشت/.test(w)),JSON.stringify(r));
 // فاکتور اقساطی مریم
 const plan=`delPlan({cats:['invoices'],basis:'doc',from:'1405/07/11',to:'1405/07/11'})`;
 const n0=R("DB.installments.length"),tuf=R("DB.serials.find(s=>s.sn==='TUF-1').status");assert.equal(tuf,"sold");
 R(`globalThis.__P=${plan};delApply(__P)`);
 assert.equal(R("DB.serials.find(s=>s.sn==='TUF-1').status"),"stock","سریال به انبار برمی‌گردد");
 assert.equal(R(`DB.installments.filter(i=>i.person==='${mar}').length`),0);assert.equal(R("DB.installments.length"),n0-6);
 assert.equal(R(`DB.receipts.filter(r=>r.person==='${mar}').length`),0,"رسید قسط پرداخت‌شده هم حذف می‌شود");
 assert.equal(R(`DB.accTx.some(t=>(DB.receipts.every(r=>r.id!==t.ref))&&t.desc&&t.desc.includes('مریم'))`),false);
 assert.equal(R("jnlBuild().every(e=>e.rows.reduce((s,r)=>s+r.d-r.c,0)===0)"),true);assert.equal(R("bsBuild(jnlBuild()).balanced"),true);
 assert.equal(R(`DB.products.filter(p=>p.track==='serial').every(p=>stockOf(p.id)===DB.serials.filter(s=>s.pid===p.id&&s.status==='stock').length)`),true);
 // ورود مجدد گردش بانک بعد از حذف قسط‌ها: نشانه‌ی «قبلاً وصول شده» پاک می‌شود
 R(`DB.bankSeen={k1:'${R("DB.installments[0].id")}',k2:'zzz'};globalThis.__P2={...delPlan({cats:['installments'],basis:'doc',from:'1000/01/01',to:'1500/01/01'})};delApply(__P2)`);
 assert.deepEqual(J("Object.keys(DB.bankSeen)"),["k2"]);
});

test("۲۵) رمز ثابت حذف: تعریف (هش)، اعتبارسنجی، رمز اشتباه، قفل موقت، تغییر و بازنشانی",async()=>{
 sandbox();
 assert.equal(R("delPassIsSet()"),false);
 assert.match(await R("delPassCheck('x').then(r=>r.err)"),/ابتدا رمز/);
 assert.match(await R("delPassSet('12','12').then(r=>r.err)"),/۴ کاراکتر/);
 assert.match(await R("delPassSet('abcd','abce').then(r=>r.err)"),/یکسان نیست/);
 assert.equal(await R("delPassSet('s3cret!','s3cret!').then(r=>r.ok)"),true);
 assert.equal(R("delPassIsSet()"),true);
 const stored=R("JSON.stringify(DB.settings.delPass)");assert.ok(!stored.includes("s3cret"),"رمز به‌صورت متن ذخیره نمی‌شود");assert.match(stored,/"hash":"[^"]{20,}"/);
 assert.equal(await R("delPassCheck('s3cret!').then(r=>r.ok)"),true);
 assert.equal(await R("delPassCheck('۱۲۳').then(r=>!!r.err)"),true);
 // ۵ تلاش اشتباه ← قفل ۶۰ ثانیه‌ای، حتی با رمز درست
 R("window._delFail=null");
 for(let k=0;k<4;k++)assert.match(await R("delPassCheck('bad').then(r=>r.err)"),/اشتباه/);
 assert.match(await R("delPassCheck('bad').then(r=>r.err)"),/قفل شد/);
 assert.match(await R("delPassCheck('s3cret!').then(r=>r.err)"),/ثانیه دیگر/,"در زمان قفل رمز درست هم پذیرفته نمی‌شود");
 R("_delFail.until=Date.now()-1");assert.equal(await R("delPassCheck('s3cret!').then(r=>r.ok)"),true,"پس از پایان قفل");
 // تغییر رمز با رمز فعلی
 assert.match(await R("delPassChange('wrong','newpass1','newpass1').then(r=>r.err)"),/اشتباه/);
 assert.equal(await R("delPassChange('s3cret!','newpass1','newpass1').then(r=>r.ok)"),true);
 assert.equal(await R("delPassCheck('s3cret!').then(r=>!!r.err)"),true);assert.equal(await R("delPassCheck('newpass1').then(r=>r.ok)"),true);
 // فراموشی: بدون قفل برنامه ممکن نیست؛ با رمز قفل برنامه ممکن است
 assert.match(await R("delPassReset('x','zzzz1','zzzz1').then(r=>r.err)"),/قفل برنامه تعریف نشده/);
 R(`DB.settings.appLock=null`);const mk=await R("lkMake('lock123')");ctx.__lk=mk;R("DB.settings.appLock=__lk");
 assert.match(await R("delPassReset('wrong','zzzz1','zzzz1').then(r=>r.err)"),/رمز قفل برنامه اشتباه/);
 assert.equal(await R("delPassReset('lock123','zzzz1','zzzz1').then(r=>r.ok)"),true);assert.equal(await R("delPassCheck('zzzz1').then(r=>r.ok)"),true);
});

test("۲۶) جریان کامل رابط: دسته و بازه ← پیش‌نمایش ← تعریف رمز ← رمز ← حذف (با اسنپ‌شات)",async()=>{
 sandbox();R("delOpen()");resetDelUi();
 const m=String(R("window.__modal"));
 for(const k of["لیست اشخاص","لیست اقساط","لیست چک‌ها","فاکتورها","کالاها","کلیه‌ی اطلاعات","زمان ثبت در برنامه","رمز حذف"])assert.ok(m.includes(k),"در رابط نیست: "+k);
 assert.ok(!m.includes("پیامک")&&!m.includes("کد ۶ رقمی"),"دیگر پیامک/کد در رابط نیست");
 assert.ok(m.includes('id="dlPass1"')&&m.includes('id="dlPass2"'),"اگر رمز تعریف نشده، فرم تعریف رمز");
 R("__t.length=0;delPreview()");assert.match(R("__t[__t.length-1]"),/حداقل یک دسته/);
 const cnt0=R("DB.installments.length"),target=R(`DB.installments.filter(i=>i.due==='1405/09/01').length`);assert.ok(target>0);
 el("dl_installments").checked=true;el("dlBasis").value="doc";el("dlFrom").value="1405/09/01";
 R("delPreview()");assert.match(el("dlPrev").innerHTML,/اقساط/);assert.equal(el("dlVerify").style.display,"");
 // بدون رمز تعریف‌شده حذف نمی‌شود
 await R("delRun()");assert.equal(R("DB.installments.length"),cnt0);assert.match(el("dlMsg").innerHTML,/ابتدا رمز/);
 // تعریف رمز از رابط
 el("dlPass1").value="abcd";el("dlPass2").value="zzzz";await R("delPassDefine()");assert.match(el("dlMsg").innerHTML,/یکسان نیست/);
 el("dlPass1").value="del-1234";el("dlPass2").value="del-1234";await R("delPassDefine()");assert.match(el("dlMsg").innerHTML,/رمز حذف ذخیره شد/);assert.ok(String(el("dlVerifyBody").innerHTML).includes('id="dlPass"'));
 // رمز اشتباه / خالی ← حذف نمی‌شود
 el("dlPass").value="";await R("delRun()");assert.equal(R("DB.installments.length"),cnt0);
 el("dlPass").value="wrong";await R("delRun()");assert.equal(R("DB.installments.length"),cnt0,"رمز اشتباه = بدون حذف");assert.match(el("dlMsg").innerHTML,/اشتباه/);
 // رمز درست
 el("dlPass").value="del-1234";await R("delRun()");await wait(50);
 assert.equal(R("DB.installments.length"),cnt0-target);assert.equal(R(`DB.installments.some(i=>i.due==='1405/09/01')`),false);assert.equal(R("__snapN"),1,"اسنپ‌شات قبل از حذف");
 assert.match(R("__t[__t.length-1]"),/حذف شد/);
 // پس از حذف، پنجره‌ی بعدی مستقیماً رمز می‌خواهد (رمز ذخیره مانده است)
 R("delOpen()");assert.ok(String(R("window.__modal")).includes('id="dlPass"')&&!String(R("window.__modal")).includes('id="dlPass1"'));
});

test("۲۷) حذف کلیه‌ی اطلاعات فقط با رمز؛ بازنشانی کامل ولی رمز حذف و قفل برنامه می‌مانند",async()=>{
 sandbox();R("delOpen()");resetDelUi();
 await R("delPassSet('wipe-pass','wipe-pass')");
 el("dl_all").checked=true;R("delUiSync()");R("delOpen()");el("dl_all").checked=true;R("delUiSync()");
 R("delPreview()");assert.match(el("dlPrev").innerHTML,/تمام اطلاعات/);
 el("dlPass").value="wrong";await R("delRun()");assert.ok(R("DB.persons.length")>0,"بدون رمز درست پاک نمی‌شود");
 el("dlPass").value="wipe-pass";await R("delRun()");await wait(80);
 for(const k of["persons","products","serials","invoices","receipts","cheques","installments","accTx"])assert.equal(R(`DB.${k}.length`),0,k);
 assert.equal(R("__snapN"),1);assert.equal(R("instGroups().length"),6,"لیست‌های اقساط پیش‌فرض برمی‌گردد");
 assert.equal(R("Object.keys(DB._ts).length"),0);
 assert.equal(R("delPassIsSet()"),true,"رمز حذف بعد از بازنشانی هم می‌ماند");assert.equal(await R("delPassCheck('wipe-pass').then(r=>r.ok)"),true);
 addPerson("شخص جدید","مشتری عادی","09120000009");newProduct({track:"qty",codeMode:"auto",markup:10,group:gid("Accessories"),brand:"X",model:"Y"});
 assert.equal(R("DB.persons.length"),1);assert.equal(R("DB.products.length"),1);
});

test("۲۸) صفحه‌ی ابزار: دکمه‌ی حذف اطلاعات جدید و بقای رندر",()=>{
 sandbox();R("vTools()");const h=el("content").innerHTML;assert.ok(h.includes("delOpen()"));assert.ok(!h.includes("wipeData()"));
 assert.doesNotThrow(()=>R("delOpen()"));
});

/* ===================== گروه‌بندی اشخاص و ورود اکسل اشخاص ===================== */
function xlsxBuf(rows,sheet){const code=`(()=>{const wb=XLSX.utils.book_new();XLSX.utils.book_append_sheet(wb,XLSX.utils.json_to_sheet(${JSON.stringify(rows)}),'${sheet||"اشخاص"}');return Array.from(new Uint8Array(XLSX.write(wb,{type:'array',bookType:'xlsx'})))})()`;return Buffer.from(J(code))}
const feed=(buf)=>{ctx.FileReader=function(){this.readAsArrayBuffer=function(){this.onload({target:{result:buf}})}}};
test("۲۹) گروه‌های استاندارد اشخاص ساخته می‌شوند و تکراری نمی‌شوند",()=>{
 sandbox();
 const before=J("DB.personGroups.map(g=>g.name)");
 R("ensurePersonGroups()");
 const names=J("DB.personGroups.map(g=>g.name)");
 for(const n of["مشتریان عادی","پرسنل فراجا","مستمری بگیران","کارمندان دانشگاه آزاد","کارمندان دانشگاه محقق اردبیلی","کارمندان صدا و سیما"])assert.ok(R(`!!pgFind(${JSON.stringify(n)})`),"گروه نیست: "+n);
 assert.ok(!names.includes("مشتریان عادی")&&names.includes("مشتری عادی"),"گروه موجود «مشتری عادی» هم‌ارز است و دوباره ساخته نمی‌شود");
 assert.equal(R("DB.personGroups.filter(g=>pgKey(g.name)===0).length"),1);
 const n1=R("DB.personGroups.length");R("ensurePersonGroups()");assert.equal(R("DB.personGroups.length"),n1,"اجرای مجدد بی‌اثر است");
 assert.equal(R("DB.personGroups.filter(g=>/فراجا|مستمری|صدا|دانشگاه/.test(g.name)).every(g=>g.supplier===false)"),true,"گروه‌های جدید فروشنده نیستند");
 assert.equal(R(`pgFind('مشتریان  عادی').id===pgFind('مشتری عادی').id`),true);
 assert.equal(R(`pgFind('کارکنان صداوسیما').id===pgFind('کارمندان صدا و سیما').id`),true,"املای «صداوسیما» هم‌ارز است");
 assert.equal(R(`pgFind('گروه ناشناخته')`),null,"نام ناشناخته پیدا نمی‌شود");
});

test("۳۰) ورود اکسل اشخاص: دکمه‌ی جدا برای هر گروه، بدون تکرار، کامل‌کردن موجودها",()=>{
 sandbox();R("ensurePersonGroups()");const p0=R("DB.persons.length");
 const g=n=>R(`pgFind(${JSON.stringify(n)}).id`);
 // پرسنل فراجا
 feed(xlsxBuf([{"نام":"احمد کریمی","موبایل":"۰۹۱۲۱۱۱۱۱۱۱","کد ملی":"۰۰۸۷۶۵۴۳۲۱","شغل":"سرباز"},{"نام":"بهرام شمس","موبایل":"09122222222"},{"نام":"","موبایل":"09120000000"}]));
 R(`xlIn({files:[{}],value:''},'persons','${g("پرسنل فراجا")}')`);
 assert.equal(R("DB.persons.length"),p0+2);
 const ahmad=J(`DB.persons.find(p=>p.name==='احمد کریمی')`);assert.equal(ahmad.group,g("پرسنل فراجا"));assert.deepEqual(ahmad.groups,[g("پرسنل فراجا")]);assert.equal(ahmad.phone,"09121111111");assert.equal(ahmad.nationalId,"0087654321");
 assert.match(R("__t[__t.length-1]"),/۲ رکورد/);assert.match(R("__t[__t.length-1]"),/پرسنل فراجا/);assert.match(R("__t[__t.length-1]"),/رد شد/);
 // مستمری بگیران: یک جدید + یک تکرارِ فراجا (کد ملی یکسان) ← عضو گروه دوم هم می‌شود
 feed(xlsxBuf([{"نام":"احمد کریمی (نام متفاوت)","کد ملی":"0087654321","آدرس":"اردبیل"},{"نام":"سیمین نوری","کد ملی":"0099999999"}]));
 R(`xlIn({files:[{}],value:''},'persons','${g("مستمری بگیران")}')`);
 assert.equal(R("DB.persons.length"),p0+3,"شخص تکراری ساخته نمی‌شود");
 const a2=J(`DB.persons.find(p=>p.nationalId==='0087654321')`);assert.deepEqual(a2.groups.sort(),[g("پرسنل فراجا"),g("مستمری بگیران")].sort());assert.equal(a2.addr,"اردبیل","فیلد خالی کامل می‌شود");assert.equal(a2.job,"سرباز","فیلد پر بازنویسی نمی‌شود");
 assert.match(R("__t[__t.length-1]"),/موجود/);
 // ورود مجدد همان فایل: چیزی اضافه نمی‌شود
 feed(xlsxBuf([{"نام":"سیمین نوری","کد ملی":"0099999999"}]));R(`xlIn({files:[{}],value:''},'persons','${g("مستمری بگیران")}')`);assert.equal(R("DB.persons.length"),p0+3);
 // شخص ساخته‌شده در گروه پیش‌فرض (مثلاً از ورود اقساط) با ورود به گروه دانشگاه منتقل می‌شود
 R(`DB.persons.push({id:'PDEF',code:7777,name:'کارمند دانشگاه',group:pgFind('مشتریان عادی').id,groups:[pgFind('مشتریان عادی').id],phone:'',nationalId:''})`);
 feed(xlsxBuf([{"نام":"کارمند دانشگاه","موبایل":"09130000000"}]));R(`xlIn({files:[{}],value:''},'persons','${g("کارمندان دانشگاه آزاد")}')`);
 const kd=J(`DB.persons.find(p=>p.id==='PDEF')`);assert.deepEqual(kd.groups,[g("کارمندان دانشگاه آزاد")]);assert.equal(kd.group,g("کارمندان دانشگاه آزاد"));assert.equal(kd.phone,"09130000000");
 // شخصی که در گروه دیگری هم هست جابه‌جا نمی‌شود، فقط عضو می‌شود
 feed(xlsxBuf([{"نام":"احمد کریمی","کد ملی":"0087654321"}]));R(`xlIn({files:[{}],value:''},'persons','${g("کارمندان صدا و سیما")}')`);
 assert.equal(J(`DB.persons.find(p=>p.nationalId==='0087654321')`).groups.length,3);
});

test("۳۱) ورود عمومی با ستون «گروه»: چند گروه، گروه ناموجود ساخته می‌شود",()=>{
 sandbox();R("ensurePersonGroups()");const gc=R("DB.personGroups.length");
 feed(xlsxBuf([{"نام":"الف","گروه":"پرسنل فراجا"},{"نام":"ب","گروه":"کارمندان دانشگاه آزاد، پرسنل فراجا"},{"نام":"پ","گروه":"گروه جدید تست"},{"نام":"ت"},{"نام":"ث","گروه":"کارکنان صداوسیما"}]));
 R(`xlIn({files:[{}],value:''},'persons')`);
 const by=n=>J(`(()=>{const p=DB.persons.find(x=>x.name==='${n}');return p.groups.map(id=>DB.personGroups.find(g=>g.id===id).name)})()`);
 assert.deepEqual(by("الف"),["پرسنل فراجا"]);
 assert.deepEqual(by("ب").sort(),["پرسنل فراجا","کارمندان دانشگاه آزاد"].sort());assert.equal(R(`DB.persons.find(p=>p.name==='ب').group===pgFind('کارمندان دانشگاه آزاد').id`),true,"گروه اصلی = اولین گروه");
 assert.deepEqual(by("پ"),["گروه جدید تست"]);assert.equal(R("DB.personGroups.length"),gc+1,"فقط «گروه جدید تست» ساخته شد");assert.deepEqual(by("ث"),["کارمندان صدا و سیما"],"املای دیگر به گروه استاندارد نگاشت می‌شود");
 assert.deepEqual(by("ت"),["مشتری عادی"],"بدون ستون گروه ← مشتریان عادی");
 assert.match(R("__t[__t.length-1]"),/گروه جدید/);
});

test("۳۲) ورود اقساط: شخص جدید در گروه متناظر لیست اقساط ساخته می‌شود؛ رابط و قالب",()=>{
 sandbox();
 feed(xlsxBuf([{"طرف حساب":"مستمری‌بگیر تست","مبلغ":"5,000,000","سررسید":"1405/08/01"}],"اقساط"));
 R(`xlIn({files:[{}],value:''},'installments','ig-refah')`);
 assert.equal(R(`pgKey(DB.personGroups.find(g=>g.id===DB.persons.find(p=>p.name==='مستمری‌بگیر تست').group).name)`),2);
 feed(xlsxBuf([{"طرف حساب":"فراجایی تست","مبلغ":"1,000,000","سررسید":"1405/08/01"}],"اقساط"));R(`xlIn({files:[{}],value:''},'installments','ig-faraja')`);
 assert.equal(R(`DB.personGroups.find(g=>g.id===DB.persons.find(p=>p.name==='فراجایی تست').group).name`),"پرسنل فراجا");
 feed(xlsxBuf([{"طرف حساب":"عادی تست","مبلغ":"1,000,000","سررسید":"1405/08/01"}],"اقساط"));R(`xlIn({files:[{}],value:''},'installments','ig-normal')`);
 assert.equal(R(`pgKey(DB.personGroups.find(g=>g.id===DB.persons.find(p=>p.name==='عادی تست').group).name)`),0);
 // رابط صفحه‌ی اشخاص: دکمه‌ی جدا برای هر گروه و قالب
 R("vPersons()");const h=el("content").innerHTML;
 for(const n of["پرسنل فراجا","مستمری بگیران","کارمندان دانشگاه آزاد","کارمندان دانشگاه محقق اردبیلی","کارمندان صدا و سیما"])assert.ok(h.includes(n),"دکمه‌ی گروه "+n);
 assert.equal((h.match(/xlIn\(this,'persons','/g)||[]).length,R("DB.personGroups.length"));
 assert.ok(h.includes("xlPersonsTemplate()"));
 assert.doesNotThrow(()=>R("xlPersonsTemplate"));
});

/* ===================== انتخاب و وصول گروهی اقساط ===================== */
test("۳۳) انتخاب گروهی اقساط: تیک ردیف، بازه با Shift، صفحه، همه‌ی نتایج، حفظ انتخاب بین صفحه‌ها",()=>{
 sandbox();
 R(`INSTSEL.clear();DB.installments=[];DB.receipts=[];DB.accTx=[];DB.cheques=[];DB.invoices=[];DB.persons=[];
  const g=DB.personGroups[0];['A','B','C'].forEach((n,k)=>DB.persons.push({id:'q'+n,code:100+k,name:'شخص '+n,group:g.id,groups:[g.id],phone:'0912000000'+k,baleId:n==='A'?'777':'',nationalId:''}));
  let c=0;[['qA',6],['qB',5],['qC',4]].forEach(([p,n])=>{for(let k=1;k<=n;k++){c++;DB.installments.push({id:'bi'+c,planId:'pl'+p,inv:'',person:p,no:k,amount:1000000*k,due:'1405/0'+(1+(c%8))+'/1'+(c%9),paid:c===3||c===8,paidDate:c===3||c===8?'1405/06/01':'',grp:c%2?'ig-normal':'ig-faraja'})}})`);
 assert.equal(R("DB.installments.length"),15);assert.equal(R("DB.installments.filter(i=>!i.paid).length"),13);
 R("Fi.grp='';Fi.mode='';Fi.q='';Fi.plan='';PGS.instlist=undefined;vInst('list')");
 let h=el("content").innerHTML;
 assert.equal((h.match(/instSelToggle\(/g)||[]).length,13,"فقط ردیف‌های باز تیک دارند");assert.ok(h.includes('id="instSelHead"')&&h.includes('id="instSelBar"'));
 assert.ok(h.includes("وصول گروهی")&&h.includes("همه‌ی نتایج باز (۱۳)"));
 // تیک تکی
 R("instSelToggle('bi1',true,{})");assert.equal(R("INSTSEL.size"),1);assert.match(el("instSelBar").innerHTML,/انتخاب‌شده/);assert.match(el("instSelBar").innerHTML,/۱٬۰۰۰٬۰۰۰/);
 R("instSelToggle('bi1',false,{})");assert.equal(R("INSTSEL.size"),0);
 // بازه با Shift (فقط ردیف‌های باز صفحه)
 const ids=J("_instPageIds");assert.equal(ids.length,13);
 R(`instSelToggle('${ids[2]}',true,{});instSelToggle('${ids[6]}',true,{shiftKey:true})`);
 assert.deepEqual(J("[...INSTSEL].sort()"),ids.slice(2,7).sort(),"بازه‌ی ۵ تایی");
 R("instSelClear()");assert.equal(R("INSTSEL.size"),0);
 // انتخاب صفحه
 R("instSelPage(true)");assert.equal(R("INSTSEL.size"),13);assert.ok(/ checked /.test(el("content").innerHTML.match(/id="instSelHead"[^>]*>/)[0]),"تیک سرستون وقتی همه‌ی ردیف‌های صفحه انتخاب است");
 R("instSelPage(false)");assert.equal(R("INSTSEL.size"),0);
 // انتخاب همه‌ی نتایج با فیلتر لیست
 R("Fi.grp='ig-faraja';vInst('list');instSelAll()");
 assert.equal(R("INSTSEL.size"),R("DB.installments.filter(i=>!i.paid&&i.grp==='ig-faraja').length"),"فقط لیست انتخاب‌شده");
 assert.equal(R("[...INSTSEL].every(id=>!DB.installments.find(i=>i.id===id).paid)"),true,"پرداخت‌شده‌ها انتخاب نمی‌شوند");
 // انتخاب با تغییر فیلتر حفظ می‌شود
 const n1=R("INSTSEL.size");R("Fi.grp='';vInst('list')");assert.equal(R("INSTSEL.size"),n1);
 R("instSelClear()");
 // حفظ انتخاب بین صفحه‌ها
 R("pgPer('instlist','10');");R("instSelPage(true)");const onP1=R("INSTSEL.size");assert.equal(onP1,R("_instPageIds.length"));assert.ok(onP1>=7&&onP1<=10);
 R("pgGo('instlist',1)");assert.equal(R("INSTSEL.size"),onP1,"رفتن به صفحه‌ی بعد انتخاب را نگه می‌دارد");
 assert.ok(!/ checked /.test(el("content").innerHTML.match(/id="instSelHead"[^>]*>/)[0]),"چک‌باکس سرستون فقط وضعیت همین صفحه را نشان می‌دهد");
 R("pgPer('instlist','100');instSelClear()");
});

test("۳۴) وصول گروهی: نقدی، با حساب بانکی، رسید و ورودی بانک، پیام تشکر جمع‌شده، اسنپ‌شات",async()=>{
 R("globalThis.__sms=[];sendSMSRaw=(to,m)=>{__sms.push([to,m])};DB.settings.baleToken='BT';DB.settings.rubikaToken='';DB.settings.allMsgOn=true;DB.settings.thanksOn=true;globalThis.__snapN=0;snapshot=async()=>{__snapN++}");
 R("INSTSEL.clear();Fi.grp='';Fi.q='';Fi.mode='';vInst('list')");
 const unpaidA=J("DB.installments.filter(i=>i.person==='qA'&&!i.paid).map(i=>i.id)"),unpaidB=J("DB.installments.filter(i=>i.person==='qB'&&!i.paid).map(i=>i.id)");
 // انتخاب: ۳ قسط از A، ۲ از B، به‌علاوه یک قسط پرداخت‌شده (باید نادیده گرفته شود)
 const sel=[...unpaidA.slice(0,3),...unpaidB.slice(0,2)];
 R(`INSTSEL.clear();${JSON.stringify(sel)}.forEach(id=>INSTSEL.add(id));INSTSEL.add('bi3')`);
 const info=J("instSelInfo()");assert.equal(info.n,5);assert.equal(info.p,2);
 const expSum=sum(J(`${JSON.stringify(sel)}.map(id=>DB.installments.find(i=>i.id===id).amount)`));assert.equal(info.sum,expSum);
 R("instBulkOpen()");const m=String(R("window.__modal"));assert.ok(m.includes("ثبت وصول گروهی")&&m.includes("۵")&&m.includes("bkAcc")&&m.includes("bkThanks"));
 // اعتبارسنجی: تاریخ نامعتبر / حساب خالی
 el("bkDate").value="1405/15/45";el("bkM").value="cash";el("bkAcc").value="";el("bkThanks").checked=true;
 await R("instBulkRun()");assert.match(R("__t[__t.length-1]"),/تاریخ نامعتبر/);assert.equal(R("DB.installments.filter(i=>i.paid).length"),2);
 el("bkDate").value="1405/07/25";el("bkM").value="account";el("bkAcc").value="";await R("instBulkRun()");assert.match(R("__t[__t.length-1]"),/حساب بانکی/);assert.equal(R("DB.receipts.length"),0);
 // اجرا با حساب بانکی
 el("bkM").value="account";el("bkAcc").value=ACC;calls.length=0;R("__sms.length=0");
 const accBefore=R(`accBal(DB.accounts.find(a=>a.id==='${ACC}'))`);
 await R("instBulkRun()");await wait(1500);
 for(const id of sel){const i=J(`DB.installments.find(x=>x.id==='${id}')`);assert.equal(i.paid,true);assert.equal(i.paidDate,"1405/07/25");assert.equal(i.paidMethod,"account");assert.equal(i.amountPaid,i.amount)}
 assert.equal(R("DB.receipts.length"),5);assert.equal(R("DB.receipts.every(r=>r.instId&&r.rows[0].method==='account'&&r.date==='1405/07/25')"),true);
 assert.equal(R("DB.accTx.length"),5);assert.equal(R("DB.accTx.every(t=>t.type==='in'&&DB.receipts.some(r=>r.id===t.ref))"),true);
 assert.equal(R(`accBal(DB.accounts.find(a=>a.id==='${ACC}'))`),accBefore+expSum);
 assert.equal(R("INSTSEL.size"),0,"انتخاب پس از ثبت پاک می‌شود");assert.equal(R("__snapN"),1,"اسنپ‌شات قبل از ثبت");
 assert.equal(R("DB.installments.find(i=>i.id==='bi3').receipts"),undefined);assert.equal(R("DB.receipts.some(r=>r.instId==='bi3')"),false,"قسط از قبل پرداخت‌شده دوباره ثبت نمی‌شود");
 // پیام تشکر: A (دارای بله) یک پیام جمع‌شده؛ B فقط پیامک (بدون شناسه بله) — هر شخص یک پیام
 assert.equal(calls.filter(x=>/bale/.test(x.u)&&/sendMessage$/.test(x.u)).length,1,"یک پیام جمع‌شده‌ی بله برای شخص A");
 assert.equal(R("__sms.length"),2,"برای هر شخص یک پیامک (A و B)");
 assert.match(R("__sms.map(x=>x[1]).join('|')"),/شخص A/);
 // دومین دور: نقدی بدون تیک پیام تشکر
 R(`INSTSEL.clear();${JSON.stringify(unpaidA.slice(3))}.forEach(id=>INSTSEL.add(id))`);
 const rest=unpaidA.length-3;R("instBulkOpen()");el("bkDate").value="1405/07/26";el("bkM").value="cash";el("bkThanks").checked=false;calls.length=0;R("__sms.length=0");
 const tx0=R("DB.accTx.length");await R("instBulkRun()");await wait(500);
 assert.equal(R("DB.receipts.length"),5+rest);assert.equal(R("DB.accTx.length"),tx0,"نقدی ورودی بانک نمی‌سازد");
 assert.equal(calls.length,0);assert.equal(R("__sms.length"),0,"بدون تیک تشکر پیامی نمی‌رود");
 // قسط حذف‌شده‌ی انتخاب‌شده نادیده گرفته می‌شود
 R("INSTSEL.add('zzz-missing')");assert.equal(R("instSelInfo().n"),0);
 // دفتر و تراکنش‌ها سالم
 assert.equal(R("jnlBuild().every(e=>e.rows.reduce((s,r)=>s+r.d-r.c,0)===0)"),true);
 assert.match(R("vInst('list'),el=0,'ok'"),/ok/);
});

test("۳۵) وصول گروهی اقساط سررسیدشده‌ی پرسنل فراجا: انتخاب یک‌کلیکی و تا تاریخ دلخواه",async()=>{
 sandbox();
 R(`INSTSEL.clear();DB.installments=[];DB.receipts=[];DB.accTx=[];DB.persons=[];window._sdG=undefined;window._sdD=undefined;{
  const g=DB.personGroups[0];['F1','F2','N1'].forEach((n,k)=>DB.persons.push({id:'f'+n,code:300+k,name:'شخص '+n,group:g.id,groups:[g.id],phone:'0912111111'+k,nationalId:''}));
  const today=jToday(),past=m=>jAddM(today,-m),fut=m=>jAddM(today,m);
  const add=(id,p,grp,due,paid)=>DB.installments.push({id,planId:'pl'+p,inv:'',person:p,no:1,amount:1000000,due,paid:!!paid,paidDate:paid?past(3):'',grp});
  add('a1','fF1','ig-faraja',past(2));add('a2','fF1','ig-faraja',past(1));add('a3','fF2','ig-faraja',today);       /* سررسیدشده */
  add('a4','fF2','ig-faraja',fut(1));add('a5','fF1','ig-faraja',past(4),true);                                     /* آینده / پرداخت‌شده */
  add('b1','fN1','ig-normal',past(2));add('b2','fN1','ig-refah',past(3));                                           /* لیست‌های دیگر */
 }`);
 // یک‌کلیکی: فراجا، سررسیدشده تا امروز
 assert.equal(R("instSelDueFor('ig-faraja')"),3);
 assert.deepEqual(J("[...INSTSEL].sort()"),["a1","a2","a3"]);
 assert.equal(R("Fi.grp"),"ig-faraja");assert.equal(R("Fi.mode"),"due","فیلتر لیست روی سررسیدشده تنظیم می‌شود");
 assert.equal(R("window._instList.length"),3);
 let h=el("content").innerHTML;assert.ok(h.includes("پرسنل فراجا: سررسیدشده‌ها")&&h.includes('id="sdG"')&&h.includes('id="sdD"'));
 assert.match(el("instSelBar").innerHTML||h,/انتخاب‌شده/);
 // انتخاب جایگزین انتخاب قبلی می‌شود (لیست‌ها قاطی نمی‌شوند)
 R("INSTSEL.add('b1')");R("instSelDueFor('ig-faraja')");assert.equal(R("INSTSEL.has('b1')"),false);
 // با تاریخ دلخواه و همه‌ی لیست‌ها
 assert.equal(R("instSelDueFor('',jAddM(jToday(),-2))"),3,"a1(−۲)، b1(−۲)، b2(−۳) تا دو ماه قبل");
 assert.deepEqual(J("[...INSTSEL].sort()"),["a1","b1","b2"]);assert.equal(R("Fi.mode"),"open");
 // از رابط: لیست و تاریخ از فیلدها خوانده می‌شود
 el("sdG").value="ig-faraja";el("sdD").value=R("jAddM(jToday(),-1)");R("instSelDue()");assert.deepEqual(J("[...INSTSEL].sort()"),["a1","a2"]);
 assert.match(R("(instSelDueFor('ig-faraja','1405/13/40'),__t[__t.length-1])"),/نامعتبر/);assert.equal(R("INSTSEL.size"),2,"تاریخ نامعتبر انتخاب را عوض نمی‌کند");
 // لیست بدون مورد
 assert.equal(R("instSelDueFor('ig-seda')"),0);assert.match(R("__t[__t.length-1]"),/پیدا نشد/);
 // وصول: فقط فراجای سررسیدشده
 R("instSelDueFor('ig-faraja')");R("instBulkOpen()");el("bkDate").value=R("jToday()");el("bkM").value="cash";el("bkThanks").checked=false;
 await R("instBulkRun()");
 assert.deepEqual(J("DB.installments.filter(i=>i.paid).map(i=>i.id).sort()"),["a1","a2","a3","a5"]);
 assert.equal(R("DB.installments.find(i=>i.id==='a4').paid"),false,"قسط آینده وصول نشد");assert.equal(R("DB.installments.find(i=>i.id==='b1').paid"),false,"لیست دیگر وصول نشد");
 assert.equal(R("DB.receipts.length"),3);assert.equal(R("INSTSEL.size"),0);
 // دوباره: چیزی برای انتخاب نمانده
 assert.equal(R("instSelDueFor('ig-faraja')"),0);
});

/* ===================== ویرایش/حذف گزینه‌ها و کالا، نقطه‌ی سفارش، رنگ فاکتور خرید ===================== */
test("۳۶) نقطه‌ی سفارش پیش‌فرض صفر؛ ویرایش و حذف گزینه‌های مشخصات (برند، مدل، حافظه، گروه، رنگ، وضعیت)",()=>{
 sandbox();const GM=gid("Mobile");
 assert.equal(R("pwDefault().reorder"),0);assert.equal(R("pwDefault().minStock"),0);
 R("confirmM=(m,cb)=>cb()");
 R(`DB.products=[];DB.serials=[];DB.invoices=[];PW=pwDefault();productWizard=productWizard;`);
 newProduct({track:"qty",codeMode:"auto",markup:10,group:GM,brand:"Samsung",model:"A55",memory:"128 GB",ram:"8 GB"});
 newProduct({track:"qty",codeMode:"auto",markup:10,group:GM,brand:"Samsung",model:"A35",memory:"128 GB",ram:"6 GB"});
 R("PW=pwDefault()");
 // ویرایش برند: فهرست + کالاها + مدل‌ها
 R("PW.brand='Samsung';PW.model='A55'");
 R("pwOptEdit('brand')");el("optIn").value="سامسونگ";R("optOk()");
 assert.equal(R("PW.brand"),"سامسونگ");assert.ok(R("DB.productOptions.brands.includes('سامسونگ')")&&!R("DB.productOptions.brands.includes('Samsung')"));
 assert.equal(R("DB.products.filter(p=>p.brand==='سامسونگ').length"),2);assert.match(R("__t[__t.length-1]"),/۲ کالا به‌روز شد/);
 // برند تکراری رد می‌شود
 R("pwOptEdit('brand')");el("optIn").value="Apple";R("optOk()");assert.match(R("__t[__t.length-1]"),/قبلاً هست/);assert.equal(R("PW.brand"),"سامسونگ");
 // ویرایش مدل
 R("PW.model='A55'");R("pwOptEdit('model')");el("optIn").value="A55 5G";R("optOk()");
 assert.equal(R("PW.model"),"A55 5G");assert.equal(R("DB.products.filter(p=>p.model==='A55 5G').length"),1);assert.equal(R("DB.products.filter(p=>p.model==='A35').length"),1);
 // ویرایش حافظه
 R("PW.memory='128 GB'");R("pwOptEdit('memory')");el("optIn").value="128GB";R("optOk()");assert.equal(R("DB.products.filter(p=>p.memory==='128GB').length"),2);
 // حذف گزینه از فهرست (کالاهای دارای آن مقدار دست‌نخورده)
 R("PW.ram='8 GB'");assert.ok(R("DB.productOptions.rams.includes('8 GB')"));R("pwOptDel('ram')");
 assert.ok(!R("DB.productOptions.rams.includes('8 GB')"));assert.equal(R("PW.ram"),"");assert.equal(R("DB.products.filter(p=>p.ram==='8 GB').length"),1,"کالا مقدار خود را نگه می‌دارد");
 // حذف مدل از فهرست
 R("PW.model='A35'");R("pwOptDel('model')");assert.ok(!R("modelsOfBrand('سامسونگ').includes('A35')"));assert.equal(R("PW.model"),"");
 // حذف برند
 R("PW.brand='سامسونگ'");R("pwOptDel('brand')");assert.ok(!R("DB.productOptions.brands.includes('سامسونگ')"));assert.equal(R("PW.brand"),"");
 // گروه کالا: ویرایش نام؛ حذف گروه دارای کالا مسدود، گروه خالی حذف می‌شود
 R("PW.group='"+GM+"'");R("pwOptEdit('group')");el("optIn").value="گوشی موبایل";R("optOk()");assert.equal(R("DB.productGroups.find(g=>g.id==='"+GM+"').name"),"گوشی موبایل");
 R("pwOptDel('group')");assert.match(R("__t[__t.length-1]"),/استفاده شده/);assert.ok(R("DB.productGroups.some(g=>g.id==='"+GM+"')"));
 const gcnt=R("DB.productGroups.length");R("DB.productGroups.push({id:'gx',name:'گروه خالی'});PW.group='gx'");R("pwOptDel('group')");assert.equal(R("DB.productGroups.length"),gcnt);
 // رنگ: ویرایش نام/رنگ نمایشی؛ حذف رنگ استفاده‌شده مسدود
 const cid=R("DB.colors[0].id");R(`PW.color='${cid}'`);R("pwOptEdit('color')");el("optIn").value="زرشکی";el("optHex").value="#aa0000";R("optOk()");
 assert.equal(R(`colorEnOf(DB.colors.find(c=>c.id==='${cid}'))`),"زرشکی");assert.equal(R(`DB.colors.find(c=>c.id==='${cid}').hex`),"#aa0000");
 R(`DB.products[0].colors=['${cid}']`);R("pwOptDel('color')");assert.match(R("__t[__t.length-1]"),/استفاده شده/);assert.ok(R(`DB.colors.some(c=>c.id==='${cid}')`));
 // گزینه‌های لپ‌تاپ: وضعیت
 R("PW.cond='استوک'");R("pwOptEdit('cond')");el("optIn").value="دست‌دوم";R("optOk()");assert.deepEqual(J("lapOpts('laptopConds')"),["نو","دست‌دوم"]);
 // بدون انتخاب چیزی نمی‌کند
 const b0=R("DB.productOptions.brands.length");R("PW.brand='';pwOptDel('brand');pwOptEdit('brand')");assert.equal(R("DB.productOptions.brands.length"),b0);
});

test("۳۷) ویرایش کامل مشخصات کالا و حذف کالا (در همان تب)",()=>{
 sandbox();R("confirmM=(m,cb)=>cb();openPages=['dash'];");
 R(`DB.products=[];DB.serials=[];DB.invoices=[];DB.settings.allowNegative=true;PW=null`);
 newProduct({track:"qty",codeMode:"auto",markup:10,group:gid("Mobile"),brand:"Xiaomi",model:"Note 13",memory:"256 GB",ram:"8 GB",lastCost:5000000,sellPrice:5500000});
 newProduct({track:"qty",codeMode:"auto",markup:10,group:gid("Mobile"),brand:"Xiaomi",model:"Note 12",memory:"128 GB",ram:"4 GB"});
 const p1=J("DB.products[0]"),p2=J("DB.products[1]");
 R(`productEdit('${p1.id}')`);assert.equal(R("PW.editPid"),p1.id);assert.equal(R("curView"),"newProduct");assert.equal(R("pageTitles.newProduct"),"ویرایش کالا");
 assert.equal(R("PW.model"),"Note 13");assert.equal(R("PW.code"),p1.code);assert.equal(R("PW.lastCost"),5000000);assert.equal(R("PW.codeMode"),"manual");
 // تغییر مشخصات
 R("Object.assign(PW,{model:'Note 13 Pro',memory:'512 GB',ram:'12 GB',sellPrice:5900000,minStock:2,reorder:3,notes:'یادداشت'})");
 R("pwUpdate()");
 let p=J(`DB.products.find(x=>x.id==='${p1.id}')`);
 assert.equal(p.model,"Note 13 Pro");assert.equal(p.memory,"512 GB");assert.equal(p.sellPrice,5900000);assert.equal(p.minStock,2);assert.equal(p.reorder,3);assert.equal(p.notes,"یادداشت");assert.match(p.name,/note 13 pro/i);assert.match(p.name,/512/);
 assert.equal(p.id,p1.id);assert.equal(p.code,p1.code,"کد ثابت می‌ماند");assert.equal(R("PW"),null);assert.equal(R("curView"),"products");assert.equal(R("pageTitles.newProduct"),"معرفی کالای جدید");assert.ok(!R("openPages.includes('newProduct')"));
 assert.match(R("__t[__t.length-1]"),/ذخیره شد/);
 // اعتبارسنجی: کد تکراری، نام تکراری، سقف سود
 R(`productEdit('${p1.id}')`);R(`PW.code='${p2.code}'`);R("__t.length=0;pwUpdate()");assert.match(R("__t[__t.length-1]"),/کد کالا قبلاً/);
 R(`PW.code='${p1.code}';PW.model='Note 12';PW.memory='128 GB';PW.ram='4 GB'`);R("__t.length=0;pwUpdate()");assert.match(R("__t[__t.length-1]"),/همین نام/);
 R("PW.renameAuto=false");R("__t.length=0;pwUpdate()");assert.match(R("__t[__t.length-1]"),/ذخیره شد/,"با خاموش کردن بازسازی‌ی نام، نام قبلی می‌ماند");
 assert.equal(R(`DB.products.find(x=>x.id==='${p1.id}').name`),p.name);
 R(`productEdit('${p1.id}')`);R("PW.lastCost=1000000;PW.sellPrice=99000000");R("__t.length=0;pwUpdate()");assert.match(R("__t[__t.length-1]"),/سود هر عدد/);
 R("pwCancel()");assert.equal(R("PW"),null);
 // کالای دارای سابقه: نوع پیگیری قابل تغییر نیست
 R(`DB.invoices.push({id:'iv1',type:'buy',no:1,date:'1405/07/01',person:'x',lines:[{pid:'${p1.id}',sid:'',sn:'',color:'',qty:1,price:1,cost:1}],pays:[]})`);
 R(`productEdit('${p1.id}')`);R("PW.track='serial'");R("__t.length=0;pwUpdate()");assert.match(R("__t[__t.length-1]"),/قابل تغییر نیست/);
 // رنگ: تغییر رنگ کالای تک‌رنگ، سریال‌ها را هم به‌روز می‌کند
 const c1=R("DB.colors[0].id"),c2=R("DB.colors[1].id");
 R(`DB.products.find(x=>x.id==='${p2.id}').colors=['${c1}'];DB.serials.push({id:'sr1',pid:'${p2.id}',sn:'S1',status:'stock',color:'${c1}'})`);
 R(`productEdit('${p2.id}')`);assert.equal(R("PW.color"),c1);R(`PW.color='${c2}'`);R("pwUpdate()");
 assert.deepEqual(J(`DB.products.find(x=>x.id==='${p2.id}').colors`),[c2]);assert.equal(R("DB.serials.find(s=>s.id==='sr1').color"),c2);
 // حذف از صفحه‌ی ویرایش: کالای دارای فاکتور مسدود؛ کالای بدون سابقه حذف و تب بسته
 R(`productEdit('${p1.id}')`);R("pwDelProduct()");assert.ok(R(`DB.products.some(x=>x.id==='${p1.id}')`));
 R("pwCancel()");
 R(`DB.invoices=[];DB.serials=[]`);R(`productEdit('${p2.id}')`);R("pwDelProduct()");
 return Promise.resolve().then(()=>new Promise(r=>setTimeout(r,60))).then(()=>{assert.ok(!R(`DB.products.some(x=>x.id==='${p2.id}')`),"حذف شد");assert.equal(R("PW"),null);assert.ok(!R("openPages.includes('newProduct')"))});
});

test("۳۸) فاکتور خرید: رنگ همان رنگ ثبت‌شده در معرفی کالا و قابل انتخاب نیست",()=>{
 sandbox();R("window._invKind='buy'");
 const c1=R("DB.colors[0].id"),c2=R("DB.colors[1].id"),c3=R("DB.colors[2].id");
 R(`DB.products=[{id:'pa',code:'P-1',name:'one color',brand:'B',model:'M',track:'serial',group:DB.productGroups[0].id,lastCost:1e6,sellPrice:1.2e6,colors:['${c1}']},{id:'pb',code:'P-2',name:'two colors',brand:'B',model:'N',track:'serial',group:DB.productGroups[0].id,lastCost:1e6,sellPrice:1.2e6,colors:['${c2}','${c3}']},{id:'pc',code:'P-3',name:'no color',brand:'B',model:'O',track:'qty',group:DB.productGroups[0].id,lastCost:1,sellPrice:2,colors:[]}]`);
 R("window.L=[{pid:'',sid:'',sn:'',color:'',qty:1,price:0,cost:0,sellAtBuy:0}];rowAddRenderAll=()=>{};recalc=()=>{}");
 // انتخاب کالا ← رنگ از خودِ کالا
 R("rowProdChange({value:'pa'},0)");assert.equal(R("window.L[0].color"),c1);
 let cell=R("rowColorCell(0,window.L[0])");assert.ok(!cell.includes("<select"),"انتخابی نیست");assert.ok(cell.includes('id="rcw_0"'));assert.ok(cell.includes(R(`esc(CL('${c1}'))`)));
 // رنگ دستی هم نادیده گرفته می‌شود (حتی اگر داده‌ی قدیمی چیز دیگری باشد)
 R(`window.L[0].color='${c3}'`);cell=R("rowColorCell(0,window.L[0])");assert.equal(R("window.L[0].color"),c1,"به رنگ ثبت‌شده برمی‌گردد");
 // کالای چندرنگ: فقط رنگ‌های همان کالا قابل انتخاب
 R("rowProdChange({value:'pb'},0)");assert.equal(R("window.L[0].color"),c2);
 cell=R("rowColorCell(0,window.L[0])");assert.ok(cell.includes("<select"));assert.equal((cell.match(/<option/g)||[]).length,2);assert.ok(cell.includes(`value="${c2}"`)&&cell.includes(`value="${c3}"`)&&!cell.includes(`value="${c1}"`));
 // بدون رنگ ثبت‌شده
 R("rowProdChange({value:'pc'},0)");assert.equal(R("window.L[0].color"),"");assert.ok(!R("rowColorCell(0,window.L[0])").includes("<select"));
 // فاکتور فروش: رنگ مثل قبل از سریال
 R("window._invKind='sale';rowProdChange({value:'pa'},0)");assert.equal(R("window.L[0].color"),"");
 // ذخیره‌ی فاکتور خرید: رنگ خط در فاکتور = رنگ کالا
 R("window._invKind='buy'");
 R(`doSaveInvoice({id:'',kind:'buy',date:'1405/07/01',person:'${personId("شرکت پخش تهران")||"x"}',group:'',disc:0,desc:'',pays:[],plan:null,checkPlan:null,lines:[{pid:'pa',sid:'',sn:'COLOR-1',color:'${c1}',qty:1,price:1000000,cost:1000000,sellAtBuy:1200000}]})`);
 assert.equal(R("DB.serials.find(s=>s.sn==='COLOR-1').color"),c1);
});
