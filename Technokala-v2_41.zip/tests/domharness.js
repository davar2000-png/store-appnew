// بارگذاری برنامه داخل jsdom برای تست‌های سطح DOM (اختیاری: اگر jsdom نصب نباشد تست‌ها رد می‌شوند). نصب: npm i jsdom
const fs=require("fs"),path=require("path");
let JSDOM=null;
for(const p of ["jsdom",path.join(__dirname,"../node_modules/jsdom"),"/tmp/jsd/node_modules/jsdom"]){try{JSDOM=require(p).JSDOM;break}catch(e){}}
module.exports.available=!!JSDOM;
module.exports.load=async function(opts){
 opts=opts||{};
 let html=fs.readFileSync(path.join(__dirname,"../dist/app.html"),"utf8").replace(/<script src="assets\/libs\/[^"]+"><\/script>/g,"");
 const xlsx=fs.readFileSync(path.join(__dirname,"../desktop/app/assets/libs/xlsx.full.min.js"),"utf8");
 const dom=new JSDOM(html,{runScripts:"dangerously",pretendToBeVisual:true,url:"http://localhost/app.html",beforeParse(w){
  w.eval(xlsx);
  w.Chart=Object.assign(function(){this.destroy=()=>{};this.update=()=>{}},{defaults:{font:{},plugins:{},color:""}});
  w.scrollTo=()=>{};w.HTMLElement.prototype.scrollIntoView=function(){};
  if(opts.indexedDB)w.indexedDB=opts.indexedDB;
  w.alert=()=>{};w.confirm=()=>true;w.prompt=()=>"";w.print=()=>{};
  w.MutationObserver=w.MutationObserver||function(){this.observe=()=>{}};
 }});
 const w=dom.window;
 await new Promise(r=>setTimeout(r,350));
 const R=c=>w.eval(c);
 R("DB=seedDB();var __t=[];toast=function(m){__t.push(String(m))};localStorage.setItem('tk_seed_inst_v1','1');"+(opts.keepSave?"":"saveDB=async()=>true;snapshot=async()=>{};"));
 return{dom,w,doc:w.document,R,J:c=>JSON.parse(w.eval("JSON.stringify("+c+")")),wait:ms=>new Promise(r=>setTimeout(r,ms))};
};

module.exports.dom=async function(fn,opts){const A=await module.exports.load(opts);try{await fn(A)}finally{try{A.w.close()}catch(e){}}};
