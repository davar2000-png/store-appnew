// تست کارایی و تصاویر: حجم بالا (هزاران شخص/قسط)، صفحه‌بندی، معادل‌بودن نمایه‌ها با محاسبه‌ی مستقیم، تصاویر تنبل و بکاپ کامل
const test=require("node:test"),assert=require("node:assert"),fs=require("fs"),vm=require("vm"),path=require("path");
const html=fs.readFileSync(path.join(__dirname,"../dist/app.html"),"utf8");
const m=html.match(/<script>([\s\S]*)<\/script>\s*<\/body>/);
const mk=()=>new Proxy(function(){},{get:(t,k)=>k===Symbol.iterator?function*(){}:k===Symbol.toPrimitive?()=>"":mk(),apply:()=>mk(),construct:()=>mk(),set:()=>true});
async function makeApp(withIdb){
 const els={};const el=id=>els[id]||(els[id]=new Proxy({value:"",checked:false,innerHTML:"",textContent:"",dataset:{},files:[],style:{},classList:{add(){},remove(){},toggle(){},contains(){return false}}},{get:(t,k)=>k in t?t[k]:mk(),set:(t,k,v)=>{t[k]=v;return true}}));
 const stores={kv:new Map(),snap:new Map(),img:new Map()};let imgGets=0;
 const req=fn=>{const r={};setTimeout(()=>{try{r.result=fn();r.onsuccess&&r.onsuccess({target:r})}catch(e){r.error=e;r.onerror&&r.onerror()}},0);return r};
 const fakeDB={objectStoreNames:{contains:n=>n in stores},createObjectStore(){},transaction(name){const st=stores[name];const tx={oncomplete:null,onerror:null,onabort:null,objectStore:()=>({
  put:(v,k)=>{const rec=structuredClone(v);setTimeout(()=>{st.set(k,rec);tx.oncomplete&&tx.oncomplete()},0);return{}},
  get:k=>{if(name==='img')imgGets++;return req(()=>st.has(k)?structuredClone(st.get(k)):undefined)},
  getAll:()=>req(()=>[...st.values()].map(v=>structuredClone(v))),getAllKeys:()=>req(()=>[...st.keys()]),
  delete:k=>{setTimeout(()=>{st.delete(k);tx.oncomplete&&tx.oncomplete()},0);return{}}})};return tx}};
 const ctx={document:mk(),indexedDB:withIdb?{open:()=>{const q={};setTimeout(()=>{q.onupgradeneeded&&q.onupgradeneeded({target:{result:fakeDB}});q.onsuccess&&q.onsuccess({target:{result:fakeDB}})},0);return q}}:undefined,
  localStorage:{getItem(){return null},setItem(){}},navigator:{},console,setTimeout:(f,ms)=>setTimeout(f,1),setInterval:()=>0,clearTimeout(){},addEventListener(){},location:{protocol:"file:"},AbortController,
  Chart:Object.assign(function(){this.destroy=()=>{};this.update=()=>{}},{defaults:{font:{},plugins:{},color:""}}),alert(){},prompt(){return""},confirm(){return true},fetch(){},Blob,File,structuredClone,TextEncoder,TextDecoder,URL:{createObjectURL:()=>"",revokeObjectURL(){}}};
 ctx.window=ctx;ctx.MutationObserver=function(){this.observe=()=>{}};vm.createContext(ctx);
 vm.runInContext(fs.readFileSync(path.join(__dirname,"../desktop/app/assets/libs/xlsx.full.min.js"),"utf8"),ctx);
 try{vm.runInContext(m[1],ctx)}catch(e){}
 ctx.document={getElementById:el,addEventListener(){},querySelectorAll:()=>[],querySelector:()=>null,createElement:()=>({click(){},style:{}}),body:{appendChild(){}}};
 const store={};ctx.localStorage={getItem:k=>store[k]||null,setItem:(k,v)=>{store[k]=v}};
 const R=c=>vm.runInContext(c,ctx);
 await new Promise(r=>setTimeout(r,250));/* پایان راه‌اندازی خودکار برنامه (init) */
 R(`DB=seedDB();${withIdb?'':'saveDB=async()=>{};snapshot=async()=>{};'}toast=m=>{globalThis.__last=m};nav=v=>{curView=v};closeM=()=>{};openM=()=>{};logAct=()=>{};localStorage.setItem('tk_seed_inst_v1','1');`);
 return{R,ctx,el,els,stores,imgGets:()=>imgGets,J:c=>JSON.parse(R("JSON.stringify("+c+")"))};
}
const wait=ms=>new Promise(r=>setTimeout(r,ms));
const ms=f=>{const s=process.hrtime.bigint();f();return Number(process.hrtime.bigint()-s)/1e6};
process.on("uncaughtException",()=>{});process.on("unhandledRejection",()=>{});

/* ---------- داده‌ی سنگین ---------- */
const N=3000;
let A;const ready=(async()=>{A=await makeApp(false);
A.R(`(()=>{
 let seed=12345;const rnd=a=>{seed=(seed*1103515245+12345)&0x7fffffff;return seed%a};
 const N=${N},g0=DB.personGroups[0].id;
 for(let k=0;k<200;k++)DB.products.push({id:'pr'+k,code:'P-'+(1001+k),name:'گوشی '+k,brand:'B',model:'M'+k,track:k%3?'serial':'qty',group:DB.productGroups[0].id,lastCost:5e6,sellPrice:6e6,minStock:1,colors:[]});
 for(let k=0;k<2500;k++){const p=DB.products[k%130];if(p.track==='serial')DB.serials.push({id:'sr'+k,pid:p.id,sn:'SN'+k,status:k%4?'stock':'sold',color:'',price:6e6,buyInv:'',saleInv:''})}
 for(let k=0;k<N;k++)DB.persons.push({id:'P'+k,code:2000+k,name:'شخص '+k+' تست',group:g0,groups:[g0],phone:'0912'+String(1000000+k),phone2:'',nationalId:String(1000000000+k),job:'',empNo:'',card:'',addr:'',photo:'',docs:[],guarantor:null,notes:'',created:'1405/0'+(1+rnd(9))+'/1'+rnd(9)});
 for(let k=0;k<N*2;k++){const p=DB.persons[rnd(N)],pr=DB.products[rnd(200)],ty=k%40===0?'buy':k%41===0?'saleret':'sale';
  DB.invoices.push({id:'V'+k,type:ty,no:1000+k,date:'1405/0'+(1+rnd(9))+'/'+(10+rnd(18)),person:p.id,lines:[{pid:pr.id,sid:'',sn:'',color:'',qty:1+rnd(2),price:6e6,cost:5e6}],pays:[{method:'cash',amount:2e6},{method:'installment',amount:4e6}],discount:0,desc:''});
  if(ty==='sale')for(let q=0;q<4;q++)DB.installments.push({id:'I'+k+'_'+q,planId:'pl'+k,inv:'V'+k,person:p.id,no:q+1,amount:1e6,due:'1405/'+String(1+((q+rnd(8))%12)).padStart(2,'0')+'/'+String(1+rnd(28)).padStart(2,'0'),paid:rnd(3)===0,paidDate:'',grp:'ig-normal'})}
 for(let k=0;k<N;k++){const p=DB.persons[rnd(N)];DB.cheques.push({id:'C'+k,no:String(100000+k),dir:k%6?'rec':'paid',person:p.id,amount:3e6,due:'1405/0'+(1+rnd(9))+'/'+(10+rnd(18)),status:k%7===0?'برگشتی':k%5?'جاری':'وصول شده',bank:'ملی'})}
 for(let k=0;k<N*2;k++){const p=DB.persons[rnd(N)];DB.receipts.push({id:'R'+k,no:1000+k,date:'1405/0'+(1+rnd(9))+'/'+(10+rnd(18)),person:p.id,dir:k%3?'in':'out',rows:[{method:'cash',amount:1e6}],desc:'',instId:''})}
 for(let k=0;k<N;k++)DB.accTx.push({id:'T'+k,acc:DB.accounts[0].id,date:'1405/05/05',type:k%3?'in':'out',amount:1e6,desc:'x',ref:'R'+k});
 DB.opening={persons:{P1:{rec:5000,pay:700}}};DB.expenses=[{id:'E1',method:'credit',person:'P3',amount:123456,date:'1405/01/01'}];
})()`);
})();

test("۱) نمایه‌های سریع با محاسبه‌ی مستقیم (روش قدیمی) دقیقاً یکی هستند",async()=>{await ready;
 // پیاده‌سازی مرجع = منطق نسخه‌های قبل (جست‌وجوی خطی)
 A.R(`
 globalThis.refPB=function(pid){let sale=0,salePaid=0,prof=0,buy=0,buyPaid=0;
  DB.invoices.filter(i=>i.person===pid).forEach(i=>{if(i.type==='sale'){sale+=invTotal(i);salePaid+=invPaid(i);prof+=invProfit(i)}else if(i.type==='saleret'){sale-=invTotal(i);salePaid-=invPaid(i)}else if(i.type==='buy'){buy+=invTotal(i);buyPaid+=invPaid(i)}else if(i.type==='buyret'){buy-=invTotal(i);buyPaid-=invPaid(i)}});
  DB.receipts.filter(r=>r.person===pid&&(r.dir==='in'||r.dir==='out')).forEach(r=>{const s=r.rows.reduce((a,x)=>a+pd(x.amount),0);if(r.dir==='in')salePaid+=s;else buyPaid+=s});
  DB.cheques.filter(c=>c.person===pid&&c.status==='برگشتی').forEach(c=>{if(c.dir==='rec')sale+=Number(c.amount||0);else buy+=Number(c.amount||0)});
  const po=((DB.opening||{}).persons||{})[pid]||{};(DB.expenses||[]).forEach(x=>{if(x.method==='credit'&&x.person===pid)buy+=x.amount});
  return{saleDebt:sale-salePaid+(po.rec||0),buyDebt:buy-buyPaid+(po.pay||0),profit:prof}};
 globalThis.refStock=function(pid){const p=DB.products.find(x=>x.id===pid);if(!p)return 0;let q=0;
  if(p.track==='serial'){q=DB.serials.filter(s=>s.pid===pid&&s.status==='stock').length;DB.invoices.forEach(inv=>inv.lines.forEach(l=>{if(l.pid!==pid||l.sid)return;const n=Number(l.qty||0);if(inv.type==='buy')q+=n;else if(inv.type==='buyret'||inv.type==='sale')q-=n;else if(inv.type==='saleret')q+=n}));return Math.max(0,q)}
  DB.invoices.forEach(inv=>{if(inv.type==='proforma')return;inv.lines.forEach(l=>{if(l.pid!==pid)return;if(inv.type==='buy'||inv.type==='saleret')q+=Number(l.qty||0);else q-=Number(l.qty||0)})});return q};
 globalThis.refAcc=a=>(a.open||0)+DB.accTx.filter(t=>t.acc===a.id).reduce((s,t)=>s+(t.type==='in'?1:-1)*t.amount,0);`);
 assert.equal(A.R(`DB.persons.every(p=>{const a=personBalance(p.id),b=refPB(p.id);return a.saleDebt===b.saleDebt&&a.buyDebt===b.buyDebt&&a.profit===b.profit})`),true,"مانده‌ی اشخاص");
 assert.equal(A.R(`DB.products.every(p=>stockOf(p.id)===refStock(p.id))`),true,"موجودی");
 assert.equal(A.R(`DB.accounts.every(a=>accBal(a)===refAcc(a))`),true,"مانده‌ی حساب");
 // بعد از تغییر درجا و ذخیره/ناوبری، نمایه معتبر می‌ماند
 A.R(`DB.invoices[10].lines[0].qty=9;DB.invoices.push(Object.assign({},DB.invoices[20],{id:'NEWV',type:'buy',person:'P7'}));DB.cheques[5].status='برگشتی';nav('x');ixInvalidate()`);
 assert.equal(A.R(`DB.persons.every(p=>{const a=personBalance(p.id),b=refPB(p.id);return a.saleDebt===b.saleDebt&&a.buyDebt===b.buyDebt})`),true);
 assert.equal(A.R(`DB.products.every(p=>stockOf(p.id)===refStock(p.id))`),true);
 // حذف با جایگزینی آرایه
 A.R(`DB.invoices=DB.invoices.filter((x,i)=>i%7!==0)`);
 assert.equal(A.R(`DB.products.every(p=>stockOf(p.id)===refStock(p.id))&&DB.persons.every(p=>personBalance(p.id).saleDebt===refPB(p.id).saleDebt)`),true,"پس از حذف فاکتورها");
});

test("۲) بودجه‌ی زمانی صفحه‌ها با ۳٬۰۰۰ شخص و ده‌ها هزار رکورد",async()=>{await ready;
 const lim={vPersons:1500,"vInst('list')":1500,"vInst('warn')":1500,"vInst('plans')":1500,"vInst('rep')":1500,vFinanceHub:1500,renderDash:1500,vProducts:1500,vProductList:1500,vInventory:1500,vSales:1500,vSettle:1500,vPurchase:1500};
 const out={};
 for(const [fn,limit] of Object.entries(lim)){const f=fn.includes('(')?fn:fn+'()';const t=ms(()=>A.R(`Fi.grp='';${f}`));out[fn]=Math.round(t);assert.ok(t<limit,fn+" کند است: "+t+"ms")}
 console.log("  زمان صفحه‌ها (ms):",JSON.stringify(out));
 let t=ms(()=>A.R("DB.persons.forEach(p=>personBalance(p.id))"));assert.ok(t<1500,"balances "+t);
 t=ms(()=>A.R("notifCount()"));assert.ok(t<600,"notifCount "+t);
 t=ms(()=>A.R("DB.products.forEach(p=>stockOf(p.id))"));assert.ok(t<400,"stock "+t);
 t=ms(()=>A.R("JSON.stringify(DB)"));assert.ok(t<1000,"stringify "+t);
});

test("۳) صفحه‌بندی: فقط یک صفحه ساخته می‌شود؛ ناوبری، تعداد ردیف، بازنشانی با تغییر فیلتر",async()=>{await ready;
 const rows=h=>(h.match(/<tr/g)||[]).length;
 A.R("Fi.grp='';Fi.q='';Fi.mode='';PGS.instlist=undefined;vInst('list')");
 let h=A.els.content.innerHTML;
 assert.ok(rows(h)<=105,"ردیف‌های صفحه‌ی اول: "+rows(h));assert.ok(h.includes('class="pager"'));
 const total=A.R("PGS.instlist.total"),pages=Math.ceil(total/100);assert.ok(total>5000&&pages>50);
 A.R("pgGo('instlist',3)");assert.equal(A.R("PGS.instlist.page"),3);assert.ok(rows(A.els.content.innerHTML)<=105);
 A.R("pgGo('instlist',999999)");assert.equal(A.R("PGS.instlist.page"),pages-1,"صفحه‌ی آخر");
 const last=rows(A.els.content.innerHTML);assert.ok(last>=2&&last<=105);
 A.R("pgPer('instlist','50')");assert.equal(A.R("PGS.instlist.page"),0);assert.ok(rows(A.els.content.innerHTML)<=55);
 // تغییر فیلتر ← بازگشت به صفحه‌ی اول
 A.R("pgGo('instlist',4);Fi.mode='open'");A.R("vInst('list')");assert.equal(A.R("PGS.instlist.page"),0,"فیلتر جدید صفحه را بازنشانی می‌کند");
 // کلیک «بعدی» که صفحه را عوض کند ولی فیلتر ثابت می‌ماند
 A.R("pgGo('instlist',2)");A.R("vInst('list')");assert.equal(A.R("PGS.instlist.page"),2,"رندر مجدد با همان فیلتر صفحه را حفظ می‌کند (مثلاً بعد از ثبت پرداخت)");
 A.R("Fi.mode='';Fi.q=''");
 // اشخاص
 A.R("resetPersonsFilters();PGS.persons=undefined;vPersons()");h=A.els.content.innerHTML;assert.ok(rows(h)<=105);assert.equal(A.R("PGS.persons.total"),N);
 // خروجی اکسل کامل می‌ماند (از کل لیست، نه فقط صفحه)
 A.R("Fi.mode='';Fi.q='';Fi.grp='';vInst('list')");assert.equal(A.R("window._instList.length"),A.R("PGS.instlist.total"),"خروجی اکسل کل لیست فیلترشده است، نه فقط صفحه");
 // لیست خالی/کم: نوار صفحه‌بندی دیده نمی‌شود
 A.R("Fi.q='zzzzzz-no-match';vInst('list')");assert.ok(!A.els.content.innerHTML.includes('class="pager"'));A.R("Fi.q=''");
});

test("۴) ورود اکسل حجیم سریع می‌ماند (قبلاً ۲۰ ثانیه برای ۵ هزار شخص)",async()=>{
 const B=await makeApp(false);
 const names=['علی','مریم','حسین'],NP=2500;
 const persons=[];for(let k=0;k<NP;k++)persons.push({"نام":names[k%3]+' '+k,"موبایل":'0912'+String(1000000+k),"کد ملی":String(1000000000+k)});
 const buf=rows=>Buffer.from(B.J(`(()=>{const wb=XLSX.utils.book_new();XLSX.utils.book_append_sheet(wb,XLSX.utils.json_to_sheet(${JSON.stringify(rows)}),'s');return Array.from(new Uint8Array(XLSX.write(wb,{type:'array',bookType:'xlsx'})))})()`));
 const feed=b=>{B.ctx.FileReader=function(){this.readAsArrayBuffer=function(){this.onload({target:{result:b}})}}};
 feed(buf(persons));let t=ms(()=>B.R(`xlIn({files:[{}],value:''},'persons','${B.R("pgFind('مشتریان عادی').id")}')`));
 assert.equal(B.R("DB.persons.length"),NP);assert.ok(t<4000,"ورود اشخاص "+t+"ms");
 feed(buf(persons));t=ms(()=>B.R(`xlIn({files:[{}],value:''},'persons','${B.R("pgFind('مشتریان عادی').id")}')`));assert.equal(B.R("DB.persons.length"),NP,"ورود تکراری شخص جدید نمی‌سازد");assert.ok(t<4000);
 const insts=[];for(let k=0;k<NP*3;k++)insts.push({"طرف حساب":persons[k%NP]["نام"],"مبلغ":"1,000,000","سررسید":"1405/0"+(1+k%9)+"/1"+(k%9)});
 feed(buf(insts));t=ms(()=>B.R(`xlIn({files:[{}],value:''},'installments','ig-normal')`));
 assert.equal(B.R("DB.installments.length"),NP*3);assert.equal(B.R("DB.persons.length"),NP);assert.ok(t<6000,"ورود اقساط "+t+"ms");
 console.log("  ورود اکسل: اشخاص و اقساط — ثبت شد، زمان آخر:",Math.round(t),"ms");
});

/* ---------- تصاویر مدارک (تنبل) ---------- */
const fakeImg=n=>"data:image/jpeg;base64,"+Buffer.alloc(80000+n,n%250).toString("base64");
test("۵) تصاویر: بعد از ذخیره از حافظه بیرون می‌روند و فقط هنگام نیاز خوانده می‌شوند",async()=>{
 const C=await makeApp(true);
 C.R(`toast=()=>{};nav=v=>{curView=v};DB.persons=[];const g=DB.personGroups[0];for(let k=0;k<12;k++)DB.persons.push({id:'P'+k,code:2000+k,name:'شخص '+k,group:g.id,groups:[g.id],phone:'',photo:'',docs:[],guarantor:{name:'ض',photo:'',docs:[]}})`);
 const imgs=[];
 for(let k=0;k<12;k++){const a=fakeImg(k*4),b=fakeImg(k*4+1),c=fakeImg(k*4+2),d=fakeImg(k*4+3);imgs.push(a,b,c,d);C.ctx.__p=[a,b,c,d];
  C.R(`(()=>{const p=DB.persons[${k}];p.photo=__p[0];p.docs=[{id:'d1',type:'کارت ملی',name:'meli.jpg',data:__p[1]},{id:'d2',type:'قرارداد',name:'c.jpg',data:__p[2]}];p.guarantor.docs=[{id:'d3',type:'کارت ملی',name:'g.jpg',data:__p[3]}]})()`)}
 const before=C.R("JSON.stringify(DB).length");assert.ok(before>3e6);
 assert.equal(await C.R("saveDB(true)"),true);
 assert.ok(C.R("JSON.stringify(DB).length")<60000,"دیتابیس درون‌حافظه فقط ارجاع دارد");
 assert.equal(C.stores.img.size,48);assert.equal(typeof C.stores.kv.get("db"),"string","دیتابیس به‌صورت رشته ذخیره می‌شود");
 assert.equal(C.R("isImgRef(DB.persons[3].photo)&&isImgRef(DB.persons[3].docs[1].data)&&isImgRef(DB.persons[3].guarantor.docs[0].data)"),true);
 C.R("IMGC.clear()");const g0=C.imgGets();
 assert.equal(await C.R("imgLoad(DB.persons[5].docs[0].data)"),imgs[5*4+1],"تصویر دقیقاً همان است");assert.equal(C.imgGets()-g0,1,"فقط یک تصویر خوانده شد");
 await C.R("imgLoad(DB.persons[5].docs[0].data)");assert.equal(C.imgGets()-g0,1,"بار دوم از کش");
 // لیست اشخاص: ریزتصویر/ارجاع، نه تصویر کامل
 C.R("resetPersonsFilters();vPersons()");const h=C.els.content.innerHTML;assert.ok((h.match(/data-ref="img:/g)||[]).length>=12);assert.ok(!h.includes(imgs[0].slice(0,200)));
 // شروع برنامه تصویری نمی‌خواند
 const g1=C.imgGets();await C.R("hydrateImgs(DB)");assert.equal(C.imgGets(),g1,"هنگام شروع هیچ تصویری خوانده نمی‌شود");
 // ذخیره‌ی دوباره (بدون تغییر) سریع و بدون خواندن تصویر
 const t=await (async()=>{const s=Date.now();await C.R("saveDB(true)");return Date.now()-s})();assert.ok(t<500);assert.equal(C.imgGets(),g1);
 // شخص جدید با تصویر: بعد از ذخیره ارجاع می‌شود، و حذف‌شدگی تصویر بی‌مصرف
 C.ctx.__n=fakeImg(999);C.R("DB.persons[0].docs.push({id:'dn',type:'سایر',name:'n.jpg',data:__n})");await C.R("saveDB(true)");assert.equal(C.stores.img.size,49);
 // پاک‌سازی تصویر بی‌مصرف: حذف مدرک ← در GC بعدی تصویر از store پاک می‌شود (اسنپ‌شات‌ها آن را نگه نمی‌دارند)
 C.R("DB.persons[0].docs.pop()");await C.R("saveDB(true)");C.stores.snap.clear();C.stores.kv.delete("snapidx");await C.R("hydrateImgs(DB)");await wait(50);
 assert.equal(C.stores.img.size,48,"تصویر بی‌مصرف پاک شد، بقیه ماندند");
 // بکاپ کامل و بازیابی روی نصب خالی
 const r=await C.R("backupFullBlob()");assert.equal(r.count,48);assert.equal(r.miss,0);
 C.stores.img.clear();C.ctx.__f=new File([r.blob],"x.tkb");
 const rd=await C.R("tkbRead(__f)");assert.equal(rd.images,48);assert.equal(rd.db.persons.length,12);assert.equal(C.stores.img.size,48);
 C.ctx.__d=rd.db;C.R("DB=__d;ixInvalidate();IMGC.clear()");assert.equal(await C.R("imgLoad(DB.persons[7].docs[0].data)"),imgs[7*4+1],"تصویر پس از بازیابی یکسان است");
 assert.equal(await C.R("imgLoad(DB.persons[7].guarantor.docs[0].data)"),imgs[7*4+3]);
 // فایل خراب
 C.ctx.__bad=new File(["not a backup"],"bad.tkb");let failed=false;try{await C.R("tkbRead(__bad)")}catch(e){failed=true}assert.equal(failed,true);
});

test("۶) اسنپ‌شات‌ها: فهرست سبک، ذخیره‌ی رشته‌ای، سقف تعداد و بازیابی",async()=>{
 const C=await makeApp(true);C.R("toast=()=>{};nav=v=>{curView=v}");
 for(let k=0;k<16;k++){C.R(`DB.persons.push({id:'S${k}',code:${k},name:'x${k}',group:DB.personGroups[0].id,groups:[]})`);await C.R(`snapshot('خودکار ${k}',true,true)`)}
 const idx=await C.R("snapIndex()");assert.ok(idx.filter(r=>C.R("isAutoSnap("+JSON.stringify(r)+")")).length<=12,"سقف اسنپ‌شات خودکار: "+idx.length);
 assert.equal(C.stores.snap.size,idx.length);
 const rec=[...C.stores.snap.values()].pop();assert.equal(typeof rec.js,"string");assert.equal(rec.data,undefined);
 // بازیابی از اسنپ‌شات قدیمی با data شیء (نسخه‌های قبل) هم کار می‌کند
 C.stores.snap.set("sOLD",{t:1,label:"قدیمی",auto:false,data:{persons:[{id:"o"}],products:[]}});C.stores.kv.delete("snapidx");
 const idx2=await C.R("snapIndex()");assert.ok(idx2.some(x=>x.label==="قدیمی"),"بازسازی فهرست از رکوردهای قدیمی");
 assert.equal(C.R(`snapData({data:{persons:[1]}}).persons.length`),1);
 // ذخیره‌ی اصلی: خواندن رشته و رکورد قدیمی (شیء) هر دو
 await C.R("saveDB(true)");assert.equal(typeof C.stores.kv.get("db"),"string");
});

test("۷) وصول گروهی ۲٬۰۰۰ قسط یک‌جا سریع و درست انجام می‌شود",async()=>{
 await ready;
 A.R("snapshot=async()=>{};DB.settings.thanksOn=false;INSTSEL.clear();Fi.grp='';Fi.mode='';Fi.q='';vInst('list')");
 const open=A.R("DB.installments.filter(i=>!i.paid).length");assert.ok(open>3000);
 A.R("window._instList=DB.installments.filter(i=>!i.paid).slice(0,2000);instSelAll()");
 const info=A.J("instSelInfo()");assert.equal(info.n,2000);
 A.el("bkDate").value="1405/07/25";A.el("bkM").value="account";A.el("bkAcc").value=A.R("DB.accounts[0].id");A.el("bkThanks").checked=false;
 const r0=A.R("DB.receipts.length"),tx0=A.R("DB.accTx.length");
 const t0=Date.now();await A.R("instBulkRun()");const dt=Date.now()-t0;
 assert.equal(A.R("DB.receipts.length"),r0+2000);assert.equal(A.R("DB.accTx.length"),tx0+2000);assert.equal(A.R("DB.installments.filter(i=>!i.paid).length"),open-2000);
 assert.ok(dt<3000,"وصول گروهی "+dt+"ms");console.log("  وصول گروهی ۲۰۰۰ قسط:",dt,"ms");
});

test("۸) لوگوی فروشگاه: بعد از ذخیره ارجاع می‌شود و هنگام چاپ از store خوانده می‌شود",async()=>{
 const C=await makeApp(true);C.R("toast=()=>{};nav=v=>{curView=v}");
 const logo="data:image/png;base64,"+Buffer.alloc(20000,7).toString("base64");
 C.ctx.__logo=logo;C.R("DB.settings.shopLogo=__logo");
 assert.equal(await C.R("saveDB(true)"),true);
 assert.ok(C.R("isImgRef(DB.settings.shopLogo)"),"لوگو به ارجاع تبدیل شد");assert.ok(C.R("JSON.stringify(DB).length")<80000,"دیتابیس سبک می‌ماند");
 assert.equal(await C.R("shopLogoData()"),logo,"هنگام چاپ لوگوی اصلی خوانده می‌شود");
 // فاکتور چاپی لوگو را دارد
 C.R("DB.persons.push({id:'q',code:1,name:'x',group:DB.personGroups[0].id,groups:[]});DB.invoices.push({id:'i1',type:'sale',no:1,date:'1405/07/25',person:'q',discount:0,lines:[],pays:[]})");
 const r=await C.R("invoiceDoc('i1','A4')");assert.ok(r.doc.includes('<img class="logo" src="data:image/png;base64,'));
 // حذف لوگو
 C.R("shopLogoRemove()");assert.equal(C.R("DB.settings.shopLogo"),"");
 const r2=await C.R("invoiceDoc('i1','A4')");assert.ok(!r2.doc.includes('<img class="logo"')&&r2.doc.includes('class="logo ph"'));
});
